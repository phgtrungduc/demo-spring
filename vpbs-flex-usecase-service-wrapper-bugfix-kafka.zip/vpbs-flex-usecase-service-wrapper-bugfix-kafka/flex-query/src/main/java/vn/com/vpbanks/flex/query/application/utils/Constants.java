package vn.com.vpbanks.flex.query.application.utils;

public interface Constants {

    public static final String YES_OPTION = "Y";
    public static final String NO_OPTION = "N";

    interface PARAM_URL {
        String ACCOUNT_ID = "{accountId}";
        String ORDER_ID = "{orderId}";
    }

    interface QUERY_PARAM {
        String REQUEST_ID = "requestId";
    }

    interface TRACKING_ACTION {
        String CREATE = "CREATE";
        String UPDATE = "UPDATE";
        String DELETE = "DELETE";
        String CANCEL = "CANCEL";
    }

    interface TRACKING_RESULT {
        String SUCCESS = "SUCCESS";
        String FAIL = "FAIL";
    }

    interface AQ_QUEUE_NAME {
        String CF = "CF";//account
        String AF = "AF";//af account
        String CI = "CI";//cash
        String OD = "OD";//order
    }

    interface SQL {
        String WITH = " WITH ";
        String COMMA = " , ";
        String ACCOUNT_NO = "accountNo";
    }
}
