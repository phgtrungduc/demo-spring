package vn.com.vpbanks.flex.query.application.utils;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@UtilityClass
public class DateTimeUtils {


    public static LocalDate convertStringToLocalDate(String date) {
        if (Objects.isNull(date)) {
            return null;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");

        return LocalDate.parse(date, formatter);
    }

    public static LocalDate convertStringToLocalDate(String date, String format) {
        if (Objects.isNull(date)) {
            return null;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);

        return LocalDate.parse(date, formatter);
    }

    public static LocalDateTime convertStringToLocalDateTime(String date, String format) {
        if (Objects.isNull(date)) {
            return null;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);

        return LocalDateTime.parse(date, formatter);
    }

    public static Date convertStringToDate(String date, String format) {
        if (Objects.isNull(date)) {
            return null;
        }
        try {
            Date convertDate = new SimpleDateFormat(format).parse(date);
            return convertDate;
        } catch (ParseException e) {
            return null;
        }
    }

    public static Date convertLocalDateToDate(LocalDate localDate) {
        return Date.from(localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
    }

    public static Date convertLocalDateTimeToDate(LocalDateTime localDateTime) {
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

    public static LocalDate convertDateToLocalDate(Date date) {
        return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDate();
    }

    public static LocalDateTime convertDateToLocalDateTime(Date date) {
        return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDateTime();
    }

    public static OffsetDateTime getCurrentUtcTime() {
        // declare and initialize an OffsetDateTime variable which we return to the main method
        OffsetDateTime offsetDateTime;
        // initialize offsetDateTime by using now() method of OffsetDateTime
        offsetDateTime = OffsetDateTime.now(ZoneOffset.UTC);
        // pass UTC date to the main method.
        return offsetDateTime;
    }

    public static String getCurrentDateTime(String format) {
        // declare and initialize an OffsetDateTime variable which we return to the main method
        Instant now = Instant.now();

        // convert Instant to ZonedDateTime
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(format).withZone(ZoneId.of("UTC"));

        String formattedDate = dtf.format(now);

        return formattedDate;
    }

    public static String getCurrentDate(String format) {
        // declare and initialize an OffsetDateTime variable which we return to the main method
        Date date = new Date();

        // convert Instant to ZonedDateTime
//        DateFormat dtf = DateTimeFormatter.ofPattern(format).withZone(ZoneId.of("UTC"));
        DateFormat dateFormat = new SimpleDateFormat(format);

        String formattedDate = dateFormat.format(date);

        return formattedDate;
    }

    public static ConcurrentHashMap<String, SimpleDateFormat> dfmList = new ConcurrentHashMap<>();

    public static String getStringCurrentDate(Date date, String format) {
        if (date == null) {
            return StringUtils.EMPTY;
        }
        SimpleDateFormat dfm = dfmList.get(format);
        if (dfm == null) {
            dfm = new SimpleDateFormat(format);
            dfmList.put(format, dfm);
        }
        return dfm.format(date);
    }

    public static String getStringCurrentDate(Instant date, String format) {
        String result;
        if (date == null) {
            return StringUtils.EMPTY;
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format)
                .withZone(ZoneId.systemDefault());

        result = formatter.format(date);
        return result;
    }
}
