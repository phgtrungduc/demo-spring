package vn.com.vpbanks.flex.query.application.utils.enums;

public enum Day {
    IN,
    OUT;
}
