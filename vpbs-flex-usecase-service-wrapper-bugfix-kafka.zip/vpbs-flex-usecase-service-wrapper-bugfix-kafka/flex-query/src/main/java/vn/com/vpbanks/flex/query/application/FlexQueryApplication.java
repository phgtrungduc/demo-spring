package vn.com.vpbanks.flex.query.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan("vn.com.vpbanks")
@EntityScan("vn.com.vpbanks")
@EnableJpaRepositories("vn.com.vpbanks")
public class FlexQueryApplication {

    public static void main(String[] args) {
        SpringApplication.run(FlexQueryApplication.class, args);
    }

}
