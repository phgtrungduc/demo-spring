package vn.com.vpbanks.flex.query.application.service;

import vn.com.vpbanks.flex.query.application.request.CustomerDirectIndirectIn;
import vn.com.vpbanks.flex.query.application.request.CustomerOfBrokerRequest;
import vn.com.vpbanks.flex.query.application.response.BaseResponse;

import java.util.List;

public interface CustomerService {
    BaseResponse getCustomersDirectIndirect(CustomerDirectIndirectIn customerDirectIndirectIn);

    BaseResponse getOrderCustomerDirectIndirect(CustomerDirectIndirectIn customerDirectIndirectIn);

    BaseResponse getCustomerDirectIndirectDetail(String agencyNo, String preBrokerNo, String accountNo);

    BaseResponse getCustomersByBroker(CustomerOfBrokerRequest request);

    BaseResponse getUnderBroker(String custodycd, String searchkey, String dept, String underCustodycd, String getCurren);

    BaseResponse getDepartment(String custId, String code, String name);

    BaseResponse getCurrentDepartment(List<String> listReCustodycd, String reFullName, Integer page, Integer size);
}
