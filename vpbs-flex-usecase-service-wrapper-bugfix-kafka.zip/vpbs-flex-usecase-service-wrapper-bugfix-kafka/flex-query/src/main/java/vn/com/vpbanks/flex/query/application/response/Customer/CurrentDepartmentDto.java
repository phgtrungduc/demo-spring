package vn.com.vpbanks.flex.query.application.response.Customer;

import lombok.Data;

@Data
public class CurrentDepartmentDto {
    private String custId;
    private String deptCode;
    private String deptName;
    private String fullName;
    private String custodycd;
}
