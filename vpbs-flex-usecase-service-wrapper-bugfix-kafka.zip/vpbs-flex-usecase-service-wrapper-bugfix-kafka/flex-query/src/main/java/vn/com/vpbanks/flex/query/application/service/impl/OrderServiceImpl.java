package vn.com.vpbanks.flex.query.application.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import vn.com.vpbanks.flex.query.application.repository.OrderRepository;
import vn.com.vpbanks.flex.query.application.request.StockOrderFilter;
import vn.com.vpbanks.flex.query.application.response.BaseResponse;
import vn.com.vpbanks.flex.query.application.service.OrderService;
import vn.com.vpbanks.flex.query.application.utils.CommonUtils;

@Service
@Slf4j
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {
    private final OrderRepository orderRepository;

    @Override
    public BaseResponse orderBooks(StockOrderFilter stockOrderFilter) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        baseResponse.setData(orderRepository.orderBooks(stockOrderFilter));
        return baseResponse;
    }

    @Override
    public BaseResponse orderBook(String orderId, String custodyCd) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        baseResponse.setData(orderRepository.orderBook(orderId, custodyCd));
        return baseResponse;
    }

    @Override
    public BaseResponse orderBookMobiles(StockOrderFilter stockOrderFilter) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        baseResponse.setData(orderRepository.orderBookMobiles(stockOrderFilter));
        return baseResponse;
    }

    @Override
    public BaseResponse histOrderBookMobiles(StockOrderFilter stockOrderFilter) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        baseResponse.setData(orderRepository.histOrderBookMobiles(stockOrderFilter));
        return baseResponse;
    }

    @Override
    public BaseResponse allOrderBookMobiles(StockOrderFilter stockOrderFilter) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        baseResponse.setData(orderRepository.allOrderBookMobiles(stockOrderFilter));
        return baseResponse;
    }
    @Override
    public BaseResponse confirmOrderBookMobiles(StockOrderFilter stockOrderFilter) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        baseResponse.setData(orderRepository.confirmOrderBookMobiles(stockOrderFilter));
        return baseResponse;
    }

    @Override
    public BaseResponse confirmHistOrderBookMobiles(StockOrderFilter stockOrderFilter) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        baseResponse.setData(orderRepository.confirmHistOrderBookMobiles(stockOrderFilter));
        return baseResponse;
    }

    @Override
    public BaseResponse confirmAllOrderBookMobiles(StockOrderFilter stockOrderFilter) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        baseResponse.setData(orderRepository.confirmAllOrderBookMobiles(stockOrderFilter));
        return baseResponse;
    }

}
