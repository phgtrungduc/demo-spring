package vn.com.vpbanks.flex.query.application.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import vn.com.vpbanks.flex.query.application.request.StockOrderFilter;
import vn.com.vpbanks.flex.query.application.response.BaseResponse;
import vn.com.vpbanks.flex.query.application.service.OrderService;
import vn.com.vpbanks.flex.query.application.utils.BaseUrl;

@Slf4j
@RestController
@RequestMapping(BaseUrl.FLEX_USECASE_SERVICE.V2 + "/")
@RequiredArgsConstructor
public class V2OrderController {

    private final OrderService orderService;

    @PostMapping("/orderBook-mobile")
    public BaseResponse orderBookMobiles(@RequestBody StockOrderFilter stockOrderFilter) {
        return orderService.orderBookMobiles(stockOrderFilter);
    }

    @PostMapping("/histOrderBook-mobile")
    public BaseResponse histOrderBookMobiles(@RequestBody StockOrderFilter stockOrderFilter) {
        return orderService.histOrderBookMobiles(stockOrderFilter);
    }

    @PostMapping("/allOrderBook-mobile")
    public BaseResponse allOrderBookMobiles(@RequestBody StockOrderFilter stockOrderFilter) {
        return orderService.allOrderBookMobiles(stockOrderFilter);
    }

    @PostMapping("/confirm/OrderBook-mobile")
    public BaseResponse confirmOrderBookMobiles(@RequestBody StockOrderFilter stockOrderFilter) {
        return orderService.confirmOrderBookMobiles(stockOrderFilter);
    }
    @PostMapping("/confirm/histOrderBook-mobile")
    public BaseResponse confirmHistOrderBookMobiles(@RequestBody StockOrderFilter stockOrderFilter) {
        return orderService.confirmHistOrderBookMobiles(stockOrderFilter);
    }
    @PostMapping("/confirm/allOrderBook-mobile")
    public BaseResponse confirmAllOrderBookMobiles(@RequestBody StockOrderFilter stockOrderFilter) {
        return orderService.confirmAllOrderBookMobiles(stockOrderFilter);
    }
}
