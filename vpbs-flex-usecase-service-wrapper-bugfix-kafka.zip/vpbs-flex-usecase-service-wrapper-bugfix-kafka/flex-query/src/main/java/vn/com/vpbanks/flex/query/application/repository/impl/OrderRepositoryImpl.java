package vn.com.vpbanks.flex.query.application.repository.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import vn.com.vpbanks.flex.query.application.repository.OrderRepository;
import vn.com.vpbanks.flex.query.application.request.CustomerDirectIndirectIn;
import vn.com.vpbanks.flex.query.application.request.StockOrderFilter;
import vn.com.vpbanks.flex.query.application.response.StockFilterResponseDTO;
import vn.com.vpbanks.flex.query.application.response.StockOrderDetailResponse;
import vn.com.vpbanks.flex.query.application.utils.DataUtils;
import vn.com.vpbanks.flex.query.application.utils.enums.ChannelFlex;
import vn.com.vpbanks.flex.query.application.utils.enums.ConfirmStatus;
import vn.com.vpbanks.flex.query.application.utils.enums.Day;
import vn.com.vpbanks.flex.query.application.utils.enums.Order;
import vn.com.vpbanks.flex.query.application.utils.enums.OrderCode;
import vn.com.vpbanks.flex.query.application.utils.enums.StockOrderStatus;
import vn.com.vpbanks.flex.query.application.utils.enums.SubAccount;
import vn.com.vpbanks.flex.query.application.utils.enums.Timeline;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import java.sql.Time;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Component
@RequiredArgsConstructor
@Slf4j
public class OrderRepositoryImpl implements OrderRepository {
    private final EntityManager entityManager;
    private final CustomersRepositoryImpl customersRepository;

    @Value("${spring.datasource.hikari.schema}")
    private String schema;

    @Value("${vpbanks.flex.sp.SP_ORDER_BOOK_MOBILE}")
    private String SP_ORDER_BOOK_MOBILE;

    @Value("${vpbanks.flex.sp.SP_HIST_ORDER_BOOK_MOBILE}")
    private String SP_HIST_ORDER_BOOK_MOBILE;

    @Value("${vpbanks.flex.sp.SP_ALL_ORDER_BOOK_MOBILE}")
    private String SP_ALL_ORDER_BOOK_MOBILE;

    @Value("${vpbanks.flex.sp.SP_CONFIRM_ORDER_BOOK_MOBILE}")
    private String SP_CONFIRM_ORDER_BOOK_MOBILE;

    @Value("${vpbanks.flex.sp.SP_CONFIRM_HIST_ORDER_BOOK_MOBILE}")
    private String SP_CONFIRM_HIST_ORDER_BOOK_MOBILE;

    @Value("${vpbanks.flex.sp.SP_CONFIRM_ALL_ORDER_BOOK_MOBILE}")
    private String SP_CONFIRM_ALL_ORDER_BOOK_MOBILE;

    @Value("${vpbanks.flex.sp.SP_ONE_MONTH_ORDER_BOOK_MOBILE}")
    private String SP_ONE_MONTH_ORDER_BOOK_MOBILE;

    @Value("${vpbanks.flex.sp.SP_TWO_MONTH_ORDER_BOOK_MOBILE}")
    private String SP_TWO_MONTH_ORDER_BOOK_MOBILE;

    @Value("${vpbanks.flex.sp.SP_THREE_MONTH_ORDER_BOOK_MOBILE}")
    private String SP_THREE_MONTH_ORDER_BOOK_MOBILE;

    @Value("${vpbanks.flex.sp.SP_CONFIRM_ONE_MONTH_ORDER_BOOK_MOBILE}")
    private String SP_CONFIRM_ONE_MONTH_ORDER_BOOK_MOBILE;

    @Value("${vpbanks.flex.sp.SP_CONFIRM_TWO_MONTH_ORDER_BOOK_MOBILE}")
    private String SP_CONFIRM_TWO_MONTH_ORDER_BOOK_MOBILE;

    @Value("${vpbanks.flex.sp.SP_CONFIRM_THREE_MONTH_ORDER_BOOK_MOBILE}")
    private String SP_CONFIRM_THREE_MONTH_ORDER_BOOK_MOBILE;



    private void sqlOrderBookMobile(StringBuilder sql) {
        sql.append(" " +
                "   ,so_lenh as ( SELECT voa.ORDERID\n" +
                "                     AS ORDERID,\n" +
                "       voa.REFORDERID\n" +
                "                     AS REFORDERID,\n" +
                "       UPPER(a1.EN_CDCONTENT)\n" +
                "                     AS side,                 -- BUY/SELL loại lệnh (điều kiện tìm kiếm)\n" +
                "       (CASE\n" +
                "            WHEN voa.REMAINQTTY <> 0 AND voa1.EDSTATUS = 'C'\n" +
                "                THEN\n" +
                "                'C'\n" +
                "            WHEN voa.REMAINQTTY <> 0 AND voa1.EDSTATUS = 'A'\n" +
                "                THEN\n" +
                "                'A'\n" +
                "            WHEN voa1.EDSTATUS IS NULL AND voa.CANCELQTTY <> 0\n" +
                "                THEN\n" +
                "                '6'\n" +
                "            WHEN voa.REMAINQTTY = 0\n" +
                "                AND voa.CANCELQTTY <> 0\n" +
                "                AND voa1.EDSTATUS = 'C'\n" +
                "                THEN\n" +
                "                '3'\n" +
                "            WHEN voa.REMAINQTTY = 0\n" +
                "                AND voa.ADJUSTQTTY > 0\n" +
                "                AND voa.pricetype = 'MP'\n" +
                "                THEN\n" +
                "                '4'\n" +
                "            WHEN voa.REMAINQTTY = 0 AND voa.ADJUSTQTTY > 0\n" +
                "                THEN\n" +
                "                '10'\n" +
                "            WHEN voa.REMAINQTTY = 0\n" +
                "                AND voa.EXECQTTY > 0\n" +
                "                AND voa.ORSTATUS = '4'\n" +
                "                THEN\n" +
                "                '12'\n" +
                "            ELSE\n" +
                "                voa.ORSTATUS\n" +
                "           END)\n" +
                "                     AS status,               -- status flex\n" +
                "       boa.ORSTATUSVALUE\n" +
                "                     AS statusValue,\n" +
                "       voa.quoteprice\n" +
                "                     AS price,                --giá\n" +
                "       sb.SYMBOL\n" +
                "                     AS symbol,               --mã cổ phiếu (điều kiện tìm kiếm)\n" +
                "       boa.EXECQTTY\n" +
                "                     AS matchVolumeInDay,     --Khối lượng khớp lệnh trong ngay\n" +
                "       voa.EXECQTTY\n" +
                "                     AS matchVolumeDay,       --Khối lượng khớp lệnh lịch sử\n" +
                "       voa.orderqtty\n" +
                "                     AS Volume,               -- khối lượng đặt\n" +
                "       cf.CUSTODYCD  AS CFCUSTODYCD,          --So tai khoan khách hàng (điều kiện tìm kiếm)\n" +
                "       cf.subCusName   AS FULLNAME,             --So tai khoan khách hàng\n" +
                "       substr(UPPER(accountType.EN_CDCONTENT), 2, length(accountType.EN_CDCONTENT)) \n" +
                "                     AS acctype_EN_CDCONTENT, -- tiểu khoản, thương/ ký quỹ (điều kiện tìm kiếm)\n" +
                "       TO_CHAR(voa.TXDATE, 'dd/mm/yyyy')    AS TXDATE,               --ngày bắt đầu (điều kiện tìm kiếm)\n" +
                "       voa.TXTIME    AS TXTIME,               --ngày bắt đầu (điều kiện tìm kiếm)\n" +
                "       TO_CHAR(voa.EXPDATE, 'dd/mm/yyyy')   AS EXPDATE,              -- ngày kết thúc\n" +
                "       voa.LAST_CHANGE,                       -- thời gian hủy, sửa, đặt\n" +
                "       voa.AFACCTNO\n" +
                "                     AS accountId,            --accountId số tiểu khản khách hàng (điều kiện tìm kiếm)\n" +
                "       CASE boa.ISDISPOSAL WHEN 'Y' THEN 'N' ELSE boa.ISCANCEL END\n" +
                "                     AS allowCancel,\n" +
                "       CASE boa.ISDISPOSAL WHEN 'Y' THEN 'N' ELSE boa.ISADMEND END\n" +
                "                     AS allowAmend,\n" +
                "       voa.pricetype AS PRICETYPE,            --Loai lênh (điều kiện tìm kiếm),\n" +
                "       cf.MOBILESMS,\n" +
                " CONCAT(TO_CHAR(voa.txdate, 'dd/mm/yyyy '), voa.txtime) createDate, " +
                " ROUND(case when voa.EXECQTTY > 0 then voa.EXECAMT/voa.EXECQTTY else 0 end,4) execprice, " +
                "       cf.custid cfCustId, \n" +
                "       cf.dept dept,                       \n" +
                "       cf.reCustodyCd reCustodyCd,                       \n" +
                "       cf.reFullName reFullName                       \n" +
                "FROM customerInfo cf \n" +
                "         LEFT JOIN " + schema + ".AFMAST af ON cf.CUSTID = af.CUSTID\n" +
                "         LEFT JOIN " + schema + ".vw_odmast_all voa ON af.ACCTNO = voa.AFACCTNO\n" +
                "         LEFT JOIN " + schema + ".vw_odmast_all voa1\n" +
                "                   ON voa.ORDERID = voa1.REFORDERID\n" +
                "                       AND voa1.EDSTATUS IN ('C', 'A')\n" +
                "                       AND voa1.EXECTYPE NOT IN ('NB', 'NS')\n" +
                "                       AND voa1.ORSTATUS NOT IN ('0', '5', '6')\n" +
                "         LEFT JOIN " + schema + ".buf_od_account boa ON voa.ORDERID = boa.ORDERID\n" +
                "         LEFT JOIN " + schema + ".allcode accountType\n" +
                "                   ON accountType.cdname = 'PRODUCTTYPE'\n" +
                "                       AND accountType.CDTYPE = 'CF'\n" +
                "                       AND accountType.cdval = af.producttype\n" +
                "         LEFT JOIN " + schema + ".SBSECURITIES sb ON voa.CODEID = sb.CODEID\n" +
                "         LEFT JOIN " + schema + ".allcode a1\n" +
                "                   ON a1.cdname = 'EXECTYPE'\n" +
                "                       AND a1.cdtype = 'FO'\n" +
                "                       AND a1.cdval = voa.exectype\n" +
                "         LEFT JOIN " + schema + ".TLPROFILES TLP ON voa.TLID = TLP.TLID\n" +
                "         LEFT JOIN " + schema + ".allcode a2\n" +
                "                   ON a2.cdname = 'VIA'\n" +
                "                       AND a2.cdtype = 'OD'\n" +
                "                       AND a2.cdcontent = voa.via\n" +
                "         LEFT JOIN " + schema + ".CONFIRMODRSTS FIRM\n" +
                "                   ON voa.ORDERID = FIRM.ORDERID\n" +
                "         LEFT JOIN " + schema + ".ALLCODE A4\n" +
                "                   ON A4.CDTYPE = 'SY'\n" +
                "                       AND A4.CDNAME = 'YESNO'\n" +
                "                       AND A4.CDVAL =\n" +
                "                           (CASE\n" +
                "                                WHEN voa.TLID = '6868' THEN 'Y'\n" +
                "                                ELSE NVL(FIRM.CONFIRMED, 'N')\n" +
                "                               END)\n" +
                "WHERE 1 = 1\n" +
                "  AND SUBSTR(voa.EXECTYPE, 1, 1) <> 'C'\n" +
                "  AND SUBSTR(voa.EXECTYPE, 1, 1) <> 'A'\n" +
                "  AND (voa.execqtty <> 0 OR voa.edstatus NOT IN ('C', 'A')) " +
                "AND EXISTS  (SELECT  1 from customerInfo customer WHERE customer.CUSTODYCD =  cf.CUSTODYCD) \n" +
                "AND voa.TXDATE >= TRUNC(SYSDATE - 29)\n");
    }


    private void sqlNative(StringBuilder sql) {
        sql.append(" SELECT sl.*, 0 total\n" +
                "FROM so_lenh sl WHERE 1 = 1  \n");
    }

    private void sqlOrderDetail(StringBuilder sql) {
        sql.append(" " +
                " SELECT voa.ORDERID AS ORDERID, \n" +
                "       CASE UPPER(a1.EN_CDCONTENT)  WHEN 'BUY' THEN 'BUY \n" +
                "                      WHEN 'SELL' THEN 'SELL' \n" +
                "                      WHEN 'SELLING EDIT' THEN 'SELL' \n" +
                "                      WHEN 'CANCEL BUYING' THEN 'BUY' \n" +
                "                      WHEN 'BUYING EDIT' THEN 'BUY' \n" +
                "                      WHEN 'CANCEL SELLING' THEN 'SELL' \n" +
                "                      END AS side, -- BUY/SELL loại lệnh \n" +

                "       CASE\n" +
                "           WHEN boa.ORSTATUSVALUE = '5' AND boa.ORSTATUSVALUE <> (CASE\n" +
                "                                                                      WHEN voa.REMAINQTTY <> 0 AND voa1.EDSTATUS = 'C' THEN  'C'\n" +
                "                                                                      WHEN voa.REMAINQTTY <> 0 AND voa1.EDSTATUS = 'A' THEN  'A'\n" +
                "                                                                      WHEN voa1.EDSTATUS IS NULL AND voa.CANCELQTTY <> 0  THEN  '6'\n" +
                "                                                                      WHEN voa.REMAINQTTY = 0  AND voa.CANCELQTTY <> 0 AND voa1.EDSTATUS = 'C' THEN '3'\n" +
                "                                                                      WHEN voa.REMAINQTTY = 0 AND voa.ADJUSTQTTY > 0 AND voa.pricetype = 'MP' THEN '4'\n" +
                "                                                                      WHEN voa.REMAINQTTY = 0 AND voa.ADJUSTQTTY > 0 THEN '10'\n" +
                "                                                                      WHEN voa.REMAINQTTY = 0 AND voa.EXECQTTY > 0 AND voa.ORSTATUS = '4' THEN '12'\n" +
                "                                                                      ELSE voa.ORSTATUS END) THEN (CASE\n" +
                "                                                                                                       WHEN voa.REMAINQTTY <> 0 AND voa1.EDSTATUS = 'C' THEN 'C'\n" +
                "                                                                                                       WHEN voa.REMAINQTTY <> 0 AND voa1.EDSTATUS = 'A'  THEN 'A'\n" +
                "                                                                                                       WHEN voa1.EDSTATUS IS NULL AND voa.CANCELQTTY <> 0 THEN '6'\n" +
                "                                                                                                       WHEN voa.REMAINQTTY = 0 AND voa.CANCELQTTY <> 0 AND voa1.EDSTATUS = 'C' THEN '3'\n" +
                "                                                                                                       WHEN voa.REMAINQTTY = 0 AND voa.ADJUSTQTTY > 0 AND voa.pricetype = 'MP' THEN '4'\n" +
                "                                                                                                       WHEN voa.REMAINQTTY = 0 AND voa.ADJUSTQTTY > 0 THEN '10'\n" +
                "                                                                                                       WHEN voa.REMAINQTTY = 0 AND voa.EXECQTTY > 0 AND voa.ORSTATUS = '4' THEN '12'\n" +
                "                                                                                                       ELSE voa.ORSTATUS END)\n" +
                "           WHEN boa.ORSTATUSVALUE IS NOT NULL THEN boa.ORSTATUSVALUE\n" +
                "           ELSE (CASE\n" +
                "                     WHEN voa.REMAINQTTY <> 0 AND voa1.EDSTATUS = 'C' THEN 'C'\n" +
                "                     WHEN voa.REMAINQTTY <> 0 AND voa1.EDSTATUS = 'A' THEN 'A'\n" +
                "                     WHEN voa1.EDSTATUS IS NULL AND voa.CANCELQTTY <> 0 THEN '6'\n" +
                "                     WHEN voa.REMAINQTTY = 0 AND voa.CANCELQTTY <> 0 AND voa1.EDSTATUS = 'C' THEN '3'\n" +
                "                     WHEN voa.REMAINQTTY = 0 AND voa.ADJUSTQTTY > 0 AND voa.pricetype = 'MP' THEN '4'\n" +
                "                     WHEN voa.REMAINQTTY = 0 AND voa.ADJUSTQTTY > 0 THEN '10'\n" +
                "                     WHEN voa.REMAINQTTY = 0 AND voa.EXECQTTY > 0 AND voa.ORSTATUS = '4' THEN '12'\n" +
                "                     ELSE voa.ORSTATUS END) END                                                   AS flexStatus,  \n" +
                "            sb.SYMBOL AS symbol,      --mã cổ phiếu (điều kiện tìm kiếm)  \n" +
                "             voa.quoteprice  AS price,   \n" +
                "             CASE WHEN boa.EXECQTTY IS NOT NULL THEN boa.EXECQTTY ELSE voa.EXECQTTY END         AS jointVolume,   \n" +
                "             voa.orderqtty                                                                              AS Volume,      -- khối lượng đặt  \n" +
                "             cf.CUSTODYCD                                                                               AS CFCUSTODYCD, --So tai khoan khách hàng (điều kiện tìm kiếm)\n" +
                "       cf.FULLNAME                                                                                AS FULLNAME,    --So tai khoan khách hàng\n" +
                "       cf.MOBILESMS,\n" +
                "       voa.AFACCTNO                                                                               AS accountId,   --accountId số tiểu khản khách hàng (điều kiện tìm kiếm)  \n" +
                "     UPPER(substr(UPPER(accountType.EN_CDCONTENT), 2, length(UPPER(accountType.EN_CDCONTENT)))) as subAccount,\n" +
                "       UPPER(voa.pricetype)                                                                       as orderCode,\n" +
                "       voa.ORDERID                                                                                as transactionId,\n" +
                "       TO_CHAR(voa.LAST_CHANGE, 'dd/mm/yyyy hh24:mi')                                             as lastModifiedDate,\n" +
                "       UPPER(voa.VIA)                                                                             as channel,\n" +
                "       voa.ORDERID                                                                                as orderId,\n" +
                "       CASE boa.ISDISPOSAL WHEN 'Y' THEN 'N' ELSE boa.ISCANCEL END                                AS allowCancel,\n" +
                "       CASE boa.ISDISPOSAL WHEN 'Y' THEN 'N' ELSE boa.ISADMEND END                                AS allowAmend,\n" +
                "       CONCAT(TO_CHAR(voa.TXDATE, 'dd/mm/yyyy '), voa.TXTIME)                                        createDate,\n" +
                "       ROUND(case when voa.EXECQTTY > 0 then voa.EXECAMT / voa.EXECQTTY else 0 end, 4)               execPrice,\n" +
                "       cf.custid                                                                                     custId,  " +
                "       CASE UPPER(voa.VIA)\n" +
                "           WHEN 'H' THEN\n" +
                "               (select CONCAT(CONCAT(cf1.CUSTODYCD, ' - '), cf1.FULLNAME)\n" +
                "                from " + schema + ".ODMAST od1\n" +
                "                         INNER JOIN " + schema + ".RECFLNK rec ON od1.TLID = rec.TLID\n" +
                "                         INNER JOIN " + schema + ".CFMAST cf1\n" +
                "                                    ON rec.CUSTID = cf1.CUSTID AND od1.orderid = :orderId -- voa.ORDERID --voa.ORDERID\n" +
                "                UNION\n" +
                "                select CONCAT(CONCAT(cf2.CUSTODYCD, ' - '), cf2.FULLNAME)\n" +
                "                from " + schema + ".ODMASTHIST od2\n" +
                "                         INNER JOIN " + schema + ".RECFLNK rec ON od2.TLID = rec.TLID\n" +
                "                         INNER JOIN " + schema + ".CFMAST cf2 ON rec.CUSTID = cf2.CUSTID AND od2.orderid = :orderId \n" +
                "                OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY)\n" +
                "\n" +
                "           ELSE CONCAT(CONCAT(cf.CUSTODYCD, ' - '), cf.FULLNAME) END                              AS orderInfo,  " +
                "                   customerInfo.dept dept,                        \n" +
                "                   customerInfo.reCustodyCd reCustodyCd,                     \n" +
                "                   customerInfo.reFullName reFullName,                        " +


                "FROM " + schema + ".CFMAST cf\n" +
                "         LEFT JOIN " + schema + ".AFMAST af ON cf.CUSTID = af.CUSTID\n" +
                "         LEFT JOIN " + schema + ".odmasthist voa ON af.ACCTNO = voa.AFACCTNO\n" +
                "         LEFT JOIN " + schema + ".odmast voa1\n" +
                "                   ON voa.ORDERID = voa1.REFORDERID\n" +
                "                       AND voa1.EDSTATUS IN ('C', 'A')\n" +
                "                       AND voa1.EXECTYPE NOT IN ('NB', 'NS')\n" +
                "                       AND voa1.ORSTATUS NOT IN ('0', '5', '6')\n" +
                "         LEFT JOIN " + schema + ".buf_od_account boa ON voa.ORDERID = boa.ORDERID\n" +
                "         LEFT JOIN " + schema + ".allcode accountType\n" +
                "                   ON accountType.cdname = 'PRODUCTTYPE'\n" +
                "                       AND accountType.CDTYPE = 'CF'\n" +
                "                       AND accountType.cdval = af.producttype\n" +
                "         LEFT JOIN " + schema + ".SBSECURITIES sb ON voa.CODEID = sb.CODEID\n" +
                "         LEFT JOIN " + schema + ".allcode a1\n" +
                "                   ON a1.cdname = 'EXECTYPE'\n" +
                "                       AND a1.cdtype = 'FO'\n" +
                "                       AND a1.cdval = voa.exectype\n" +
                "         LEFT JOIN " + schema + ".TLPROFILES TLP ON voa.TLID = TLP.TLID\n" +
                "         LEFT JOIN " + schema + ".allcode a2\n" +
                "                   ON a2.cdname = 'VIA'\n" +
                "                       AND a2.cdtype = 'OD'\n" +
                "                       AND a2.cdcontent = voa.via\n" +
                "         LEFT JOIN " + schema + ".CONFIRMODRSTS FIRM\n" +
                "                   ON voa.ORDERID = FIRM.ORDERID\n" +
                "         LEFT JOIN " + schema + ".ALLCODE A4\n" +
                "                   ON A4.CDTYPE = 'SY'\n" +
                "                       AND A4.CDNAME = 'YESNO'\n" +
                "                       AND A4.CDVAL =\n" +
                "                           (CASE\n" +
                "                                WHEN voa.TLID = '6868' THEN 'Y'\n" +
                "                                ELSE NVL(FIRM.CONFIRMED, 'N')\n" +
                "                               END)\n" +
                "         INNER JOIN customerInfo customerInfo ON upper(cf.CUSTODYCD) =  upper(customerInfo.custodyCd) \n" +
                "WHERE 1 = 1\n" +
                "  AND SUBSTR(voa.EXECTYPE, 1, 1) <> 'C'\n" +
                "  AND SUBSTR(voa.EXECTYPE, 1, 1) <> 'A'\n" +
                "  AND (voa.execqtty <> 0 OR voa.edstatus NOT IN ('C', 'A')) " +
                "   AND voa.ORDERID = :orderId ");
    }


    private void sqlNativeTotal(StringBuilder sql) {
        sql.append(" " +
                " SELECT null   AS ORDERID,\n" +
                "       null      AS REFORDERID,\n" +
                "       null              AS side,                 -- BUY/SELL loại lệnh (điều kiện tìm kiếm)\n" +
                "       null     AS status,               -- status flex\n" +
                "       null     AS statusValue,\n" +
                "       null      AS price,                --giá\n" +
                "       null        AS symbol,               --mã cổ phiếu (điều kiện tìm kiếm)\n" +
                "       null       AS matchVolumeInDay,     --Khối lượng khớp lệnh trong ngay\n" +
                "       null       AS matchVolumeDay,       --Khối lượng khớp lệnh lịch sử\n" +
                "       null      AS Volume,               -- khối lượng đặt\n" +
                "       null  AS CFCUSTODYCD,          --So tai khoan khách hàng (điều kiện tìm kiếm)\n" +
                "       null   AS FULLNAME,             --So tai khoan khách hàng\n" +
                "       null  AS acctype_EN_CDCONTENT, -- tiểu khoản, thương/ ký quỹ (điều kiện tìm kiếm)\n" +
                "       null   AS TXDATE,               --ngày bắt đầu (điều kiện tìm kiếm)\n" +
                "       null    AS TXTIME,               --ngày bắt đầu (điều kiện tìm kiếm)\n" +
                "       null   AS EXPDATE,              -- ngày kết thúc\n" +
                "       null LAST_CHANGE,                       -- thời gian hủy, sửa, đặt\n" +
                "       null           AS accountId,            --accountId số tiểu khản khách hàng (điều kiện tìm kiếm)\n" +
                "       null       AS allowCancel,\n" +
                "       null  AS allowAmend,\n" +
                "       null AS PRICETYPE,            --Loai lênh (điều kiện tìm kiếm),\n" +
                "       null MOBILESMS,\n" +
                " null createDate, " +
                " null execprice, " +
                "       null cfCustId, \n" +
                "       null dept,                       \n" +
                "       null reCustodyCd,                       \n" +
                "       null reFullName,                        " +
                "       count(1) total                       \n" +
                "FROM so_lenh ");
    }

    private void condition(StockOrderFilter stockOrderFilter, StringBuilder sql, Map<String, Object> mapParam) {

        if (!Objects.isNull(stockOrderFilter.getStatus()) && stockOrderFilter.getStatus() != StockOrderStatus.ALL) {
            sql.append(" AND (CASE\n" +
                    "           WHEN voa.REMAINQTTY <> 0 AND voa1.EDSTATUS = 'C'\n" +
                    "               THEN\n" +
                    "               'C'\n" +
                    "           WHEN voa.REMAINQTTY <> 0 AND voa1.EDSTATUS = 'A'\n" +
                    "               THEN\n" +
                    "               'A'\n" +
                    "           WHEN voa1.EDSTATUS IS NULL AND voa.CANCELQTTY <> 0\n" +
                    "               THEN\n" +
                    "               '6'\n" +
                    "           WHEN voa.REMAINQTTY = 0\n" +
                    "               AND voa.CANCELQTTY <> 0\n" +
                    "               AND voa1.EDSTATUS = 'C'\n" +
                    "               THEN\n" +
                    "               '3'\n" +
                    "           WHEN voa.REMAINQTTY = 0\n" +
                    "               AND voa.ADJUSTQTTY > 0\n" +
                    "               AND voa.pricetype = 'MP'\n" +
                    "               THEN\n" +
                    "               '4'\n" +
                    "           WHEN voa.REMAINQTTY = 0 AND voa.ADJUSTQTTY > 0\n" +
                    "               THEN\n" +
                    "               '10'\n" +
                    "           WHEN voa.REMAINQTTY = 0\n" +
                    "               AND voa.EXECQTTY > 0\n" +
                    "               AND voa.ORSTATUS = '4'\n" +
                    "               THEN\n" +
                    "               '12'\n" +
                    "           ELSE\n" +
                    "               voa.ORSTATUS\n" +
                    "    END) IN :status ");
            mapParam.put("status", stockOrderFilter.getFlexStatus());
        }

        if (!CollectionUtils.isEmpty(stockOrderFilter.getCustomerAccountNumbers())) {
            sql.append(" AND upper(cf.CUSTODYCD) IN :custodyCds  ");
            mapParam.put("custodyCds", DataUtils.toUpper(stockOrderFilter.getCustomerAccountNumbers()));
        }

        if (!Strings.isEmpty(stockOrderFilter.getCustomerAccountNumber())) {
            sql.append("  AND upper(cf.CUSTODYCD) = :custodyCdOrder ");
            mapParam.put("custodyCdOrder", DataUtils.toUpper(stockOrderFilter.getCustomerAccountNumber()));
        }

        if (!CollectionUtils.isEmpty(stockOrderFilter.getStockSymbols())) {
            sql.append(" AND upper(sb.SYMBOL) IN  :stockSymbol ");
            mapParam.put("stockSymbol", DataUtils.toUpper(stockOrderFilter.getStockSymbols()));
        }

        if (!Strings.isEmpty(stockOrderFilter.getSymbol())) {
            sql.append(" AND upper(sb.SYMBOL) LIKE :symbol ");
            mapParam.put("symbol", "%" + stockOrderFilter.getSymbol() + "%");
        }

        if (!CollectionUtils.isEmpty(stockOrderFilter.getSubAccounts())) {
            sql.append(" AND UPPER(accountType.EN_CDCONTENT) IN  :subAccount ");
            mapParam.put("subAccount", SubAccount.toStringDot(stockOrderFilter.getSubAccounts()));
        }

        //filter by price type (LO / ATO)
        if (!CollectionUtils.isEmpty(stockOrderFilter.getOrderCodes())) {
            sql.append(" AND upper(voa.pricetype) IN :orderCode ");
            mapParam.put("orderCode", OrderCode.toStrings(stockOrderFilter.getOrderCodes()));
        }

        //filter by side (BUY/SELL)
        if (!CollectionUtils.isEmpty(stockOrderFilter.getOrderSides())) {
            sql.append(" AND UPPER(a1.EN_CDCONTENT) IN :side ");

            mapParam.put("side", Order.toStrings(stockOrderFilter.getOrderSides()));
        }

        //filter by channel (SALESUPORT/WEB)
        if (!CollectionUtils.isEmpty(stockOrderFilter.getChannels())) {
            sql.append(" AND upper(voa.VIA) IN  :via ");
            mapParam.put("via", ChannelFlex.toStrings(stockOrderFilter.getChannels()));
        }

        if (!Strings.isEmpty(stockOrderFilter.getStartDate())) {
            sql.append(" AND voa.TXDATE >= TO_DATE(:startDate, 'dd/mm/yyyy')");
            mapParam.put("startDate", stockOrderFilter.getStartDate().toString());
        }
        if (!Strings.isEmpty(stockOrderFilter.getToDate())) {
            sql.append(" AND voa.TXDATE   <= TO_DATE(:toDate, 'dd/mm/yyyy')");
            mapParam.put("toDate", stockOrderFilter.getToDate());
        }

        if (!Objects.isNull(stockOrderFilter.getConfirmStatus())) {
            sql.append(" AND UPPER(a4.en_cdcontent) = :confirm ");
            mapParam.put("confirm", stockOrderFilter.getConfirmStatus().name());
        }

        if (!Objects.isNull(stockOrderFilter.getDay())) {
            if (stockOrderFilter.getDay() == Day.IN) {
                sql.append(" AND CASE boa.ISDISPOSAL WHEN 'Y' THEN 'N' ELSE boa.ISCANCEL END IS NOT NULL ");
                sql.append(" AND CASE boa.ISDISPOSAL WHEN 'Y' THEN 'N' ELSE boa.ISADMEND END IS NOT NULL ");
            }
            if (stockOrderFilter.getDay() == Day.OUT) {
                sql.append(" AND CASE boa.ISDISPOSAL WHEN 'Y' THEN 'N' ELSE boa.ISCANCEL END IS NULL ");
                sql.append(" AND CASE boa.ISDISPOSAL WHEN 'Y' THEN 'N' ELSE boa.ISADMEND END IS NULL ");
            }
        }

        if (!CollectionUtils.isEmpty(stockOrderFilter.getTimelines())) {
            stockOrderFilter.getTimelines().stream().filter(Objects::nonNull).forEach(value -> {
                if (value == Timeline.OPTION) {
                    return;
                }
                sql.append(" AND ( ");
                if (value == Timeline.IN_DAY) {
                    sql.append("  voa.TXDATE >= CURRENT_DATE ");
                }
                if (value == Timeline.ONE_HOUR) {
                    sql.append(" TO_CHAR(voa.TXDATE, 'dd/MM/yyyy') = TO_CHAR(CURRENT_DATE, 'dd/MM/yyyy') ");
                    sql.append(" AND (cast(voa.txtime AS time(0)) BETWEEN ");
                    sql.append(" cast((LOCALTIMESTAMP - interval '1 hour') AS time(0)) ");
                    sql.append(" AND cast(LOCALTIMESTAMP AS time(0))) ");
                }
                if (value == Timeline.THREE_HOURS) {
                    sql.append(" TO_CHAR(voa.TXDATE, 'dd/MM/yyyy') = TO_CHAR(CURRENT_DATE, 'dd/MM/yyyy') ");
                    sql.append(" AND (cast(voa.txtime AS time(0)) BETWEEN ");
                    sql.append(" cast((LOCALTIMESTAMP - interval '3 hour') AS time(0)) ");
                    sql.append(" AND cast(LOCALTIMESTAMP AS time(0))) ");
                }
                if (value == Timeline.ONE_MONTH) {
                    sql.append(" voa.TXDATE >= (TRUNC(SYSDATE) - interval '1' month) ");
                    sql.append(" AND voa.TXDATE <= CURRENT_DATE ");
                }
                if (value == Timeline.TWO_MONTH) {
                    sql.append(" voa.TXDATE >= (TRUNC(SYSDATE) - interval '2' month) ");
                    sql.append(" AND voa.TXDATE <= CURRENT_DATE ");
                }
                if (value == Timeline.THREE_MONTH) {
                    sql.append(" voa.TXDATE >= (TRUNC(SYSDATE) - interval '3' month) ");
                    sql.append(" AND voa.TXDATE <= CURRENT_DATE ");
                }
                sql.append(" ) ");
            });
        }

        sql.append(" ORDER BY voa.TXDATE DESC, voa.TXTIME DESC ");
    }

    @Override
    public List<StockFilterResponseDTO> orderBooks(StockOrderFilter stockOrderFilter) {
        long start = System.currentTimeMillis();
        log.info("orderBooks request: ", stockOrderFilter);
        List<StockFilterResponseDTO> response = new ArrayList<>();
        Map<String, Object> mapParam = new HashMap<>();
        StringBuilder sql = new StringBuilder();

        //param filter customer
        CustomerDirectIndirectIn customerDirectIndirectIn = new CustomerDirectIndirectIn();
        customerDirectIndirectIn.setAccountNo(stockOrderFilter.getAccountNo());
        customerDirectIndirectIn.setAccount(stockOrderFilter.getAccount());
        customerDirectIndirectIn.setDepts(stockOrderFilter.getDept());
        customerDirectIndirectIn.setCus(stockOrderFilter.getCustomerAccountNumbers());
        customerDirectIndirectIn.setReCustodyCd(stockOrderFilter.getReCustodyCd());
        sql.append(customersRepository.orderCustomerDirectIndirect(customerDirectIndirectIn, mapParam));

        sqlOrderBookMobile(sql);
        condition(stockOrderFilter, sql, mapParam);
        sql.append(" ) ");


        sql.append(" ( ");
        sqlNativeTotal(sql);
        sql.append(" ) ");

        sql.append(" UNION ALL ");

        sql.append(" ( ");

        sqlNative(sql);
        if (null != stockOrderFilter.getPage() && null != stockOrderFilter.getSize()) {
            sql.append("   OFFSET :page ROWS FETCH NEXT :size ROWS ONLY ");
            mapParam.put("page", stockOrderFilter.getPage() * stockOrderFilter.getSize());
            mapParam.put("size", stockOrderFilter.getSize());
        }
        sql.append(" )");

        try {
            Query query = entityManager.createNativeQuery(sql.toString());
            mappingParamSql(mapParam, query);
            response = getOrderBook(query);
            log.info("timeline excute sql " + (System.currentTimeMillis() - start) / 1000F);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return response;
    }

    @Override
    public List<StockOrderDetailResponse> orderBook(String orderId, String custodyCd) {
        log.info("orderBook detail request: ", orderId, custodyCd);
        List<StockFilterResponseDTO> response = new ArrayList<>();
        Map<String, Object> mapParam = new HashMap<>();
        StringBuilder sql = new StringBuilder();

        //param filter customer
        CustomerDirectIndirectIn customerDirectIndirectIn = new CustomerDirectIndirectIn();
        customerDirectIndirectIn.setAccountNo(custodyCd);
        sql.append(customersRepository.orderCustomerDirectIndirect(customerDirectIndirectIn, mapParam));

        sqlOrderDetail(sql);
        mapParam.put("orderId", orderId);

        return null;
    }

    @Override
    public List<StockFilterResponseDTO> orderBookMobiles(StockOrderFilter stockOrderFilter) {
        long start = System.currentTimeMillis();
        List<StockFilterResponseDTO> response = new ArrayList<>();
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_ORDER_BOOK_MOBILE);

        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_accountNo", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_account", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_depts", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_reCustodyCds", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_customerAccountNumbers", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_status", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_symbols", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_subAccounts", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orderSides", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orderCodes", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_channels", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_startDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_toDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_day", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_timelines", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_flexStatus", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_page", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_size", Integer.class, ParameterMode.IN);

        query.setParameter("p_accountNo", DataUtils.safeToString(stockOrderFilter.getAccountNo()));//DONE "116C888777"
        query.setParameter("p_account", DataUtils.safeToString(stockOrderFilter.getAccount()).toUpperCase()); //DONE NGÔ
        query.setParameter("p_depts", convertArrayToString(stockOrderFilter.getDept(), ",")); //MB03,MB04,MB05 DONE
        query.setParameter("p_reCustodyCds", convertArrayToString(stockOrderFilter.getReCustodyCd(), ","));  //DONE 116C743405,0001026497
        query.setParameter("p_customerAccountNumbers", convertArrayToString(stockOrderFilter.getCustomerAccountNumbers(), ",")); //DONE 116C100991
        query.setParameter("p_status", "");//DONE
        query.setParameter("p_symbols", convertArrayToString(stockOrderFilter.getStockSymbols(), ",").toUpperCase());//DONE AAA,NKG,HPG,STB,ABS,DIG,TCB,VIC
        query.setParameter("p_subAccounts", convertArraySubToString(stockOrderFilter.getSubAccounts(), ","));//DONE .NORMAL,.MARGIN
        query.setParameter("p_orderSides", convertArrayOrderToString(stockOrderFilter.getOrderSides(), ","));//DONE BUY,SELL Buy
        query.setParameter("p_orderCodes", convertArrayOrderCodeToString(stockOrderFilter.getOrderCodes(), ","));//DONE LO,MP,ATO,ATC,A24_7,PLO,MTL,MOK,MAK,GTC
        query.setParameter("p_channels", convertArrayChanelToString(stockOrderFilter.getChannels(), ","));//DONE Z,Y,M,O,F,H
        query.setParameter("p_startDate", DataUtils.safeToString(stockOrderFilter.getStartDate())); //DONE 01/12/2023
        query.setParameter("p_toDate", DataUtils.safeToString(stockOrderFilter.getToDate()));//DONE 01/4/2024
        query.setParameter("p_day", "");//DONE
        query.setParameter("p_timelines", convertTimelineToString(stockOrderFilter.getTimelines())); // IN_DAY
        query.setParameter("p_flexStatus", convertArrayToString(stockOrderFilter.getFlexStatus(), ",")); //DONE C,A,6,3,4,10,12
        query.setParameter("p_page", stockOrderFilter.getPage() * stockOrderFilter.getSize());
        query.setParameter("p_size", stockOrderFilter.getSize());

        query.execute();

        try {
            response = mappingResultOrderBooks(query.getResultList());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("timeline excute sql " + (System.currentTimeMillis() - start) / 1000F);
        return response;
    }

    @Override
    public List<StockFilterResponseDTO> histOrderBookMobiles(StockOrderFilter stockOrderFilter) {
        long start = System.currentTimeMillis();
        List<StockFilterResponseDTO> response = new ArrayList<>();

        String storeProcedure = SP_HIST_ORDER_BOOK_MOBILE;
        if (stockOrderFilter.getTimelines().contains(Timeline.ONE_MONTH)) {
            storeProcedure = SP_ONE_MONTH_ORDER_BOOK_MOBILE;
        }else if(stockOrderFilter.getTimelines().contains(Timeline.TWO_MONTH)){
            storeProcedure = SP_TWO_MONTH_ORDER_BOOK_MOBILE;
        }else if(stockOrderFilter.getTimelines().contains(Timeline.THREE_MONTH)){
            storeProcedure = SP_THREE_MONTH_ORDER_BOOK_MOBILE;
        }

        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(storeProcedure);

        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_accountNo", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_account", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_depts", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_reCustodyCds", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_customerAccountNumbers", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_status", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_symbols", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_subAccounts", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orderSides", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orderCodes", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_channels", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_startDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_toDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_day", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_timelines", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_flexStatus", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_page", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_size", Integer.class, ParameterMode.IN);

        query.setParameter("p_accountNo", DataUtils.safeToString(stockOrderFilter.getAccountNo()));//DONE "116C888777"
        query.setParameter("p_account", DataUtils.safeToString(stockOrderFilter.getAccount()).toUpperCase()); //DONE NGÔ
        query.setParameter("p_depts", convertArrayToString(stockOrderFilter.getDept(), ",")); //MB03,MB04,MB05 DONE
        query.setParameter("p_reCustodyCds", convertArrayToString(stockOrderFilter.getReCustodyCd(), ","));  //DONE 116C743405,0001026497
        query.setParameter("p_customerAccountNumbers", convertArrayToString(stockOrderFilter.getCustomerAccountNumbers(), ",")); //DONE 116C100991
        query.setParameter("p_status", "");//DONE
        query.setParameter("p_symbols", convertArrayToString(stockOrderFilter.getStockSymbols(), ",").toUpperCase());//DONE AAA,NKG,HPG,STB,ABS,DIG,TCB,VIC
        query.setParameter("p_subAccounts", convertArraySubToString(stockOrderFilter.getSubAccounts(), ","));//DONE .NORMAL,.MARGIN
        query.setParameter("p_orderSides", convertArrayOrderToString(stockOrderFilter.getOrderSides(), ","));//DONE BUY,SELL Buy
        query.setParameter("p_orderCodes", convertArrayOrderCodeToString(stockOrderFilter.getOrderCodes(), ","));//DONE LO,MP,ATO,ATC,A24_7,PLO,MTL,MOK,MAK,GTC
        query.setParameter("p_channels", convertArrayChanelToString(stockOrderFilter.getChannels(), ","));//DONE Z,Y,M,O,F,H
        query.setParameter("p_startDate", DataUtils.safeToString(stockOrderFilter.getStartDate())); //DONE 01/12/2023
        query.setParameter("p_toDate", DataUtils.safeToString(stockOrderFilter.getToDate()));//DONE 01/4/2024
        query.setParameter("p_day", "");//DONE
        query.setParameter("p_timelines", convertTimelineToString(stockOrderFilter.getTimelines())); // IN_DAY
        query.setParameter("p_flexStatus", convertArrayToString(stockOrderFilter.getFlexStatus(), ",")); //DONE C,A,6,3,4,10,12
        query.setParameter("p_page", stockOrderFilter.getPage() * stockOrderFilter.getSize());
        query.setParameter("p_size", stockOrderFilter.getSize());

        query.execute();

        try {
            response = mappingResultOrderBooks(query.getResultList());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("timeline excute sql " + (System.currentTimeMillis() - start) / 1000F);
        return response;
    }

    @Override
    public List<StockFilterResponseDTO> allOrderBookMobiles(StockOrderFilter stockOrderFilter) {
        long start = System.currentTimeMillis();
        List<StockFilterResponseDTO> response = new ArrayList<>();
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_ALL_ORDER_BOOK_MOBILE);

        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_accountNo", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_account", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_depts", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_reCustodyCds", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_customerAccountNumbers", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_status", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_symbols", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_subAccounts", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orderSides", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orderCodes", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_channels", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_startDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_toDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_day", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_timelines", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_flexStatus", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_page", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_size", Integer.class, ParameterMode.IN);

        query.setParameter("p_accountNo", DataUtils.safeToString(stockOrderFilter.getAccountNo()));//DONE "116C888777"
        query.setParameter("p_account", DataUtils.safeToString(stockOrderFilter.getAccount()).toUpperCase()); //DONE NGÔ
        query.setParameter("p_depts", convertArrayToString(stockOrderFilter.getDept(), ",")); //MB03,MB04,MB05 DONE
        query.setParameter("p_reCustodyCds", convertArrayToString(stockOrderFilter.getReCustodyCd(), ","));  //DONE 116C743405,0001026497
        query.setParameter("p_customerAccountNumbers", convertArrayToString(stockOrderFilter.getCustomerAccountNumbers(), ",")); //DONE 116C100991
        query.setParameter("p_status", "");//DONE
        query.setParameter("p_symbols", convertArrayToString(stockOrderFilter.getStockSymbols(), ",").toUpperCase());//DONE AAA,NKG,HPG,STB,ABS,DIG,TCB,VIC
        query.setParameter("p_subAccounts", convertArraySubToString(stockOrderFilter.getSubAccounts(), ","));//DONE .NORMAL,.MARGIN
        query.setParameter("p_orderSides", convertArrayOrderToString(stockOrderFilter.getOrderSides(), ","));//DONE BUY,SELL Buy
        query.setParameter("p_orderCodes", convertArrayOrderCodeToString(stockOrderFilter.getOrderCodes(), ","));//DONE LO,MP,ATO,ATC,A24_7,PLO,MTL,MOK,MAK,GTC
        query.setParameter("p_channels", convertArrayChanelToString(stockOrderFilter.getChannels(), ","));//DONE Z,Y,M,O,F,H
        query.setParameter("p_startDate", DataUtils.safeToString(stockOrderFilter.getStartDate())); //DONE 01/12/2023
        query.setParameter("p_toDate", DataUtils.safeToString(stockOrderFilter.getToDate()));//DONE 01/4/2024
        query.setParameter("p_day", "");//DONE
        query.setParameter("p_timelines", convertTimelineToString(stockOrderFilter.getTimelines())); // IN_DAY
        query.setParameter("p_flexStatus", convertArrayToString(stockOrderFilter.getFlexStatus(), ",")); //DONE C,A,6,3,4,10,12
        query.setParameter("p_page", stockOrderFilter.getPage() * stockOrderFilter.getSize());
        query.setParameter("p_size", stockOrderFilter.getSize());

        query.execute();

        try {
            response = mappingResultOrderBooks(query.getResultList());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("timeline excute sql " + (System.currentTimeMillis() - start) / 1000F);
        return response;
    }

    @Override
    public List<StockFilterResponseDTO> confirmOrderBookMobiles(StockOrderFilter stockOrderFilter) {
        long start = System.currentTimeMillis();
        List<StockFilterResponseDTO> response = new ArrayList<>();
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_CONFIRM_ORDER_BOOK_MOBILE);

        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_accountNo", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_account", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_depts", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_reCustodyCds", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_customerAccountNumbers", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_status", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_symbols", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_subAccounts", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orderSides", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orderCodes", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_channels", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_startDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_toDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_day", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_timelines", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_flexStatus", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_confirmStatus", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_page", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_size", Integer.class, ParameterMode.IN);

        query.setParameter("p_accountNo", DataUtils.safeToString(stockOrderFilter.getAccountNo()));//DONE "116C888777"
        query.setParameter("p_account", DataUtils.safeToString(stockOrderFilter.getAccount()).toUpperCase()); //DONE NGÔ
        query.setParameter("p_depts", convertArrayToString(stockOrderFilter.getDept(), ",")); //MB03,MB04,MB05 DONE
        query.setParameter("p_reCustodyCds", convertArrayToString(stockOrderFilter.getReCustodyCd(), ","));  //DONE 116C743405,0001026497
        query.setParameter("p_customerAccountNumbers", convertArrayToString(stockOrderFilter.getCustomerAccountNumbers(), ",")); //DONE 116C100991
        query.setParameter("p_status", "");//DONE
        query.setParameter("p_symbols", convertArrayToString(stockOrderFilter.getStockSymbols(), ",").toUpperCase());//DONE AAA,NKG,HPG,STB,ABS,DIG,TCB,VIC
        query.setParameter("p_subAccounts", convertArraySubToString(stockOrderFilter.getSubAccounts(), ","));//DONE .NORMAL,.MARGIN
        query.setParameter("p_orderSides", convertArrayOrderToString(stockOrderFilter.getOrderSides(), ","));//DONE BUY,SELL Buy
        query.setParameter("p_orderCodes", convertArrayOrderCodeToString(stockOrderFilter.getOrderCodes(), ","));//DONE LO,MP,ATO,ATC,A24_7,PLO,MTL,MOK,MAK,GTC
        query.setParameter("p_channels", convertArrayChanelToString(stockOrderFilter.getChannels(), ","));//DONE Z,Y,M,O,F,H
        query.setParameter("p_startDate", DataUtils.safeToString(stockOrderFilter.getStartDate())); //DONE 01/12/2023
        query.setParameter("p_toDate", DataUtils.safeToString(stockOrderFilter.getToDate()));//DONE 01/4/2024
        query.setParameter("p_day", "");//DONE
        query.setParameter("p_timelines", convertTimelineToString(stockOrderFilter.getTimelines())); // IN_DAY
        query.setParameter("p_flexStatus", convertArrayToString(stockOrderFilter.getFlexStatus(), ",")); //DONE C,A,6,3,4,10,12
        query.setParameter("p_confirmStatus", convertConfirmStatusToString(stockOrderFilter.getConfirmStatus()));
        query.setParameter("p_page", stockOrderFilter.getPage() * stockOrderFilter.getSize());
        query.setParameter("p_size", stockOrderFilter.getSize());

        query.execute();

        try {
            response = mappingResultOrderBooks(query.getResultList());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("timeline excute sql " + (System.currentTimeMillis() - start) / 1000F);
        return response;
    }

    @Override
    public List<StockFilterResponseDTO> confirmHistOrderBookMobiles(StockOrderFilter stockOrderFilter) {
        long start = System.currentTimeMillis();
        List<StockFilterResponseDTO> response = new ArrayList<>();

        String storeProcedure = SP_CONFIRM_HIST_ORDER_BOOK_MOBILE;
        if (stockOrderFilter.getTimelines().contains(Timeline.ONE_MONTH)) {
            storeProcedure = SP_CONFIRM_ONE_MONTH_ORDER_BOOK_MOBILE;
        }else if(stockOrderFilter.getTimelines().contains(Timeline.TWO_MONTH)){
            storeProcedure = SP_CONFIRM_TWO_MONTH_ORDER_BOOK_MOBILE;
        }else if(stockOrderFilter.getTimelines().contains(Timeline.THREE_MONTH)){
            storeProcedure = SP_CONFIRM_THREE_MONTH_ORDER_BOOK_MOBILE;
        }

        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(storeProcedure);

        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_accountNo", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_account", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_depts", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_reCustodyCds", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_customerAccountNumbers", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_status", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_symbols", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_subAccounts", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orderSides", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orderCodes", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_channels", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_startDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_toDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_day", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_timelines", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_flexStatus", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_confirmStatus", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_page", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_size", Integer.class, ParameterMode.IN);

        query.setParameter("p_accountNo", DataUtils.safeToString(stockOrderFilter.getAccountNo()));//DONE "116C888777"
        query.setParameter("p_account", DataUtils.safeToString(stockOrderFilter.getAccount()).toUpperCase()); //DONE NGÔ
        query.setParameter("p_depts", convertArrayToString(stockOrderFilter.getDept(), ",")); //MB03,MB04,MB05 DONE
        query.setParameter("p_reCustodyCds", convertArrayToString(stockOrderFilter.getReCustodyCd(), ","));  //DONE 116C743405,0001026497
        query.setParameter("p_customerAccountNumbers", convertArrayToString(stockOrderFilter.getCustomerAccountNumbers(), ",")); //DONE 116C100991
        query.setParameter("p_status", "");//DONE
        query.setParameter("p_symbols", convertArrayToString(stockOrderFilter.getStockSymbols(), ",").toUpperCase());//DONE AAA,NKG,HPG,STB,ABS,DIG,TCB,VIC
        query.setParameter("p_subAccounts", convertArraySubToString(stockOrderFilter.getSubAccounts(), ","));//DONE .NORMAL,.MARGIN
        query.setParameter("p_orderSides", convertArrayOrderToString(stockOrderFilter.getOrderSides(), ","));//DONE BUY,SELL Buy
        query.setParameter("p_orderCodes", convertArrayOrderCodeToString(stockOrderFilter.getOrderCodes(), ","));//DONE LO,MP,ATO,ATC,A24_7,PLO,MTL,MOK,MAK,GTC
        query.setParameter("p_channels", convertArrayChanelToString(stockOrderFilter.getChannels(), ","));//DONE Z,Y,M,O,F,H
        query.setParameter("p_startDate", DataUtils.safeToString(stockOrderFilter.getStartDate())); //DONE 01/12/2023
        query.setParameter("p_toDate", DataUtils.safeToString(stockOrderFilter.getToDate()));//DONE 01/4/2024
        query.setParameter("p_day", "");//DONE
        query.setParameter("p_timelines", convertTimelineToString(stockOrderFilter.getTimelines())); // IN_DAY
        query.setParameter("p_flexStatus", convertArrayToString(stockOrderFilter.getFlexStatus(), ",")); //DONE C,A,6,3,4,10,12
        query.setParameter("p_confirmStatus", convertConfirmStatusToString(stockOrderFilter.getConfirmStatus()));
        query.setParameter("p_page", stockOrderFilter.getPage() * stockOrderFilter.getSize());
        query.setParameter("p_size", stockOrderFilter.getSize());

        query.execute();

        try {
            response = mappingResultOrderBooks(query.getResultList());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("timeline excute sql " + (System.currentTimeMillis() - start) / 1000F);
        return response;
    }

    @Override
    public List<StockFilterResponseDTO> confirmAllOrderBookMobiles(StockOrderFilter stockOrderFilter) {
        long start = System.currentTimeMillis();
        List<StockFilterResponseDTO> response = new ArrayList<>();
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_CONFIRM_ALL_ORDER_BOOK_MOBILE);

        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_accountNo", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_account", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_depts", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_reCustodyCds", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_customerAccountNumbers", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_status", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_symbols", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_subAccounts", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orderSides", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orderCodes", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_channels", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_startDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_toDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_day", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_timelines", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_flexStatus", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_confirmStatus", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_page", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_size", Integer.class, ParameterMode.IN);

        query.setParameter("p_accountNo", DataUtils.safeToString(stockOrderFilter.getAccountNo()));//DONE "116C888777"
        query.setParameter("p_account", DataUtils.safeToString(stockOrderFilter.getAccount()).toUpperCase()); //DONE NGÔ
        query.setParameter("p_depts", convertArrayToString(stockOrderFilter.getDept(), ",")); //MB03,MB04,MB05 DONE
        query.setParameter("p_reCustodyCds", convertArrayToString(stockOrderFilter.getReCustodyCd(), ","));  //DONE 116C743405,0001026497
        query.setParameter("p_customerAccountNumbers", convertArrayToString(stockOrderFilter.getCustomerAccountNumbers(), ",")); //DONE 116C100991
        query.setParameter("p_status", "");//DONE
        query.setParameter("p_symbols", convertArrayToString(stockOrderFilter.getStockSymbols(), ",").toUpperCase());//DONE AAA,NKG,HPG,STB,ABS,DIG,TCB,VIC
        query.setParameter("p_subAccounts", convertArraySubToString(stockOrderFilter.getSubAccounts(), ","));//DONE .NORMAL,.MARGIN
        query.setParameter("p_orderSides", convertArrayOrderToString(stockOrderFilter.getOrderSides(), ","));//DONE BUY,SELL Buy
        query.setParameter("p_orderCodes", convertArrayOrderCodeToString(stockOrderFilter.getOrderCodes(), ","));//DONE LO,MP,ATO,ATC,A24_7,PLO,MTL,MOK,MAK,GTC
        query.setParameter("p_channels", convertArrayChanelToString(stockOrderFilter.getChannels(), ","));//DONE Z,Y,M,O,F,H
        query.setParameter("p_startDate", DataUtils.safeToString(stockOrderFilter.getStartDate())); //DONE 01/12/2023
        query.setParameter("p_toDate", DataUtils.safeToString(stockOrderFilter.getToDate()));//DONE 01/4/2024
        query.setParameter("p_day", "");//DONE
        query.setParameter("p_timelines", convertTimelineToString(stockOrderFilter.getTimelines())); // IN_DAY
        query.setParameter("p_flexStatus", convertArrayToString(stockOrderFilter.getFlexStatus(), ",")); //DONE C,A,6,3,4,10,12
        query.setParameter("p_confirmStatus", convertConfirmStatusToString(stockOrderFilter.getConfirmStatus()));
        query.setParameter("p_page", stockOrderFilter.getPage() * stockOrderFilter.getSize());
        query.setParameter("p_size", stockOrderFilter.getSize());

        query.execute();

        try {
            response = mappingResultOrderBooks(query.getResultList());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("timeline excute sql " + (System.currentTimeMillis() - start) / 1000F);
        return response;
    }


    private String mappingStatus(Object status, Object statusValue) {
        String statusValues = DataUtils.safeToString(statusValue);
        String statues = DataUtils.safeToString(status);
        if ("5".equals(statusValues) && !DataUtils.safeToString(statusValues).equals(statues)) {
            return statues;
        }

        if (!Strings.isEmpty(statusValues)) {
            return statusValues;
        }
        return statues;
    }


    private List<StockFilterResponseDTO> getOrderBook(Query query) {
        List<Object[]> rows = query.getResultList();
        if (CollectionUtils.isEmpty(rows)) {
            return List.of();
        }
        List<StockFilterResponseDTO> listData = new ArrayList<>(rows.size());
        StockFilterResponseDTO stockFilterResponse;
        for (Object[] row : rows) {

            stockFilterResponse = new StockFilterResponseDTO();
            stockFilterResponse.setStockOrderId(DataUtils.safeToString(row[0]));
            stockFilterResponse.setRefOrderId(DataUtils.safeToString(row[1]));
            stockFilterResponse.setOrderSide(DataUtils.safeToString(row[2]));
            stockFilterResponse.setStatus(mappingStatus(DataUtils.safeToString(row[3]), DataUtils.safeToString(row[4])));
            stockFilterResponse.setOrderPrice(DataUtils.safeToBigDecimal(row[5]));
            stockFilterResponse.setStockCode(DataUtils.safeToString(row[6]));
            stockFilterResponse.setJoinVolume(row[7] != null ? DataUtils.safeToLong(row[7]) : DataUtils.safeToLong(row[8]));
            stockFilterResponse.setJoin(DataUtils.safeToLong(row[9]));
            stockFilterResponse.setCustomerAccountNumber(DataUtils.safeToString(row[10]));
            stockFilterResponse.setCustomerAccountName(DataUtils.safeToString(row[11]));
            stockFilterResponse.setPhone(DataUtils.safeToString(row[21]));
            stockFilterResponse.setSubAccount(DataUtils.safeToString(row[12]));
            stockFilterResponse.setStartDate(DataUtils.safeToString(row[13]));
            stockFilterResponse.setExpiredDate(DataUtils.safeToString(row[15]));
            stockFilterResponse.setLastModifiedDate(DataUtils.safeToString(row[16]));
            stockFilterResponse.setAccountId(DataUtils.safeToString(row[17]));
            stockFilterResponse.setAllowCancel(DataUtils.safeToString(row[18]));
            stockFilterResponse.setAllowAmend(DataUtils.safeToString(row[19]));
            stockFilterResponse.setOrderCode(DataUtils.safeToString(row[20]));
            stockFilterResponse.setCreateDate(DataUtils.safeToString(row[22]));
            stockFilterResponse.setExecPrice(DataUtils.safeToBigDecimal(row[23]));
            stockFilterResponse.setCustId(DataUtils.safeToString(row[24]));
            stockFilterResponse.setDept(DataUtils.safeToString(row[25]));
            stockFilterResponse.setReCustodyCd(DataUtils.safeToString(row[26]));
            stockFilterResponse.setReFullName(DataUtils.safeToString(row[27]));
            stockFilterResponse.setTotal(DataUtils.safeToBigDecimal(row[28]));
            listData.add(stockFilterResponse);
        }
        return listData;
    }


    private void mappingParamSql(Map<String, Object> paramValue, Query query) {
        if (CollectionUtils.isEmpty(paramValue)) {
            return;
        }

        paramValue.entrySet().stream().filter(Objects::nonNull).forEach(param -> {
            query.setParameter(param.getKey(), param.getValue());
        });

    }

    private String convertArrayToString(List<String> list, String pre) {
        if (CollectionUtils.isEmpty(list)) {
            return Strings.EMPTY;
        }
        StringBuilder result = new StringBuilder();
        for (String value : list) {
            if (Strings.isEmpty(value)) {
                continue;
            }
            result.append(value);
            result.append(pre);
        }
        result.deleteCharAt(result.length() - 1);
        return result.toString();

    }

    private String convertArraySubToString(List<SubAccount> list, String pre) {
        if (CollectionUtils.isEmpty(list)) {
            return Strings.EMPTY;
        }

        List<String> subAccounts = SubAccount.toStringDot(list);
        return convertArrayToString(subAccounts, pre);

    }

    private String convertArrayOrderToString(List<Order> list, String pre) {
        if (CollectionUtils.isEmpty(list)) {
            return Strings.EMPTY;
        }
        StringBuilder result = new StringBuilder();
        for (Order value : list) {
            if (Objects.isNull(value)) {
                continue;
            }
            result.append(value.name());
            result.append(pre);
        }
        result.deleteCharAt(result.length() - 1);
        return result.toString();

    }

    private String convertArrayOrderCodeToString(List<OrderCode> list, String pre) {
        if (CollectionUtils.isEmpty(list)) {
            return Strings.EMPTY;
        }
        StringBuilder result = new StringBuilder();
        for (OrderCode value : list) {
            if (Objects.isNull(value)) {
                continue;
            }
            result.append(value.name());
            result.append(pre);
        }
        result.deleteCharAt(result.length() - 1);
        return result.toString();

    }

    private String convertArrayChanelToString(List<ChannelFlex> list, String pre) {
        if (CollectionUtils.isEmpty(list)) {
            return Strings.EMPTY;
        }

        List<String> channels = ChannelFlex.toStrings(list);
        return convertArrayToString(channels, pre);
    }

    private String convertTimelineToString(List<Timeline> list) {
        if (CollectionUtils.isEmpty(list) || list.contains(Timeline.OPTION)) {
            return Strings.EMPTY;
        }

        for (Timeline value : list) {
            if (Objects.isNull(value)) {
                continue;
            }
            return value.name();
        }
        return Strings.EMPTY;
    }
    private String convertConfirmStatusToString(ConfirmStatus status) {
        if (Objects.isNull(status)) {
            return Strings.EMPTY;
        }
        return status.name();
    }

    private String mappingStatus(String reMainQTTY, String edStatus, String cancelQTTY, Long adJustQTTY, String orStatus, Long execQTTY, String priceType) {

        if (!"0".equals(reMainQTTY) && "C".equals(edStatus)) {
            return "C";
        } else if (!"0".equals(reMainQTTY) && "A".equals(edStatus)) {
            return "A";
        } else if (null == edStatus && !"0".equals(cancelQTTY)) {
            return "6";
        } else if ("0".equals(reMainQTTY) && !"0".equals(cancelQTTY) && "C".equals(edStatus)) {
            return "3";
        } else if ("0".equals(reMainQTTY) && adJustQTTY > 0 && "MP".equals(priceType)) {
            return "4";
        } else if ("0".equals(reMainQTTY) && adJustQTTY > 0) {
            return "10";
        } else if ("0".equals(reMainQTTY) && execQTTY > 0 && "4".equals(orStatus)) {
            return "12";
        } else {
            return orStatus;
        }
    }

    private String handleAllowCancel(String isDisposal, String isCancel) {
        if ("Y".equals(isDisposal)) {
            return "N";
        }
        return isCancel;
    }

    private String handleAllowUpdate(String isDisposal, String isAdMend) {
        if ("Y".equals(isDisposal)) {
            return "N";
        }
        return isAdMend;
    }

    private List<StockFilterResponseDTO> mappingResultOrderBooks(List<Object[]> objects) {

        if (CollectionUtils.isEmpty(objects)) {
            return List.of();
        }
        List<StockFilterResponseDTO> listData = new ArrayList<>(objects.size());
        StockFilterResponseDTO stockFilterResponse;
        for (Object[] row : objects) {

            stockFilterResponse = new StockFilterResponseDTO();
            stockFilterResponse.setStockOrderId(DataUtils.safeToString(row[0]));
            stockFilterResponse.setRefOrderId(DataUtils.safeToString(row[1]));
            stockFilterResponse.setOrderSide(DataUtils.safeToString(row[2]));
            stockFilterResponse.setStatus(mappingStatus(DataUtils.safeToString(row[3]), DataUtils.safeToStringNull(row[4]), DataUtils.safeToString(row[5]), DataUtils.safeToLong(row[6]), DataUtils.safeToString(row[7]), DataUtils.safeToLong(row[13]), DataUtils.safeToString(row[24])));
            stockFilterResponse.setOrderPrice(DataUtils.safeToBigDecimal(row[9]));
            stockFilterResponse.setStockCode(DataUtils.safeToString(row[10]));
            stockFilterResponse.setJoinVolume(row[11] != null ? DataUtils.safeToLong(row[11]) : DataUtils.safeToLong(row[12]));
            stockFilterResponse.setJoin(DataUtils.safeToLong(row[13]));
            stockFilterResponse.setCustomerAccountNumber(DataUtils.safeToString(row[14]));
            stockFilterResponse.setCustomerAccountName(DataUtils.safeToString(row[15]));
            stockFilterResponse.setPhone(DataUtils.safeToString(row[26]));
            stockFilterResponse.setSubAccount(DataUtils.safeToStringIndex(row[16], 1));
            stockFilterResponse.setStartDate(DataUtils.safeToString(row[17]));
            stockFilterResponse.setExpiredDate(DataUtils.safeToString(row[19]));
            stockFilterResponse.setLastModifiedDate(DataUtils.safeToString(row[20]));
            stockFilterResponse.setAccountId(DataUtils.safeToString(row[21]));
            stockFilterResponse.setAllowCancel(handleAllowCancel(DataUtils.safeToString(row[22]), DataUtils.safeToString(row[23])));
            stockFilterResponse.setAllowAmend(handleAllowUpdate(DataUtils.safeToString(row[22]), DataUtils.safeToString(row[24])));
            stockFilterResponse.setOrderCode(DataUtils.safeToString(row[25]));
            stockFilterResponse.setCreateDate(DataUtils.safeToString(row[27]));
            stockFilterResponse.setExecPrice(DataUtils.safeToBigDecimal(row[28]));
            stockFilterResponse.setCustId(DataUtils.safeToString(row[29]));
            stockFilterResponse.setDept(DataUtils.safeToString(row[30]));
            stockFilterResponse.setReCustodyCd(DataUtils.safeToString(row[31]));
            stockFilterResponse.setReFullName(DataUtils.safeToString(row[32]));
            listData.add(stockFilterResponse);
        }
        return listData;
    }
}
