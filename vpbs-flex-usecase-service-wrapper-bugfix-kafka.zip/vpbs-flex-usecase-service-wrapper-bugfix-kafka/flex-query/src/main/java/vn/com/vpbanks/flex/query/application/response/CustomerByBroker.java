package vn.com.vpbanks.flex.query.application.response;

import lombok.Data;

@Data
public class CustomerByBroker {

    private String userId;


    private String accountNo;


    private String cusFullName;


    private String isFavorite;


    private String reCustodyCd;

    private String deptId;

    private String deptName;
}
