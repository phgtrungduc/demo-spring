package vn.com.vpbanks.flex.query.application.service;

import vn.com.vpbanks.flex.query.application.request.StockOrderFilter;
import vn.com.vpbanks.flex.query.application.response.BaseResponse;

public interface OrderService {

    BaseResponse orderBooks(StockOrderFilter stockOrderFilter);
    BaseResponse orderBook(String orderId, String custodyCd);
    BaseResponse orderBookMobiles(StockOrderFilter stockOrderFilter);
    BaseResponse histOrderBookMobiles(StockOrderFilter stockOrderFilter);
    BaseResponse allOrderBookMobiles(StockOrderFilter stockOrderFilter);
    BaseResponse confirmOrderBookMobiles(StockOrderFilter stockOrderFilter);
    BaseResponse confirmHistOrderBookMobiles(StockOrderFilter stockOrderFilter);
    BaseResponse confirmAllOrderBookMobiles(StockOrderFilter stockOrderFilter);


}
