package vn.com.vpbanks.flex.query.application.request;

import lombok.Data;

import java.util.List;

@Data
public class GetEInvestOrderRequest {
    private List<String> afacctno;
    private List<String> txnum;
    private List<String> status;
    private Integer page;
    private Integer size;
}
