package vn.com.vpbanks.flex.query.application.response.Customer;

import lombok.Data;

@Data
public class DepartmentDto {
    private String deptid;
    private String deptname;
}
