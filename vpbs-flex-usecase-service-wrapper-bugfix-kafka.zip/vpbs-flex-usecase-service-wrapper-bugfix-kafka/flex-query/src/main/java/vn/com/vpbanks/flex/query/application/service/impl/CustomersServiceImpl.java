package vn.com.vpbanks.flex.query.application.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import vn.com.vpbanks.flex.query.application.repository.CustomersRepository;
import vn.com.vpbanks.flex.query.application.request.CustomerDirectIndirectIn;
import vn.com.vpbanks.flex.query.application.request.CustomerOfBrokerRequest;
import vn.com.vpbanks.flex.query.application.response.Customer.CurrentDepartmentDto;
import vn.com.vpbanks.flex.query.application.response.Customer.GetDepartmentDto;
import vn.com.vpbanks.flex.query.application.response.Customer.GetUnderBrokerDto;
import vn.com.vpbanks.flex.query.application.response.CustomerByBroker;
import vn.com.vpbanks.flex.query.application.response.CustomerDirectIndirect;
import vn.com.vpbanks.flex.query.application.response.CustomerDirectIndirectDetail;
import vn.com.vpbanks.flex.query.application.service.CustomerService;
import vn.com.vpbanks.flex.query.application.response.BaseResponse;


import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class CustomersServiceImpl implements CustomerService {
    private final CustomersRepository customersRepository;


    @Override
    public BaseResponse getCustomersDirectIndirect(CustomerDirectIndirectIn customerDirectIndirectIn) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        try {
            List<CustomerDirectIndirect> customerDirectIndirects = customersRepository.getCustomerDirectIndirect(customerDirectIndirectIn);

            baseResponse.setData(customerDirectIndirects);
            return baseResponse;

        } catch (Exception ex) {
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            log.error(ex.getMessage(), ex);
        }
        return null;
    }

    @Override
    public BaseResponse getOrderCustomerDirectIndirect(CustomerDirectIndirectIn customerDirectIndirectIn) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        try {
            List<CustomerDirectIndirect> customerDirectIndirects = customersRepository.getOrderCustomerDirectIndirect(customerDirectIndirectIn);

            baseResponse.setData(customerDirectIndirects);
            return baseResponse;

        } catch (Exception ex) {
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            log.error(ex.getMessage(), ex);
        }
        return null;
    }

    @Override
    public BaseResponse getCustomerDirectIndirectDetail(String agencyNo, String preBrokerNo, String accountNo) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        try {
            CustomerDirectIndirectDetail customerDirectIndirectDetail = customersRepository.getCustomerDirectIndirectDetail(agencyNo, preBrokerNo, accountNo);
            baseResponse.setData(customerDirectIndirectDetail);
            return baseResponse;

        } catch (Exception ex) {
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            log.error(ex.getMessage(), ex);
        }
        return null;
    }

    @Override
    public BaseResponse getCustomersByBroker(CustomerOfBrokerRequest request) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        try {

            List<CustomerByBroker> customerDirectIndirects = customersRepository.getCustomersByBroker(request.getFilterCustomerType(), request.getReCustodyCds(), request.getCustodyCds(), request.getDepts(), request.getPage(), request.getSize());
            String data = Objects.isNull(customerDirectIndirects) ? StringUtils.EMPTY : customerDirectIndirects.stream().map(x -> x.getAccountNo()).collect(Collectors.joining(","));
            baseResponse.setData(data);
            return baseResponse;

        } catch (Exception ex) {
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            log.error(ex.getMessage(), ex);

            return baseResponse;
        }
    }

    @Override
    public BaseResponse getUnderBroker(String custId, String searchkey, String dept, String underCustodycd, String getCurren) {

        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        try {
            GetUnderBrokerDto responses = customersRepository.getUnderBroker(
                    custId
                    , searchkey
                    , StringUtils.isEmpty(dept) ? null : Arrays.asList(dept.split(","))
                    , StringUtils.isEmpty(underCustodycd) ? null : Arrays.asList(underCustodycd.split(","))
                    , getCurren
            );
            baseResponse.setData(responses);
            return baseResponse;
        } catch (Exception ex) {
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            log.error(ex.getMessage(), ex);

            return baseResponse;
        }
    }

    @Override
    public BaseResponse getDepartment(String custId, String code, String name) {

        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        try {
            GetDepartmentDto responses = customersRepository.getDepartment(custId, code, name);
            baseResponse = BaseResponse.ofSucceeded();
            baseResponse.setData(responses);
            return baseResponse;
        } catch (Exception ex) {
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            log.error(ex.getMessage(), ex);

            return baseResponse;
        }
    }

    @Override
    public BaseResponse getCurrentDepartment(List<String> listReCustodycd, String reFullName, Integer page, Integer size) {

        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        try {
            List<CurrentDepartmentDto> responses = customersRepository.getCurrentDepartment(listReCustodycd, reFullName, PageRequest.of(Objects.isNull(page) ? 0 : page, Objects.isNull(page) ? 500 : page));
            baseResponse.setData(responses);
            return baseResponse;
        } catch (Exception ex) {
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            log.error(ex.getMessage(), ex);

            return baseResponse;
        }
    }
}
