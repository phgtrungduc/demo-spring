package vn.com.vpbanks.flex.query.application.response;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import vn.com.vpbanks.flex.query.application.utils.BaseRest;


import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BaseResponse<T> implements Serializable {
    //    @SerializedName("s")
    private Integer status;

    @SerializedName("ec")
    private String code;

    @SerializedName("em")
    private String message;

    @SerializedName("d")
    private T data;

    public static <T> BaseResponse<T> ofSucceeded() {
        BaseResponse<T> baseResponse = new BaseResponse<>();
        baseResponse.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_SUCCESS);
        baseResponse.setMessage(BaseRest.SUCCESS.SUCCESS);
        baseResponse.setCode(BaseRest.RESPONSE.OK_CODE);
        return baseResponse;
    }

    public static <T> BaseResponse<T> ofFailedNoResult(String errorMessage) {
        BaseResponse<T> baseResponse = new BaseResponse<>();
        baseResponse.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_ERROR);
        baseResponse.setCode(BaseRest.RESPONSE.FAIL);
        baseResponse.setMessage(BaseRest.ERROR_MESSAGE.NO_RESULT);
        return baseResponse;
    }

    public static <T> BaseResponse<T> ofFailedException(String errorMessage) {
        BaseResponse<T> baseResponse = new BaseResponse<>();
        baseResponse.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_ERROR);
        baseResponse.setCode(BaseRest.ERROR_CODE.ERR500);
        baseResponse.setMessage(errorMessage);
        return baseResponse;
    }

    public static BaseResponse ofFailedFlexResponse(Object data) {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_ERROR);
        baseResponse.setMessage(BaseRest.ERROR_MESSAGE.BAD_REQUEST);
        baseResponse.setCode(BaseRest.ERROR_CODE.ERR400);
        baseResponse.setData(data);
        return baseResponse;
    }

    public static <T> BaseResponse<T> ofSucceeded(Object data) {
        BaseResponse<T> baseResponse = new BaseResponse<>();
        baseResponse.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_SUCCESS);
        baseResponse.setMessage(BaseRest.SUCCESS.SUCCESS);
        baseResponse.setCode(BaseRest.RESPONSE.OK_CODE);
        baseResponse.setData((T) data);
        return baseResponse;
    }
}
