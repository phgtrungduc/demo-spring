package vn.com.vpbanks.flex.query.application.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import vn.com.vpbanks.flex.query.application.utils.enums.Order;
import vn.com.vpbanks.flex.query.application.utils.enums.StockOrderStatus;

import java.math.BigDecimal;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class StockOrderDetailResponse {

    @JsonProperty("stockOrderId")
    private Long stockOrderId;

    @JsonProperty("orderSide")
    private String orderSide;

    @JsonProperty("status")
    private StockOrderStatus status;

    @JsonProperty("symbol")
    private String symbol;

    @JsonProperty("price")
    private BigDecimal price;

    @JsonProperty("jointVolume")
    private Long jointVolume;

    @JsonProperty("volume")
    private Long volume;

    @JsonProperty("customerAccountNumber")
    private String customerAccountNumber;

    @JsonProperty("customerAccountName")
    private String customerAccountName;

    @JsonProperty("subAccount")
    private String subAccount;

    @JsonProperty("orderCode")
    private String orderCode;

    @JsonProperty("transactionId")
    private String transactionId;

    @JsonProperty("lastModifiedDate")
    private String lastModifiedDate;

    @JsonProperty("channel")
    private String channel;

    @JsonProperty("orderId")
    private String orderId;

    @JsonProperty("accountId")
    private String accountId;

    @JsonProperty("phone")
    private String phone;

    @JsonProperty("allowCancel")
    private String allowCancel;

    @JsonProperty("allowAmend")
    private String allowAmend;

    @JsonProperty("flexStatus")
    private String flexStatus;

    @JsonProperty("execPrice")
    private BigDecimal execPrice;

    @JsonProperty("createDate")
    private String createDate;

    @JsonProperty("custId")
    private String custId;

    @JsonProperty("dept")
    private String dept;

    @JsonProperty("reFullName")
    private String reFullName;

    @JsonProperty("reCustodyCd")
    private String reCustodyCd;

    @JsonProperty("orderName")
    private String orderName;

    @JsonProperty("orderCustodyCd")
    private String orderCustodyCd;

    @JsonProperty("orderDept")
    private String orderDept;

}
