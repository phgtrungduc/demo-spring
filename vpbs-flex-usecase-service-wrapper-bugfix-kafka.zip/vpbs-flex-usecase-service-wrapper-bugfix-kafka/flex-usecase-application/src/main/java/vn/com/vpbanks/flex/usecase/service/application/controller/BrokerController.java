package vn.com.vpbanks.flex.usecase.service.application.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.BrokerRequest;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.ReGrpLnkRequest;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.RightOffRegisterRequest;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.TransferStockRequest;
import vn.com.vpbanks.flex.usecase.service.business.broker.service.BrokerService;
import vn.com.vpbanks.flex.usecase.service.common.annotation.ValidFormatDate;
import vn.com.vpbanks.flex.usecase.service.common.dto.request.BaseRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.common.utils.BaseUrl;
import vn.com.vpbanks.flex.usecase.service.trackings.aspect.Tracking;

import javax.validation.Valid;

@Slf4j
@RestController
@RequestMapping(BaseUrl.FLEX_USECASE_SERVICE.V1 + "/flex")
@RequiredArgsConstructor
@Validated
public class BrokerController {

    private final BrokerService brokerService;

    @PostMapping("addBroker")
    @Tracking(action = "CREATE")
    public BaseResponse addBroker(@Valid @RequestBody BaseRequest<BrokerRequest> brokerRequest) {
        String ipAddress = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest().getRemoteAddr();
        return brokerService.addBroker(brokerRequest, ipAddress);
    }

    @PostMapping("assignBrokerToGroup")
    public BaseResponse addReGrpLink(@Valid @RequestBody ReGrpLnkRequest reGrpLnkRequest) {
        String ipAddress = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest().getRemoteAddr();
        return brokerService.addReGrpLink(reGrpLnkRequest, ipAddress);
    }

    @PostMapping("internalStockTransfer")
    public BaseResponse internalStockTransfer(@Valid @RequestBody TransferStockRequest transferStockRequest) {
        String ipAddress = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest().getRemoteAddr();
        return brokerService.internalStockTransfer(transferStockRequest, ipAddress);
    }


    @PostMapping("rightOffRegister")
    public BaseResponse rightOffRegister(@Valid @RequestBody RightOffRegisterRequest rightOffRegisterRequest) {
        String ipAddress = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest().getRemoteAddr();
        return brokerService.addRightOffRegister(rightOffRegisterRequest, ipAddress);
    }

    @GetMapping("getReCustomer")
    public BaseResponse getCustomerOfBroker(@RequestParam("reCusToDyCd") String reCusToDyCd) {
        return brokerService.getCustomerOfBroker(reCusToDyCd);
    }

    /**
     * Api lấy thông tin môi giới
     *
     * @param custoDyCd
     * @return
     */
    @GetMapping("getBrokerInfo")
    public BaseResponse getBrokerInfo(@RequestParam String custoDyCd) {
        return brokerService.getBrokerInfo(custoDyCd);
    }

    /**
     * API lấy thông tin sự quyền
     *
     * @param fromDate
     * @param toDate
     * @param afAcctNo số tiểu khoản
     * @param isCom    đã phân bổ hay chưa
     * @param symbol
     * @param caType   loại sự quyền
     * @return
     */
    @GetMapping("getRightInfo")
    public BaseResponse getRightInfo(@ValidFormatDate @RequestParam String fromDate,
                                     @ValidFormatDate @RequestParam String toDate,
                                     @RequestParam String afAcctNo,
                                     @RequestParam String isCom,
                                     @RequestParam(required = false) String symbol,
                                     @RequestParam(required = false) String caType) {
        return brokerService.getRightInfo(fromDate, toDate, afAcctNo, isCom, symbol, caType);
    }
}
