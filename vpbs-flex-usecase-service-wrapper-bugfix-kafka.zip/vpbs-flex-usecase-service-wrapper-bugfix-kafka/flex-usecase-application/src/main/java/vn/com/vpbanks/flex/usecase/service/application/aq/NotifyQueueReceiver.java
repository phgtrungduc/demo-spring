package vn.com.vpbanks.flex.usecase.service.application.aq;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;
import vn.com.vpbanks.flex.usecase.service.common.utils.CommonUtils;
import vn.com.vpbanks.flex.usecase.service.business.aq.service.NotificationAdvancedQueueService;

import java.util.Map;

@Component
@Slf4j
@RequiredArgsConstructor
@ConditionalOnProperty(prefix = "vpbanks.flex.features", name = "notification-queue-enabled", havingValue = "true")
public class NotifyQueueReceiver {


    private final NotificationAdvancedQueueService notificationAdvancedQueueService;

    @JmsListener(destination = "${vpbanks.aq.notifyQueue}", containerFactory = "jmsListenerContainerFactory")
    public void handleQueueNotify(String message) {
        if (message == null) {
            log.error("NULL value message ");
            return;
        }

        log.debug("NotifyQueueReceiver received the message : {} ", message);
        Map<String, String> messageMap = CommonUtils.handleAQMessage(message);
        notificationAdvancedQueueService.handleNotificationQueue(messageMap);
    }
}

