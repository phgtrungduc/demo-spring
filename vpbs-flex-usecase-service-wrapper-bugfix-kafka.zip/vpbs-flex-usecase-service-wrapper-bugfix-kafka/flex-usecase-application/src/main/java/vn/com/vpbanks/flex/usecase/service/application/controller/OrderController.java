package vn.com.vpbanks.flex.usecase.service.application.controller;

import com.google.gson.Gson;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;
import vn.com.vpbanks.flex.usecase.service.business.order.request.*;
import vn.com.vpbanks.flex.usecase.service.common.constants.KafkaTopicConstants;
import vn.com.vpbanks.flex.usecase.service.common.dto.request.BaseRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.common.utils.BaseUrl;
import vn.com.vpbanks.flex.usecase.service.trackings.aspect.Tracking;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.service.FlexInquiryOrderService;
import vn.com.vpbanks.flex.usecase.service.business.order.service.OrderService;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;

@Slf4j
@RestController
@RequestMapping(BaseUrl.FLEX_USECASE_SERVICE.V1 + "/flex")
@RequiredArgsConstructor
public class OrderController {
    private final FlexInquiryOrderService flexInquiryOrderService;

    private final OrderService orderService;
    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;


    @DeleteMapping(value = "cancelOrder")
    @Tracking(action = "CANCEL")
    public BaseResponse cancelOrder(@Valid @RequestBody BaseRequest<CancelOrderRequest> cancelOrderRequestBaseRequest, HttpServletRequest httpServletRequest) {
        return orderService.cancelOrder(cancelOrderRequestBaseRequest, httpServletRequest.getRemoteAddr());
    }

    @PostMapping(value = "/postOrders")
    public BaseResponse postOrders(@RequestBody @Valid BaseRequest<PostOrdersRequests> postOrdersDTO, HttpServletRequest httpServletRequest) {
        String ipAddress = httpServletRequest.getHeader("x-forwarded-for");
        if (ipAddress == null) {
            ipAddress = httpServletRequest.getRemoteAddr();
        }
        return orderService.saveOder(postOrdersDTO, ipAddress);
    }

    @GetMapping(value = "/detailOrder")
    public BaseResponse getInquiryDetailOrder(@RequestParam String accountId,
                                              @RequestParam String orderId,
                                              @RequestParam String orderType,
                                              @RequestParam String orderStatus,
                                              @RequestParam String symbol) {
        return flexInquiryOrderService.getDetailOrder(accountId, orderId, orderType, symbol, orderStatus);
    }


    @PutMapping("updateOrder")
    @Tracking(action = "UPDATE")
    public BaseResponse editOrder(@Valid @RequestBody BaseRequest<OrderUpdateReq> orderUpdateRequest) {
        return orderService.updateOrder(orderUpdateRequest);
    }

    @GetMapping("order/{accountId}/history-order-match")
    public BaseResponse getHistoryOrderMatch(@PathVariable(name = "accountId") String accountId,
                                             @RequestParam("fromDate") String fromDate,
                                             @RequestParam("toDate") String toDate,
                                             @RequestParam("symbol") String symbol,
                                             @RequestParam("execType") String execType,
                                             @RequestParam(value = "offset", required = false) Integer offset,
                                             @RequestParam(value = "limit", required = false) Integer limit) {
        return orderService.getHistoryOrderMatch(accountId, fromDate, toDate, symbol, execType, offset, limit);
    }

    @GetMapping("order/history-order-match")
    public BaseResponse getHistoryOrderMatchByListSubAccounts(@Valid @RequestParam(name = "accountIds") List<String> accountIds,
                                                              @RequestParam("fromDate") String fromDate,
                                                              @RequestParam("toDate") String toDate,
                                                              @RequestParam("symbol") String symbol,
                                                              @RequestParam("execType") String execType) {
        return orderService.getHistoryOrderMatchByListSubAccounts(accountIds, fromDate, toDate, symbol, execType);
    }

    @GetMapping("order/history-order")
    public BaseResponse getHistoryOrder(@RequestParam(name = "accountId") String accountId,
                                        @RequestParam("fromDate") String fromDate,
                                        @RequestParam("toDate") String toDate,
                                        @RequestParam(value = "symbol", required = false) String symbol,
                                        @RequestParam(value = "execType", required = false) String execType,
                                        @RequestParam(value = "orsStatus", required = false) String orsStatus,
                                        @RequestParam(value = "offset", required = false) Integer offset,
                                        @RequestParam(value = "limit", required = false) Integer limit) {
        return orderService.getHistoryOrder(accountId, fromDate, toDate, symbol, execType, orsStatus, offset, limit);
    }

    @KafkaListener(groupId = "flex", topics = "Connector_Flex_PostOrder",
            containerFactory = "KafkaListenerContainerFactory")
    public void receivedMessagePostOrder(String message) {
        log.info("receivedMessage post order {}", message);
        Gson gson = new Gson();
        BaseRequest<PostOrdersRequests> postOrderReq = gson.fromJson(message, BasePostOrdersRequests.class);
        var data = postOrderReq.getData();
        data.setVia(data.getVia().toUpperCase());
        postOrderReq.setData(data);

        orderService.postOrderKafka(postOrderReq);
    }

    @KafkaListener(groupId = "flex", topics = "Connector_Flex_CancelOrder",
            containerFactory = "KafkaListenerContainerFactory")
    public void receivedMessageCancelOrder(String message) {
        log.info("receivedMessageCancelOrder cancel order {}", message);
        Gson gson = new Gson();
        BaseRequest<CancelOrderRequest> cancelOrderRequestBaseRequest = gson.fromJson(message, BaseCancelOrdersRequest.class);
        var data = cancelOrderRequestBaseRequest.getData();
        data.setVia(data.getVia().toUpperCase());
        cancelOrderRequestBaseRequest.setData(data);

        orderService.cancelOrderKafka(cancelOrderRequestBaseRequest);
    }


    @KafkaListener(groupId = "flex", topics = "Connector_Flex_PostConditionOrder",
            containerFactory = "KafkaListenerContainerFactory")
    public void receivedMessageConditionOrder(String message) {
        log.info("receivedMessageCondition order {}", message);
        Gson gson = new Gson();
        BaseRequest<PostOrdersRequests> postOrderReq = gson.fromJson(message, BasePostOrdersRequests.class);
        var data = postOrderReq.getData();
        data.setVia(data.getVia().toUpperCase());
        postOrderReq.setData(data);
        orderService.postOrderConditionKafka(postOrderReq);
    }

    @KafkaListener(groupId = "flex", topics = "Connector_Flex_CancelConditionOrder",
            containerFactory = "KafkaListenerContainerFactory")
    public void receivedMessageConditionCancelOrder(String message) {
        log.info("receivedMessageConditionCancelOrder cancel order {}", message);
        Gson gson = new Gson();
        BaseRequest<CancelOrderRequest> cancelOrderRequestBaseRequest = gson.fromJson(message, BaseCancelOrdersRequest.class);
        var data = cancelOrderRequestBaseRequest.getData();
        data.setVia(data.getVia().toUpperCase());
        cancelOrderRequestBaseRequest.setData(data);
        orderService.cancelOrderConditionKafka(cancelOrderRequestBaseRequest);
    }

    @KafkaListener(groupId = "flex", topics = KafkaTopicConstants.FLEX_POST_ORDER_CW_TOPIC,
            containerFactory = "KafkaListenerContainerFactory")
    public void receivePostOrderCoveredWarrant(String message) {
        log.info("receive post order message from covered warrant : {}", message);
        Gson gson = new Gson();
        BaseRequest<PostOrdersRequests> postOrderReq = gson.fromJson(message, BasePostOrdersRequests.class);
        var data = postOrderReq.getData();
        data.setVia(data.getVia().toUpperCase());
        postOrderReq.setData(data);
        orderService.postOrderKafka(postOrderReq);
    }

    @KafkaListener(groupId = "flex", topics = KafkaTopicConstants.FLEX_CANCEL_ORDER_CW_TOPIC,
            containerFactory = "KafkaListenerContainerFactory")
    public void receiveCancelOrderCoveredWarrant(String message) {
        log.info("receive cancel order message from covered warrant : {}", message);
        Gson gson = new Gson();
        BaseRequest<CancelOrderRequest> cancelOrderRequestBaseRequest = gson.fromJson(message, BaseCancelOrdersRequest.class);
        var data = cancelOrderRequestBaseRequest.getData();
        data.setVia(data.getVia().toUpperCase());
        cancelOrderRequestBaseRequest.setData(data);
        orderService.cancelOrderKafka(cancelOrderRequestBaseRequest);
    }


    @PostMapping("/testReceivedMessageConditionOrder")
    public void ReceivedMessageConditionOrder(@RequestBody String message) {
        log.info("testReceivedMessageConditionOrder post order {}", message);
        kafkaTemplate.send("Connector_Flex_PostConditionOrder", message);
    }

    @PostMapping("/testReceivedMessageConditionCancelOrder")
    public void testReceivedMessageConditionCancelOrder(@RequestBody String message) {
        log.info("receivedMessageConditionCancelOrder cancel order {}", message);
        kafkaTemplate.send("Connector_Flex_CancelConditionOrder", message);
    }

    @PostMapping("/orderBook-mobile")
    public BaseResponse orderBook(@RequestBody  StockOrderFilter stockOrderFilter) {
        return orderService.orderBooks(stockOrderFilter);
    }
}
