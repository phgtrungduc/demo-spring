package vn.com.vpbanks.flex.usecase.service.application.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.request.CustomerDirectIndirectIn;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.request.CustomerOfBrokerRequest;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.service.CustomerService;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.common.utils.BaseUrl;
import vn.com.vpbanks.flex.usecase.service.trackings.aspect.Tracking;

import java.util.List;

@Slf4j
@RestController
@RequestMapping(BaseUrl.FLEX_USECASE_SERVICE.V1 + "/")
@RequiredArgsConstructor
public class Customer {

    private final CustomerService customerService;

    @PostMapping("direct-indirect/customers")
    @Tracking(action = "SEARCH")
    public BaseResponse customers(@RequestBody CustomerDirectIndirectIn customerDirectIndirectIn) {
        return customerService.getCustomersDirectIndirect(customerDirectIndirectIn);
    }

    @PostMapping("order/direct-indirect/customers")
    @Tracking(action = "SEARCH")
    public BaseResponse OrderCustomerDirectIndirects(@RequestBody CustomerDirectIndirectIn customerDirectIndirectIn) {
        return customerService.getOrderCustomerDirectIndirect(customerDirectIndirectIn);
    }

    @GetMapping("agency/{agencyNo}-{preBrokerNo}/direct-indirect/customers/{accountNo}")
    @Tracking(action = "SEARCH")
    public BaseResponse customersDetail(@PathVariable String agencyNo,@PathVariable String preBrokerNo, @PathVariable String accountNo) {
        return customerService.getCustomerDirectIndirectDetail(agencyNo, preBrokerNo, accountNo);
    }

    @PostMapping("direct-indirect/brokes/customers")
    @Tracking(action = "SEARCH")
    public BaseResponse getCustomersByBroker(@RequestBody CustomerOfBrokerRequest customerDirectIndirectIn) {
        return customerService.getCustomersByBroker(customerDirectIndirectIn);
    }

}
