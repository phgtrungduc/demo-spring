package vn.com.vpbanks.flex.usecase.service.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication
@ComponentScan("vn.com.vpbanks")
@EntityScan("vn.com.vpbanks")
@EnableJpaRepositories("vn.com.vpbanks")
@EnableMongoRepositories("vn.com.vpbanks")
public class FlexUsecaseApplication {

    public static void main(String[] args) {
        SpringApplication.run(FlexUsecaseApplication.class, args);
    }

}
