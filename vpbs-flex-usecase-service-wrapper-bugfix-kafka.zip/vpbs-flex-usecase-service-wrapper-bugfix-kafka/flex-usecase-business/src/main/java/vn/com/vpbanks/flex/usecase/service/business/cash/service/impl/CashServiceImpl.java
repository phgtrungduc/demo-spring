package vn.com.vpbanks.flex.usecase.service.business.cash.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import vn.com.vpbanks.flex.usecase.service.business.cash.repository.CashRepository;
import vn.com.vpbanks.flex.usecase.service.business.cash.repository.vo.BankNoStroDVO;
import vn.com.vpbanks.flex.usecase.service.business.cash.repository.vo.CashStatementHistVO;
import vn.com.vpbanks.flex.usecase.service.business.cash.request.*;
import vn.com.vpbanks.flex.usecase.service.business.cash.response.*;
import vn.com.vpbanks.flex.usecase.service.business.cash.service.CashService;
import vn.com.vpbanks.flex.usecase.service.business.mapper.BankNoStroMapper;
import vn.com.vpbanks.flex.usecase.service.business.mapper.CashMapper;
import vn.com.vpbanks.flex.usecase.service.common.dto.request.BaseRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.StoredProcedureError;
import vn.com.vpbanks.flex.usecase.service.common.exceptions.ApiException;
import vn.com.vpbanks.flex.usecase.service.common.utils.BaseRest;
import vn.com.vpbanks.flex.usecase.service.common.utils.CommonUtils;
import vn.com.vpbanks.flex.usecase.service.common.utils.MessageUtil;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class CashServiceImpl implements CashService {

    private static final String SUCCESS_CODE = "0";
    private static final String EMPTY_STRING = "";
    private final CashRepository cashRepository;
    private final BankNoStroMapper bankNoStroMapper;
    private final MessageUtil messageUtil;

    @Autowired
    private CashMapper cashMapper;

    @Override
    public BaseResponse getBankNoStro() {
        BaseResponse baseResponse;
        try {
            List<BankNoStroDVO> bankNoStroDVOS = cashRepository.getBankNoStro();
            List<BankNoStrResponse> bankNoStrResponses = bankNoStroMapper.fromListSourceToListTarget(bankNoStroDVOS);

            baseResponse = BaseResponse.ofSucceeded();
            baseResponse.setData(bankNoStrResponses);

        } catch (Exception ex) {
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
        }
        return baseResponse;
    }

    @Override
    public BaseResponse increaseMoney(BaseRequest<IncreaseMoneyRequest> increaseMoneyRequestBaseRequest, String ipAddress) {

        BaseResponse baseResponse;
        String requestId = increaseMoneyRequestBaseRequest.getRequestId();
        IncreaseMoneyRequest data = increaseMoneyRequestBaseRequest.getData();
        this.validateIncreaseMoney(data);

        StoredProcedureError response = cashRepository.increaseMoney(requestId, data.getCustId(),
                data.getAccountId(), data.getBankId(), data.getAmount(), data.getDesc(), data.getIsNotifySms(), data.getVia(), ipAddress);

        if (SUCCESS_CODE.equals(response.getErrCd())) {
            baseResponse = BaseResponse.ofSucceeded();
            baseResponse.setData(response);
            return baseResponse;
        }

        baseResponse = BaseResponse.ofFailedFlexResponse(response);
        return baseResponse;
    }

    @Override
    public BaseResponse internalTransfer(BaseRequest<InternalTransferRequest> internalTransferRequestBaseRequest, String ipAddress) {
        BaseResponse baseResponse;
        try {

            InternalTransferRequest data = internalTransferRequestBaseRequest.getData();
            String requestId = internalTransferRequestBaseRequest.getRequestId();
            if (data.getAmount() % 1 != 0) {
                BaseResponse responses = new BaseResponse();
                responses.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_ERROR);
                responses.setMessage(BaseRest.ERROR_MESSAGE.VALID_AMOUNT);
                responses.setCode(BaseRest.ERROR_CODE.ERR400);
                responses.setData(null);
                return responses;
            }
            StoredProcedureError response = cashRepository.internalTransfer(data, ipAddress, requestId);
            if (SUCCESS_CODE.equals(response.getErrCd())) {
                baseResponse = BaseResponse.ofSucceeded();
                baseResponse.setData(response);
                return baseResponse;
            }
            baseResponse = BaseResponse.ofFailedFlexResponse(response.getErrParam());
            baseResponse.setData(response);

            return baseResponse;
        } catch (Exception ex) {
            log.error("internal transfer error {}", CommonUtils.handlerError(ex));
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            return baseResponse;
        }
    }

    @Override
    public BaseResponse blockAmount(BaseRequest<BlockAmountRequest> blockAmountRequestBaseRequest, String ipAddress) {
        BaseResponse baseResponse;
        try {
            BlockAmountRequest data = blockAmountRequestBaseRequest.getData();
            String requestId = blockAmountRequestBaseRequest.getRequestId();

            StoredProcedureError response = cashRepository.blockAmount(data, ipAddress, requestId);

            if (SUCCESS_CODE.equals(response.getErrCd())) {
                baseResponse = BaseResponse.ofSucceeded();
                baseResponse.setData(response);
                return baseResponse;
            }
            baseResponse = BaseResponse.ofFailedFlexResponse(response.getErrParam());
            baseResponse.setData(response);

            return baseResponse;
        } catch (Exception ex) {
            log.error("block amount error {}", CommonUtils.handlerError(ex));
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            return baseResponse;
        }
    }

    @Override
    public BaseResponse unBlockAmount(BaseRequest<BlockAmountRequest> blockAmountRequestBaseRequest, String ipAddress) {
        BaseResponse baseResponse;
        try {
            BlockAmountRequest data = blockAmountRequestBaseRequest.getData();
            String requestId = blockAmountRequestBaseRequest.getRequestId();

            StoredProcedureError response = cashRepository.unBlockAmount(data, ipAddress, requestId);

            if (SUCCESS_CODE.equals(response.getErrCd())) {
                baseResponse = BaseResponse.ofSucceeded();
                baseResponse.setData(response);
                return baseResponse;
            }
            baseResponse = BaseResponse.ofFailedFlexResponse(response.getErrParam());
            baseResponse.setData(response);

            return baseResponse;
        } catch (Exception ex) {
            log.error("unblock amount error {}", CommonUtils.handlerError(ex));
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            return baseResponse;
        }
    }

    @Override
    public BaseResponse getCashStatementHist(List<CashStatementHistRequest> cashStatementHistRequestList) {
        BaseResponse baseResponse;
        Map<String, List<CashStatementHistResponse>> responseData = new HashMap<>();
        try {
            cashStatementHistRequestList.forEach(
                    cashStatementHistRequest -> {
                        int compareDate = compareDate(cashStatementHistRequest);
                        if (compareDate > 0) {
                            throw new ApiException("From Date must before To Date");
                        }
                        List<CashStatementHistVO> cashStatementHists = cashRepository.getCashStatementHist(cashStatementHistRequest);
                        List<CashStatementHistResponse> cashStatementHistResponses = cashMapper.fromListSourceToListTarget(cashStatementHists);
                        if (!CollectionUtils.isEmpty(cashStatementHistResponses)) {
                            responseData.put(cashStatementHistResponses.get(0).getAfAcctNo(), cashStatementHistResponses);
                        }
                    }
            );
            baseResponse = BaseResponse.ofSucceeded();
            baseResponse.setData(responseData);
            return baseResponse;
        } catch (Exception ex) {
            log.error("getCashStatementHist error {}", CommonUtils.handlerError(ex));
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            return baseResponse;
        }
    }

    @Override
    public BaseResponse<Object> getHoldBalance(String custodyCd, String accountNo) {
        List<HoldBalanceResponse> holdBalance = cashRepository.getHoldBalance(custodyCd, accountNo);
        BaseResponse<Object> baseResponse = BaseResponse.ofSucceeded();
        baseResponse.setData(holdBalance);
        return baseResponse;
    }

    @Override
    public BaseResponse<Object> getHoldStock(String custodyCd, String accountNo) {
        List<HoldStockResponse> holdStock = cashRepository.getHoldStock(custodyCd, accountNo);
        BaseResponse<Object> baseResponse = BaseResponse.ofSucceeded();
        baseResponse.setData(holdStock);
        return baseResponse;
    }

    @Override
    public BaseResponse<Object> getUnHoldEOD() {
        List<UnHoldEODResponse> unHoldEOD = cashRepository.getUnHoldEOD();
        BaseResponse<Object> baseResponse = BaseResponse.ofSucceeded();
        baseResponse.setData(unHoldEOD);
        return baseResponse;
    }

    @Override
    public BaseResponse<Object> holdBalance(HoldBalanceRequest holdBalanceRequest) {
        log.info("[holdBalance] request :{}", holdBalanceRequest);
        BaseResponse<Object> baseResponse;
        StoredProcedureError spResponse = cashRepository.holdBalance(holdBalanceRequest);
        if (SUCCESS_CODE.equals(spResponse.getErrCd())) {
            baseResponse = BaseResponse.ofSucceeded();
            return baseResponse;
        }
        throw new ApiException(spResponse.getErrCd(), spResponse.getErrParam(), null);
    }

    @Override
    public BaseResponse<Object> unHoldBalance(UnHoldBalanceRequest unHoldBalanceRequest) {
        log.info("[unHoldBalance] request :{}", unHoldBalanceRequest);
        BaseResponse<Object> baseResponse;
        StoredProcedureError spResponse = cashRepository.unHoldBalance(unHoldBalanceRequest);
        if (SUCCESS_CODE.equals(spResponse.getErrCd())) {
            baseResponse = BaseResponse.ofSucceeded();
            return baseResponse;
        }

        throw new ApiException(spResponse.getErrCd(), spResponse.getErrParam(), null);
    }

    @Override
    public BaseResponse<Object> holdStock(HoldStockRequest holdStockRequest) {
        log.info("[holdStock] request :{}", holdStockRequest);
        BaseResponse<Object> baseResponse;
        StoredProcedureError spResponse = cashRepository.holdStock(holdStockRequest);
        if (SUCCESS_CODE.equals(spResponse.getErrCd())) {
            baseResponse = BaseResponse.ofSucceeded();
            return baseResponse;
        }

        throw new ApiException(spResponse.getErrCd(), spResponse.getErrParam(), null);
    }

    @Override
    public BaseResponse<Object> unHoldStock(UnHoldStockRequest unHoldStockRequest) {
        log.info("[unHoldStock] request :{}", unHoldStockRequest);
        BaseResponse<Object> baseResponse;
        StoredProcedureError spResponse = cashRepository.unHoldStock(unHoldStockRequest);
        if (SUCCESS_CODE.equals(spResponse.getErrCd())) {
            baseResponse = BaseResponse.ofSucceeded();
            return baseResponse;
        }

        throw new ApiException(spResponse.getErrCd(), spResponse.getErrParam(), null);
    }

    private void validateIncreaseMoney(IncreaseMoneyRequest increaseMoneyRequest) {
        String notifySmsYn = increaseMoneyRequest.getIsNotifySms();
        List<String> notifySmsValues = List.of("Y", "N");

        if (!notifySmsValues.contains(notifySmsYn)) {
            String mgsErr = messageUtil.getMessage("ERR101002");
            throw new ApiException(BaseRest.ERROR_CODE.ERR400, BaseRest.ERROR_MESSAGE.BAD_REQUEST, mgsErr);
        }

        if (Objects.isNull(increaseMoneyRequest.getDesc())) {
            increaseMoneyRequest.setDesc(EMPTY_STRING);
        }
    }

    @Override
    public BaseResponse getSecuritiesStatement(String accountId, String fromDate, String toDate, String symbol) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        try {
            if (accountId.isEmpty()) {
                BaseResponse responses = new BaseResponse();
                responses.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_ERROR);
                responses.setMessage(BaseRest.ERROR_MESSAGE.INPUT_ACCOUNTID);
                responses.setCode(BaseRest.ERROR_CODE.ERR400);
                responses.setData("");
                return responses;
            } else if (symbol.isEmpty()) {
                BaseResponse responses = new BaseResponse();
                responses.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_ERROR);
                responses.setMessage(BaseRest.ERROR_MESSAGE.INPUT_NO_VALIT);
                responses.setCode(BaseRest.ERROR_CODE.ERR400);
                responses.setData("");
                return responses;
            } else if (fromDate.isEmpty()) {
                BaseResponse responses = new BaseResponse();
                responses.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_ERROR);
                responses.setMessage(BaseRest.ERROR_MESSAGE.INPUT_FROMDATE);
                responses.setCode(BaseRest.ERROR_CODE.ERR400);
                responses.setData("");
                return responses;
            } else if (toDate.isEmpty()) {
                BaseResponse responses = new BaseResponse();
                responses.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_ERROR);
                responses.setMessage(BaseRest.ERROR_MESSAGE.INPUT_TODATE);
                responses.setCode(BaseRest.ERROR_CODE.ERR400);
                responses.setData("");
                return responses;
            } else if (!isValidFormat(fromDate)) {
                BaseResponse responses = new BaseResponse();
                responses.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_ERROR);
                responses.setMessage(BaseRest.ERROR_MESSAGE.VALIDATE_FROMDATE);
                responses.setCode(BaseRest.ERROR_CODE.ERR400);
                responses.setData("");
                return responses;
            } else if (!isValidFormat(toDate)) {
                BaseResponse responses = new BaseResponse();
                responses.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_ERROR);
                responses.setMessage(BaseRest.ERROR_MESSAGE.VALIDATE_TODATE);
                responses.setCode(BaseRest.ERROR_CODE.ERR400);
                responses.setData("");
                return responses;
            } else if (checkCompareFromDateAndToDate(fromDate, toDate) == 1) {
                BaseResponse responses = new BaseResponse();
                responses.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_ERROR);
                responses.setMessage(BaseRest.ERROR_MESSAGE.CHECKFROMDATE);
                responses.setCode(BaseRest.ERROR_CODE.ERR400);
                responses.setData("");
                return responses;
            } else if (checkCompareFromDateAndToDate(fromDate, toDate) == 0) {
                BaseResponse responses = new BaseResponse();
                responses.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_SUCCESS);
                responses.setMessage(BaseRest.SUCCESS.SUCCESS);
                responses.setCode(BaseRest.RESPONSE.OK_CODE);
                responses.setData("");
                return responses;
            }
            List<SecuritiesStatementResponse> storedProcedureResponse = cashRepository.getSecuritiesStatement(accountId, fromDate, toDate, symbol);
            if (storedProcedureResponse == null) {
                BaseResponse responses = new BaseResponse();
                responses.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_SUCCESS);
                responses.setMessage(BaseRest.ERROR_MESSAGE.SYMBOL);
                responses.setCode(BaseRest.RESPONSE.OK_CODE);
                responses.setData(null);
                return responses;
            }
            baseResponse = BaseResponse.ofSucceeded();
            baseResponse.setData(storedProcedureResponse);
            return baseResponse;
        } catch (Exception ex) {
            log.error("getSecuritiesStatement error {}", CommonUtils.handlerError(ex));
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            return baseResponse;
        }

    }

    public static int checkCompareFromDateAndToDate(String fromDate, String toDate) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date date1 = sdf.parse(fromDate);
        Date date2 = sdf.parse(toDate);
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        cal1.setTime(date1);
        cal2.setTime(date2);

        int checkDate = 0;

        if (cal1.after(cal2)) {
            checkDate = 1;
            return checkDate;
        }
        if (cal1.before(cal2)) {
            checkDate = 2;
            return checkDate;
        }
        return checkDate;
    }


    public static boolean isValidFormat(String value) {
        LocalDateTime ldt = null;
        Locale locale = null;
        DateTimeFormatter fomatter = DateTimeFormatter.ofPattern("dd/MM/yyyy", locale.ENGLISH);

        try {
            ldt = LocalDateTime.parse(value, fomatter);
            String result = ldt.format(fomatter);
            return result.equals(value);
        } catch (DateTimeParseException e) {
            try {
                LocalDate ld = LocalDate.parse(value, fomatter);
                String result = ld.format(fomatter);
                return result.equals(value);
            } catch (DateTimeParseException exp) {
                try {
                    LocalTime lt = LocalTime.parse(value, fomatter);
                    String result = lt.format(fomatter);
                    return result.equals(value);
                } catch (DateTimeParseException e2) {
                }
            }
        }

        return false;
    }


    private int compareDate(CashStatementHistRequest cashStatementHistRequest) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
        int result = 0;
        try {
            Date fromDate = sdf.parse(cashStatementHistRequest.getFromDate());
            Date toDate = sdf.parse(cashStatementHistRequest.getToDate());
            result = fromDate.compareTo(toDate);
            return result;
        } catch (ParseException ex) {
            log.error("compareDate error {}", CommonUtils.handlerError(ex));
            throw new ApiException("Format of From Date or To Date incorrect");
        }
    }
}
