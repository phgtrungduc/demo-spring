package vn.com.vpbanks.flex.usecase.service.business.customer.repository.vo;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Builder
public class BeneficiaryAccountDVO {
    private String bankCode;
    private String bankName;
    private String bankAccountCode;
    private String bankAccountName;
    private String branchId;
    private String branchCode;
    private String branchName;
    private String isBankBond;
    private BigDecimal bankId;
}
