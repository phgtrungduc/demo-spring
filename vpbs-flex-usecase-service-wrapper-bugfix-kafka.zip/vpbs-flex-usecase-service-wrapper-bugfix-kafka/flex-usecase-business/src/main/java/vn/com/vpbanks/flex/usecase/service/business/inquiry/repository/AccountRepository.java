package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository;

import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.SubAccountAvailableBalanceDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.SummaryAccountVO;

public interface AccountRepository {

    public SubAccountAvailableBalanceDVO getSubAccountAvailableBalance(String accountId);

    SummaryAccountVO getSummaryAccount(String accountId);
}
