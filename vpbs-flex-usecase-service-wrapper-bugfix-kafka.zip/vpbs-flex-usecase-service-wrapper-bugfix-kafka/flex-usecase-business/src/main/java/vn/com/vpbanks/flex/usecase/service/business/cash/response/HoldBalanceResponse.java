package vn.com.vpbanks.flex.usecase.service.business.cash.response;

import lombok.*;

import java.math.BigDecimal;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class HoldBalanceResponse {
    private String custodyCd;
    private String customerId;
    private String accountNo;
    private BigDecimal advanceLine;
}
