package vn.com.vpbanks.flex.usecase.service.business.aq.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import vn.com.vpbanks.flex.usecase.service.business.aq.request.AccountNotificationFromQueue;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountNotification {
    private String eventType;
    private String custoDyCd;
    private String custId;
    private String fullName;
    private String mobileSms;
    private String idCode;
    private String address;
    private String idPlace;
    private String email;
    private String status;

    public AccountNotification(AccountNotificationFromQueue queue) {
        this.eventType = queue.getEVENTTYPE();
        this.custoDyCd = queue.getCUSTODYCD();
        this.custId = queue.getCUSTID();
        this.fullName = queue.getFULLNAME();
        this.mobileSms = queue.getMOBILESMS();
        this.idCode = queue.getIDCODE();
        this.address = queue.getADDRESS();
        this.idPlace = queue.getIDPLACE();
        this.email = queue.getEMAIL();
        this.status = queue.getSTATUS();
    }
}
