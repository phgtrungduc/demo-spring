package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class SummaryAccountVO {

    private BigDecimal balance;
    private BigDecimal ciBalance;
    private BigDecimal tdBalance;
    private BigDecimal intBalance;
    private BigDecimal careceiving;
    private BigDecimal receivingT1;
    private BigDecimal receivingT2;
    private BigDecimal receivingT3;
    private BigDecimal securitiesAmt;
    private BigDecimal totalDebtAmt;
    private BigDecimal secureAmt;
    private BigDecimal trfBuyAmt;
    private BigDecimal t0debtAmt;
    private BigDecimal advancedAmt;
    private BigDecimal dfDebtAmt;
    private BigDecimal tdDebtAmt;
    private BigDecimal ciDepoFeeAcr;
    private BigDecimal depositFeeAmtCt;
    private BigDecimal netAssetValue;
    private BigDecimal mrCrLimit;
    private BigDecimal debtAmt;
    private BigDecimal advanceMaxAmtFee;
    private BigDecimal receivingAmt;
    private BigDecimal marginRate;
    private BigDecimal smsFeeAmt;
    private BigDecimal iBrokerFeeAmt;
    private BigDecimal holdBalance;
    private BigDecimal mrIrate;
    private BigDecimal mrmRate;
    private BigDecimal alvpayamt;
    private BigDecimal ciDePoFee;
    private BigDecimal tdIntAmt;
    private BigDecimal addVnd;
    private BigDecimal addVnd1;
    private Character coreBank;
    private BigDecimal bankAcctNo;
    private String bankName;
    private BigDecimal emkAmt;
    private String baldefovd;
    private BigDecimal eInvestAmt;
    private BigDecimal eInvestFix;
    private BigDecimal marginAmt;
    private String accountNumber;

    public SummaryAccountVO(Object[] object) {
        this.balance = (BigDecimal) object[0];
        this.ciBalance = (BigDecimal) object[1];
        this.tdBalance = (BigDecimal) object[2];
        this.intBalance = (BigDecimal) object[3];
        this.careceiving = (BigDecimal) object[4];
        this.receivingT1 = (BigDecimal) object[5];
        this.receivingT2 = (BigDecimal) object[6];
        this.receivingT3 = (BigDecimal) object[7];
        this.securitiesAmt = (BigDecimal) object[8];
        this.totalDebtAmt = (BigDecimal) object[9];
        this.secureAmt = (BigDecimal) object[10];
        this.trfBuyAmt = (BigDecimal) object[11];
        this.marginAmt = (BigDecimal) object[12];
        this.t0debtAmt = (BigDecimal) object[13];
        this.advancedAmt = (BigDecimal) object[14];
        this.dfDebtAmt = (BigDecimal) object[15];
        this.tdDebtAmt = (BigDecimal) object[16];
        this.ciDepoFeeAcr = (BigDecimal) object[17];
        this.depositFeeAmtCt= (BigDecimal) object[18];
        this.netAssetValue = (BigDecimal) object[19];
        this.mrCrLimit = (BigDecimal) object[20];
        this.debtAmt = (BigDecimal) object[21];
        this.advanceMaxAmtFee = (BigDecimal) object[22];
        this.receivingAmt = (BigDecimal) object[23];
        this.marginRate = (BigDecimal) object[24];
        this.smsFeeAmt = (BigDecimal) object[25];
        this.iBrokerFeeAmt = (BigDecimal) object[26];
        this.holdBalance = (BigDecimal) object[27];
        this.mrIrate = (BigDecimal) object[28];
        this.mrmRate = (BigDecimal) object[29];
        this.alvpayamt = convertBigDecimal(object[30]);
        this.ciDePoFee = (BigDecimal) object[31];
        this.tdIntAmt = (BigDecimal) object[32];
        this.addVnd = (BigDecimal) object[33];
        this.addVnd1 = convertBigDecimal(object[34]);
        this.coreBank = convertChar(object[35]);
        this.bankAcctNo = convertBigDecimal(object[36]);
        this.bankName = convertStr(object[37]);
        this.emkAmt = convertBigDecimal(object[38]);
        this.baldefovd = convertStr(object[39]);
        this.eInvestAmt =  convertBigDecimal(object[40]);
        this.eInvestFix = convertBigDecimal(object[41]);
    }

    private BigDecimal convertBigDecimal(Object object) {
        try {
            return object == null ? null : new BigDecimal(object.toString());
        } catch (Exception e) {
            return null;
        }
    }

    private Character convertChar(Object object) {
        String str = object == null ? null : String.valueOf(object);
        if (str == null || str.isBlank()) {
            return null;
        }
        return str.charAt(0);
    }

    private String convertStr(Object object) {
        return object == null ? null : String.valueOf(object);
    }

}
