package vn.com.vpbanks.flex.usecase.service.business.salesupport.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.repository.CustomersRepository;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.request.CustomerDirectIndirectIn;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.request.CustomerOfBrokerRequest;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.response.CustomerByBroker;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.response.CustomerDirectIndirect;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.response.CustomerDirectIndirectDetail;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.service.CustomerService;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class CustomersServiceImpl implements CustomerService {
    private final CustomersRepository customersRepository;


    @Override
    public BaseResponse getCustomersDirectIndirect(CustomerDirectIndirectIn customerDirectIndirectIn) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        try {
            List<CustomerDirectIndirect> customerDirectIndirects = customersRepository.getCustomerDirectIndirect(customerDirectIndirectIn);

            baseResponse.setData(customerDirectIndirects);
            return baseResponse;

        } catch (Exception ex) {
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            log.error(ex.getMessage(), ex);
        }
        return null;
    }

    @Override
    public BaseResponse getOrderCustomerDirectIndirect(CustomerDirectIndirectIn customerDirectIndirectIn) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        try {
            List<CustomerDirectIndirect> customerDirectIndirects = customersRepository.getOrderCustomerDirectIndirect(customerDirectIndirectIn);

            baseResponse.setData(customerDirectIndirects);
            return baseResponse;

        } catch (Exception ex) {
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            log.error(ex.getMessage(), ex);
        }
        return null;
    }

    @Override
    public BaseResponse getCustomerDirectIndirectDetail(String agencyNo, String preBrokerNo, String accountNo) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        try {
            CustomerDirectIndirectDetail customerDirectIndirectDetail = customersRepository.getCustomerDirectIndirectDetail(agencyNo, preBrokerNo, accountNo);
            baseResponse.setData(customerDirectIndirectDetail);
            return baseResponse;

        } catch (Exception ex) {
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            log.error(ex.getMessage(), ex);
        }
        return null;
    }

    @Override
    public BaseResponse getCustomersByBroker(CustomerOfBrokerRequest request) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        try {

            List<CustomerByBroker> customerDirectIndirects = customersRepository.getCustomersByBroker(request.getFilterCustomerType(), request.getReCustodyCds(), request.getCustodyCds(), request.getDepts(), request.getPage(), request.getSize());
            String data = Objects.isNull(customerDirectIndirects) ? StringUtils.EMPTY : customerDirectIndirects.stream().map(x -> x.getAccountNo()).collect(Collectors.joining(","));
            baseResponse.setData(data);
            return baseResponse;
        } catch (Exception ex) {
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            log.error(ex.getMessage(), ex);

            return baseResponse;
        }
    }
}
