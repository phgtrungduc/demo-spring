package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository;

import org.springframework.data.domain.Pageable;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.InquiryDetailOrderDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.InquiryOrderDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.AvailableTradeResponse;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.RightOffListResponse;
import vn.com.vpbanks.flex.usecase.service.business.order.request.StockOrderFilter;
import vn.com.vpbanks.flex.usecase.service.business.order.response.StockFilterResponseDTO;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.CurrentDepartmentDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.DepartmentDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.DirectManagementDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.GetDepartmentDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.GetUnderBrokerDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.REGRPDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseStoredProcedureResponse;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.HistoryOrderMatchDVO;

import java.math.BigDecimal;
import java.util.List;

public interface InquiryOrderRepository {

    List<InquiryDetailOrderDVO> getInquiryDetailOrder(String accountId, String orderId, String execType, String symbol, String orsStatus);

    BaseStoredProcedureResponse<List<HistoryOrderMatchDVO>> getHistoryOrderMatch(String accountId, String fromDate, String toDate, String symbol, String execType, int offSet, int limit);

    List<InquiryOrderDVO> getInquiryOrder(String accountId, String orderId, String execType, String symbol, String orsStatus, Long offset, Long limit);

    List<RightOffListResponse> getGetRightOffList(String accountId);

    List<AvailableTradeResponse> getAvailableTrade(String accountId, String symbol, BigDecimal quotePrice);

    BaseStoredProcedureResponse getHistoryOrder(String accountId, String fromDate, String toDate, String symbol, String execType, String orsStatus, Integer offset, Integer limit);

    GetUnderBrokerDto getUnderBroker(String custId, String searchkey, List<String> listDept, List<String> listUnderCustodycd, String getCurren);
    GetDepartmentDto getDepartment(String custId, String code, String name);

    List<REGRPDto> getByPrgrpid(List<String> listPrgrpid);

    List<CurrentDepartmentDto> getCurrentDepartment(List<String> listReCustodycd, String reFullName, Pageable page);
    List<StockFilterResponseDTO> orderBooks(StockOrderFilter stockOrderFilter);
}
