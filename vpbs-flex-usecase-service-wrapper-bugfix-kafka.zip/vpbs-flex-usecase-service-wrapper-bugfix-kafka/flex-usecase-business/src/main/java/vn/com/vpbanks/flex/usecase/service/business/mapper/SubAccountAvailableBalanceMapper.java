package vn.com.vpbanks.flex.usecase.service.business.mapper;

import org.mapstruct.Mapper;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.SubAccountAvailableBalanceDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.SubAccountAvailableBalanceResponse;

@Mapper(componentModel = "spring")
public interface SubAccountAvailableBalanceMapper extends BaseMapper<SubAccountAvailableBalanceDVO, SubAccountAvailableBalanceResponse> {

}
