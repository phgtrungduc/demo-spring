package vn.com.vpbanks.flex.usecase.service.business.inquiry.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class HistoryOrderResponse implements Serializable {
    private String orderId;
    private String txDate;
    private String symbol;
    private String execType;
    private BigDecimal orderQtty;
    private BigDecimal quotePrice;
    private BigDecimal execQtty;
    private BigDecimal execPrice;
    private BigDecimal execAmt;
    private String orStatus;
    private BigDecimal feeAmt;
    private BigDecimal taxAmt;
    private String markerName;
    private String via;
    private String side;
    private String orStatusValue;
    private String matchTypeValue;
    private String priceType;
    private String refOrderId;
    private BigDecimal aright;
    private String feeRate;
}
