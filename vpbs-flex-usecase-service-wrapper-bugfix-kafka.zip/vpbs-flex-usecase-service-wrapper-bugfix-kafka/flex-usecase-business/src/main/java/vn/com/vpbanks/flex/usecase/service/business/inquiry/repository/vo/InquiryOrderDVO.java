package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class InquiryOrderDVO implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "CUSTODYCD")
    private String custoDyCd;

    @Column(name = "TXDATE")
    private Timestamp txDate;

    @Id
    @Column(name = "CUSTID")
    private String custId;

    @Column(name = "AFACCTNO")
    private String afAcctNo;

    @Column(name = "ODORDERID")
    private String orderId;

    @Column(name = "TXTIME")
    private String txTime;

    @Column(name = "SYMBOL")
    private String symbol;

    @Column(name = "ALLOWCANCEL")
    private String allowCancel;

    @Column(name = "ALLOWAMEND")
    private String allowAmend;

    @Column(name = "SIDE")
    private String side;

    @Column(name = "PRICE")
    private BigDecimal price;

    @Column(name = "PRICETYPE")
    private String priceType;

    @Column(name = "via")
    private String via;

    @Column(name = "QTTY")
    private BigDecimal qtty;

    @Column(name = "execqtty")
    private BigDecimal execQtty;

    @Column(name = "EXECAMT")
    private BigDecimal execAmt;

    @Column(name = "EXECPRICE")
    private BigDecimal execPrice;

    @Column(name = "REMAINQTTY")
    private BigDecimal remainQtty;

    @Column(name = "REMAINAMT")
    private BigDecimal remainAmt;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "ORSTATUS")
    private String orStatus;

    @Column(name = "EN_ORSTATUS")
    private String enOrStatus;

    @Column(name = "TLNAME")
    private String tlName;

    @Column(name = "USERNAME")
    private String username;

    @Column(name = "HOSESESSION")
    private String hoseSession;

    @Column(name = "CANCELQTTY")
    private BigDecimal cancelQtty;

    @Column(name = "ADJUSTQTTY")
    private BigDecimal adjustQtty;

    @Column(name = "ISDISPOSAL")
    private String isDisposal;

    @Column(name = "ROOTORDERID")
    private String rootOrderId;

    @Column(name = "TIMETYPE")
    private String timeType;

    @Column(name = "TIMETYPEVALUE")
    private String timeTypeValue;

    @Column(name = "FEEDBACKMSG")
    private String feedBackMsg;

    @Column(name = "LIMITPRICE")
    private BigDecimal limitPrice;

    @Column(name = "ODTIMESTAMP")
    private Timestamp odTimeStamp;

    @Column(name = "SDTIME")
    private String sdtime;

    @Column(name = "MATCHTYPE_CODE")
    private String matchTypeCode;

    @Column(name = "PRODUCTTYPENAME")
    private String productTypeName;

    @Column(name = "R")
    private BigDecimal no;

    @Column(name = "L_COUNT")
    private BigDecimal totalElements;

    @Column(name = "ARIGHT")
    private BigDecimal aright;
}
