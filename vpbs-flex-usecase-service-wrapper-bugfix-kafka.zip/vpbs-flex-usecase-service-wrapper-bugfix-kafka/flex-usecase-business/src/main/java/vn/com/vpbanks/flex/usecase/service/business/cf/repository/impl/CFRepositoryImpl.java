package vn.com.vpbanks.flex.usecase.service.business.cf.repository.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import vn.com.vpbanks.flex.usecase.service.business.cf.repository.CFRepository;
import vn.com.vpbanks.flex.usecase.service.business.cf.repository.vo.OpenCSAccountDVO;
import vn.com.vpbanks.flex.usecase.service.business.cf.request.CalCI1202Request;
import vn.com.vpbanks.flex.usecase.service.business.cf.request.OpenCSAccountRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseStoredProcedureResponse;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.math.BigDecimal;

@Component
@RequiredArgsConstructor
public class CFRepositoryImpl implements CFRepository {

    @Value("${vpbanks.flex.sp.SP_OPEN_CS_ACCOUNT}")
    private String SP_OPEN_CS_ACCOUNT;

    @Value("${vpbanks.flex.sp.SP_CAL_CI_1202}")
    private String SP_CAL_CI_1202;
    private final EntityManager entityManager;
    private static final String SUCCESS_CODE = "0";

    @Override
    public BaseStoredProcedureResponse openCommissionAccount(OpenCSAccountRequest openCSAccountRequest) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_OPEN_CS_ACCOUNT, OpenCSAccountDVO.class);
        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_custid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_aftype", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.OUT);

        query.setParameter("p_custid", openCSAccountRequest.getCustId());
        query.setParameter("p_aftype", openCSAccountRequest.getAfType());

        query.execute();

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errMsg = (String) query.getOutputParameterValue("p_err_param");

        OpenCSAccountDVO openCSAccountDVO = null;
        if (SUCCESS_CODE.equals(errCode)) {
            openCSAccountDVO = (OpenCSAccountDVO) query.getSingleResult();
        }

        BaseStoredProcedureResponse baseStoredProcedureResponse = new BaseStoredProcedureResponse();
        baseStoredProcedureResponse.setData(openCSAccountDVO);
        baseStoredProcedureResponse.setErrCd(errCode);
        baseStoredProcedureResponse.setErrMsg(errMsg);

        return baseStoredProcedureResponse;
    }

    @Override
    public BaseStoredProcedureResponse calCI1202(CalCI1202Request calCI1202Request) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_CAL_CI_1202);
        query.registerStoredProcedureParameter("p_acctno", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_amount", BigDecimal.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_desc", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.OUT);

        query.setParameter("p_acctno", calCI1202Request.getAcctNo());
        query.setParameter("p_amount", calCI1202Request.getAmount());
        query.setParameter("p_desc", ObjectUtils.isEmpty(calCI1202Request.getDesc()) ? "" : calCI1202Request.getDesc());

        query.execute();

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errMsg = (String) query.getOutputParameterValue("p_err_param");

        BaseStoredProcedureResponse baseStoredProcedureResponse = new BaseStoredProcedureResponse();
        baseStoredProcedureResponse.setErrCd(errCode);
        baseStoredProcedureResponse.setErrMsg(errMsg);

        return baseStoredProcedureResponse;
    }
}
