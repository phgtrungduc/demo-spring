package vn.com.vpbanks.flex.usecase.service.business.inquiry.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class SubAccountAvailableBalanceResponse {

    @JsonProperty("accountId")
    private String accountNo;

    @JsonProperty("balance")
    private BigDecimal BALDEFOVD;
}
