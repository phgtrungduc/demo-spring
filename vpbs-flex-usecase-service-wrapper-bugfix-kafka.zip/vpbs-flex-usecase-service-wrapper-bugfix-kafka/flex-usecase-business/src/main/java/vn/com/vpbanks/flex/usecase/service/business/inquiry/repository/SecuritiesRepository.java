package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository;

import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.SecuritiesInfoDVO;

import java.util.List;

public interface SecuritiesRepository {
    List<SecuritiesInfoDVO> getSecuritiesInfo(String issuerId, String codeId, String symbol, String secTypeName, String tradePlace, Integer offset, Integer limit);
}
