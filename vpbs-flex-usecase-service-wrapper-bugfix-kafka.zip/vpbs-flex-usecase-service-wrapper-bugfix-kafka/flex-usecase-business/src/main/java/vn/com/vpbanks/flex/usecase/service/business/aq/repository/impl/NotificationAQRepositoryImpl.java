package vn.com.vpbanks.flex.usecase.service.business.aq.repository.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import vn.com.vpbanks.flex.usecase.service.business.aq.repository.vo.*;
import vn.com.vpbanks.flex.usecase.service.business.aq.repository.NotificationAQRepository;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@Slf4j
@RequiredArgsConstructor
public class NotificationAQRepositoryImpl implements NotificationAQRepository {

    private final EntityManager entityManager;

    @Value("${vpbanks.flex.sp.SP_GET_CWETF_EXPIRED}")
    private String SP_GET_CWETF_EXPIRED;

    @Value("${vpbanks.flex.sp.SP_GET_CUST_RIGHT_TO_BUY}")
    private String SP_GET_CUST_RIGHT_TO_BUY;

    @Value("${vpbanks.flex.sp.SP_GET_MR_0002}")
    private String SP_GET_MR_0002;

    @Value("${vpbanks.flex.sp.SP_GET_MR_0003}")
    private String SP_GET_MR_0003;

    @Value("${vpbanks.flex.sp.SP_GET_LNS_DUEDATE}")
    private String SP_GET_LNS_DUEDATE;

    @Value("${vpbanks.flex.sp.SP_GET_CONFIRM_ORDER}")
    private String SP_GET_CONFIRM_ORDER;

    @Value("${vpbanks.flex.sp.SP_GET_ALL_ACCOUNT}")
    private String SP_GET_ALL_ACCOUNT;

    @Value(("${vpbanks.flex.sp.SP_GET_CUSTOMER}"))
    private String SP_GET_CUSTOMER;

    @Value(("${vpbanks.flex.sp.SP_GEN_TEMPLATE_MAIL}"))
    private String SP_GEN_TEMPLATE_MAIL;

    /**
     * Lay thong tin chung quyen va chung chi quy sap het han(5 ngay lam viec)
     * fopks_inquiryapi.pr_get_cwetf_expired
     *
     * @return
     */
    @Override
    public List<CwetfExpriedDVO> getListCwetfExpried() {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_CWETF_EXPIRED);
        query.registerStoredProcedureParameter("p_refcursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.INOUT);

//        query.execute();
        String errCd = (String) query.getOutputParameterValue("p_err_code");
        String errMsg = (String) query.getOutputParameterValue("p_err_param");

        if ("-1".equals(errCd)) {
            // Stored procedure throw exception NO_DATA_FOUND.
            log.info("getListCwetfExpried throw exception NO_DATA_FOUND , errMsg : {}", errMsg);
            return null;
        }

        List<CwetfExpriedDVO> cwetfExpriedDVOS = new ArrayList<>();
        List<Object[]> objects = query.getResultList();
        cwetfExpriedDVOS = objects.stream()
                .map(CwetfExpriedDVO::new)
                .collect(Collectors.toList());

        return cwetfExpriedDVOS;
    }

    @Override
    public List<CustRightToBuyDVO> getListCustRightToBuy() {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_CUST_RIGHT_TO_BUY);
        query.registerStoredProcedureParameter("p_REFCURSOR", void.class, ParameterMode.REF_CURSOR);

        try {
            List<Object[]> objects = query.getResultList();
            List<CustRightToBuyDVO> custRightToBuyDVOS = objects.stream()
                    .map(item -> {
                        CustRightToBuyDVO custRightToBuyDVO = new CustRightToBuyDVO();
                        custRightToBuyDVO.setTEMPLATEID((String) item[0]);
                        custRightToBuyDVO.setCUSTODYCD((String) item[1]);
                        custRightToBuyDVO.setCUSTID((String) item[2]);
                        custRightToBuyDVO.setAFACCTNO((String) item[3]);
                        custRightToBuyDVO.setSYMBOL((String) item[4]);
                        custRightToBuyDVO.setCAMASTID((String) item[5]);
                        custRightToBuyDVO.setREPORTDATE((String) item[6]);
                        custRightToBuyDVO.setBEGINDATE((String) item[7]);
                        custRightToBuyDVO.setDUEDATE((String) item[8]);
                        custRightToBuyDVO.setCODE_CO((String) item[9]);
                        return custRightToBuyDVO;
                    })
                    .collect(Collectors.toList());

            return custRightToBuyDVOS;
        } catch (NoResultException ex) {
            log.info("getListCustRightToBuy return no result exception , message : {} ", ex.getMessage());
            return null;
        }
    }

    @Override
    public List<Mr0002DVO> getListMr0002() {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_MR_0002);
        query.registerStoredProcedureParameter("p_REFCURSOR", void.class, ParameterMode.REF_CURSOR);

        try {
            List<Object[]> objects = query.getResultList();
            List<Mr0002DVO> mr0002DVOS = objects.stream()
                    .map(item -> {
                        Mr0002DVO mr0002DVO = new Mr0002DVO();
                        mr0002DVO.setTEMPLATEID((String) item[0]);
                        mr0002DVO.setCUSTID((String) item[1]);
                        mr0002DVO.setCUSTODYCD((String) item[2]);
                        mr0002DVO.setAFACCTNO((String) item[3]);
                        mr0002DVO.setADDVND((String) item[4]);
                        mr0002DVO.setCODE_CO((String) item[5]);
                        mr0002DVO.setShortbank((String) item[6]);
                        mr0002DVO.setFullbank((String) item[7]);
                        return mr0002DVO;
                    })
                    .collect(Collectors.toList());

            return mr0002DVOS;
        } catch (NoResultException ex) {
            log.info("getListMr0002 return no result exception , message : {} ", ex.getMessage());
            return null;
        }
    }

    @Override
    public List<Mr0003DVO> getListMr0003() {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_MR_0003);
        query.registerStoredProcedureParameter("p_REFCURSOR", void.class, ParameterMode.REF_CURSOR);

        try {
            List<Object[]> objects = query.getResultList();
            log.info("[getListMr0003] templateId: NIA_TTT_327C, objects : {}", objects);
            List<Mr0003DVO> mr0003DVOS = objects.stream()
                    .map(item -> {
                        Mr0003DVO mr0003DVO = new Mr0003DVO();
                        mr0003DVO.setTEMPLATEID((String) item[0]);
                        mr0003DVO.setCUSTID((String) item[1]);
                        mr0003DVO.setCUSTODYCD((String) item[2]);
                        mr0003DVO.setAFACCTNO((String) item[3]);
                        mr0003DVO.setADDVND((String) item[4]);
                        mr0003DVO.setCODE_CO((String) item[5]);
                        mr0003DVO.setOVDAMOUNT((String) item[6]);
                        mr0003DVO.setCUSTODYCD_ACCTNO((String) item[7]);
                        mr0003DVO.setMARGINRATE(item[8].toString());
                        mr0003DVO.setShortbank((String) item[9]);
                        mr0003DVO.setFullbank((String) item[10]);
                        return mr0003DVO;
                    })
                    .collect(Collectors.toList());

            return mr0003DVOS;
        } catch (NoResultException ex) {
            log.info("getListMr0003 return no result exception , message : {} ", ex.getMessage());
            return null;
        }
    }

    @Override
    public List<LnsDueDateDVO> getListLnsDueDate() {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_LNS_DUEDATE);
        query.registerStoredProcedureParameter("p_REFCURSOR", void.class, ParameterMode.REF_CURSOR);

        try {
            List<Object[]> objects = query.getResultList();
            List<LnsDueDateDVO> lnsDueDateDVOS = objects.stream()
                    .map(item -> {
                        LnsDueDateDVO lnsDueDateDVO = new LnsDueDateDVO();
                        lnsDueDateDVO.setTEMPLATEID((String) item[0]);
                        lnsDueDateDVO.setCODE_CO((String) item[1]);
                        lnsDueDateDVO.setCUSTODYCD((String) item[2]);
                        lnsDueDateDVO.setCUSTID((String) item[3]);
                        lnsDueDateDVO.setAFACCTNO((String) item[4]);
                        lnsDueDateDVO.setAUTOID((BigDecimal) item[5]);
                        lnsDueDateDVO.setOVERDUEDATE((String) item[6]);
                        lnsDueDateDVO.setPRINAMT((String) item[7]);
                        lnsDueDateDVO.setDEBTINTEREST((String) item[8]);
                        lnsDueDateDVO.setDEBTFEE((String) item[9]);
                        lnsDueDateDVO.setTOTALDEBT((String) item[10]);
                        lnsDueDateDVO.setShortbank((String) item[11]);
                        lnsDueDateDVO.setFullbank((String) item[12]);
                        return lnsDueDateDVO;
                    })
                    .collect(Collectors.toList());

            return lnsDueDateDVOS;
        } catch (NoResultException ex) {
            log.info("getListLnsDueDate return no result exception , message : {} ", ex.getMessage());
            return null;
        }
    }

    @Override
    public List<ConfirmOrderDVO> getListConfirmOrder(String afAcctNo) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_CONFIRM_ORDER);
        query.registerStoredProcedureParameter("p_REFCURSOR", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_afacctno", String.class, ParameterMode.IN);

        query.setParameter("p_afacctno", afAcctNo);

        try {
            List<Object[]> objects = query.getResultList();
            List<ConfirmOrderDVO> confirmOrderDVOS = objects.stream()
                    .map(item -> {
                        ConfirmOrderDVO confirmOrderDVO = new ConfirmOrderDVO();
                        confirmOrderDVO.setTEMPLATEID((String) item[0]);
                        confirmOrderDVO.setCODE_CO((String) item[1]);
                        confirmOrderDVO.setCUSTODYCD((String) item[2]);
                        confirmOrderDVO.setCUSTID((String) item[3]);
                        confirmOrderDVO.setAFACCTNO((String) item[4]);
                        confirmOrderDVO.setCNT((BigDecimal) item[5]);
                        return confirmOrderDVO;
                    })
                    .collect(Collectors.toList());

            return confirmOrderDVOS;
        } catch (NoResultException ex) {
            log.info("getListConfirmOrder return no result exception , message : {} ", ex.getMessage());
            return null;
        }
    }

    @Override
    public Optional<CustomerInfoDVO> getCustomerInfoFromCusToDyCd(String cusToDyCd) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_CUSTOMER, CustomerInfoDVO.class);
        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_custodycd", String.class, ParameterMode.IN);

        query.setParameter("p_custodycd", cusToDyCd);
        CustomerInfoDVO customerInfoDVO;
        try {
            customerInfoDVO = (CustomerInfoDVO) query.getSingleResult();
        } catch (NoResultException ex) {
            log.error("getCustomerInfoFromCusToDyCd function throw NoResultException , message {} ", ex.getMessage());
            customerInfoDVO = null;
        } catch (Exception ex) {
            log.error("getCustomerInfoFromCusToDyCd function throw exception , message {} ", ex.getMessage());
            customerInfoDVO = null;
        }
        return Optional.ofNullable(customerInfoDVO);
    }

    @Override
    public List<SubAccountInfoDVO> getListSubAccountNo(String custId, String accountId) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_ALL_ACCOUNT, CustomerInfoDVO.class);
        query.registerStoredProcedureParameter("p_refcursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_customerid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_accountid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.INOUT);

        accountId = accountId == null ? accountId : "ALL";
        query.setParameter("p_customerid", custId);
        query.setParameter("p_accountid", accountId);

        List<SubAccountInfoDVO> subAccountInfoDVOS;
        try {
            List<Object[]> objects = query.getResultList();
            subAccountInfoDVOS = objects.stream()
                    .map(item -> {
                        SubAccountInfoDVO subAccountInfoDVO = new SubAccountInfoDVO();
                        subAccountInfoDVO.setSubAccountNo((String) item[0]);
                        subAccountInfoDVO.setCusToDyCd((String) item[1]);
                        subAccountInfoDVO.setSubAccountNo((String) item[2]);
                        subAccountInfoDVO.setName((String) item[3]);
                        return subAccountInfoDVO;
                    })
                    .collect(Collectors.toList());
        } catch (NoResultException ex) {
            log.error("getListSubAccountNo throw NoResultException , message {} ", ex.getMessage());
            subAccountInfoDVOS = Collections.emptyList();
        }

        return subAccountInfoDVOS;
    }

    @Override
    public void generateTemplate(String messageType, String keyValue) {
        log.info("[START] generateTemplate {} ", LocalDateTime.now());
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GEN_TEMPLATE_MAIL);
        query.registerStoredProcedureParameter("p_message_type", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_key_value", String.class, ParameterMode.IN);

        query.setParameter("p_message_type", messageType);
        query.setParameter("p_key_value", keyValue);
        query.execute();
        log.info("[END] generateTemplate {} ", LocalDateTime.now());
    }
}