package vn.com.vpbanks.flex.usecase.service.business.cash.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.math.BigDecimal;
import java.util.Date;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class UnHoldEODResponse {
    private String brokerCode;
    private String custodyCd;

    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "Asia/Bangkok")
    private Date tradingDate;
    private String symbol;
    private String transactionType;

    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "Asia/Bangkok")
    private Date settleDate;

    private BigDecimal quantity;
    private BigDecimal price;
    private BigDecimal execAmt;
    private BigDecimal feeAmt;
    private BigDecimal taxAmt;
    private BigDecimal netExecAmt;
    private String orderNo;
}
