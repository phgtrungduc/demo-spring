package vn.com.vpbanks.flex.usecase.service.business.cash.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class InternalTransferRequest {

    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String accountId;

    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String receiveAccount;

    @Positive(message = "{validation.positive_number}")
    @NotNull(message = "{validation.not_null}")
    private double amount;

    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String transDescription;

    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String via;
}
