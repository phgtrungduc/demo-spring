package vn.com.vpbanks.flex.usecase.service.business.aq.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderNotificationFromQueue {
    private String EXECTYPE;

    private String AFACCTNO;

    private String PRICE;

    private BigDecimal QUOTEPRICE;

    private String ORSTATUS;

    private String AUTOID;

    private BigDecimal CANCELQTTY;

    private String ACCTNO;

    private String TIMETYPEVALUE;

    private String VIA;

    private String CUSTODYCD;

    private String PRICETYPE;

    private String EVENTTYPE;

    private BigDecimal EXECQTTY;

    private String FEEDBACKMSG;

    private String SYMBOL;

    private BigDecimal ADJUSTQTTY;

    private String APPLYTIME;

    private BigDecimal ORDERQTTY;

    private String ORSTATUSVALUE;

    private BigDecimal REMAINQTTY;

    private Timestamp LOGTIME;

    private BigDecimal EXECPRICE;

    private String REQUESTID;

    private String FOVIA;
}
