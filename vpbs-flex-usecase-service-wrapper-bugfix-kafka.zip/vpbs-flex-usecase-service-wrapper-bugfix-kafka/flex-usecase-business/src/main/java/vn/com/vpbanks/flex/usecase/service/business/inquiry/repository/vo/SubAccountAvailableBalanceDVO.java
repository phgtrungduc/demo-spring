package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.io.Serializable;
import java.math.BigDecimal;

@Setter
@Getter
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class SubAccountAvailableBalanceDVO implements Serializable {

    @Id
    @Column(name = "ACCTNO")
    private String accountNo;

    @Column(name = "BALDEFOVD")
    private BigDecimal BALDEFOVD;
}
