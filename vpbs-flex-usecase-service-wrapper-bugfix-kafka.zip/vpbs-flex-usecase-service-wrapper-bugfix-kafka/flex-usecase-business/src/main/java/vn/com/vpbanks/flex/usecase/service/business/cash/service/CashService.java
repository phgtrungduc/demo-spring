package vn.com.vpbanks.flex.usecase.service.business.cash.service;

import vn.com.vpbanks.flex.usecase.service.business.cash.request.*;
import vn.com.vpbanks.flex.usecase.service.common.dto.request.BaseRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;

import java.util.List;

public interface CashService {
    BaseResponse getBankNoStro();

    BaseResponse increaseMoney(BaseRequest<IncreaseMoneyRequest> increaseMoneyRequestBaseRequest, String ipAddress);

    BaseResponse internalTransfer(BaseRequest<InternalTransferRequest> internalTransferRequestBaseRequest, String ipAddress);

    BaseResponse blockAmount(BaseRequest<BlockAmountRequest> blockAmountRequestBaseRequest, String ipAddress);

    BaseResponse unBlockAmount(BaseRequest<BlockAmountRequest> blockAmountRequestBaseRequest, String ipAddress);

    BaseResponse getSecuritiesStatement(String accountId, String fromDate, String toDate, String symbol);

    BaseResponse getCashStatementHist(List<CashStatementHistRequest> cashStatementHistRequestList);

    BaseResponse<Object> getHoldBalance(String custodyCd, String accountNo);

    BaseResponse<Object> getHoldStock(String custodyCd, String accountNo);

    BaseResponse<Object> getUnHoldEOD();

    BaseResponse<Object> holdBalance(HoldBalanceRequest holdBalanceRequest);

    BaseResponse<Object> unHoldBalance(UnHoldBalanceRequest unHoldBalanceRequest);

    BaseResponse<Object> holdStock(HoldStockRequest holdStockRequest);

    BaseResponse<Object> unHoldStock(UnHoldStockRequest unHoldStockRequest);
}
