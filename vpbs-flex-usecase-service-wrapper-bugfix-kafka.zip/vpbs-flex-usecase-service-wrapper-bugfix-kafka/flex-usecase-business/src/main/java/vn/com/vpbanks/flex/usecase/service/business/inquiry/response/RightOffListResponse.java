package vn.com.vpbanks.flex.usecase.service.business.inquiry.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import javax.persistence.Column;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RightOffListResponse implements Serializable {
//    @Id

    private static final long serialVersionUID = 1L;
    @JsonProperty("accountId")
    @Column(name = "ACCOUNTID")
    private String accountId;

    @JsonProperty("caMastId")
    @Column(name = "CAMASTID")
    private String caMastId;

    @JsonProperty("symbol")
    @Column(name = "SYMBOL")
    private String symbol;

    @JsonProperty("rightBuyAvaIlaBle")
    @Column(name = "RIGHTBUYAVAILABLE")
    private BigDecimal rightBuyAvaIlaBle;

    @JsonProperty("rightReGisTeRed")
    @Column(name = "RIGHTREGISTERED")
    private BigDecimal rightReGisTeRed;

    @JsonProperty("price")
    @Column(name = "PRICE")
    private BigDecimal price;

    @JsonProperty("amt")
    @Column(name = "AMT")
    private BigDecimal amt;

    @JsonProperty("descRipTion")
    @Column(name = "DESCRIPTION")
    private String descRipTion;

    @JsonProperty("allowReGist")
    @Column(name = "ALLOWREGIST")
    private Character allowReGist;

    @JsonProperty("reGistLastDate")
    @Column(name = "REGISTLASTDATE")
    private String reGistLastDate;

    @JsonProperty("exRate")
    @Column(name = "EXRATE")
    private String exRate;

    @JsonProperty("rightOffRate")
    @Column(name = "RIGHTOFFRATE")
    private String rightOffRate;

    @JsonProperty("fromDateTransFer")
    @Column(name = "FROMDATETRANSFER")
    private String fromDateTransFer;

    @JsonProperty("toDateTransFer")
    @Column(name = "TODATETRANSFER")
    private String toDateTransFer;

    @JsonProperty("secType")
    @Column(name = "SECTYPE")
    private String secType;

    @JsonProperty("parValue")
    @Column(name = "PARVALUE")
    private BigDecimal parValue;

    @JsonProperty("beginDate")
    @Column(name = "BEGINDATE")
    private String beginDate;

    @JsonProperty("reportDate")
    @Column(name = "REPORTDATE")
    private String reportDate;

    @JsonProperty("qtty")
    @Column(name = "QTTY")
    private BigDecimal qtty;

    @JsonProperty("pendingQtty")
    @Column(name = "PENDINGQTTY")
    private BigDecimal pendingQtty;

    @JsonProperty("regQtty")
    @Column(name = "REGQTTY")
    private BigDecimal regQtty;

    @JsonProperty("outBalance")
    @Column(name = "OUTBALANCE")
    private BigDecimal outBalance;

    @JsonProperty("kdqDate")
    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "Asia/Bangkok")
    private Date kdqDate;
}
