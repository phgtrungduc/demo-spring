package vn.com.vpbanks.flex.usecase.service.business.cf.request;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
public class OpenCSAccountRequest {
    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String custId;

    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String afType;
}

