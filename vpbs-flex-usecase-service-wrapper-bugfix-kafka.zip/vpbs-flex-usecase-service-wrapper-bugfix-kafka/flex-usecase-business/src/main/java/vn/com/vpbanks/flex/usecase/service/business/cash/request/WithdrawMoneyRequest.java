package vn.com.vpbanks.flex.usecase.service.business.cash.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.kafka.common.protocol.types.Field;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class WithdrawMoneyRequest {
    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String custId;

    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String accountId;

    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String bankId;

    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String via;

    @Positive(message = "{validation.positive_number}")
    @NotNull(message = "{validation.not_null}")
    private Long amount;

//    @NotNull(message = "{validation.not_null}")
//    @NotNull(message = "{validation.not_null}")
    private String desc;

    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String isnotisms;
}
