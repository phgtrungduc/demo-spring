package vn.com.vpbanks.flex.usecase.service.business.aq.response;

import lombok.Data;
import vn.com.vpbanks.flex.usecase.service.business.aq.request.ChangePasswordNotificationFromQueue;

@Data
public class ChangePasswordNotification {
    private String eventType;
    private String userLogin;
    private String custId;
    private String custoDyCd;

    public ChangePasswordNotification(ChangePasswordNotificationFromQueue changePasswordNotificationFromQueue) {
        this.eventType = changePasswordNotificationFromQueue.getEVENTTYPE();
        this.userLogin = changePasswordNotificationFromQueue.getUSERLOGIN();
        this.custId = changePasswordNotificationFromQueue.getCUSTID();
        this.custoDyCd = changePasswordNotificationFromQueue.getCUSTODYCD();
    }
}

