package vn.com.vpbanks.flex.usecase.service.business.salesupport.repository;

import vn.com.vpbanks.flex.usecase.service.business.salesupport.request.CustomerDirectIndirectIn;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.response.CustomerByBroker;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.response.CustomerDirectIndirect;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.response.CustomerDirectIndirectDetail;

import java.util.List;

public interface CustomersRepository {

    List<CustomerDirectIndirect> getCustomerDirectIndirect(CustomerDirectIndirectIn customerDirectIndirectIn);

    List<CustomerDirectIndirect> getOrderCustomerDirectIndirect(CustomerDirectIndirectIn customerDirectIndirectIn);

    CustomerDirectIndirectDetail getCustomerDirectIndirectDetail(String agencyNo, String preBrokerNo, String accountNo);

    List<CustomerByBroker> getCustomersByBroker(String customerType, List<String> preCustodyCds, List<String> custodyCds, List<String> listDept, Integer page, Integer size);

}
