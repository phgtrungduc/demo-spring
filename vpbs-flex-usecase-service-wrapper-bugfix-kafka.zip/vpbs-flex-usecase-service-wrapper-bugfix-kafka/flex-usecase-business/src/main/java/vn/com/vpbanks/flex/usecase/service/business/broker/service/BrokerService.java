package vn.com.vpbanks.flex.usecase.service.business.broker.service;

import vn.com.vpbanks.flex.usecase.service.business.broker.request.BrokerRequest;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.ReGrpLnkRequest;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.RightOffRegisterRequest;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.TransferStockRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.request.BaseRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;

public interface BrokerService {
    BaseResponse addBroker(BaseRequest<BrokerRequest> brokerRequest, String ipAddress);

    BaseResponse addReGrpLink(ReGrpLnkRequest reGrpLnkRequest, String ipAddress);

    BaseResponse internalStockTransfer(TransferStockRequest transferStockRequest, String ipAddress);

    BaseResponse addRightOffRegister(RightOffRegisterRequest rightOffRegisterRequest, String ipAddress);

    BaseResponse getCustomerOfBroker(String reCusToDyCd);

    BaseResponse getBrokerInfo(String custoDyCd);

    BaseResponse getRightInfo(String fromDate, String toDate, String afAcctNo, String isCom, String symbol, String caType);
}
