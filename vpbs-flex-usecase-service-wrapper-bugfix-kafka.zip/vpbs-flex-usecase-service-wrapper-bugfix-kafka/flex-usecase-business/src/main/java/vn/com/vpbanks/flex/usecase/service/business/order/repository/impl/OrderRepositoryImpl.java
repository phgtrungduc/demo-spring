package vn.com.vpbanks.flex.usecase.service.business.order.repository.impl;

import io.netty.util.internal.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import vn.com.vpbanks.flex.usecase.service.business.order.repository.OrderRepository;
import vn.com.vpbanks.flex.usecase.service.business.order.request.PostOrdersRequests;
import vn.com.vpbanks.flex.usecase.service.business.order.response.PostOrdersResponseResponse;
import vn.com.vpbanks.flex.usecase.service.common.dto.request.BaseRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.StoredProcedureError;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.util.List;

@Repository
@RequiredArgsConstructor
@Slf4j
public class OrderRepositoryImpl implements OrderRepository {

    private final EntityManager entityManager;

    @Value("${vpbanks.flex.sp.SP_CREATE_ORDER}")
    private String SP_CREATE_ORDER;
    @Value("${vpbanks.flex.sp.SP_CREATE_ORDER_WITH_BROKER_NAME}")
    private String SP_CREATE_ORDER_WITH_BROKER_NAME;

    @Value("${vpbanks.flex.sp.SP_CANCEL_ORDER}")
    private String SP_CANCEL_ORDER;
    @Value("${vpbanks.flex.sp.SP_EDIT_ORDER}")
    private String SP_EDIT_ORDER;

    @Override
    @Transactional
    public StoredProcedureError cancelOrder(String requestId, String accountNo, String orderId, String cusId, String ipAddress, String channel, String validationType, String device, String deviceType) {

        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_CANCEL_ORDER);

        // register stored params
        query.registerStoredProcedureParameter("p_requestid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_accountid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orderid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_userName", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_ipaddress", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_via", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter("p_validationtype", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_devicetype", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_device", String.class, ParameterMode.IN);
        // set value for params
        query.setParameter("p_requestid", requestId);
        query.setParameter("p_accountid", accountNo);
        query.setParameter("p_orderid", orderId);
        query.setParameter("p_userName", cusId);
        query.setParameter("p_ipaddress", StringUtils.hasText(ipAddress) ? ipAddress : "");
        query.setParameter("p_via", channel);

        query.setParameter("p_validationtype", StringUtils.hasText(validationType) ? validationType.toUpperCase() : "");
        query.setParameter("p_devicetype", StringUtils.hasText(deviceType) ? deviceType : "");
        query.setParameter("p_device", StringUtils.hasText(device) ? device : "");
        // execute stored procedure
        query.execute();

        String errCd = (String) query.getOutputParameterValue("p_err_code");
        String errParam = (String) query.getOutputParameterValue("p_err_param");

        StoredProcedureError response = new StoredProcedureError(errCd, errParam);

        return response;
    }

    @Override
    @Transactional
    public PostOrdersResponseResponse saveOder(BaseRequest<PostOrdersRequests> postOrdersDTO, String ipAddress) {
        PostOrdersResponseResponse postOrdersResponseResponse = new PostOrdersResponseResponse();
        log.info("saveOder post order {}", postOrdersDTO);
        try {
            String procedure;
            if (!StringUtil.isNullOrEmpty(postOrdersDTO.getData().getBrokerUserName())){
                procedure = SP_CREATE_ORDER_WITH_BROKER_NAME;
            }else {
                procedure = SP_CREATE_ORDER;
            }
            log.info("saveOder procedure {}", procedure);
            StoredProcedureQuery query = entityManager.createStoredProcedureQuery(procedure);

            query.registerStoredProcedureParameter("p_requestid", String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("p_accountid", String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("p_userName", String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("p_instrument", String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("p_qty", Long.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("p_side", String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("p_type", String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("p_limitprice", String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("p_ipaddress", String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("p_orderid", void.class, ParameterMode.REF_CURSOR);
            query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
            query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.INOUT);
            query.registerStoredProcedureParameter("p_via", String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("p_validationtype", String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("p_devicetype", String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("p_device", String.class, ParameterMode.IN);


            if (!StringUtil.isNullOrEmpty(postOrdersDTO.getData().getBrokerUserName())) {
                query.registerStoredProcedureParameter("p_brokerUserName", String.class, ParameterMode.IN);
            }
// bind params value
            query.setParameter("p_requestid", postOrdersDTO.getRequestId());
            query.setParameter("p_accountid", postOrdersDTO.getData().getAccountId());
            query.setParameter("p_userName", postOrdersDTO.getData().getUserName());
            query.setParameter("p_instrument", postOrdersDTO.getData().getInstrument().toUpperCase());
            query.setParameter("p_qty", postOrdersDTO.getData().getQty());
            query.setParameter("p_side", postOrdersDTO.getData().getSide());
            query.setParameter("p_type", postOrdersDTO.getData().getType());
            query.setParameter("p_limitprice", postOrdersDTO.getData().getLimitPrice().toUpperCase());
            query.setParameter("p_ipaddress", StringUtils.hasText(ipAddress) ? ipAddress : "");
            query.setParameter("p_err_code", "");
            query.setParameter("p_err_param", "");
            query.setParameter("p_via", postOrdersDTO.getData().getVia().toUpperCase());
            query.setParameter("p_validationtype", StringUtils.hasText(postOrdersDTO.getData().getValidationType()) ? postOrdersDTO.getData().getValidationType().toUpperCase() : "");
            query.setParameter("p_devicetype", StringUtils.hasText(postOrdersDTO.getData().getDeviceType()) ? postOrdersDTO.getData().getDeviceType() : "");
            query.setParameter("p_device", StringUtils.hasText(postOrdersDTO.getData().getDevice()) ? postOrdersDTO.getData().getDevice() : "");
            if (!StringUtil.isNullOrEmpty(postOrdersDTO.getData().getBrokerUserName())) {
                query.setParameter("p_brokerUserName", postOrdersDTO.getData().getBrokerUserName());
            }
            query.execute();

            String errEc = (String) query.getOutputParameterValue("p_err_code");
            String errPram = (String) query.getOutputParameterValue("p_err_param");
            postOrdersResponseResponse.setErrCode(errEc);
            postOrdersResponseResponse.setErrParam(errPram);
            if ("0".equals(errEc)) {
                List<String> orderIds = query.getResultList();
                postOrdersResponseResponse.setOrderIds(orderIds);
            }

            return postOrdersResponseResponse;

        } catch (Exception e) {
            log.info("OrderRepositoryImpl error : {} ", e.getMessage());
        }
        return postOrdersResponseResponse;
    }

    @Override
    @Transactional
    public StoredProcedureError editOrder(String requestId, String accountId, String orderId, String userName, Integer qty, Integer limitPrice, String ipAddress, String via, String validationType, String device, String deviceType) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_EDIT_ORDER);
        log.info("post order {}", ipAddress);

        // register stored params
        query.registerStoredProcedureParameter("p_requestid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_accountid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orderid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_userName", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_qty", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_limitprice", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_ipaddress", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_via", String.class, ParameterMode.IN);

        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_validationtype", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_devicetype", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_device", String.class, ParameterMode.IN);

        // set value for params
        query.setParameter("p_requestid", requestId);
        query.setParameter("p_accountid", accountId);
        query.setParameter("p_orderid", orderId);
        query.setParameter("p_userName", userName);
        query.setParameter("p_ipaddress", StringUtils.hasText(ipAddress) ? ipAddress : "");
        query.setParameter("p_qty", qty);
        query.setParameter("p_limitprice", limitPrice);
        query.setParameter("p_via", via);
        query.setParameter("p_validationtype", StringUtils.hasText(validationType) ? validationType.toUpperCase() : "");
        query.setParameter("p_devicetype", StringUtils.hasText(deviceType) ? deviceType : "");
        query.setParameter("p_device", StringUtils.hasText(device) ? device : "");

        // execute stored procedure
        query.execute();

        String errCd = (String) query.getOutputParameterValue("p_err_code");
        String errParam = (String) query.getOutputParameterValue("p_err_param");

        StoredProcedureError response = new StoredProcedureError(errCd, errParam);

        return response;

    }
}
