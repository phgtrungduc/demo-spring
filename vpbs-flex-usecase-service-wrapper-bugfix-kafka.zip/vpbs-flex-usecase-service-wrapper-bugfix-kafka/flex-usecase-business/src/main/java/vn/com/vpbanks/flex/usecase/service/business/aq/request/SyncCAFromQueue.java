package vn.com.vpbanks.flex.usecase.service.business.aq.request;

import lombok.Data;

import java.math.BigDecimal;

@Data
/**
 * Tín hiệu đồng bộ quyền
 */
public class SyncCAFromQueue {
    private String EVENTTYPE;
    private String AUTOID;
    private String CODEID;
    private String LOGTIME;
    private String NEWSTATUS;
    private String OLDSTATUS;
    private String SYMBOL;
    private String CATYPE;
    private String KHQDATE;
}
