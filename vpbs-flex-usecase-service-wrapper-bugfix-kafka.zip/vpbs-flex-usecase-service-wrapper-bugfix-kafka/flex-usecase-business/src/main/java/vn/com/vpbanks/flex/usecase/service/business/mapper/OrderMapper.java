package vn.com.vpbanks.flex.usecase.service.business.mapper;

import org.mapstruct.Mapper;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.InquiryOrderDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.InquiryOrderResponse;

@Mapper(componentModel = "spring")
public interface OrderMapper extends BaseMapper<InquiryOrderDVO, InquiryOrderResponse>{

//    InquiryOrderResponse InquiryOrderToInquiryOrderDTO(InquiryOrderDVO inquiryOrderDVO);
}
