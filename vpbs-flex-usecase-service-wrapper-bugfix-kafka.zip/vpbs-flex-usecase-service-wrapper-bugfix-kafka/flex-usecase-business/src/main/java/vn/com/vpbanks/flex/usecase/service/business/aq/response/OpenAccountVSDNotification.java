package vn.com.vpbanks.flex.usecase.service.business.aq.response;

import lombok.Data;
import vn.com.vpbanks.flex.usecase.service.business.aq.request.OpenAccountVSDNotificationFromQueue;

@Data
public class OpenAccountVSDNotification {
    private String eventType;
    private String type;
    private String status;
    private String custoDyCd;
    private String idNumber;

    public OpenAccountVSDNotification(OpenAccountVSDNotificationFromQueue openAccountVSDNotificationFromQueue) {
        this.eventType = openAccountVSDNotificationFromQueue.getEVENTTYPE();
        this.type = openAccountVSDNotificationFromQueue.getTYPE();
        this.status = openAccountVSDNotificationFromQueue.getSTATUS();
        this.custoDyCd = openAccountVSDNotificationFromQueue.getCUSTODYCD();
        this.idNumber = openAccountVSDNotificationFromQueue.getIDNUMBER();
    }
}
