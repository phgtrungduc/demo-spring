package vn.com.vpbanks.flex.usecase.service.business.inquiry.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.InquiryOrderRepository;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.InquiryDetailOrderDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.InquiryOrderDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.SummaryAccountVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.AvailableTradeResponse;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.InquiryDetailOrderResponse;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.InquiryOrderResponse;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.RightOffListResponse;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.service.FlexInquiryOrderService;
import vn.com.vpbanks.flex.usecase.service.business.mapper.DetailOrderMapper;
import vn.com.vpbanks.flex.usecase.service.business.mapper.OrderMapper;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.CurrentDepartmentDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.DepartmentDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.DirectManagementDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.GetDepartmentDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.GetUnderBrokerDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.REGRPDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.common.utils.BaseRest;
import vn.com.vpbanks.flex.usecase.service.common.utils.CommonUtils;
import vn.com.vpbanks.flex.usecase.service.common.utils.MessageUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class FlexInquiryOrderImpl implements FlexInquiryOrderService {

    private static final int DEFAULT_OFFSET_VALUE = 0;
    private static final int DEFAULT_LIMIT_VALUE = 1000000000;

    private final InquiryOrderRepository inquiryOrderRepository;

    @Autowired
    private OrderMapper orderMapper;
    @Autowired
    private DetailOrderMapper detailOrderMapper;

    @Autowired
    private MessageUtil messageUtil;

    @Override
    public BaseResponse getDetailOrder(String accountId, String orderId, String orderType, String symbol, String orderStatus) {
        List<InquiryDetailOrderDVO> inquiryDetailOrderDVO = inquiryOrderRepository.getInquiryDetailOrder(accountId, orderId, orderType, symbol, orderStatus);
        List<InquiryDetailOrderResponse> inquiryOrderDTOS = detailOrderMapper.fromListSourceToListTarget(inquiryDetailOrderDVO);
        if (!Objects.isNull(inquiryOrderDTOS)) {
            BaseResponse baseResponse = null;
            baseResponse = BaseResponse.ofSucceeded();
            baseResponse.setData(!inquiryOrderDTOS.isEmpty() ? inquiryOrderDTOS.get(0) : null);
            baseResponse.setCode(BaseRest.RESPONSE.OK_CODE);
            return baseResponse;
        } else {
            BaseResponse baseResponse = null;
            baseResponse = BaseResponse.ofFailedFlexResponse(inquiryOrderDTOS);
            return baseResponse;
        }
    }

    public BaseResponse getOrder(String accountId, String orderId, String orderType, String symbol, String orderStatus, Long offset, Long limit) {
        offset = offset == null ? DEFAULT_OFFSET_VALUE : offset;
        limit = limit == null ? DEFAULT_LIMIT_VALUE : limit;

        List<InquiryOrderDVO> inquiryOrderDVOS = inquiryOrderRepository.getInquiryOrder(accountId, orderId, orderType, symbol, orderStatus, offset, limit);
        List<InquiryOrderResponse> inquiryOrderResponses = orderMapper.fromListSourceToListTarget(inquiryOrderDVOS);

        BaseResponse baseResponse;
        baseResponse = BaseResponse.ofSucceeded();
        baseResponse.setData(inquiryOrderResponses);
        baseResponse.setCode(BaseRest.RESPONSE.OK_CODE);

        return baseResponse;
    }

    @Override
    public BaseResponse getGetRightOffList(String accountId) {
        BaseResponse baseResponse = null;
        List<RightOffListResponse> rightOffListResponses = inquiryOrderRepository.getGetRightOffList(accountId);
        baseResponse = BaseResponse.ofSucceeded();
        baseResponse.setData(rightOffListResponses);
        baseResponse.setCode(BaseRest.RESPONSE.OK_CODE);
        return baseResponse;
    }

    @Override
    public BaseResponse getAvailableTrade(String accountId, String symbol, String quotePriceInput) {
        log.info("[getAvailableTrade] accountId: {},symbol : {}, quotePriceInput: {}", accountId, symbol, quotePriceInput);
        BigDecimal quotePrice = BigDecimal.ZERO;
        if (!StringUtils.isEmpty(quotePriceInput)) {
            try {
                quotePrice = new BigDecimal(quotePriceInput);
            } catch (NumberFormatException ex) {
                BaseResponse responses = new BaseResponse();
                responses.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_ERROR);
                responses.setMessage(messageUtil.getMessage("ERR101004"));
                responses.setCode(BaseRest.ERROR_CODE.ERR500);
                responses.setData("");
                return responses;
            }
        }

        BaseResponse baseResponse = null;
        List<AvailableTradeResponse> rightOffListResponses = inquiryOrderRepository.getAvailableTrade(accountId, symbol, quotePrice);
        baseResponse = BaseResponse.ofSucceeded();
        baseResponse.setData(rightOffListResponses);
        baseResponse.setCode(BaseRest.RESPONSE.OK_CODE);
        return baseResponse;

    }

    private List<String> getListAutoId(List<String> listAutoId, List<String> listTemp) {
        List<REGRPDto> listREGRPDto = inquiryOrderRepository.getByPrgrpid(listTemp);
        if (!CollectionUtils.isEmpty(listREGRPDto))
            listTemp = listREGRPDto.stream().map(REGRPDto::getAutoId).collect(Collectors.toList());
        else
            return listAutoId;

        if (!CollectionUtils.isEmpty(listREGRPDto)) {
            listAutoId.addAll(listTemp);
            getListAutoId(listAutoId, listTemp);
        }

        return listAutoId;
    }

    @Override
    public BaseResponse getUnderBroker(String custId, String searchkey, String dept, String underCustodycd, String getCurren) {

        BaseResponse baseResponse = null;
        GetUnderBrokerDto responses = inquiryOrderRepository.getUnderBroker(
                custId
                , searchkey
                , StringUtils.isEmpty(dept) ? null : Arrays.asList(dept.split(","))
                , StringUtils.isEmpty(underCustodycd) ? null : Arrays.asList(underCustodycd.split(","))
                , getCurren
        );
        baseResponse = BaseResponse.ofSucceeded();
        baseResponse.setData(responses);
        baseResponse.setCode(BaseRest.RESPONSE.OK_CODE);
        return baseResponse;
    }

    @Override
    public BaseResponse getDepartment(String custId, String code, String name) {

        BaseResponse baseResponse = null;
        GetDepartmentDto responses = inquiryOrderRepository.getDepartment(custId, code, name);
        baseResponse = BaseResponse.ofSucceeded();
        baseResponse.setData(responses);
        baseResponse.setCode(BaseRest.RESPONSE.OK_CODE);
        return baseResponse;
    }

    @Override
    public BaseResponse getCurrentDepartment(List<String> listReCustodycd, String reFullName, Integer page, Integer size) {

        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        List<CurrentDepartmentDto> responses = inquiryOrderRepository.getCurrentDepartment(listReCustodycd, reFullName, PageRequest.of(Objects.isNull(page) ? 0 : page, Objects.isNull(page) ? 500 : page));
        baseResponse.setData(responses);
        baseResponse.setCode(BaseRest.RESPONSE.OK_CODE);
        return baseResponse;
    }
}
