package vn.com.vpbanks.flex.usecase.service.business.inquiry.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.AFADTypeVO;

@Getter
@Setter
@NoArgsConstructor
public class AFTypeResponse {

    @JsonProperty("afAdType")
    private AFADTypeVO afAdType;

}
