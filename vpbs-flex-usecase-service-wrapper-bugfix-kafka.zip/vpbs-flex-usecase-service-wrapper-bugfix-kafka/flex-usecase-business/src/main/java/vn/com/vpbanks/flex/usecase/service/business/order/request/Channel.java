package vn.com.vpbanks.flex.usecase.service.business.order.request;

import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public enum Channel {
    CUSTOMER,
    BROKER,
    COUNTER;

    public static List<String> toStrings(List<Channel> channels) {
        List<String> output = new ArrayList<>();
        if (CollectionUtils.isEmpty(channels)) {
            return output;
        }

        return channels.stream()
                .filter(Objects::nonNull)
                .map(Enum::name)
                .collect(Collectors.toList());
    }
}
