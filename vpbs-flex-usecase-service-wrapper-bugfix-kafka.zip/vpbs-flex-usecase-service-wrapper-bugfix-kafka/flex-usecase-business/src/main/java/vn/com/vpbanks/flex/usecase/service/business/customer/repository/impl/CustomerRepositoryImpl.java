package vn.com.vpbanks.flex.usecase.service.business.customer.repository.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import vn.com.vpbanks.flex.usecase.service.business.customer.repository.CustomerRepository;
import vn.com.vpbanks.flex.usecase.service.business.customer.repository.vo.BeneficiaryAccountDVO;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Repository
@RequiredArgsConstructor
@Slf4j
public class CustomerRepositoryImpl implements CustomerRepository {
    private final EntityManager entityManager;
    private static final String SUCCESS_CD = "0";

    @Value("${vpbanks.flex.sp.SP_GET_BENEFICIARY_ACCOUNT}")
    private String SP_GET_BENEFICIARY_ACCOUNT;

    @Override
    public List<BeneficiaryAccountDVO> getBeneficiaryAccount(String custId) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_BENEFICIARY_ACCOUNT);

        query.registerStoredProcedureParameter("p_refcursor", Class.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_custid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.INOUT);

        query.setParameter("p_custid", custId);

        try {
            List<Object[]> objects = query.getResultList();

            List<BeneficiaryAccountDVO> beneficiaryAccountDVOS = objects.stream().map(item -> {
                BeneficiaryAccountDVO beneficiaryAccountDVO = BeneficiaryAccountDVO.builder()
                        .bankCode((String) item[0])
                        .bankName((String) item[1])
                        .bankAccountCode((String) item[2])
                        .bankAccountName((String) item[3])
                        .branchId((String) item[4])
                        .branchCode((String) item[5])
                        .branchName((String) item[6])
                        .isBankBond((String) item[7])
                        .bankId((BigDecimal) item[8])
                        .build();
                return beneficiaryAccountDVO;
            }).collect(Collectors.toList());

            return beneficiaryAccountDVOS;
        } catch (NoResultException ex) {
            log.error("NoResultException : {}", ex.getMessage());
            return null;
        }
    }
}
