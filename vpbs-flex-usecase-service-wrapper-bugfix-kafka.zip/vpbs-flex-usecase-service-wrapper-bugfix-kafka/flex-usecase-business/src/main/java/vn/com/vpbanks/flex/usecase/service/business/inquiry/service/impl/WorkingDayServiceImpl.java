package vn.com.vpbanks.flex.usecase.service.business.inquiry.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.WorkingDayRepository;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.CurrentDateFlexDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.WorkingDayDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.WorkingDayResponse;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.service.WorkingDayService;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class WorkingDayServiceImpl implements WorkingDayService {

    private final WorkingDayRepository workingDayRepository;

    @Override
    public List<WorkingDayResponse> getListWorkingDay(String fromDate, String toDate, String holiday) {
        List<WorkingDayDVO> days = workingDayRepository.getListWorkingDay(fromDate, toDate, holiday);
        List<WorkingDayResponse> workingDayResponseList = days.stream().map(WorkingDayResponse::new)
                .collect(Collectors.toList());
        return workingDayResponseList;
    }

    @Override
    public BaseResponse getCurrentDateFlex() {
        CurrentDateFlexDVO currentDate = workingDayRepository.getCurrentDateFlex();
        BaseResponse baseResponse = BaseResponse.ofSucceeded(currentDate);
        return baseResponse;
    }
}
