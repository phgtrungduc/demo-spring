package vn.com.vpbanks.flex.usecase.service.business.inquiry.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class InquiryDetailOrderResponse implements Serializable {
    @JsonProperty("custoDyCd")
    private String custoDyCd;

    @JsonProperty("txDate")
    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "Asia/Bangkok")
    private Date txDate;

    @JsonProperty("custId")
    private String custId;

    @JsonProperty("afAcctNo")
    private String afAcctNo;

    @JsonProperty("orderId")
    private String orderId;

    @JsonProperty("txTime")
    private String txTime;

    @JsonProperty("symbol")
    private String symbol;

    @JsonProperty("allowCancel")
    private String allowCancel;

    @JsonProperty("allowAmend")
    private String allowAmend;

    @JsonProperty("side")
    private String side;

    @JsonProperty("price")
    private BigDecimal price;

    @JsonProperty("priceType")
    private String priceType;

    @JsonProperty("via")
    private String via;

    @JsonProperty("qtty")
    private BigDecimal qtty;

    @JsonProperty("execqtty")
    private BigDecimal execQtty;

    @JsonProperty("execAmt")
    private BigDecimal execAmt;

    @JsonProperty("execPrice")
    private BigDecimal execPrice;

    @JsonProperty("remainQtty")
    private BigDecimal remainQtty;

    @JsonProperty("remainAmt")
    private BigDecimal remainAmt;

    @JsonProperty("status")
    private String status;

    @JsonProperty("orStatus")
    private String orStatus;

    @JsonProperty("enOrStatus")
    private String enOrStatus;

    @JsonProperty("tlName")
    private String tlName;

    @JsonProperty("username")
    private String username;

    @JsonProperty("hoseSession")
    private String hoseSession;

    @JsonProperty("cancelQtty")
    private BigDecimal cancelQtty;

    @JsonProperty("adjustQtty")
    private BigDecimal adjustQtty;

    @JsonProperty("isDisposal")
    private String isDisposal;

    @JsonProperty("rootOrderId")
    private String rootOrderId;

    @JsonProperty("timeType")
    private String timeType;

    @JsonProperty("timeTypeValue")
    private String timeTypeValue;

    @JsonProperty("feedBackMsg")
    private String feedBackMsg;

    @JsonProperty("limitPrice")
    private BigDecimal limitPrice;

    @JsonProperty("odTimeStamp")
    private String odTimeStamp;

    @JsonProperty("sdtime")
    private String sdtime;

    @JsonProperty("matchTypeCode")
    private String matchTypeCode;

    @JsonProperty("productTypeName")
    private String productTypeName;

    @JsonProperty("feeAmt")
    private BigDecimal feeAmt;

    @JsonProperty("taxSellAmt")
    private BigDecimal taxSellAmt;
}
