package vn.com.vpbanks.flex.usecase.service.business.broker.repository.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.procedure.ProcedureOutputs;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import vn.com.vpbanks.flex.usecase.service.business.broker.repository.HolderRepository;
import vn.com.vpbanks.flex.usecase.service.business.broker.repository.vo.HolderInfoDVO;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Component
@Slf4j
@RequiredArgsConstructor
public class HolderRepositoryImpl implements HolderRepository {
    private final EntityManager entityManager;

    @Value("${vpbanks.flex.sp.SP_GET_HOLDER}")
    private String SP_GET_HOLDER;

    @Override
    public List<HolderInfoDVO> getHolder(String custodyCd, String symbol) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_HOLDER);
        query.registerStoredProcedureParameter("p_refcursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_custodycd", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_symbol", String.class, ParameterMode.IN);

        query.setParameter("p_custodycd", custodyCd);
        query.setParameter("p_symbol", symbol);

        try {
            List<Object[]> objects = query.getResultList();
            query.unwrap(ProcedureOutputs.class).release();
            return objects.stream()
                    .map(item -> HolderInfoDVO.builder()
                            .custodyCd((String) item[0])
                            .symbol((String) item[1])
                            .isShareHolder(String.valueOf(item[2]))
                            .registerType((String) item[3])
                            .registerDate((String) item[4])
                            .registerTypeDescription((String) item[5])
                            .build())
                    .collect(Collectors.toList());
        } catch (Exception ex) {
            log.error("[getHolder] got exception : {}", ex.getMessage());
            return Collections.emptyList();
        }
    }
}

