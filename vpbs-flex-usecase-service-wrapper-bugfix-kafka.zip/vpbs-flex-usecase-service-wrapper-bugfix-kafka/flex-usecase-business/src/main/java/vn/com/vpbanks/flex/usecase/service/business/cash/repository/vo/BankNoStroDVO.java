package vn.com.vpbanks.flex.usecase.service.business.cash.repository.vo;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class BankNoStroDVO {

    @Id
    @Column(name = "BANKID")
    private String bankId;

    @Column(name = "BANKNAME")
    private String bankName;

    @Column(name = "BANKACCTNO")
    private String bankAcctNo;

    @Column(name = "GLACCOUNT")
    private String glAccount;
}
