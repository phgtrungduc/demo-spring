package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.InquiryOrderRepository;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.HistoryOrderDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.HistoryOrderMatchDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.InquiryDetailOrderDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.InquiryOrderDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.AvailableTradeResponse;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.RightOffListResponse;
import vn.com.vpbanks.flex.usecase.service.business.order.request.ChannelFlex;
import vn.com.vpbanks.flex.usecase.service.business.order.request.Day;
import vn.com.vpbanks.flex.usecase.service.business.order.request.Order;
import vn.com.vpbanks.flex.usecase.service.business.order.request.OrderCode;
import vn.com.vpbanks.flex.usecase.service.business.order.request.StockOrderFilter;
import vn.com.vpbanks.flex.usecase.service.business.order.request.StockOrderStatus;
import vn.com.vpbanks.flex.usecase.service.business.order.request.SubAccount;
import vn.com.vpbanks.flex.usecase.service.business.order.request.Timeline;
import vn.com.vpbanks.flex.usecase.service.business.order.response.StockFilterResponseDTO;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.CurrentDepartmentDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.DepartmentDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.GetDepartmentDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.GetUnderBrokerDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.REGRPDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.UnderBrokerDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseStoredProcedureResponse;
import vn.com.vpbanks.flex.usecase.service.common.utils.Constants;
import vn.com.vpbanks.flex.usecase.service.common.utils.DataUtils;
import vn.com.vpbanks.flex.usecase.service.common.exceptions.ApiException;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.ParameterMode;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class InquiryOrderRepositoryImpl implements InquiryOrderRepository {

    private static final String SUCCESS_CD = "0";
    private final EntityManager entityManager;

    @Value("${vpbanks.flex.sp.SP_GET_INQUIRY_ORDER}")
    private String SP_GET_INQUIRY_ORDER;
    @Value("${vpbanks.flex.sp.SP_GET_HISTORY_ORDER_MATCH}")
    private String SP_GET_HISTORY_ORDER_MATCH;

    @Value("${vpbanks.flex.sp.SP_GET_RIGHT_OFF_LIST}")
    private String SP_GET_RIGHT_OFF_LIST;

    @Value("${vpbanks.flex.sp.SP_GET_AVAILABLE_TRADE}")
    private String SP_GET_AVAILABLE_TRADE;

    @Value("${vpbanks.flex.sp.SP_GET_HISTORY_ORDER}")
    private String SP_GET_HISTORY_ORDER;

    @Value("${spring.datasource.hikari.schema}")
    private String schema;

    @Override
    public List<InquiryDetailOrderDVO> getInquiryDetailOrder(String accountId, String orderId, String execType, String symbol, String orsStatus) {

        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_INQUIRY_ORDER);
        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_accountId", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orderid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_execType", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_symbol", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orsStatus", String.class, ParameterMode.IN);

        query.setParameter("p_accountId", accountId);
        query.setParameter("p_orderid", orderId);
        query.setParameter("p_symbol", symbol);
        query.setParameter("p_execType", execType);
        query.setParameter("p_orsStatus", orsStatus);
        query.execute();

        List<InquiryDetailOrderDVO> inquiryDetailOrderDVOS = null;
        List<Object[]> orders = query.getResultList();

        inquiryDetailOrderDVOS = orders.stream().map(item -> {
            InquiryDetailOrderDVO.InquiryDetailOrderDVOBuilder builder = InquiryDetailOrderDVO.builder();
            builder.custoDyCd((String) item[0])
                    .txDate((Date) item[1])
                    .custId((String) item[2])
                    .afAcctNo((String) item[3])
                    .orderId((String) item[4])
                    .txTime((String) item[5])
                    .symbol((String) item[6])
                    .allowCancel((String) item[7])
                    .allowAmend((String) item[8])
                    .side((String) item[9])
                    .price((BigDecimal) item[10])
                    .priceType((String) item[11])
                    .via((String) item[12])
                    .qtty((BigDecimal) item[13])
                    .execQtty((BigDecimal) item[14])
                    .execAmt((BigDecimal) item[15])
                    .execPrice((BigDecimal) item[16])
                    .remainQtty((BigDecimal) item[17])
                    .remainAmt((BigDecimal) item[18])
                    .status((String) item[19])
                    .orStatus((String) item[20])
                    .enOrStatus((String) item[21])
                    .tlName((String) item[22])
                    .username((String) item[23])
                    .hoseSession((String) item[24])
                    .cancelQtty((BigDecimal) item[25])
                    .adjustQtty((BigDecimal) item[26])
                    .isDisposal((String) item[27])
                    .rootOrderId((String) item[28])
                    .timeType((String) item[29])
                    .timeTypeValue((String) item[30])
                    .feedBackMsg((String) item[31])
                    .limitPrice((BigDecimal) item[32])
                    .odTimeStamp((Timestamp) item[33])
                    .sdtime((String) item[34])
                    .matchTypeCode((String) item[35])
                    .productTypeName((String) item[36])
                    .feeAmt((BigDecimal) item[37])
                    .taxSellAmt((BigDecimal) item[38]);
            return builder.build();
        }).collect(Collectors.toList());
        return inquiryDetailOrderDVOS;
    }

    @Override
    public BaseStoredProcedureResponse<List<HistoryOrderMatchDVO>> getHistoryOrderMatch(String accountId, String fromDate, String toDate, String symbol, String execType, int offSet, int limit) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_HISTORY_ORDER_MATCH);
        query.registerStoredProcedureParameter("p_refcursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_accountId", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_fromDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_toDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_symbol", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_execType", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_offset", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_limit", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.INOUT);

        query.setParameter("p_accountId", accountId);
        query.setParameter("p_fromDate", fromDate);
        query.setParameter("p_toDate", toDate);
        query.setParameter("p_symbol", symbol);
        query.setParameter("p_execType", execType);
        query.setParameter("p_offset", offSet);
        query.setParameter("p_limit", limit);

        query.execute();
        String errCd = (String) query.getOutputParameterValue("p_err_code");
        String errMsg = (String) query.getOutputParameterValue("p_err_param");
        log.debug("errCd {} , errMsg {} ", errCd, errMsg);
        List<HistoryOrderMatchDVO> result = null;
        if (SUCCESS_CD.equals(errCd)) {
            try {
                List<Object[]> historyOrderMatchDVOS = query.getResultList();
                result = historyOrderMatchDVOS.stream().map(item -> {
                    HistoryOrderMatchDVO.HistoryOrderMatchDVOBuilder builder = HistoryOrderMatchDVO.builder();
                    builder.orderId((String) item[0])
                            .txDate((String) item[1])
                            .symbol((String) item[2])
                            .execType((String) item[3])
                            .side((String) item[4])
                            .priceType((String) item[5])
                            .matchTypeValue((String) item[6])
                            .matchQtty((BigDecimal) item[7])
                            .matchPrice((BigDecimal) item[8])
                            .matchAmt((BigDecimal) item[9])
                            .feeAmt((BigDecimal) item[10])
                            .vat((BigDecimal) item[11])
                            .via((String) item[12])
                            .sellTaxAmt((BigDecimal) item[13])
                            .makerName((String) item[14])
                            .afAcctNo((String) item[15])
                            .custoDyCd((String) item[16])
                            .fullName((String) item[17])
                            .fromDate((String) item[18])
                            .toDate((String) item[19])
                            .matchTypeCode((String) item[20])
                            .viaCode((String) item[21])
                            .feeRate((BigDecimal) item[22])
                            .r((BigDecimal) item[23])
                            .lCount((BigDecimal) item[24]);
                    return builder.build();
                }).collect(Collectors.toList());
            } catch (NoResultException ex) {
                result = null;
                log.error("[Error ] getHistoryOrderMatch stored procedure throw exception " + ex.getMessage());
            }
        }
        BaseStoredProcedureResponse<List<HistoryOrderMatchDVO>> storedProcedureResponse = new BaseStoredProcedureResponse<>();
        storedProcedureResponse.setData(result);
        storedProcedureResponse.setErrCd(errCd);
        storedProcedureResponse.setErrMsg(errMsg);

        return storedProcedureResponse;
    }

    @Override
    public List<InquiryOrderDVO> getInquiryOrder(String accountId, String orderId, String execType, String symbol, String orsStatus, Long offset, Long limit) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_INQUIRY_ORDER);
        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_accountId", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orderid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_execType", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_symbol", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orsStatus", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_offset", Long.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_limit", Long.class, ParameterMode.IN);

        query.setParameter("p_accountId", accountId);
        query.setParameter("p_orderid", orderId);
        query.setParameter("p_symbol", symbol);
        query.setParameter("p_execType", execType);
        query.setParameter("p_orsStatus", orsStatus);
        query.setParameter("p_offset", offset);
        query.setParameter("p_limit", limit);
        query.execute();

        List<InquiryOrderDVO> inquiryOrderDVOS = null;
        List<Object[]> orders = query.getResultList();

        inquiryOrderDVOS = orders.stream().map(item -> {
            InquiryOrderDVO.InquiryOrderDVOBuilder builder = InquiryOrderDVO.builder();
            builder.custoDyCd((String) item[0])
                    .txDate((Timestamp) item[1])
                    .custId((String) item[2])
                    .afAcctNo((String) item[3])
                    .orderId((String) item[4])
                    .txTime((String) item[5])
                    .symbol((String) item[6])
                    .allowCancel((String) item[7])
                    .allowAmend((String) item[8])
                    .side((String) item[9])
                    .price((BigDecimal) item[10])
                    .priceType((String) item[11])
                    .via((String) item[12])
                    .qtty((BigDecimal) item[13])
                    .execQtty((BigDecimal) item[14])
                    .execAmt((BigDecimal) item[15])
                    .execPrice((BigDecimal) item[16])
                    .remainQtty((BigDecimal) item[17])
                    .remainAmt((BigDecimal) item[18])
                    .status((String) item[19])
                    .orStatus((String) item[20])
                    .enOrStatus((String) item[21])
                    .tlName((String) item[22])
                    .username((String) item[23])
                    .hoseSession((String) item[24])
                    .cancelQtty((BigDecimal) item[25])
                    .adjustQtty((BigDecimal) item[26])
                    .isDisposal((String) item[27])
                    .rootOrderId((String) item[28])
                    .timeType((String) item[29])
                    .timeTypeValue((String) item[30])
                    .feedBackMsg((String) item[31])
                    .limitPrice((BigDecimal) item[32])
                    .odTimeStamp((Timestamp) item[33])
                    .sdtime((String) item[34])
                    .matchTypeCode((String) item[35])
                    .productTypeName((String) item[36])
                    .aright((BigDecimal) item[37])
                    .no((BigDecimal) item[38])
                    .totalElements((BigDecimal) item[39]);
            return builder.build();
        }).collect(Collectors.toList());
        return inquiryOrderDVOS;
    }

    public List<RightOffListResponse> getGetRightOffList(String accountId) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_RIGHT_OFF_LIST);
        query.registerStoredProcedureParameter("pv_refCursor", Class.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_accountId", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.OUT);

        query.setParameter("p_accountId", accountId);

        query.execute();
        List<RightOffListResponse> rightOffListResponses = null;
        List<Object[]> orders = query.getResultList();
        rightOffListResponses = orders.stream().map(item -> {
            RightOffListResponse.RightOffListResponseBuilder builder = RightOffListResponse.builder();
            builder.accountId((String) item[0])
                    .caMastId((String) item[1])
                    .symbol((String) item[2])
                    .rightBuyAvaIlaBle((BigDecimal) item[3])
                    .rightReGisTeRed((BigDecimal) item[4])
                    .price((BigDecimal) item[5])
                    .amt((BigDecimal) item[6])
                    .descRipTion((String) item[7])
                    .allowReGist((Character) item[8])
                    .reGistLastDate((String) item[9])
                    .exRate((String) item[10])
                    .rightOffRate((String) item[11])
                    .fromDateTransFer((String) item[12])
                    .toDateTransFer((String) item[13])
                    .secType((String) item[14])
                    .parValue((BigDecimal) item[16])
                    .beginDate((String) item[17])
                    .reportDate((String) item[18])
                    .qtty((BigDecimal) item[19])
                    .pendingQtty((BigDecimal) item[20])
                    .regQtty((BigDecimal) item[21])
                    .outBalance((BigDecimal) item[22])
                    .kdqDate((Date) item[23]);
            return builder.build();
        }).collect(Collectors.toList());
        return rightOffListResponses;
    }

    @Override
    public List<AvailableTradeResponse> getAvailableTrade(String accountId, String symbol, BigDecimal quotePrice) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_AVAILABLE_TRADE);
        query.registerStoredProcedureParameter("pv_refCuror", Class.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_accountId", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_symbol", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_quoteprice", BigDecimal.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.OUT);

        query.setParameter("p_accountId", accountId);
        query.setParameter("p_symbol", !StringUtils.isEmpty(symbol) ? symbol.toUpperCase() : "");
        query.setParameter("p_quoteprice", quotePrice != null ? quotePrice : BigDecimal.ZERO);

        query.execute();

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errParam = (String) query.getOutputParameterValue("p_err_param");

        if (SUCCESS_CD.equals(errCode)) {
            List<Object[]> availableTrades = query.getResultList();
            return availableTrades.stream().map(item -> {
                AvailableTradeResponse.AvailableTradeResponseBuilder builder = AvailableTradeResponse.builder();
                builder.ppse((BigDecimal) item[0])
                        .maxQtty((BigDecimal) item[1])
                        .trade((BigDecimal) item[2])
                        .mrRatioLoan((String) item[3])
                        .pp0((BigDecimal) item[4])
                        .balance((BigDecimal) item[5])
                        .cashPendingSend((BigDecimal) item[6])
                        .mortgage((BigDecimal) item[7])
                ;
                return builder.build();
            }).collect(Collectors.toList());
        } else {
            log.error("[getAvailableTrade] got error : {} {} ", errCode, errParam);
            throw new ApiException(errCode, errParam, null);
        }
    }

    @Override
    public BaseStoredProcedureResponse getHistoryOrder(String accountId, String fromDate, String toDate, String symbol, String execType, String orsStatus, Integer offset, Integer limit) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_HISTORY_ORDER);
        query.registerStoredProcedureParameter("p_refcursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_accountId", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_fromDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_toDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_symbol", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_execType", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_orsStatus", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_offset", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_limit", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.OUT);

        query.setParameter("p_accountId", accountId);
        query.setParameter("p_fromDate", fromDate);
        query.setParameter("p_toDate", toDate);
        query.setParameter("p_symbol", symbol == null ? "ALL" : symbol);
        query.setParameter("p_execType", execType == null ? "ALL" : execType);
        query.setParameter("p_orsStatus", orsStatus == null ? "ALL" : orsStatus);
        query.setParameter("p_offset", offset);
        query.setParameter("p_limit", limit);

        query.execute();
        String errCd = (String) query.getOutputParameterValue("p_err_code");
        String errMsg = (String) query.getOutputParameterValue("p_err_param");

        BaseStoredProcedureResponse baseStoredProcedureResponse = new BaseStoredProcedureResponse();

        if (SUCCESS_CD.equals(errCd)) {
            List<Object[]> objects = query.getResultList();
            if (!CollectionUtils.isEmpty(objects)) {
                List<HistoryOrderDVO> result = new ArrayList<>();

                result = objects.stream().map(object -> {
                    HistoryOrderDVO historyOrderDVO = HistoryOrderDVO.builder()
                            .orderId((String) object[0])
                            .txDate((String) object[1])
                            .symbol((String) object[2])
                            .execType((String) object[3])
                            .orderQtty((BigDecimal) object[4])
                            .quotePrice((BigDecimal) object[5])
                            .execQtty((BigDecimal) object[6])
                            .execPrice((BigDecimal) object[7])
                            .execAmt((BigDecimal) object[8])
                            .orStatus((String) object[10])
                            .feeAmt((BigDecimal) object[11])
                            .taxAmt((BigDecimal) object[12])
                            .markerName((String) object[16])
                            .via((String) object[18])
                            .side((String) object[19])
                            .orStatusValue((String) object[20])
                            .matchTypeValue((String) object[22])
                            .priceType((String) object[23])
                            .refOrderId((String) object[24])
                            .aright((BigDecimal) object[25])
                            .txTime((String) object[26])
                            .feeRate((BigDecimal) object[27])
                            .build();
                    return historyOrderDVO;
                }).collect(Collectors.toList());

                baseStoredProcedureResponse.setData(result);
            }

        }

        baseStoredProcedureResponse.setErrCd(errCd);
        baseStoredProcedureResponse.setErrMsg(errMsg);
        log.debug("errCd {} , errMsg {} ", errCd, errMsg);
        return baseStoredProcedureResponse;
    }

    @Override
    public List<REGRPDto> getByPrgrpid(List<String> listAutoId) {
        Map<String, Object> mapParam = new HashMap<>();
        List<REGRPDto> response = new ArrayList<>();
        StringBuilder sql = new StringBuilder(" select " +
                "AUTOID" +
                ",CUSTID" +
                ",PRGRPID" +
                ",FULLNAME" +
                " from "+ schema +".REGRP");
        sql.append(" where 1=1 ");
        if (!CollectionUtils.isEmpty(listAutoId)) {
            sql.append(" AND prgrpid in :autoId ");
            mapParam.put("autoId", listAutoId);
        } else
            return response;

        try {
            Query query = entityManager.createNativeQuery(sql.toString());
            mappingParamSql(mapParam, query);
            response = mappingListREGRPDto(query);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return response;

    }

    private REGRPDto mappingREGRPDto(Query query) {
        List<Object[]> rows = query.getResultList();
        if (CollectionUtils.isEmpty(rows)) {
            return null;
        }

        REGRPDto data = new REGRPDto();
        Object[] row = rows.get(0);

        data.setAutoId(DataUtils.toString(row[0]));
        data.setCustId(DataUtils.toString(row[1]));
        data.setPrgrpId(DataUtils.toString(row[2]));
        data.setFullName(DataUtils.toString(row[3]));

        return data;
    }

    private List<REGRPDto> mappingListREGRPDto(Query query) {
        List<Object[]> rows = query.getResultList();
        if (CollectionUtils.isEmpty(rows)) {
            return List.of();
        }
        List<REGRPDto> listData = new ArrayList<>(rows.size());
        REGRPDto data;
        for (Object[] row : rows) {

            data = new REGRPDto();
            data.setAutoId(DataUtils.toString(row[0]));
            data.setCustId(DataUtils.toString(row[1]));
            data.setPrgrpId(DataUtils.toString(row[2]));
            data.setFullName(DataUtils.toString(row[3]));

            listData.add(data);
        }
        return listData;
    }

    @Override
    public List<CurrentDepartmentDto> getCurrentDepartment(List<String> listReCustodycd, String reFullName, Pageable page) {
        List<CurrentDepartmentDto> response = new ArrayList<>();
        Map<String, Object> mapParam = new HashMap<>();
//        StringBuilder sql = new StringBuilder(" WITH cte (AUTOID,PRGRPID,CUSTID,DEPTID,DEPTNAME,ACTYPE,CUSTODYCD,FULLNAME) as " +
//                "(SELECT a.AUTOID " +
//                ",a.PRGRPID " +
//                ",a.CUSTID" +
//                " , CASE WHEN a.FULLNAME LIKE '%VIP%' THEN 'VIP' WHEN a.FULLNAME LIKE '%EPartner%' THEN 'ePartner'      ELSE SUBSTR(a.FULLNAME,18,4) END  DEPTID " +
//                ",a.FULLNAME DEPTNAME" +
//                ",a.ACTYPE" +
//                ",cf.CUSTODYCD" +
//                ",cf.FULLNAME" +
//                " FROM REGRP a " +
//                " INNER JOIN CFMAST cf ON a.CUSTID = cf.CUSTID " +
//                " where a.STATUS = 'A' AND cf.CUSTODYCD IN ( :custodycd )" +
//                " UNION ALL " +
//                " SELECT R.AUTOID,R.PRGRPID,b.CUSTID" +
//                " , CASE WHEN R.FULLNAME LIKE '%VIP%' THEN 'VIP' WHEN R.FULLNAME LIKE '%EPartner%' THEN 'ePartner'      ELSE SUBSTR(R.FULLNAME,18,4) END  DEPTID " +
//                " ,R.FULLNAME DEPTNAME,R.ACTYPE,b.CUSTODYCD,b.FULLNAME " +
//                "  FROM  cte b     " +
//                " INNER JOIN REGRP R ON b.PRGRPID = R.AUTOID and R.STATUS = 'A' "+
//                //"  INNER JOIN CFMAST cf ON R.CUSTID = cf.CUSTID ) "+
//                " ) " +
//                " select a.CUSTID,a.DEPTID,a.DEPTNAME,a.FULLNAME,a.CUSTODYCD from cte a  " +
//                " inner join (  select min(ACTYPE) as MIN_ACTYPE , CUSTID   " +
//                "                    from cte  where (ACTYPE = '0001' or ACTYPE = '0005')  " +
//                "                     group by CUSTID  " +
//                "                    ) b on a.ACTYPE = b.MIN_ACTYPE " +
//                " where 1=1 ");

        StringBuilder sql = new StringBuilder("WITH pb (\n" +
                "    custid,\n" +
                "    autoid,\n" +
                "    actype,\n" +
                "    fullname,\n" +
                "    ref_custid,\n" +
                "    custodycd\n" +
                ") AS (\n" +
                "    SELECT\n" +
                "        rl.custid,\n" +
                "        r.autoid autoid,\n" +
                "        r.actype,\n" +
                "        r.fullname,\n" +
                "        r.custid ref_custid,\n" +
                "        cf.custodycd\n" +
                "    FROM\n" +
                "             "+ schema +".regrplnk rl\n" +
                "        INNER JOIN "+ schema +".regrp  r ON r.autoid = rl.refrecflnkid\n" +
                "                                       AND rl.status = 'A'\n" +
                "        INNER JOIN "+ schema +".cfmast cf ON rl.custid = cf.custid\n" +
                "    WHERE\n" +
                "            1 = 1\n" +
                "        AND cf.custodycd IN ( :custodycd )\n" +
                "    UNION ALL\n" +
                "    SELECT\n" +
                "        pb.custid,\n" +
                "        r.prgrpid autoid,\n" +
                "        r.actype,\n" +
                "        r.fullname,\n" +
                "        r.custid  ref_custid,\n" +
                "        pb.custodycd\n" +
                "    FROM\n" +
                "             pb pb\n" +
                "        INNER JOIN "+ schema +".regrp r ON pb.autoid = r.autoid\n" +
                "                                       AND r.status = 'A'\n" +
                ")\n" +
                "SELECT\n" +
                "   distinct  \n" +
                "   pb.custid,\n" +
                "    CASE\n" +
                "            WHEN pb.fullname LIKE '%VIP%' THEN\n" +
                "                'VIP'\n" +
                "            WHEN pb.fullname LIKE '%EPartner%' THEN\n" +
                "                'ePartner'\n" +
                "            ELSE\n" +
                "                substr(pb.fullname, 18, 4)\n" +
                "        END        deptid,\n" +
                "        pb.fullname deptname,\n" +
                "    cf.fullname,\n" +
                "    pb.custodycd\n" +
                "FROM\n" +
                "         pb pb\n" +
                "         INNER JOIN "+ schema +".cfmast cf ON pb.custid = cf.custid\n" +
                "    INNER JOIN (\n" +
                "        SELECT\n" +
                "            MIN(actype) AS min_actype,\n" +
                "            custid\n" +
                "        FROM\n" +
                "            pb\n" +
                "        WHERE\n" +
                "            ( actype = '0001'\n" +
                "              OR actype = '0005' )\n" +
                "        GROUP BY\n" +
                "            custid\n" +
                "    ) bptemp ON bptemp.custid = pb.custid\n" +
                "                AND bptemp.min_actype = pb.actype");
        mapParam.put("custodycd", listReCustodycd);

        if (!StringUtils.isEmpty(reFullName)) {
            sql.append(" AND upper(pb.fullname.DEPTNAME) LIKE :fullName  ");
            mapParam.put("fullName", "%" + reFullName.toUpperCase() + "%");
        }

        try {
            Query query = entityManager.createNativeQuery(sql.toString());
            mappingParamSql(mapParam, query);

//            query.setFirstResult(page.getPageNumber() * page.getPageSize());
//            query.setMaxResults(page.getPageSize());

            response = getCurrentDepartment(query);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return response;
    }

    private void sqlNative(StringBuilder sql){
        sql.append(" " +
                " SELECT voa.ORDERID\n" +
                "                     AS ORDERID,\n" +
                "       voa.REFORDERID\n" +
                "                     AS REFORDERID,\n" +
                "       UPPER(a1.EN_CDCONTENT)\n" +
                "                     AS side,                 -- BUY/SELL loại lệnh (điều kiện tìm kiếm)\n" +
                "       (CASE\n" +
                "            WHEN voa.REMAINQTTY <> 0 AND voa1.EDSTATUS = 'C'\n" +
                "                THEN\n" +
                "                'C'\n" +
                "            WHEN voa.REMAINQTTY <> 0 AND voa1.EDSTATUS = 'A'\n" +
                "                THEN\n" +
                "                'A'\n" +
                "            WHEN voa1.EDSTATUS IS NULL AND voa.CANCELQTTY <> 0\n" +
                "                THEN\n" +
                "                '6'\n" +
                "            WHEN voa.REMAINQTTY = 0\n" +
                "                AND voa.CANCELQTTY <> 0\n" +
                "                AND voa1.EDSTATUS = 'C'\n" +
                "                THEN\n" +
                "                '3'\n" +
                "            WHEN voa.REMAINQTTY = 0\n" +
                "                AND voa.ADJUSTQTTY > 0\n" +
                "                AND voa.pricetype = 'MP'\n" +
                "                THEN\n" +
                "                '4'\n" +
                "            WHEN voa.REMAINQTTY = 0 AND voa.ADJUSTQTTY > 0\n" +
                "                THEN\n" +
                "                '10'\n" +
                "            WHEN voa.REMAINQTTY = 0\n" +
                "                AND voa.EXECQTTY > 0\n" +
                "                AND voa.ORSTATUS = '4'\n" +
                "                THEN\n" +
                "                '12'\n" +
                "            ELSE\n" +
                "                voa.ORSTATUS\n" +
                "           END)\n" +
                "                     AS status,               -- status flex\n" +
                "       boa.ORSTATUSVALUE\n" +
                "                     AS statusValue,\n" +
                "       voa.quoteprice\n" +
                "                     AS price,                --giá\n" +
                "       sb.SYMBOL\n" +
                "                     AS symbol,               --mã cổ phiếu (điều kiện tìm kiếm)\n" +
                "       boa.EXECQTTY\n" +
                "                     AS matchVolumeInDay,     --Khối lượng khớp lệnh trong ngay\n" +
                "       voa.EXECQTTY\n" +
                "                     AS matchVolumeDay,       --Khối lượng khớp lệnh lịch sử\n" +
                "       voa.orderqtty\n" +
                "                     AS Volume,               -- khối lượng đặt\n" +
                "       cf.CUSTODYCD  AS CFCUSTODYCD,          --So tai khoan khách hàng (điều kiện tìm kiếm)\n" +
                "       cf.FULLNAME   AS FULLNAME,             --So tai khoan khách hàng\n" +
                "       substr(UPPER(accountType.EN_CDCONTENT), 2, length(accountType.EN_CDCONTENT)) \n" +
                "                     AS acctype_EN_CDCONTENT, -- tiểu khoản, thương/ ký quỹ (điều kiện tìm kiếm)\n" +
                "       TO_CHAR(voa.TXDATE, 'dd/mm/yyyy')    AS TXDATE,               --ngày bắt đầu (điều kiện tìm kiếm)\n" +
                "       voa.TXTIME    AS TXTIME,               --ngày bắt đầu (điều kiện tìm kiếm)\n" +
                "       TO_CHAR(voa.EXPDATE, 'dd/mm/yyyy')   AS EXPDATE,              -- ngày kết thúc\n" +
                "       voa.LAST_CHANGE,                       -- thời gian hủy, sửa, đặt\n" +
                "       voa.AFACCTNO\n" +
                "                     AS accountId,            --accountId số tiểu khản khách hàng (điều kiện tìm kiếm)\n" +
                "       CASE boa.ISDISPOSAL WHEN 'Y' THEN 'N' ELSE boa.ISCANCEL END\n" +
                "                     AS allowCancel,\n" +
                "       CASE boa.ISDISPOSAL WHEN 'Y' THEN 'N' ELSE boa.ISADMEND END\n" +
                "                     AS allowAmend,\n" +
                "       voa.pricetype AS PRICETYPE,            --Loai lênh (điều kiện tìm kiếm),\n" +
                "       cf.MOBILESMS,\n" +
                " CONCAT(TO_CHAR(voa.txdate, 'dd/mm/yyyy '), voa.txtime) createDate, "+
                " ROUND(case when voa.EXECQTTY > 0 then voa.EXECAMT/voa.EXECQTTY else 0 end,4) execprice, "+
                "       cf.custid cfCustId, \n" +

                "       0 total                       \n" +
                "FROM "+ schema +".CFMAST cf\n" +
                "         LEFT JOIN "+ schema +".AFMAST af ON cf.CUSTID = af.CUSTID\n" +
                "         LEFT JOIN "+ schema +".vw_odmast_all voa ON af.ACCTNO = voa.AFACCTNO\n" +
                "         LEFT JOIN "+ schema +".vw_odmast_all voa1\n" +
                "                   ON voa.ORDERID = voa1.REFORDERID\n" +
                "                       AND voa1.EDSTATUS IN ('C', 'A')\n" +
                "                       AND voa1.EXECTYPE NOT IN ('NB', 'NS')\n" +
                "                       AND voa1.ORSTATUS NOT IN ('0', '5', '6')\n" +
                "         LEFT JOIN "+ schema +".buf_od_account boa ON voa.ORDERID = boa.ORDERID\n" +
                "         LEFT JOIN "+ schema +".allcode accountType\n" +
                "                   ON accountType.cdname = 'PRODUCTTYPE'\n" +
                "                       AND accountType.CDTYPE = 'CF'\n" +
                "                       AND accountType.cdval = af.producttype\n" +
                "         LEFT JOIN "+ schema +".SBSECURITIES sb ON voa.CODEID = sb.CODEID\n" +
                "         LEFT JOIN "+ schema +".allcode a1\n" +
                "                   ON a1.cdname = 'EXECTYPE'\n" +
                "                       AND a1.cdtype = 'FO'\n" +
                "                       AND a1.cdval = voa.exectype\n" +
                "         LEFT JOIN "+ schema +".TLPROFILES TLP ON voa.TLID = TLP.TLID\n" +
                "         LEFT JOIN "+ schema +".allcode a2\n" +
                "                   ON a2.cdname = 'VIA'\n" +
                "                       AND a2.cdtype = 'OD'\n" +
                "                       AND a2.cdcontent = voa.via\n" +
                "         LEFT JOIN "+ schema +".CONFIRMODRSTS FIRM\n" +
                "                   ON voa.ORDERID = FIRM.ORDERID\n" +
                "         LEFT JOIN "+ schema +".ALLCODE A4\n" +
                "                   ON A4.CDTYPE = 'SY'\n" +
                "                       AND A4.CDNAME = 'YESNO'\n" +
                "                       AND A4.CDVAL =\n" +
                "                           (CASE\n" +
                "                                WHEN voa.TLID = '6868' THEN 'Y'\n" +
                "                                ELSE NVL(FIRM.CONFIRMED, 'N')\n" +
                "                               END)\n" +
                "WHERE 1 = 1\n" +
                "  AND SUBSTR(voa.EXECTYPE, 1, 1) <> 'C'\n" +
                "  AND SUBSTR(voa.EXECTYPE, 1, 1) <> 'A'\n" +
                "  AND (voa.execqtty <> 0 OR voa.edstatus NOT IN ('C', 'A')) ");
    }

    private void sqlNativeTotal(StringBuilder sql){
        sql.append(" " +
                " SELECT null   AS ORDERID,\n" +
                "       null      AS REFORDERID,\n" +
                "       null              AS side,                 -- BUY/SELL loại lệnh (điều kiện tìm kiếm)\n" +
                "       null     AS status,               -- status flex\n" +
                "       null     AS statusValue,\n" +
                "       null      AS price,                --giá\n" +
                "       null        AS symbol,               --mã cổ phiếu (điều kiện tìm kiếm)\n" +
                "       null       AS matchVolumeInDay,     --Khối lượng khớp lệnh trong ngay\n" +
                "       null       AS matchVolumeDay,       --Khối lượng khớp lệnh lịch sử\n" +
                "       null      AS Volume,               -- khối lượng đặt\n" +
                "       null  AS CFCUSTODYCD,          --So tai khoan khách hàng (điều kiện tìm kiếm)\n" +
                "       null   AS FULLNAME,             --So tai khoan khách hàng\n" +
                "       null  AS acctype_EN_CDCONTENT, -- tiểu khoản, thương/ ký quỹ (điều kiện tìm kiếm)\n" +
                "       null   AS TXDATE,               --ngày bắt đầu (điều kiện tìm kiếm)\n" +
                "       null    AS TXTIME,               --ngày bắt đầu (điều kiện tìm kiếm)\n" +
                "       null   AS EXPDATE,              -- ngày kết thúc\n" +
                "       null LAST_CHANGE,                       -- thời gian hủy, sửa, đặt\n" +
                "       null           AS accountId,            --accountId số tiểu khản khách hàng (điều kiện tìm kiếm)\n" +
                "       null       AS allowCancel,\n" +
                "       null  AS allowAmend,\n" +
                "       null AS PRICETYPE,            --Loai lênh (điều kiện tìm kiếm),\n" +
                "       null MOBILESMS,\n" +
                " null createDate, "+
                " null execprice, "+
                "       null cfCustId, \n" +

                "       count(*) total                       \n" +
                "FROM "+ schema +".CFMAST cf\n" +
                "         LEFT JOIN "+ schema +".AFMAST af ON cf.CUSTID = af.CUSTID\n" +
                "         LEFT JOIN "+ schema +".vw_odmast_all voa ON af.ACCTNO = voa.AFACCTNO\n" +
                "         LEFT JOIN "+ schema +".vw_odmast_all voa1\n" +
                "                   ON voa.ORDERID = voa1.REFORDERID\n" +
                "                       AND voa1.EDSTATUS IN ('C', 'A')\n" +
                "                       AND voa1.EXECTYPE NOT IN ('NB', 'NS')\n" +
                "                       AND voa1.ORSTATUS NOT IN ('0', '5', '6')\n" +
                "         LEFT JOIN "+ schema +".buf_od_account boa ON voa.ORDERID = boa.ORDERID\n" +
                "         LEFT JOIN "+ schema +".allcode accountType\n" +
                "                   ON accountType.cdname = 'PRODUCTTYPE'\n" +
                "                       AND accountType.CDTYPE = 'CF'\n" +
                "                       AND accountType.cdval = af.producttype\n" +
                "         LEFT JOIN "+ schema +".SBSECURITIES sb ON voa.CODEID = sb.CODEID\n" +
                "         LEFT JOIN "+ schema +".allcode a1\n" +
                "                   ON a1.cdname = 'EXECTYPE'\n" +
                "                       AND a1.cdtype = 'FO'\n" +
                "                       AND a1.cdval = voa.exectype\n" +
                "         LEFT JOIN "+ schema +".TLPROFILES TLP ON voa.TLID = TLP.TLID\n" +
                "         LEFT JOIN "+ schema +".allcode a2\n" +
                "                   ON a2.cdname = 'VIA'\n" +
                "                       AND a2.cdtype = 'OD'\n" +
                "                       AND a2.cdcontent = voa.via\n" +
                "         LEFT JOIN "+ schema +".CONFIRMODRSTS FIRM\n" +
                "                   ON voa.ORDERID = FIRM.ORDERID\n" +
                "         LEFT JOIN "+ schema +".ALLCODE A4\n" +
                "                   ON A4.CDTYPE = 'SY'\n" +
                "                       AND A4.CDNAME = 'YESNO'\n" +
                "                       AND A4.CDVAL =\n" +
                "                           (CASE\n" +
                "                                WHEN voa.TLID = '6868' THEN 'Y'\n" +
                "                                ELSE NVL(FIRM.CONFIRMED, 'N')\n" +
                "                               END)\n" +
                "WHERE 1 = 1\n" +
                "  AND SUBSTR(voa.EXECTYPE, 1, 1) <> 'C'\n" +
                "  AND SUBSTR(voa.EXECTYPE, 1, 1) <> 'A'\n" +
                "  AND (voa.execqtty <> 0 OR voa.edstatus NOT IN ('C', 'A')) ");
    }

    private void condition(StockOrderFilter stockOrderFilter, StringBuilder sql, Map<String, Object> mapParam, boolean showTotalPage){

        if (!Objects.isNull(stockOrderFilter.getStatus()) && stockOrderFilter.getStatus() != StockOrderStatus.ALL) {
            sql.append(" AND (CASE\n" +
                    "           WHEN voa.REMAINQTTY <> 0 AND voa1.EDSTATUS = 'C'\n" +
                    "               THEN\n" +
                    "               'C'\n" +
                    "           WHEN voa.REMAINQTTY <> 0 AND voa1.EDSTATUS = 'A'\n" +
                    "               THEN\n" +
                    "               'A'\n" +
                    "           WHEN voa1.EDSTATUS IS NULL AND voa.CANCELQTTY <> 0\n" +
                    "               THEN\n" +
                    "               '6'\n" +
                    "           WHEN voa.REMAINQTTY = 0\n" +
                    "               AND voa.CANCELQTTY <> 0\n" +
                    "               AND voa1.EDSTATUS = 'C'\n" +
                    "               THEN\n" +
                    "               '3'\n" +
                    "           WHEN voa.REMAINQTTY = 0\n" +
                    "               AND voa.ADJUSTQTTY > 0\n" +
                    "               AND voa.pricetype = 'MP'\n" +
                    "               THEN\n" +
                    "               '4'\n" +
                    "           WHEN voa.REMAINQTTY = 0 AND voa.ADJUSTQTTY > 0\n" +
                    "               THEN\n" +
                    "               '10'\n" +
                    "           WHEN voa.REMAINQTTY = 0\n" +
                    "               AND voa.EXECQTTY > 0\n" +
                    "               AND voa.ORSTATUS = '4'\n" +
                    "               THEN\n" +
                    "               '12'\n" +
                    "           ELSE\n" +
                    "               voa.ORSTATUS\n" +
                    "    END) IN :status ");
            mapParam.put("status", stockOrderFilter.getFlexStatus());
        }

        if (!CollectionUtils.isEmpty(stockOrderFilter.getCustomerAccountNumbers())) {
            sql.append(" AND upper(cf.CUSTODYCD) IN :custodyCds  ");
            mapParam.put("custodyCds", DataUtils.toUpper(stockOrderFilter.getCustomerAccountNumbers()));
        }

        if (!Strings.isEmpty(stockOrderFilter.getCustomerAccountNumber())) {
            sql.append("  AND upper(cf.CUSTODYCD) = :custodyCd ");
            mapParam.put("custodyCd", DataUtils.toUpper(stockOrderFilter.getCustomerAccountNumber()));
        }

        if (!CollectionUtils.isEmpty(stockOrderFilter.getStockSymbols())) {
            sql.append(" AND upper(sb.SYMBOL) IN  :stockSymbol ");
            mapParam.put("stockSymbol", DataUtils.toUpper(stockOrderFilter.getStockSymbols()));
        }

        if (!Strings.isEmpty(stockOrderFilter.getSymbol())) {
            sql.append(" AND upper(sb.SYMBOL) LIKE :symbol ");
            mapParam.put("symbol", "%" + stockOrderFilter.getSymbol() + "%");
        }

        if (!CollectionUtils.isEmpty(stockOrderFilter.getSubAccounts())) {
            sql.append(" AND UPPER(accountType.EN_CDCONTENT) IN  :subAccount ");
            mapParam.put("subAccount", SubAccount.toStringDot(stockOrderFilter.getSubAccounts()));
        }

        //filter by price type (LO / ATO)
        if (!CollectionUtils.isEmpty(stockOrderFilter.getOrderCodes())) {
            sql.append(" AND upper(voa.pricetype) IN :orderCode ");
            mapParam.put("orderCode", OrderCode.toStrings(stockOrderFilter.getOrderCodes()));
        }

        //filter by side (BUY/SELL)
        if (!CollectionUtils.isEmpty(stockOrderFilter.getOrderSides())) {
            sql.append(" AND UPPER(a1.EN_CDCONTENT) IN :side ");

            mapParam.put("side", Order.toStrings(stockOrderFilter.getOrderSides()));
        }

        //filter by channel (SALESUPORT/WEB)
        if (!CollectionUtils.isEmpty(stockOrderFilter.getChannels())) {
            sql.append(" AND upper(voa.VIA) IN  :via ");
            mapParam.put("via", ChannelFlex.toStrings(stockOrderFilter.getChannels()));
        }

        if (!Strings.isEmpty(stockOrderFilter.getStartDate())) {
            sql.append(" AND voa.TXDATE >= TO_DATE(:startDate, 'dd/mm/yyyy')");
            mapParam.put("startDate", stockOrderFilter.getStartDate().toString());
        }
        if (!Strings.isEmpty(stockOrderFilter.getToDate())) {
            sql.append(" AND voa.TXDATE   <= TO_DATE(:toDate, 'dd/mm/yyyy')");
            mapParam.put("toDate", stockOrderFilter.getToDate());
        }

        if (!Objects.isNull(stockOrderFilter.getConfirmStatus())) {
            sql.append(" AND UPPER(a4.en_cdcontent) = :confirm ");
            mapParam.put("confirm", stockOrderFilter.getConfirmStatus().name());
        }

        if (!Objects.isNull(stockOrderFilter.getDay())) {
            if(stockOrderFilter.getDay() == Day.IN){
                sql.append(" AND CASE boa.ISDISPOSAL WHEN 'Y' THEN 'N' ELSE boa.ISCANCEL END IS NOT NULL ");
                sql.append(" AND CASE boa.ISDISPOSAL WHEN 'Y' THEN 'N' ELSE boa.ISADMEND END IS NOT NULL ");
            }
            if(stockOrderFilter.getDay() == Day.OUT){
                sql.append(" AND CASE boa.ISDISPOSAL WHEN 'Y' THEN 'N' ELSE boa.ISCANCEL END IS NULL ");
                sql.append(" AND CASE boa.ISDISPOSAL WHEN 'Y' THEN 'N' ELSE boa.ISADMEND END IS NULL ");
            }
        }

        if(!CollectionUtils.isEmpty(stockOrderFilter.getTimelines())){
            stockOrderFilter.getTimelines().stream().filter(Objects::nonNull).forEach(value -> {
                if (value == Timeline.OPTION) {
                    return;
                }
                sql.append(" AND ( ");
                if (value == Timeline.IN_DAY) {
                    sql.append("  voa.TXDATE >= CURRENT_DATE ");
                }
                if (value == Timeline.ONE_HOUR) {
                    sql.append(" TO_CHAR(voa.TXDATE, 'dd/MM/yyyy') = TO_CHAR(CURRENT_DATE, 'dd/MM/yyyy') ");
                    sql.append(" AND (cast(voa.txtime AS time(0)) BETWEEN ");
                    sql.append(" cast((LOCALTIMESTAMP - interval '1 hour') AS time(0)) ");
                    sql.append(" AND cast(LOCALTIMESTAMP AS time(0))) ");
                }
                if (value == Timeline.THREE_HOURS) {
                    sql.append(" TO_CHAR(voa.TXDATE, 'dd/MM/yyyy') = TO_CHAR(CURRENT_DATE, 'dd/MM/yyyy') ");
                    sql.append(" AND (cast(voa.txtime AS time(0)) BETWEEN ");
                    sql.append(" cast((LOCALTIMESTAMP - interval '3 hour') AS time(0)) ");
                    sql.append(" AND cast(LOCALTIMESTAMP AS time(0))) ");
                }
                if (value == Timeline.ONE_MONTH) {
                    sql.append(" voa.TXDATE >= (TRUNC(SYSDATE) - interval '1' month) ");
                    sql.append(" AND voa.TXDATE <= CURRENT_DATE ");
                }
                if (value == Timeline.TWO_MONTH) {
                    sql.append(" voa.TXDATE >= (TRUNC(SYSDATE) - interval '2' month) ");
                    sql.append(" AND voa.TXDATE <= CURRENT_DATE ");
                }
                if (value == Timeline.THREE_MONTH) {
                    sql.append(" voa.TXDATE >= (TRUNC(SYSDATE) - interval '3' month) ");
                    sql.append(" AND voa.TXDATE <= CURRENT_DATE ");
                }
                sql.append(" ) ");
            });
        }

        if(showTotalPage){
            return;
        }
        if (null != stockOrderFilter.getPage() && null != stockOrderFilter.getSize()) {
            sql.append(" order by voa.TXDATE DESC, voa.TXTIME DESC  OFFSET :page ROWS FETCH NEXT :size ROWS ONLY ");
            mapParam.put("page", stockOrderFilter.getPage() * stockOrderFilter.getSize());
            mapParam.put("size", stockOrderFilter.getSize() );
        }
    }

    @Override
    public List<StockFilterResponseDTO> orderBooks(StockOrderFilter stockOrderFilter) {
        List<StockFilterResponseDTO> response = new ArrayList<>();
        Map<String, Object> mapParam = new HashMap<>();
        StringBuilder sql = new StringBuilder();
        sql.append(" ( ");
        sqlNativeTotal(sql);
        condition(stockOrderFilter,sql, mapParam, true);
        sql.append(" ) ");

        sql.append(" UNION ALL ");

        sql.append(" ( ");

        sqlNative(sql);
        condition(stockOrderFilter,sql, mapParam, false);
        sql.append(" )");



        try {
            Query query = entityManager.createNativeQuery(sql.toString());
            mappingParamSql(mapParam, query);
            response = getOrderBook(query);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return response;
    }

    private List<CurrentDepartmentDto> getCurrentDepartment(Query query) {
        List<Object[]> rows = query.getResultList();
        if (CollectionUtils.isEmpty(rows)) {
            return List.of();
        }
        List<CurrentDepartmentDto> listData = new ArrayList<>(rows.size());
        CurrentDepartmentDto data;
        for (Object[] row : rows) {

            data = new CurrentDepartmentDto();
            data.setCustId(DataUtils.toString(row[0]));
            data.setDeptCode(DataUtils.toString(row[1]));
            data.setDeptName(DataUtils.toString(row[2]));
            data.setFullName(DataUtils.toString(row[3]));
            data.setCustodycd(DataUtils.toString(row[4]));
            listData.add(data);
        }
        return listData;
    }

    private String mappingStatus(Object status, Object statusValue){
        String statusValues = DataUtils.safeToString(statusValue);
        String statues = DataUtils.safeToString(status);
        if("5".equals(statusValues) && !DataUtils.safeToString(statusValues).equals(statues)){
            return statues;
        }

        if(!Strings.isEmpty(statusValues)){
            return statusValues;
        }
        return statues;
    }


    private List<StockFilterResponseDTO> getOrderBook(Query query) {
        List<Object[]> rows = query.getResultList();
        if (CollectionUtils.isEmpty(rows)) {
            return List.of();
        }
        List<StockFilterResponseDTO> listData = new ArrayList<>(rows.size());
        StockFilterResponseDTO stockFilterResponse;
        for (Object[] row : rows) {

            stockFilterResponse = new StockFilterResponseDTO();
            stockFilterResponse.setStockOrderId(DataUtils.safeToString(row[0]));
            stockFilterResponse.setRefOrderId(DataUtils.safeToString(row[1]));
            stockFilterResponse.setOrderSide(DataUtils.safeToString(row[2]));
            stockFilterResponse.setStatus( mappingStatus(DataUtils.safeToString(row[3]), DataUtils.safeToString(row[4])) );
            stockFilterResponse.setOrderPrice(DataUtils.safeToBigDecimal(row[5]));
            stockFilterResponse.setStockCode(DataUtils.safeToString(row[6]));
            stockFilterResponse.setJoinVolume(row[7] != null?DataUtils.safeToLong(row[7]):DataUtils.safeToLong(row[8]));
            stockFilterResponse.setJoin(DataUtils.safeToLong(row[9]));
            stockFilterResponse.setCustomerAccountNumber(DataUtils.safeToString(row[10]));
            stockFilterResponse.setCustomerAccountName(DataUtils.safeToString(row[11]));
            stockFilterResponse.setPhone(DataUtils.safeToString(row[21]));
            stockFilterResponse.setSubAccount(DataUtils.safeToString(row[12]));
            stockFilterResponse.setStartDate(DataUtils.safeToString(row[13]));
            stockFilterResponse.setExpiredDate(DataUtils.safeToString(row[15]));
            stockFilterResponse.setLastModifiedDate(DataUtils.safeToString(row[16]));
            stockFilterResponse.setAccountId(DataUtils.safeToString(row[17]));
            stockFilterResponse.setAllowCancel(DataUtils.safeToString(row[18]));
            stockFilterResponse.setAllowAmend(DataUtils.safeToString(row[19]));
            stockFilterResponse.setOrderCode(DataUtils.safeToString(row[20]));
            stockFilterResponse.setCreateDate(DataUtils.safeToString(row[22]));
            stockFilterResponse.setExecPrice(DataUtils.safeToBigDecimal(row[23]));
            stockFilterResponse.setCustId(DataUtils.safeToString(row[24]));
            stockFilterResponse.setTotal(DataUtils.safeToBigDecimal(row[25]));
            stockFilterResponse.setOrderCustodyCd("");
            listData.add(stockFilterResponse);
        }
        return listData;
    }

    @Override
    public GetUnderBrokerDto getUnderBroker(String custId, String searchkey, List<String> listDept, List<String> listUnderCustodycd, String getCurren) {
        GetUnderBrokerDto response = new GetUnderBrokerDto();
        Map<String, Object> mapParam = new HashMap<>();
        StringBuilder sql = new StringBuilder("WITH cte ( autoid ) AS (\n" +
                "    SELECT\n" +
                "        a.autoid\n" +
                "    FROM\n" +
                "             "+ schema +".regrp a\n" +
                "        INNER JOIN "+ schema +".cfmast cf ON a.custid = cf.custid\n" +
                "    WHERE\n" +
                "            a.status = 'A'\n" +
                "        AND cf.custid = :custId \n" +
                "    UNION ALL\n" +
                "    SELECT\n" +
                "        b.autoid\n" +
                "    FROM\n" +
                "             "+ schema +".regrp b\n" +
                "        INNER JOIN cte c ON b.prgrpid = c.autoid\n" +
                "    WHERE\n" +
                "        b.status = 'A'\n" +
                "), pb (\n" +
                "    custid,\n" +
                "    autoid,\n" +
                "    actype,\n" +
                "    fullname,\n" +
                "    ref_custid\n" +
                ") AS (\n" +
                "    SELECT\n" +
                "        rl.custid,\n" +
                "        r.autoid autoid,\n" +
                "        r.actype,\n" +
                "        r.fullname,\n" +
                "        r.custid ref_custid\n" +
                "    FROM\n" +
                "             "+ schema +".regrplnk rl\n" +
                "        INNER JOIN "+ schema +".regrp r ON r.autoid = rl.refrecflnkid\n" +
                "                                       AND rl.status = 'A'\n" +
                "    UNION ALL\n" +
                "    SELECT\n" +
                "        pb.custid,\n" +
                "        r.prgrpid autoid,\n" +
                "        r.actype,\n" +
                "        r.fullname,\n" +
                "        r.custid  ref_custid\n" +
                "    FROM\n" +
                "             pb pb\n" +
                "        INNER JOIN "+ schema +".regrp r ON pb.autoid = r.autoid\n" +
                "                                       AND r.status = 'A'\n" +
                ")\n" +
                ",pb2 (\n" +
                "    custid,\n" +
                "    autoid,\n" +
                "    actype,\n" +
                "    fullname,\n" +
                "    ref_custid\n" +
                ") AS (\n" +
                "    SELECT\n" +
                "        rl.custid,\n" +
                "        r.autoid autoid,\n" +
                "        r.actype,\n" +
                "        r.fullname,\n" +
                "        r.custid ref_custid\n" +
                "    FROM\n" +
                "        cte c\n" +
                "        INNER JOIN     "+ schema +".regrp rl on c.autoid = rl.autoid\n" +
                "        INNER JOIN "+ schema +".regrp r ON r.autoid = rl.prgrpid\n" +
                "                                       AND rl.status = 'A'\n" +
                "    UNION ALL\n" +
                "    SELECT\n" +
                "        pb.custid,\n" +
                "        r.prgrpid autoid,\n" +
                "        r.actype,\n" +
                "        r.fullname,\n" +
                "        r.custid  ref_custid\n" +
                "    FROM\n" +
                "             pb pb\n" +
                "        INNER JOIN "+ schema +".regrp r ON pb.autoid = r.autoid\n" +
                "                                       AND r.status = 'A'\n" +
                ")\n" +
                ",pball (custid,\n" +
                "    actype,\n" +
                "    fullname,\n" +
                "    ref_custid) as \n" +
                "    (\n" +
                "    select distinct * from (\n" +
                "        select custid,\n" +
                "    actype,\n" +
                "    fullname,\n" +
                "    ref_custid from pb\n" +
                "        UNION ALL\n" +
                "        select custid,\n" +
                "    actype,\n" +
                "    fullname,\n" +
                "    ref_custid from pb2)\n" +
                "    )\n" +
                ",underBroker(custid,\n" +
                "    custodycd,\n" +
                "    fullname,\n" +
                "    urank,\n" +
                "    mobilesms,\n" +
                "    deptname,\n" +
                "    deptid,\n" +
                "    min_actype)as \n" +
                "(\n" +
                "--Lay danh sách trong bảng regrplnk\n" +
                "SELECT\n" +
                "    a.custid,\n" +
                "    a.custodycd,\n" +
                "    a.fullname,\n" +
                "    a.urank,\n" +
                "    a.mobilesms,\n" +
                "    a.deptname,\n" +
                "    a.deptid,\n" +
                "    bptemp.min_actype\n" +
                "FROM\n" +
                "         (\n" +
                "        SELECT DISTINCT\n" +
                "            pb.actype,\n" +
                "            rl.custid,\n" +
                "            re1.typename urank,\n" +
                "            cf1.custodycd,\n" +
                "            cf1.fullname,\n" +
                "            cf1.mobilesms,\n" +
                "            CASE\n" +
                "                WHEN pb.fullname LIKE '%VIP%' THEN\n" +
                "                    'VIP'\n" +
                "                WHEN pb.fullname LIKE '%EPartner%' THEN\n" +
                "                    'ePartner'\n" +
                "                ELSE\n" +
                "                    substr(pb.fullname, 18, 4)\n" +
                "            END          deptid,\n" +
                "            pb.fullname  deptname\n" +
                "        FROM\n" +
                "            "+ schema +".regrplnk rl\n" +
                "            LEFT JOIN "+ schema +".regrp    r ON r.custid = rl.custid\n" +
                "            LEFT JOIN "+ schema +".cfmast   cf1 ON rl.custid = cf1.custid\n" +
                "            LEFT JOIN "+ schema +".retype   re1 ON r.actype = re1.actype\n" +
                "            LEFT JOIN pball                pb ON rl.custid = pb.custid\n" +
                "        WHERE\n" +
                "            rl.refrecflnkid IN (\n" +
                "                SELECT\n" +
                "                    autoid\n" +
                "                FROM\n" +
                "                    cte\n" +
                "            )\n" +
                "            AND rl.status = 'A'\n" +
                "            AND ( pb.actype = '0001'\n" +
                "                  OR pb.actype = '0005' )\n" +
                "\t\t\t\t  \n" +
                "    ) a\n" +
                "    INNER JOIN (\n" +
                "        SELECT\n" +
                "            MIN(actype) AS min_actype,\n" +
                "            custid\n" +
                "        FROM\n" +
                "            pball\n" +
                "        WHERE\n" +
                "            ( actype = '0001'\n" +
                "              OR actype = '0005' )\n" +
                "        GROUP BY\n" +
                "            custid\n" +
                "    ) bptemp ON bptemp.custid = a.custid\n" +
                "                AND bptemp.min_actype = a.actype \n" +
                "    UNION ALL\n" +
                "    ------- Lay danh sách trong bảng regrp\n" +
                "    SELECT\n" +
                "    a.custid,\n" +
                "    a.custodycd,\n" +
                "    a.fullname,\n" +
                "    a.urank,\n" +
                "    a.mobilesms,\n" +
                "    a.deptname,\n" +
                "    a.deptid,\n" +
                "    bptemp.min_actype\n" +
                "FROM\n" +
                "         (\n" +
                "    SELECT DISTINCT\n" +
                "            pb.actype,\n" +
                "            rl.custid,\n" +
                "            re1.typename urank,\n" +
                "            cf1.custodycd,\n" +
                "            cf1.fullname,\n" +
                "            cf1.mobilesms,\n" +
                "            CASE\n" +
                "                WHEN pb.fullname LIKE '%VIP%' THEN\n" +
                "                    'VIP'\n" +
                "                WHEN pb.fullname LIKE '%EPartner%' THEN\n" +
                "                    'ePartner'\n" +
                "                ELSE\n" +
                "                    substr(pb.fullname, 18, 4)\n" +
                "            END          deptid,\n" +
                "            pb.fullname  deptname\n" +
                "        FROM\n" +
                "            "+ schema +".regrp rl\n" +
                "            LEFT JOIN "+ schema +".cfmast   cf1 ON rl.custid = cf1.custid\n" +
                "            LEFT JOIN "+ schema +".retype   re1 ON rl.actype = re1.actype\n" +
                "            LEFT JOIN pball                pb ON rl.custid = pb.custid\n" +
                "        WHERE\n" +
                "            rl.autoid IN (\n" +
                "                SELECT\n" +
                "                    autoid\n" +
                "                FROM\n" +
                "                    cte\n" +
                "            )\n" +
                "            AND rl.status = 'A'\n" +
                "            AND ( pb.actype = '0001'\n" +
                "                  OR pb.actype = '0005' )\n" +
                "                \n" +
                "                ) a\n" +
                "INNER JOIN (\n" +
                "        SELECT\n" +
                "            MIN(actype) AS min_actype,\n" +
                "            custid\n" +
                "        FROM\n" +
                "            pball\n" +
                "        WHERE\n" +
                "            ( actype = '0001'\n" +
                "              OR actype = '0005' )\n" +
                "        GROUP BY\n" +
                "            custid\n" +
                "    ) bptemp ON bptemp.custid = a.custid\n" +
                "                AND bptemp.min_actype = a.actype\n" +
                "                \n" +
                ")" +
                "select distinct a.* from underBroker a \n" +
                "\n" +
                "\n ");
        sql.append(" where 1=1  ");
        if (!Constants.YES_OPTION.equalsIgnoreCase(getCurren) ) {
            sql.append(" and a.custid <> :custId ");
        }

        mapParam.put("custId", custId);
        if (!CollectionUtils.isEmpty(listUnderCustodycd)) {
            sql.append(" AND upper(a.CUSTODYCD) IN ( :listUnderCustodycd ) ");
            mapParam.put("listUnderCustodycd", listUnderCustodycd);
        }

        if (!StringUtils.isEmpty(searchkey)) {
            sql.append(" AND ( upper(a.CUSTODYCD) LIKE :searchkey  OR upper(a.FULLNAME)  LIKE :searchkey OR upper(a.MOBILESMS) LIKE :searchkey ) ");
            mapParam.put("searchkey", "%" + searchkey.toUpperCase() + "%");
        }

        if (!CollectionUtils.isEmpty(listDept)) {
            sql.append(" AND upper(a.DEPTID) IN ( :detp ) ");
            mapParam.put("detp", listDept);
        }

        try {
            Query query = entityManager.createNativeQuery(sql.toString());
            mappingParamSql(mapParam, query);

//            query.setFirstResult(page.getPageNumber() * page.getPageSize());
//            query.setMaxResults(page.getPageSize());

            // Get total
            //Query queryCount = entityManager.createNativeQuery("select count(*) from (" + sql + " ) demo");
            //mappingParamSql(mapParam, queryCount);

            List<UnderBrokerDto> listData = mappinUnderBroker(query);
            //var total = queryCount.getSingleResult();

            response.setTotalOfRecord(DataUtils.toLong(listData.size()));
            response.setListData(listData);
            return response;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return response;
    }

    private List<UnderBrokerDto> mappinUnderBroker(Query query) {
        List<Object[]> rows = query.getResultList();
        if (CollectionUtils.isEmpty(rows)) {
            return List.of();
        }
        List<UnderBrokerDto> listData = new ArrayList<>(rows.size());
        UnderBrokerDto data;
        for (Object[] row : rows) {

            data = new UnderBrokerDto();
            data.setCustId(DataUtils.toString(row[0]));
            data.setCustodyCd(DataUtils.toString(row[1]));
            data.setFullName(DataUtils.toString(row[2]));
            data.setURank(DataUtils.toString(row[3]));
            data.setMobile(DataUtils.toString(row[4]));
            data.setDept(DataUtils.toString(row[5]));

            listData.add(data);
        }
        return listData;
    }

    @Override
    public GetDepartmentDto getDepartment(String custId, String deptId, String deptName) {
        GetDepartmentDto response = new GetDepartmentDto();
        Map<String, Object> mapParam = new HashMap<>();
        StringBuilder sql = new StringBuilder("select a.* from ( " +
                "SELECT " +
                "CUSTID" +
                ",DEPTNAME" +
                ", CASE WHEN DEPTNAME LIKE '%VIP%' THEN 'VIP' WHEN DEPTNAME LIKE '%EPartner%' THEN 'ePartner' ELSE SUBSTR(DEPTNAME,18,4) END  DEPTID" +
                ",REF_CUSTID  " +
                "FROM (SELECT  R2.CUSTID REF_CUSTID,R.CUSTID,CASE WHEN R2.AUTOID IN (18,4104) THEN R2.FULLNAME ELSE R.FULLNAME END DEPTNAME,R.FULLNAME  " +
                " FROM "+ schema +".REGRP R " +
                " INNER JOIN "+ schema +".REGRP R2 ON ((R2.AUTOID = R.PRGRPID AND R2.ACTYPE = '0005') OR(R2.CUSTID = R.CUSTID AND (R.ACTYPE = '0001' OR R.ACTYPE = '0005' ))) " +
                //" WHERE R.PRGRPID = 0" +
                ") R " +
                ") a ");
        sql.append(" WHERE 1 = 1  AND a.CUSTID <> :custId");

        sql.append(" AND  upper(a.REF_CUSTID) = :custId ");
        mapParam.put("custId", custId.toUpperCase());

        if (!StringUtils.isEmpty(deptId)) {
            sql.append(" AND upper(a.DEPTID) LIKE :deptId ");
            mapParam.put("deptId", "%" + deptId.toUpperCase() + "%");
        }

        if (!StringUtils.isEmpty(deptName)) {
            sql.append(" AND upper(a.DEPTNAME) LIKE :deptName ");
            mapParam.put("deptName", "%" + deptName.toUpperCase() + "%");
        }

        sql.append(" ORDER BY a.DEPTNAME ");

        try {
            Query query = entityManager.createNativeQuery(sql.toString());
            mappingParamSql(mapParam, query);

            List<DepartmentDto> listData = mappinGetDepartment(query);
            //var total = queryCount.getSingleResult();

            response.setTotalOfRecord(DataUtils.toLong(listData.size()));
            response.setListData(listData);
            return response;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return response;
    }

    private List<DepartmentDto> mappinGetDepartment(Query query) {
        List<Object[]> rows = query.getResultList();
        if (CollectionUtils.isEmpty(rows)) {
            return List.of();
        }
        List<DepartmentDto> listData = new ArrayList<>(rows.size());
        DepartmentDto data;
        for (Object[] row : rows) {

            data = new DepartmentDto();
            data.setDeptname(DataUtils.toString(row[1]));
            data.setDeptid(DataUtils.toString(row[2]));

            listData.add(data);
        }
        return listData;
    }

    private void mappingParamSql(Map<String, Object> paramValue, Query query) {
        if (CollectionUtils.isEmpty(paramValue)) {
            return;
        }

        paramValue.entrySet().stream().filter(Objects::nonNull).forEach(param -> {
            query.setParameter(param.getKey(), param.getValue());
        });

    }
}
