package vn.com.vpbanks.flex.usecase.service.business.cf.repository.vo;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class OpenCSAccountDVO {

    @Id
    @Column(name = "acctno")
    String acctNo;
}
