package vn.com.vpbanks.flex.usecase.service.business.order.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import java.io.Serializable;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class OrderUpdateReq implements Serializable {

    private String requestId;

    @JsonProperty("accountId")
    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String accountId;

    @JsonProperty("orderId")
    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String orderId;

    @JsonProperty("cusId")
    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String cusId;

    @NotNull(message = "{validation.not_null}")
    @Positive(message = "{validation.positive_number}")
    @JsonProperty("qty")
    private Integer qty;

    @JsonProperty("limitPrice")
    @Positive(message = "{validation.positive_number}")
    @NotNull(message = "{validation.not_null}")
    private Integer limitPrice;

    @JsonProperty("ipAddress")
    @NotNull
    private String ipAddress;

    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    @JsonProperty("via")
    private String via;

    @JsonProperty("validationType")
    private String validationType;

    @JsonProperty("device")
    private String device;

    @JsonProperty("deviceType")
    private String deviceType;
}
