package vn.com.vpbanks.flex.usecase.service.business.aq.request;

import lombok.Data;

/**
 *  Tín hiệu bật tắt EInvest Auto
 */
@Data
public class SignalEInvestAutoFromQueue {
    private String EVENTTYPE;
    private String CUSTID;
    private String CUSTODYCD;
    private String FULLNAME;
    private String CIMODE;
}
