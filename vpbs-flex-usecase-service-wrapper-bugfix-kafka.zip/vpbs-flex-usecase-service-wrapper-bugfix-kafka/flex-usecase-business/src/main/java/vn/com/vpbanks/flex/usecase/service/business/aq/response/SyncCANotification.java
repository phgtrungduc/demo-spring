package vn.com.vpbanks.flex.usecase.service.business.aq.response;

import lombok.Data;
import vn.com.vpbanks.flex.usecase.service.business.aq.request.SyncCAFromQueue;

@Data
public class SyncCANotification {
    private String eventType;
    private String autoId;
    private String codeId;
    private String logTime;
    private String newStatus;
    private String oldStatus;
    private String symbol;

    private String caType;

    private String khqDate;

    public SyncCANotification(SyncCAFromQueue syncCAFromQueue) {
        this.eventType = syncCAFromQueue.getEVENTTYPE();
        this.autoId = syncCAFromQueue.getAUTOID();
        this.logTime = syncCAFromQueue.getLOGTIME();
        this.codeId = syncCAFromQueue.getCODEID();
        this.newStatus = syncCAFromQueue.getNEWSTATUS();
        this.oldStatus = syncCAFromQueue.getOLDSTATUS();
        this.symbol = syncCAFromQueue.getSYMBOL();
        this.caType = syncCAFromQueue.getCATYPE();
        this.khqDate = syncCAFromQueue.getKHQDATE();
    }
}
