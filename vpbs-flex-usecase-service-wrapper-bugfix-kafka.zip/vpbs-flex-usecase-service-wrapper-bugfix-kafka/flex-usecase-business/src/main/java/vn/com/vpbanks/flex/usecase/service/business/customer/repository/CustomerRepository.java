package vn.com.vpbanks.flex.usecase.service.business.customer.repository;

import vn.com.vpbanks.flex.usecase.service.business.customer.repository.vo.BeneficiaryAccountDVO;

import java.util.List;

public interface CustomerRepository {
    List<BeneficiaryAccountDVO> getBeneficiaryAccount(String custId);
}
