package vn.com.vpbanks.flex.usecase.service.business.aq.response;

import lombok.Data;

@Data
public class SignalSession {
    private String eventType;
    private String exchange;
    private String session;
}
