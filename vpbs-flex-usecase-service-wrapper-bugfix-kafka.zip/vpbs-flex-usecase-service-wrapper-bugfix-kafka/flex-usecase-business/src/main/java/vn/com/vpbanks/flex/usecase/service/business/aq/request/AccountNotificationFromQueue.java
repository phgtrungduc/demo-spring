package vn.com.vpbanks.flex.usecase.service.business.aq.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AccountNotificationFromQueue {
    private String EVENTTYPE;
    private String CUSTID;
    private String CUSTODYCD;
    private String FULLNAME;
    private String MOBILESMS;
    private String IDCODE;
    private String ADDRESS;
    private String IDPLACE;
    private String EMAIL;
    private String STATUS;
}
