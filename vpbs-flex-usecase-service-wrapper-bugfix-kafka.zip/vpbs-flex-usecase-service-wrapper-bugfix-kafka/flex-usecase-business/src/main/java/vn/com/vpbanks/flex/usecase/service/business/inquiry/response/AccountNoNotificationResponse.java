package vn.com.vpbanks.flex.usecase.service.business.inquiry.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
//@Entity
public class AccountNoNotificationResponse implements Serializable {
    private String id;

    private String cfType;

    private String cusToDyCd;

    private String name;

    private String currency;

    private String coreBank;

    private String productTypeName;

    private String enProductTypeName;

    private String typeName;

    private String enTypeName;

    private String afAcctNoExt;

    private String enAfAcctNoExt;

    private String productType;

    private String isFcBond;

    private String accountType;

    private String status;

    private String mobileSms;

    private String idCode;

    private String cusId;


    public AccountNoNotificationResponse(AccountResponse queue, String mobileSms, String idCode, String cusId) {
        this.id = queue.getId();
        this.cfType = queue.getCfType();
        this.cusToDyCd = queue.getCusToDyCd();
        this.name = queue.getName();
        this.currency = queue.getCurrency();
        this.coreBank = queue.getCoreBank();
        this.productTypeName = queue.getProductTypeName();
        this.enProductTypeName = queue.getEnProductTypeName();
        this.typeName = queue.getTypeName();
        this.enTypeName = queue.getEnTypeName();
        this.afAcctNoExt = queue.getAfAcctNoExt();
        this.productType = queue.getProductType();
        this.isFcBond = queue.getIsFcBond();
        this.accountType = queue.getAccountType();
        this.status = queue.getStatus();
        this.mobileSms = mobileSms;
        this.idCode = idCode;
        this.cusId = cusId;
    }

}
