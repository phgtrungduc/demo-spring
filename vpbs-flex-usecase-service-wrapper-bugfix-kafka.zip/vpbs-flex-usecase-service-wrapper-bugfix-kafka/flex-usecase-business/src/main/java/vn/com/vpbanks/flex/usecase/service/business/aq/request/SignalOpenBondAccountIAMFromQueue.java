package vn.com.vpbanks.flex.usecase.service.business.aq.request;

import lombok.Data;

@Data
public class SignalOpenBondAccountIAMFromQueue {
    private String EVENTTYPE;
    private String CUSTID;
    private String CUSTODYCD;
    private String FULLNAME;
    private String CUSTTYPE;
    private String IDTYPE;
    private String IDCODE;
    private String MOBILE;
    private String EMAIL;
    private String ISBOND;
    private String STATUS;
}
