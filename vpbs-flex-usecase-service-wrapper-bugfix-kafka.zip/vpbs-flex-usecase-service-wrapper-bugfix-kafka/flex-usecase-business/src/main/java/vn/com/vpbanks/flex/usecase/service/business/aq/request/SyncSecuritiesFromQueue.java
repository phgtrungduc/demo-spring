package vn.com.vpbanks.flex.usecase.service.business.aq.request;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class SyncSecuritiesFromQueue {
    private String EVENTTYPE;
    private String ACCTNO;
    private String CUSTODYCD;
    private String AFACCTNO;
    private String LOGTIME;
    private String SYMBOL;
    private String STATUS;
    private BigDecimal TRADE;
    private BigDecimal TOTAL_QTTY;
    private BigDecimal BLOCKED;
    private BigDecimal ABSTANDING;
    private BigDecimal RESTRICTQTTY;
    private BigDecimal MORTAGE;
    private BigDecimal AVLWITHDRAW;
}
