package vn.com.vpbanks.flex.usecase.service.business.cash.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import javax.persistence.Column;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class SecuritiesStatementResponse implements Serializable {

    private static final long serialVersionUID = 1L;
    @JsonProperty("busDate")
    @Column(name = "BUSDATE")
    private String busDate;

    @JsonProperty("symBol")
    @Column(name = "SYMBOL")
    private String symBol;

    @JsonProperty("creditAmt")
    @Column(name = "CREDITAMT")
    private BigDecimal creditAmt;

    @JsonProperty("debitAmt")
    @Column(name = "DEBITAMT")
    private BigDecimal debitAmt;

    @JsonProperty("txDesc")
    @Column(name = "TXDESC")
    private String txDesc;

    @JsonProperty("tltxcd")
    @Column(name = "TLTXCD")
    private String tltxcd;

    @JsonProperty("tl_Desc")
    @Column(name = "TL_DESC")
    private String tl_Desc;
}
