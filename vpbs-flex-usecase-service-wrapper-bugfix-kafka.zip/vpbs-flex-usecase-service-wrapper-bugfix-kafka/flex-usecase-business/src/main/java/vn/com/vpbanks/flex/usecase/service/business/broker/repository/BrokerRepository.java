package vn.com.vpbanks.flex.usecase.service.business.broker.repository;

import vn.com.vpbanks.flex.usecase.service.business.broker.repository.vo.BrokerGroupDVO;
import vn.com.vpbanks.flex.usecase.service.business.broker.repository.vo.CustomerOfBrokerDVO;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.BrokerRequest;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.ReGrpLnkRequest;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.RightOffRegisterRequest;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.TransferStockRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseStoredProcedureResponse;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.StoredProcedureError;

import java.util.List;

public interface BrokerRepository {
    StoredProcedureError addBroker(BrokerRequest brokerRequest, String ipAddress, String requestId);

    BaseStoredProcedureResponse<BrokerGroupDVO> addReGrpLink(ReGrpLnkRequest reGrpLnkRequest, String ipAddress);

    StoredProcedureError addTransferStock(TransferStockRequest transferStockRequest, String ipAddress, String requestId);

    StoredProcedureError addRightOffRegister(RightOffRegisterRequest rightOffRegisterRequest, String ipAddress, String requestId);

    BaseStoredProcedureResponse<List<CustomerOfBrokerDVO>> getCustomerOfBroker(String reCusToDyCd);

    BaseStoredProcedureResponse getBrokerInfo(String custoDyCd);

    BaseStoredProcedureResponse getRightInfo(String fromDate, String toDate, String afAcctNo, String isCom, String symbol, String caType);
}
