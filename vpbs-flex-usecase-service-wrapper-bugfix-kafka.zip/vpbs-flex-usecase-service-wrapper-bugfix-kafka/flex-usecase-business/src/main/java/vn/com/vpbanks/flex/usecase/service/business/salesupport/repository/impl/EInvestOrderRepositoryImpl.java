package vn.com.vpbanks.flex.usecase.service.business.salesupport.repository.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.repository.EInvestOrderRepository;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.EInvestOrderDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.GetEInvestOrderDto;
import vn.com.vpbanks.flex.usecase.service.common.utils.DataUtils;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Component
@RequiredArgsConstructor
@Slf4j
public class EInvestOrderRepositoryImpl implements EInvestOrderRepository {
    private final EntityManager entityManager;

    @Value("${spring.datasource.hikari.schema}")
    private String schema;

    @Override
    public GetEInvestOrderDto getEInvestOrder(List<String> afacctno, List<String> txnum, List<String> status, Integer page, Integer size) {
        GetEInvestOrderDto response = new GetEInvestOrderDto();
        if (CollectionUtils.isEmpty(afacctno) && CollectionUtils.isEmpty(txnum)) {
            return null;
        }

        Map<String, Object> mapParam = new HashMap<>();
        StringBuilder sql = new StringBuilder();
        queryGetEInvestOrder(sql, mapParam, afacctno, txnum, status);

//        sql.append(" select null as  AFACCTNO" +
//                ",null as  TXNUM" +
//                ",null as  STATUS " +
//                ", count(*) total ");
//        sql.append(" FROM cte ) ");
//        sql.append(" union all ");
        sql.append(" select  AFACCTNO" +
                ",TXNUM" +
                ",STATUS " +
                ", null as total ");
        sql.append(" FROM cte  ");

        try {
            Query query = entityManager.createNativeQuery(sql.toString());
            if (!Objects.isNull(page) && Objects.isNull(size)) {
                query.setParameter("page", page * size);
                query.setParameter("size", size);
            }
            mappingParamSql(mapParam, query);

            List<EInvestOrderDto> listData = mappinGetEInvestOrder(query);

            response.setTotalOfRecord(DataUtils.toLong(listData.size()));
            response.setListData(listData);
            return response;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return response;
    }

    private void queryGetEInvestOrder(StringBuilder sql, Map<String, Object> mapParam, List<String> afacctno, List<String> txnum, List<String> status) {

        sql.append("WITH cte (AFACCTNO,TXNUM,STATUS) as ");
        sql.append("(");
        sql.append(" select AFACCTNO,TXNUM,STATUS from " + schema + ".TDMAST ");
        sql.append("WHERE 1 = 1");
        if (!CollectionUtils.isEmpty(afacctno)) {
            sql.append(" AND AFACCTNO in ( :afacctno ) ");
            mapParam.put("afacctno", afacctno);
        }
        if (!CollectionUtils.isEmpty(txnum)) {
            sql.append(" AND TXNUM in ( :txnum ) ");
            mapParam.put("txnum", txnum);
        }
        if (!CollectionUtils.isEmpty(status)) {
            sql.append(" AND STATUS in ( :status ) ");
            mapParam.put("status", status);
        }
        sql.append(")");


    }

    private List<EInvestOrderDto> mappinGetEInvestOrder(Query query) {
        List<Object[]> rows = query.getResultList();
        if (CollectionUtils.isEmpty(rows)) {
            return List.of();
        }
        List<EInvestOrderDto> listData = new ArrayList<>(rows.size());
        EInvestOrderDto data;
        for (Object[] row : rows) {

            data = new EInvestOrderDto();
            data.setAfacctno(DataUtils.toString(row[0]));
            data.setTxnum(DataUtils.toString(row[1]));
            data.setStatus(DataUtils.toString(row[2]));

            listData.add(data);
        }
        return listData;
    }

    private void mappingParamSql(Map<String, Object> paramValue, Query query) {
        if (CollectionUtils.isEmpty(paramValue)) {
            return;
        }

        paramValue.entrySet().stream().filter(Objects::nonNull).forEach(param -> {
            query.setParameter(param.getKey(), param.getValue());
        });

    }
}
