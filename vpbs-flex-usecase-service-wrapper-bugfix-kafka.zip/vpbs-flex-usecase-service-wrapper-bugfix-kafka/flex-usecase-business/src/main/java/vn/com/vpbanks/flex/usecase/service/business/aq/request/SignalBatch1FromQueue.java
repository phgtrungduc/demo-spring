package vn.com.vpbanks.flex.usecase.service.business.aq.request;

import lombok.Data;

/**
 *  Tín hiệu báo batch 1.
 */
@Data
public class SignalBatch1FromQueue {
    private String EVENTTYPE;
    private String STATUS;
}
