package vn.com.vpbanks.flex.usecase.service.business.aq.repository.vo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class Mr0002DVO implements Serializable {
    @JsonIgnore
    private String TEMPLATEID;

    private String CUSTID;

    private String CUSTODYCD;

    private String AFACCTNO;

    private String ADDVND;

    private String CODE_CO;

    private String shortbank;
    private String fullbank;
}
