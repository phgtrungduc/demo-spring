package vn.com.vpbanks.flex.usecase.service.business.aq.response;

import lombok.Data;
import vn.com.vpbanks.flex.usecase.service.business.aq.request.SignalBatch1FromQueue;

@Data
public class SignalBatch1Notification {
    private String eventType;
    private String status;

    public SignalBatch1Notification(SignalBatch1FromQueue signalBatch1FromQueue) {
        this.eventType = signalBatch1FromQueue.getEVENTTYPE();
        this.status = signalBatch1FromQueue.getSTATUS();
    }
}
