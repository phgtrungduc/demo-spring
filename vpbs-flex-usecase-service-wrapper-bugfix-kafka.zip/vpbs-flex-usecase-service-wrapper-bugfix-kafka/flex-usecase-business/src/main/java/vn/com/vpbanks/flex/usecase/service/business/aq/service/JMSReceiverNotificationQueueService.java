package vn.com.vpbanks.flex.usecase.service.business.aq.service;

import java.util.Map;

public interface JMSReceiverNotificationQueueService {
    void JMSNotificationQueue(Map<String, String> hashMap);
}
