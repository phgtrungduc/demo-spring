package vn.com.vpbanks.flex.usecase.service.business.inquiry.service;

import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;

public interface SecuritiesPortfolioService {
    BaseResponse getSecuritiesPortfolio(String pAccountId, String pSymbol, int p_offset, int p_limit);

    BaseResponse getSecuritiesInfo(String issuerId, String codeId, String symbol, String secTypeName, String tradePlace, Integer pageIndex, Integer pageSize);
}
