package vn.com.vpbanks.flex.usecase.service.business.broker.service;

import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;

public interface HolderService {
    BaseResponse<Object> getHolder(String custodyCd, String symbol);
}
