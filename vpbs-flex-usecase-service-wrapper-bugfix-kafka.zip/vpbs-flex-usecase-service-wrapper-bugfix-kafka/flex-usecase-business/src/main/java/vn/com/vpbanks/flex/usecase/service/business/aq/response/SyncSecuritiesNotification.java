package vn.com.vpbanks.flex.usecase.service.business.aq.response;

import lombok.Data;
import vn.com.vpbanks.flex.usecase.service.business.aq.request.SyncSecuritiesFromQueue;

import java.math.BigDecimal;

@Data
public class SyncSecuritiesNotification {
    private String eventType;
    private String acctNo;
    private String custoDyCd;
    private String afAcctNo;
    private String logTime;
    private String symbol;
    private String status;
    private BigDecimal trade;
    private BigDecimal totalQtty;
    private BigDecimal mortAge;

    private BigDecimal blocked;
    private BigDecimal abstanding;
    private BigDecimal restrictQtty;
    private BigDecimal avlWithdraw;

    public SyncSecuritiesNotification(SyncSecuritiesFromQueue syncSecuritiesFromQueue) {
        this.eventType = syncSecuritiesFromQueue.getEVENTTYPE();
        this.acctNo = syncSecuritiesFromQueue.getACCTNO();
        this.custoDyCd = syncSecuritiesFromQueue.getCUSTODYCD();
        this.afAcctNo = syncSecuritiesFromQueue.getAFACCTNO();
        this.logTime = syncSecuritiesFromQueue.getLOGTIME();
        this.symbol = syncSecuritiesFromQueue.getSYMBOL();
        this.status = syncSecuritiesFromQueue.getSTATUS();
        this.trade = syncSecuritiesFromQueue.getTRADE();
        this.totalQtty = syncSecuritiesFromQueue.getTOTAL_QTTY();
        this.mortAge = syncSecuritiesFromQueue.getMORTAGE();
        this.blocked = syncSecuritiesFromQueue.getBLOCKED();
        this.abstanding = syncSecuritiesFromQueue.getABSTANDING();
        this.restrictQtty = syncSecuritiesFromQueue.getRESTRICTQTTY();
        this.avlWithdraw = syncSecuritiesFromQueue.getAVLWITHDRAW();
    }
}
