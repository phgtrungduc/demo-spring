package vn.com.vpbanks.flex.usecase.service.business.aq.request;

import lombok.Data;

@Data
public class SmartOtpMessageFromQueue {
    private String EVENTTYPE;
    private String CUSTID;
    private String CUSTODYCD;
    private String STATUS;
}
