package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.impl;

import com.google.gson.Gson;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.AccountCusResponse;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.AccountResponse;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.StoredProcedureError;
import vn.com.vpbanks.flex.usecase.service.business.cash.request.WithdrawMoneyRequest;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.AccountNoNotificationResponse;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Repository
@Log4j2
public class AccountsRepository {
    @Autowired
    EntityManager entityManager;

    @Value("${vpbanks.flex.sp.SP_GET_ALL_ACCOUNT}")
    private String SP_GET_ALL_ACCOUNT;
    @Value("${vpbanks.flex.sp.SP_GET_CUSTOMER}")
    private String SP_GET_CUSTOMER;

    @Value("${vpbanks.flex.sp.SP_GET_WITHDRAW_MONEY}")
    private String SP_GET_WITHDRAW_MONEY;

    public List<AccountResponse> getAccount(String customerId, String accountId) {
        List<AccountResponse> accountRes = new ArrayList<>();
        log.info("[getAccount] customerId: {}, accountId: {}", customerId, accountId);
        try {
            StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_ALL_ACCOUNT, AccountResponse.class);
            query.registerStoredProcedureParameter("p_refcursor", void.class, ParameterMode.REF_CURSOR);
            query.registerStoredProcedureParameter("p_customerid", String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("p_accountid", String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
            query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.INOUT);
            accountId = accountId != null ? accountId : "ALL";
            query.setParameter("p_customerid", customerId);
            query.setParameter("p_accountid", accountId);
            query.setParameter("p_err_code", "");
            query.setParameter("p_err_param", "");

//            query.execute();
            String errCd = (String) query.getOutputParameterValue("p_err_code");
            log.info("[getAccount] errCd: {}", errCd);
            if ("-1".equals(errCd)) {
                return Collections.EMPTY_LIST;
            }
            accountRes = query.getResultList();
        } catch (Exception ex) {
            log.info("AccountsRepository error : {} ", ex.getMessage());
        }
        return accountRes;
    }

    public List<AccountNoNotificationResponse> getAccountNoNo(String customerId, String accountId) {
        List<AccountNoNotificationResponse> accountRes = new ArrayList<>();
        try {
            StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_ALL_ACCOUNT, AccountNoNotificationResponse.class);
            query.registerStoredProcedureParameter("p_refcursor", Class.class, ParameterMode.REF_CURSOR);
            query.registerStoredProcedureParameter("p_customerid", String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("p_accountid", String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
            query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.INOUT);
            query.setParameter("p_customerid", customerId);
            query.setParameter("p_accountid", accountId);
            query.execute();
            accountRes = query.getResultList();
        } catch (Exception ex) {
            log.info("AccountsRepository error : {} ", ex.getMessage());
        }
        return accountRes;
    }


    public List<AccountCusResponse> getInformationCus(String custodycd) {
        List<AccountCusResponse> accountCusResponses = new ArrayList<>();
        try {
            StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_CUSTOMER, AccountCusResponse.class);
            query.registerStoredProcedureParameter("pv_refCursor", Class.class, ParameterMode.REF_CURSOR);
            query.registerStoredProcedureParameter("p_custodycd", String.class, ParameterMode.IN);
            query.setParameter("p_custodycd", custodycd);
//            query.execute();

            accountCusResponses = query.getResultList();

        } catch (Exception ex) {
            log.info("getAccountCus error : {} ", ex.getMessage());
        }
        return accountCusResponses;
    }


    public StoredProcedureError getWithdrawMoney(WithdrawMoneyRequest withdrawMoneyRequest, String ipAddress, String requestId) {
        Gson gson = new Gson();
        String req = gson.toJson(withdrawMoneyRequest);
        log.debug("WithdrawMoney: {}", req);
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_WITHDRAW_MONEY);

        query.registerStoredProcedureParameter("p_requestid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_custid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_accountid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_bankid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_amount", Long.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_via", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_desc", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_isnotisms", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_ipaddress", String.class, ParameterMode.IN);

        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_message", String.class, ParameterMode.INOUT);

        // binding value for params
        query.setParameter("p_requestid", requestId);
        query.setParameter("p_custid", withdrawMoneyRequest.getCustId());
        query.setParameter("p_accountid", withdrawMoneyRequest.getAccountId());
        query.setParameter("p_bankid", withdrawMoneyRequest.getBankId());
        query.setParameter("p_amount", withdrawMoneyRequest.getAmount());
        query.setParameter("p_via", withdrawMoneyRequest.getVia());
        query.setParameter("p_desc", withdrawMoneyRequest.getDesc());
        query.setParameter("p_isnotisms", withdrawMoneyRequest.getIsnotisms());
        query.setParameter("p_ipaddress", ipAddress);

        query.execute();

        String errCd = (String) query.getOutputParameterValue("p_err_code");
        String errMsg = (String) query.getOutputParameterValue("p_err_message");

        StoredProcedureError storedProcedureError = new StoredProcedureError();
        storedProcedureError.setErrCd(errCd);
        storedProcedureError.setErrParam(errMsg);

        return storedProcedureError;
    }

}
