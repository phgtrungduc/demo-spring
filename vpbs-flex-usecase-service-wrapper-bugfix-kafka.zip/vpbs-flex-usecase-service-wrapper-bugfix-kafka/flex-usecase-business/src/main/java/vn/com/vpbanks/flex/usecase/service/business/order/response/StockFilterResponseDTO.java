package vn.com.vpbanks.flex.usecase.service.business.order.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StockFilterResponseDTO {

    @JsonProperty("stockOrderId")
    private String stockOrderId;

    @JsonProperty("reforderid")
    private String refOrderId;

    @JsonProperty("orderSide")
    private String orderSide;

    @JsonProperty("status")
    private String status;

    @JsonProperty("orderPrice")
    private BigDecimal orderPrice;

    @JsonProperty("stockCode")
    private String stockCode;

    @JsonProperty("joinVolume")
    private Long joinVolume;

    @JsonProperty("join")
    private Long join;

    @JsonProperty("customerAccountNumber")
    private String customerAccountNumber;

    @JsonProperty("customerAccountName")
    private String customerAccountName;

    @JsonProperty("subAccount")
    private String subAccount;

    @JsonProperty("startDate")
    private String startDate;

    @JsonProperty("expiredDate")
    private String expiredDate;

    @JsonProperty("lastModifiedDate")
    private String lastModifiedDate;

    @JsonProperty("accountId")
    private String accountId;

    @JsonProperty("allowCancel")
    private String allowCancel;

    @JsonProperty("allowAmend")
    private String allowAmend;

    @JsonProperty("flexStatus")
    private String flexStatus;

    @JsonProperty("orderCode")
    private String orderCode;

    @JsonProperty("phone")
    private String phone;

    @JsonProperty("createDate")
    private String createDate;

    @JsonProperty("execPrice")
    private BigDecimal execPrice;

    @JsonProperty("custId")
    private String custId;

    @JsonProperty("reFullName")
    private String reFullName;

    @JsonProperty("reCustodyCd")
    private String reCustodyCd;

    @JsonProperty("dept")
    private String dept;

    @JsonProperty("orderName")
    private String orderName;

    @JsonProperty("orderCustodyCd")
    private String orderCustodyCd;

    @JsonProperty("orderDept")
    private String orderDept;

    @JsonProperty("total")
    private BigDecimal total;

}

