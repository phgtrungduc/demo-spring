package vn.com.vpbanks.flex.usecase.service.business.order.request;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class PostOrdersRequests implements Serializable {

    @JsonProperty("accountId")
    @NotBlank(message = "accountId chưa được truyền hoặc truyền không đúng!")
    private String accountId;

    @JsonProperty("userName")
    @NotBlank(message = "userName chưa được truyền hoặc truyền không đúng!")
    private String userName;

    @JsonProperty("instrument")
    @NotBlank(message = "instrument chưa được truyền hoặc truyền không đúng!")
    private String instrument;

    @JsonProperty("qty")
    @NotNull(message = "qty chưa được truyền hoặc truyền không đúng!")
    private Long qty;

    @JsonProperty("side")
    @NotBlank(message = "side chưa được truyền hoặc truyền không đúng!")
    private String side;

    @JsonProperty("type")
    @NotBlank(message = "type chưa được truyền hoặc truyền không đúng!")
    private String type;

    @JsonProperty("limitPrice")
    @NotBlank(message = "limitPrice chưa được truyền hoặc truyền không đúng!")
    private String limitPrice;


    @JsonProperty("via")
    @NotBlank(message = "via chưa được truyền hoặc truyền không đúng!")
    private String via;

    @JsonProperty("ipAddress")
    private String ipAddress;

    @JsonProperty("validationType")
    private String validationType;

    @JsonProperty("device")
    private String device;

    @JsonProperty("deviceType")
    private String deviceType;

    @JsonProperty("brokerUserName")
    private String brokerUserName;
}
