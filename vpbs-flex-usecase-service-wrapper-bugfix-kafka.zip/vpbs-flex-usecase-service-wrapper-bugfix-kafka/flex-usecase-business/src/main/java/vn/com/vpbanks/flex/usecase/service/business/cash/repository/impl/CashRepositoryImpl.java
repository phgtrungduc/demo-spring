package vn.com.vpbanks.flex.usecase.service.business.cash.repository.impl;

import com.google.gson.Gson;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import vn.com.vpbanks.flex.usecase.service.business.cash.repository.CashRepository;
import vn.com.vpbanks.flex.usecase.service.business.cash.repository.vo.BankNoStroDVO;
import vn.com.vpbanks.flex.usecase.service.business.cash.repository.vo.CashStatementHistVO;
import vn.com.vpbanks.flex.usecase.service.business.cash.request.*;
import vn.com.vpbanks.flex.usecase.service.business.cash.response.HoldBalanceResponse;
import vn.com.vpbanks.flex.usecase.service.business.cash.response.HoldStockResponse;
import vn.com.vpbanks.flex.usecase.service.business.cash.response.SecuritiesStatementResponse;
import vn.com.vpbanks.flex.usecase.service.business.cash.response.UnHoldEODResponse;
import vn.com.vpbanks.flex.usecase.service.common.config.properties.CashStoredProcedureProperties;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.StoredProcedureError;
import vn.com.vpbanks.flex.usecase.service.common.exceptions.ApiException;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Component
@Slf4j
public class CashRepositoryImpl implements CashRepository {

    private final EntityManager entityManager;
    private final CashStoredProcedureProperties cashStoredProcedureProperties;
    private static final String SUCCESS_CD = "0";

    @Value("${vpbanks.flex.sp.SP_GET_BANK_NO_STRO}")
    private String SP_GET_BANK_NO_STRO;
    @Value("${vpbanks.flex.sp.SP_INCREASE_MONEY}")
    private String SP_INCREASE_MONEY;

    @Value("${vpbanks.flex.sp.SP_INTERNAL_TRANSFER}")
    private String SP_INTERNAL_TRANSFER;

    @Value("${vpbanks.flex.sp.SP_BLOCK_AMOUNT}")
    private String SP_BLOCK_AMOUNT;
    @Value("${vpbanks.flex.sp.SP_UN_BLOCK_AMOUNT}")
    private String SP_UN_BLOCK_AMOUNT;
    @Value("${vpbanks.flex.sp.SP_GET_CASH_STATEMENT_HST}")
    private String SP_GET_CASH_STATEMENT_HST;

    @Value("${vpbanks.flex.sp.SP_SECURITIES_STATEMENT}")
    private String SP_SECURITIES_STATEMENT;

    @Override
    public List<BankNoStroDVO> getBankNoStro() {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_BANK_NO_STRO, BankNoStroDVO.class);
        query.registerStoredProcedureParameter("pv_refCursor", Void.class, ParameterMode.REF_CURSOR);
        List<BankNoStroDVO> bankNoStroDVOS = query.getResultList();

        return bankNoStroDVOS;
    }

    @Override
    public StoredProcedureError increaseMoney(String requestId, String custId, String accountId, String bankId, Long amount, String desc, String isNotiSms, String via, String ipAddress) {

        log.debug("params :requestId {} , custId {} , accountId {}, bankId {}, amount {} , via {} , ipAddress",
                requestId, custId, accountId, bankId, amount, via, ipAddress);

        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_INCREASE_MONEY);

        query.registerStoredProcedureParameter("p_requestid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_custid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_accountid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_bankid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_amount", Long.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_desc", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_isnotisms", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_via", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_ipaddress", String.class, ParameterMode.IN);

        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_message", String.class, ParameterMode.INOUT);

        // binding value for params
        query.setParameter("p_requestid", requestId);
        query.setParameter("p_custid", custId);
        query.setParameter("p_accountid", accountId);
        query.setParameter("p_bankid", bankId);
        query.setParameter("p_amount", amount);
        query.setParameter("p_desc", desc);
        query.setParameter("p_isnotisms", isNotiSms);
        query.setParameter("p_via", via);
        query.setParameter("p_ipaddress", ipAddress);

        query.execute();

        String errCd = (String) query.getOutputParameterValue("p_err_code");
        String errMsg = (String) query.getOutputParameterValue("p_err_message");

        StoredProcedureError storedProcedureError = new StoredProcedureError();
        storedProcedureError.setErrCd(errCd);
        storedProcedureError.setErrParam(errMsg);

        return storedProcedureError;
    }

    @Override
    public StoredProcedureError internalTransfer(InternalTransferRequest internalTransferRequest, String ipAddress, String requestId) {
        Gson gson = new Gson();
        String req = gson.toJson(internalTransferRequest);
        log.debug("internalTransfer: {}", req);
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_INTERNAL_TRANSFER);

        query.registerStoredProcedureParameter("p_requestid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_accountId", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_receiveAccount", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_amout", Double.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_transDescrtiption", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_via", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_ipaddress", String.class, ParameterMode.IN);

        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_message", String.class, ParameterMode.INOUT);

        // binding value for params
        query.setParameter("p_requestid", requestId);
        query.setParameter("p_accountId", internalTransferRequest.getAccountId());
        query.setParameter("p_receiveAccount", internalTransferRequest.getReceiveAccount());
        query.setParameter("p_amout", internalTransferRequest.getAmount());
        query.setParameter("p_transDescrtiption", internalTransferRequest.getTransDescription());
        query.setParameter("p_via", internalTransferRequest.getVia());
        query.setParameter("p_ipaddress", ipAddress);

        query.execute();

        String errCd = (String) query.getOutputParameterValue("p_err_code");
        String errMsg = (String) query.getOutputParameterValue("p_err_message");

        StoredProcedureError storedProcedureError = new StoredProcedureError();
        storedProcedureError.setErrCd(errCd);
        storedProcedureError.setErrParam(errMsg);

        return storedProcedureError;
    }

    @Override
    public StoredProcedureError blockAmount(BlockAmountRequest blockAmountRequest, String ipAddress, String requestId) {
        Gson gson = new Gson();
        String req = gson.toJson(blockAmountRequest);
        log.debug("blockAmount: {}", req);
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_BLOCK_AMOUNT);

        query.registerStoredProcedureParameter("p_requestid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_custid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_accountid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_amount", Long.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_via", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_ipaddress", String.class, ParameterMode.IN);

        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_message", String.class, ParameterMode.INOUT);

        // binding value for params
        query.setParameter("p_requestid", requestId);
        query.setParameter("p_custid", blockAmountRequest.getCustId());
        query.setParameter("p_accountid", blockAmountRequest.getAccountId());
        query.setParameter("p_amount", blockAmountRequest.getAmount());
        query.setParameter("p_via", blockAmountRequest.getVia());
        query.setParameter("p_ipaddress", ipAddress);

        query.execute();

        String errCd = (String) query.getOutputParameterValue("p_err_code");
        String errMsg = (String) query.getOutputParameterValue("p_err_message");

        StoredProcedureError storedProcedureError = new StoredProcedureError();
        storedProcedureError.setErrCd(errCd);
        storedProcedureError.setErrParam(errMsg);

        return storedProcedureError;
    }

    @Override
    public StoredProcedureError unBlockAmount(BlockAmountRequest blockAmountRequest, String ipAddress, String requestId) {
        Gson gson = new Gson();
        String req = gson.toJson(blockAmountRequest);
        log.debug("unBlockAmount: {}", req);
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_UN_BLOCK_AMOUNT);

        query.registerStoredProcedureParameter("p_requestid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_custid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_accountid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_amount", Long.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_via", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_ipaddress", String.class, ParameterMode.IN);

        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_message", String.class, ParameterMode.INOUT);

        // binding value for params
        query.setParameter("p_requestid", requestId);
        query.setParameter("p_custid", blockAmountRequest.getCustId());
        query.setParameter("p_accountid", blockAmountRequest.getAccountId());
        query.setParameter("p_amount", blockAmountRequest.getAmount());
        query.setParameter("p_via", blockAmountRequest.getVia());
        query.setParameter("p_ipaddress", ipAddress);

        query.execute();

        String errCd = (String) query.getOutputParameterValue("p_err_code");
        String errMsg = (String) query.getOutputParameterValue("p_err_message");

        StoredProcedureError storedProcedureError = new StoredProcedureError();
        storedProcedureError.setErrCd(errCd);
        storedProcedureError.setErrParam(errMsg);

        return storedProcedureError;
    }

    public List<SecuritiesStatementResponse> getSecuritiesStatement(String accountId, String fromDate, String toDate, String symbol) {
//        try {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_SECURITIES_STATEMENT);

        query.registerStoredProcedureParameter("p_refcursor", Class.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_accountId", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_fromDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_toDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_symbol", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.OUT);
// bind params value
        query.setParameter("p_accountId", accountId);
        query.setParameter("p_fromDate", fromDate);
        query.setParameter("p_toDate", toDate);
        query.setParameter("p_symbol", symbol);
// execute
        query.execute();
        List<SecuritiesStatementResponse> securitiesStatementResponses = null;
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        try {
            List<Object[]> resultList = query.getResultList();
            securitiesStatementResponses = resultList.stream().map(item -> {
                SecuritiesStatementResponse.SecuritiesStatementResponseBuilder builder = SecuritiesStatementResponse.builder();
                builder.busDate(item[0] != null ? sdf.format(item[0]) : "")
                        .symBol((String) item[1])
                        .creditAmt((BigDecimal) item[2])
                        .debitAmt((BigDecimal) item[3])
                        .txDesc((String) item[4])
                        .tltxcd((String) item[5])
                        .tl_Desc((String) item[6]);
                return builder.build();
            }).collect(Collectors.toList());

        } catch (Exception ex) {
            log.info("STORE RETURN NO RESULT", ex);
            securitiesStatementResponses = null;
        }
        return securitiesStatementResponses;
    }

    @Override
    public List<CashStatementHistVO> getCashStatementHist(CashStatementHistRequest cashStatementHistRequest) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_CASH_STATEMENT_HST);
        query.registerStoredProcedureParameter("p_refcursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_accountId", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_fromDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_toDate", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.INOUT);

        query.setParameter("p_accountId", cashStatementHistRequest.getAccountId());
        query.setParameter("p_fromDate", cashStatementHistRequest.getFromDate());
        query.setParameter("p_toDate", cashStatementHistRequest.getToDate());

        List<CashStatementHistVO> cashStatementHistVOS = null;
        List<Object[]> statementHist = query.getResultList();
        String p_err_code = (String) query.getOutputParameterValue("p_err_code");
        if ("0".equals(p_err_code)) {
            return null;
        }

        cashStatementHistVOS = statementHist.stream().map(item -> {
            CashStatementHistVO.CashStatementHistVOBuilder builder = CashStatementHistVO.builder();
            builder.afAcctNo((String) item[0])
                    .busDate((Timestamp) item[1])
                    .transactionNum((String) item[2])
                    .transactionCode((String) item[3])
                    .tlTxDesc((String) item[4])
                    .creditAmt((BigDecimal) item[5])
                    .debitAmt((BigDecimal) item[6])
                    .txDesc((String) item[7])
                    .beginingBalance((BigDecimal) item[8])
                    .ciReceivingBal((BigDecimal) item[9])
                    .ciEmkAmtBal((BigDecimal) item[10])
                    .ciDfDebtAmtBal((BigDecimal) item[11])
                    .odBuySecu((BigDecimal) item[12])
                    .ciAvailBal((BigDecimal) item[13])
                    .endingBalance((BigDecimal) item[14])
                    .dueAmt((BigDecimal) item[18])
                    .available((BigDecimal) item[19]);
            return builder.build();
        }).collect(Collectors.toList());

        return cashStatementHistVOS;
    }

    @Override
    public StoredProcedureError unHoldStock(UnHoldStockRequest unHoldStockRequest) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(cashStoredProcedureProperties.getSP_UN_HOLD_STOCK());
        query.registerStoredProcedureParameter("p_requestid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_custodycd", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_acctno", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_symbol", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_qtty", BigDecimal.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_desc", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_message", String.class, ParameterMode.INOUT);

        query.setParameter("p_requestid", unHoldStockRequest.getRequestId());
        query.setParameter("p_custodycd", unHoldStockRequest.getCustodyCd());
        query.setParameter("p_acctno", unHoldStockRequest.getAccountNo());
        query.setParameter("p_symbol", unHoldStockRequest.getSymbol());
        query.setParameter("p_qtty", unHoldStockRequest.getQuantity());
        query.setParameter("p_desc", unHoldStockRequest.getDescription() == null ? "" : unHoldStockRequest.getDescription());

        query.execute();

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errParam = (String) query.getOutputParameterValue("p_err_message");
        return new StoredProcedureError(errCode, errParam);
    }

    @Override
    public StoredProcedureError holdStock(HoldStockRequest holdStockRequest) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(cashStoredProcedureProperties.getSP_HOLD_STOCK());
        query.registerStoredProcedureParameter("p_requestid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_custodycd", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_acctno", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_symbol", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_qtty", BigDecimal.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_desc", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_message", String.class, ParameterMode.INOUT);

        query.setParameter("p_requestid", holdStockRequest.getRequestId());
        query.setParameter("p_custodycd", holdStockRequest.getCustodyCd());
        query.setParameter("p_acctno", holdStockRequest.getAccountNo());
        query.setParameter("p_symbol", holdStockRequest.getSymbol());
        query.setParameter("p_qtty", holdStockRequest.getQuantity());
        query.setParameter("p_desc", holdStockRequest.getDescription() == null ? "" : holdStockRequest.getDescription());

        query.execute();

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errParam = (String) query.getOutputParameterValue("p_err_message");
        return new StoredProcedureError(errCode, errParam);
    }

    @Override
    public StoredProcedureError unHoldBalance(UnHoldBalanceRequest unHoldBalanceRequest) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(cashStoredProcedureProperties.getSP_UN_HOLD_BALANCE());
        query.registerStoredProcedureParameter("p_requestid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_custodycd", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_acctno", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_amt", BigDecimal.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_desc", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_message", String.class, ParameterMode.INOUT);

        query.setParameter("p_requestid", unHoldBalanceRequest.getRequestId());
        query.setParameter("p_custodycd", unHoldBalanceRequest.getCustodyCd());
        query.setParameter("p_acctno", unHoldBalanceRequest.getAccountNo());
        query.setParameter("p_amt", unHoldBalanceRequest.getAmount());
        query.setParameter("p_desc", unHoldBalanceRequest.getDescription() == null ? "" : unHoldBalanceRequest.getDescription());

        query.execute();

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errParam = (String) query.getOutputParameterValue("p_err_message");
        return new StoredProcedureError(errCode, errParam);
    }

    @Override
    public StoredProcedureError holdBalance(HoldBalanceRequest holdBalanceRequest) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(cashStoredProcedureProperties.getSP_HOLD_BALANCE());
        query.registerStoredProcedureParameter("p_requestid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_custodycd", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_acctno", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_amt", BigDecimal.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_desc", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_message", String.class, ParameterMode.INOUT);

        query.setParameter("p_requestid", holdBalanceRequest.getRequestId());
        query.setParameter("p_custodycd", holdBalanceRequest.getCustodyCd());
        query.setParameter("p_acctno", holdBalanceRequest.getAccountNo());
        query.setParameter("p_amt", holdBalanceRequest.getAmount());
        query.setParameter("p_desc", holdBalanceRequest.getDescription() == null ? "" : holdBalanceRequest.getDescription());

        query.execute();

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errParam = (String) query.getOutputParameterValue("p_err_message");
        return new StoredProcedureError(errCode, errParam);
    }

    @Override
    public List<HoldStockResponse> getHoldStock(String custodyCd, String accountNo) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(cashStoredProcedureProperties.getSP_GET_HOLD_STOCK());
        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_custodycd", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_acctno", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.INOUT);

        query.setParameter("p_custodycd", custodyCd);
        query.setParameter("p_acctno", accountNo);

        query.execute();

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errParam = (String) query.getOutputParameterValue("p_err_param");

        if (SUCCESS_CD.equals(errCode)) {
            List<Object[]> result = query.getResultList();
            return result.stream().map(item -> HoldStockResponse.builder()
                            .custodyCd((String) item[0])
                            .customerId((String) item[1])
                            .accountNo((String) item[2])
                            .symbol((String) item[3])
                            .trade((BigDecimal) item[4])
                            .build()
                    )
                    .collect(Collectors.toList());
        } else {
            log.error("getHoldStock execute sp got error : {}", errParam);
            throw new ApiException(errCode, errParam, null);
        }
    }

    @Override
    public List<UnHoldEODResponse> getUnHoldEOD() {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(cashStoredProcedureProperties.getSP_GET_UN_HOLD_EOD());
        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.INOUT);

        query.setParameter("p_err_code", "0");
        query.execute();

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errParam = (String) query.getOutputParameterValue("p_err_param");

        if (SUCCESS_CD.equals(errCode)) {
            List<Object[]> result = query.getResultList();
            return result.stream().map(item -> UnHoldEODResponse.builder()
                            .brokerCode((String) item[0])
                            .custodyCd((String) item[1])
                            .tradingDate((Date) item[2])
                            .symbol((String) item[3])
                            .transactionType((String) item[4])
                            .settleDate((Date) item[5])
                            .quantity((BigDecimal) item[6])
                            .price((BigDecimal) item[7])
                            .execAmt((BigDecimal) item[8])
                            .feeAmt((BigDecimal) item[9])
                            .taxAmt((BigDecimal) item[10])
                            .netExecAmt((BigDecimal) item[11])
                            .orderNo((String) item[12])
                            .build()
                    )
                    .collect(Collectors.toList());
        } else {
            log.error("getUnHoldEOD execute sp got error : {}", errParam);
            throw new ApiException(errCode, errParam, null);
        }
    }

    @Override
    public List<HoldBalanceResponse> getHoldBalance(String custodyCd, String accountNo) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(cashStoredProcedureProperties.getSP_GET_HOLD_BALANCE());
        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_custodycd", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_acctno", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.INOUT);

        query.setParameter("p_custodycd", custodyCd);
        query.setParameter("p_acctno", accountNo);

        query.execute();

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errParam = (String) query.getOutputParameterValue("p_err_param");

        if (SUCCESS_CD.equals(errCode)) {
            List<Object[]> result = query.getResultList();
            return result.stream().map(item -> HoldBalanceResponse.builder()
                            .custodyCd((String) item[0])
                            .customerId((String) item[1])
                            .accountNo((String) item[2])
                            .advanceLine((BigDecimal) item[3])
                            .build()
                    )
                    .collect(Collectors.toList());
        } else {
            log.error("getHoldBalance execute sp got error : {}", errParam);
            throw new ApiException(errCode, errParam, null);
        }
    }

}
