package vn.com.vpbanks.flex.usecase.service.business.salesupport.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.repository.CustomersRepository;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.repository.EInvestOrderRepository;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.request.CustomerDirectIndirectIn;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.request.GetEInvestOrderRequest;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.response.CustomerDirectIndirect;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.service.EInvestOrderService;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.EInvestOrderDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.GetEInvestOrderDto;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class EInvestOrderServiceImpl implements EInvestOrderService {
    private final EInvestOrderRepository eInvestOrderRepository;

    @Override
    public BaseResponse getEInvestOrder(GetEInvestOrderRequest request) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        try {
            List<EInvestOrderDto> customerDirectIndirects = eInvestOrderRepository.getEInvestOrder(request.getAfacctno(), request.getTxnum(), request.getStatus(), request.getPage(), request.getSize()).getListData();
            baseResponse.setData(customerDirectIndirects);
            return baseResponse;

        } catch (Exception ex) {
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            log.error(ex.getMessage(), ex);
        }
        return null;
    }
}
