package vn.com.vpbanks.flex.usecase.service.business.order.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PostOrderKafkaResponse {
    private String errCd;
    private String errParam;
    private List<PostOrderSPResponse> order;
}

