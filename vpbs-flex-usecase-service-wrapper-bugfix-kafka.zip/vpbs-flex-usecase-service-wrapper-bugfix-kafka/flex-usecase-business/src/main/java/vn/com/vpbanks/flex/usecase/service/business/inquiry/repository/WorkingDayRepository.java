package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository;

import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.CurrentDateFlexDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.WorkingDayDVO;

import java.util.List;

public interface WorkingDayRepository {
    List<WorkingDayDVO> getListWorkingDay(String fromDate, String toDate, String holiday);

    CurrentDateFlexDVO getCurrentDateFlex();
}
