package vn.com.vpbanks.flex.usecase.service.business.inquiry.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.WorkingDayDVO;

@Data
@AllArgsConstructor
public class WorkingDayResponse {
    private Long autoId;

    private String sbDate;

    private String holiday;

    public WorkingDayResponse() {

    }

    public WorkingDayResponse(WorkingDayDVO workingDayDVO) {
        this.autoId = workingDayDVO.getAutoId();
        this.sbDate = workingDayDVO.getSbDate();
        this.holiday = workingDayDVO.getHoliday();
    }
}
