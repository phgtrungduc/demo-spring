package vn.com.vpbanks.flex.usecase.service.business.aq.repository.vo;

import lombok.Data;

@Data
public class SubAccountInfoDVO {
    private String cfType;

    private String cusToDyCd;

    private String subAccountNo;

    private String name;
}
