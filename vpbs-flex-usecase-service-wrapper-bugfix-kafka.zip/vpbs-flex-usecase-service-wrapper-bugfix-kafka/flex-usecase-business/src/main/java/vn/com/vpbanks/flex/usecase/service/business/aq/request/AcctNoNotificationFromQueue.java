package vn.com.vpbanks.flex.usecase.service.business.aq.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AcctNoNotificationFromQueue {
    private String EVENTTYPE;
    private String ACCTNO;
    private String STATUS;
    private String CUSTID;
    private String CUSTODYCD;
}
