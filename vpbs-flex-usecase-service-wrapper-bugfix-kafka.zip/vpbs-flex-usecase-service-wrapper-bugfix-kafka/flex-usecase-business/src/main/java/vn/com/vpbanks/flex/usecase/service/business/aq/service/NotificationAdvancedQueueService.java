package vn.com.vpbanks.flex.usecase.service.business.aq.service;


import org.springframework.stereotype.Service;

import java.util.Map;

public interface NotificationAdvancedQueueService {
    void handleNotificationQueue(Map<String, String> message);
}
