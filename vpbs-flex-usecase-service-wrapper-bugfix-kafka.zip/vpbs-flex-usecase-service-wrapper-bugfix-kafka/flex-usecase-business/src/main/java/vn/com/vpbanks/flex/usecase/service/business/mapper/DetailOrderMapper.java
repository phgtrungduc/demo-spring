package vn.com.vpbanks.flex.usecase.service.business.mapper;

import org.mapstruct.Mapper;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.InquiryDetailOrderDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.InquiryDetailOrderResponse;

@Mapper(componentModel = "spring")
public interface DetailOrderMapper extends BaseMapper<InquiryDetailOrderDVO, InquiryDetailOrderResponse>{
}
