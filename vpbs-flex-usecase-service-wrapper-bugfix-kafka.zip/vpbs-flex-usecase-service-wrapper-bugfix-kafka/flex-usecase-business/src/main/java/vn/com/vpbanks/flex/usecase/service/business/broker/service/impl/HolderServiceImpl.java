package vn.com.vpbanks.flex.usecase.service.business.broker.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import vn.com.vpbanks.flex.usecase.service.business.broker.repository.HolderRepository;
import vn.com.vpbanks.flex.usecase.service.business.broker.repository.vo.HolderInfoDVO;
import vn.com.vpbanks.flex.usecase.service.business.broker.service.HolderService;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class HolderServiceImpl implements HolderService {

    private final HolderRepository holderRepository;

    @Override
    public BaseResponse<Object> getHolder(String custodyCd, String symbol) {
        log.info("[getHolder] custodyCd= {},symbol={}", custodyCd, symbol);
        List<HolderInfoDVO> holderInfoDVOS = holderRepository.getHolder(custodyCd, symbol);
        return BaseResponse.ofSucceeded(holderInfoDVOS);
    }
}
