package vn.com.vpbanks.flex.usecase.service.business.order.request;

public enum Day {
    IN,
    OUT;
}
