package vn.com.vpbanks.flex.usecase.service.business.salesupport.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDirectIndirectIn {

    @JsonProperty("accountNo")
    private String accountNo;

    @JsonProperty("account")
    private String account;

    @JsonProperty("dept")
    private List<String> depts;

    @JsonProperty("cus")
    private List<String> cus;

    @JsonProperty("reCustodyCd")
    private List<String> reCustodyCd;

    @JsonProperty("fromNav")
    private String fromNav;

    @JsonProperty("toNav")
    private String toNav;

    @JsonProperty("fromMar")
    private String fromMar;

    @JsonProperty("toMar")
    private String toMar;

    @JsonProperty("fromValue")
    private String fromValue;

    @JsonProperty("toValue")
    private String toValue;

    @JsonProperty("fromCasa")
    private String fromCasa;

    @JsonProperty("toCasa")
    private String toCasa;

    @JsonProperty("isEinvest")
    private String isEinvest;

    @JsonProperty("page")
    private Integer page;

    @JsonProperty("size")
    private Integer size;

    @JsonProperty("customerFavourites")
    private List<String> customerFavourites;

    @JsonProperty("createdBy")
    private String createdBy;

    @JsonProperty("orderBroker")
    private String orderBroker;

    @JsonProperty("orderId")
    private String orderId;

}
