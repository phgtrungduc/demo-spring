package vn.com.vpbanks.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.com.vpbanks.constants.UrlConstants;
import vn.com.vpbanks.service.LoanSeRateService;

import static vn.com.vpbanks.constants.BaseConfigConstants.SEARCH_KEY_ALL;

@RequiredArgsConstructor
@RestController
@RequestMapping(UrlConstants.V1_BASIC_EXTERNAL_URL)
public class LoanSeRateController {

    private final LoanSeRateService loanSeRateService;

    @GetMapping("lnSeRate")
    public ResponseEntity<Object> getLnSeRate(@RequestParam(required = false, defaultValue = SEARCH_KEY_ALL) String lnSeRateId,
                                              @RequestParam(required = false) Integer pageIndex,
                                              @RequestParam(required = false) Integer pageSize,
                                              @RequestParam String productType) {

        return loanSeRateService.getLnSeRate(lnSeRateId, pageIndex, pageSize, productType);
    }

    @GetMapping("lndebtlvschm/{lnId}")
    public ResponseEntity<Object> getLndebtlvschm(@PathVariable String lnId) {
        return loanSeRateService.getLndebtlvschm(lnId);
    }
}
