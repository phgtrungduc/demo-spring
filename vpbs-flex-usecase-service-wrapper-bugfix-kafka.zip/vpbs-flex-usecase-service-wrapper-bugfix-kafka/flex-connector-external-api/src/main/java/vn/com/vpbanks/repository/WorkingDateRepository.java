package vn.com.vpbanks.repository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import vn.com.vpbanks.repository.vo.CurrentDateFlexVO;
import vn.com.vpbanks.repository.vo.WorkingDayDVO;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Repository
@RequiredArgsConstructor
@Slf4j
public class WorkingDateRepository {

    private final EntityManager entityManager;

    @Value("${vpbanks.flex.sp.FUNC_GET_CURRENT_DATE}")
    private String FUNC_GET_CURRENT_DATE;

    @Value("${vpbanks.flex.sp.SP_GET_LIST_WORKING_DAY}")
    private String SP_GET_LIST_WORKING_DAY;

    public CurrentDateFlexVO getCurrentDateFlex() {
        String currentDateQuery = "SELECT " + FUNC_GET_CURRENT_DATE + " as current_date from dual";
        Query query = entityManager.createNativeQuery(currentDateQuery, CurrentDateFlexVO.class);
        CurrentDateFlexVO currentDate = null;

        try {
            currentDate = (CurrentDateFlexVO) query.getSingleResult();
        } catch (NoResultException exception) {
            log.info("WorkingDayRepository getCurrentDateFlex throw NoResultException ");
        }

        return currentDate;
    }

    public List<WorkingDayDVO> getListWorkingDay(String fromDate, String toDate, String holiday) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(SP_GET_LIST_WORKING_DAY, WorkingDayDVO.class);
        storedProcedureQuery.registerStoredProcedureParameter("p_refcursor", void.class, ParameterMode.REF_CURSOR);
        storedProcedureQuery.registerStoredProcedureParameter("p_frdate", String.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("p_todate", String.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("p_holiday", String.class, ParameterMode.IN);

        storedProcedureQuery.setParameter("p_frdate", fromDate);
        storedProcedureQuery.setParameter("p_todate", toDate);
        storedProcedureQuery.setParameter("p_holiday", holiday);
        List<WorkingDayDVO> days = new ArrayList<>();
        try {
            days = storedProcedureQuery.getResultList();
        } catch (NoResultException exception) {
            days = Collections.emptyList();
            log.info("WorkingDayRepository getListWorkingDay throw NoResultException ");
        }
        return days;
    }
}