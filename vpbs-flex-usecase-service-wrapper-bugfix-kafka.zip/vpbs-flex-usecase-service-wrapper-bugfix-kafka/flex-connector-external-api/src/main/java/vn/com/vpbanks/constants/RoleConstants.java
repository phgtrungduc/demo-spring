package vn.com.vpbanks.constants;

import org.springframework.stereotype.Component;

@Component
public class RoleConstants {

}
