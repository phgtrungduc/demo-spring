package vn.com.vpbanks.dto.request;


import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class RegisterHolderReq {
    @NotBlank
    private String requestId;
    private String custodyCd;

    @NotBlank
    private String symbol;

    @NotBlank
    private String via;

    private String ipAddress;

    @NotBlank
    private String transType;
}
