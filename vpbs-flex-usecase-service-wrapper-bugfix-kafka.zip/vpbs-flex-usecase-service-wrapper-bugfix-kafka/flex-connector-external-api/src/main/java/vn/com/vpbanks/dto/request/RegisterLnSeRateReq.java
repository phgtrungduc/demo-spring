package vn.com.vpbanks.dto.request;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class RegisterLnSeRateReq {
    @NotBlank
    private String requestId;
    private String custodyCd;

    @NotBlank
    private String lnSeRateId;

    @NotBlank
    private String via;
    private String ipAddress;

    @NotBlank
    private String productType;
}
