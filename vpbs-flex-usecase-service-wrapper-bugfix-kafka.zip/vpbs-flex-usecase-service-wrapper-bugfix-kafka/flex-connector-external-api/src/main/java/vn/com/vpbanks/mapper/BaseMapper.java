package vn.com.vpbanks.mapper;

import java.util.List;

public interface BaseMapper <S,T>{

    List<T> fromListSourceToListTarget(List<S> source);

    T fromSourceToTarget(S source);

}