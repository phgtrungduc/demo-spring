package vn.com.vpbanks.dto.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import vn.com.vpbanks.repository.vo.LndebtlvschmDVO;
import vn.com.vpbanks.repository.vo.SymbolLnSeRateDVO;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LnSeRateRes {
    private String id;
    private String lnSeRateName;
    private BigDecimal rate1;
    private BigDecimal rate2;
    private BigDecimal rate3;
    private BigDecimal lnLimitMax;
    private BigDecimal lnAfLimit;
    private String status;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy", timezone = "Asia/Bangkok")
    private Timestamp expiredDate;

    private String afType;
    private String calType;
    private BigDecimal valDay;
    private String productType;

    private List<SymbolLnSeRateDVO> symbols;
    private  List<LndebtlvschmDVO> loanRates;
    private String note;
}
