package vn.com.vpbanks.config.properties;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@Setter
@Getter
@ConfigurationProperties(prefix = "vpbanks.flex.sp")
public class StoredProduceProperties {
    private String SP_REGISTER_LNSERATE;
    private String SP_CANCEL_LNSERATE;
    private String SP_GET_STATUS_LNSERATE;
    private String SP_GET_LNSERATE;
    private String SP_GET_SYMBOL_LNSERATE;
    private String SP_GET_Lndebtlvschm;
    private String SP_REGISTER_HOLDER;
    private String SP_GET_HOLDER;
}
