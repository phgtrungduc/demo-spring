package vn.com.vpbanks.repository.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import java.math.BigDecimal;
import java.sql.Timestamp;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class LnSeRateAccountDVO {
    private String id;
    private String lnSeRateName;
    private BigDecimal rate1;
    private BigDecimal rate2;
    private BigDecimal rate3;
    private BigDecimal lnLimitMax;
    private BigDecimal lnAfLimit;
    private String via;
    private String status;
    private BigDecimal accUserStatus;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy", timezone = "Asia/Bangkok")
    private Timestamp effectiveDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy", timezone = "Asia/Bangkok")
    private Timestamp expiredDate;

    @JsonIgnore
    private BigDecimal rowNum;
    @JsonIgnore
    private BigDecimal totalRecord;

    private String calType;
    private BigDecimal valDay;
    private BigDecimal tnLimitMax;
}
