package vn.com.vpbanks.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.com.vpbanks.constants.UrlConstants;
import vn.com.vpbanks.dto.request.RegisterHolderReq;
import vn.com.vpbanks.service.HolderService;

import javax.validation.Valid;

@RequiredArgsConstructor
@RestController
@RequestMapping(UrlConstants.V1_BASIC_EXTERNAL_URL + UrlConstants.HOLDERS)
public class HolderController {
    private final HolderService holderService;

    @PostMapping
    public ResponseEntity<Object> registerHolder(@Valid @RequestBody RegisterHolderReq registerHolderReq) {
        return holderService.registerHolder(registerHolderReq);
    }

    @GetMapping
    public ResponseEntity<Object> getHolder(@RequestParam String symbol) {
        return holderService.getHolder(symbol);
    }

}
