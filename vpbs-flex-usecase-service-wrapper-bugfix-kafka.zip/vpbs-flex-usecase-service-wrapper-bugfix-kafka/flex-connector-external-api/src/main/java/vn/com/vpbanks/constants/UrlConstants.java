package vn.com.vpbanks.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class UrlConstants {
    public static final String V1_BASIC_ADMIN_URL = "/admin/v1";
    public static final String V1_BASIC_EXTERNAL_URL = "/external/v1";
    public static final String V1_BASIC_INTERNAL_URL = "/internal/v1";
    public static final String V1_BASIC_DOMAIN_URL = "/api/v1";

    public static final String ACCOUNTS = "/accounts";
    public static final String HOLDERS = "/holders";
}
