package vn.com.vpbanks.dto.common;

import lombok.Data;

@Data
public class BaseStoredProduceResponse {
    private String errCode;
    private String errMessage;
    private Object data;
}
