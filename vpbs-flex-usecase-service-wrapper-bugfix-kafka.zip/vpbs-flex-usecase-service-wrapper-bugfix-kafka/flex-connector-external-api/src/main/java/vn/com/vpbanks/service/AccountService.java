package vn.com.vpbanks.service;

import org.springframework.http.ResponseEntity;
import vn.com.vpbanks.dto.request.CancelLnSeRateReq;
import vn.com.vpbanks.dto.request.RegisterLnSeRateReq;

public interface AccountService {
    ResponseEntity<Object> registerLnSeRate(String custodyCd, RegisterLnSeRateReq registerLnSeRateReq);

    ResponseEntity<Object> cancelLnSeRate(String custodyCd, CancelLnSeRateReq cancelLnSeRateReq);

    ResponseEntity<Object> getStatusLnSeRate(String accountNo, String lnSeRateId, Integer pageIndex, Integer pageSize, String productType);

    ResponseEntity<Object> getCurrentDateFlex();

    ResponseEntity<Object> getListWorkingDay(String fromDate, String toDate, String holiday);
}
