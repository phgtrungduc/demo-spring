package vn.com.vpbanks.service;

import org.springframework.http.ResponseEntity;
import vn.com.vpbanks.dto.request.RegisterHolderReq;

public interface HolderService {
    ResponseEntity<Object> registerHolder(RegisterHolderReq registerHolderReq);

    ResponseEntity<Object> getHolder(String symbol);
}
