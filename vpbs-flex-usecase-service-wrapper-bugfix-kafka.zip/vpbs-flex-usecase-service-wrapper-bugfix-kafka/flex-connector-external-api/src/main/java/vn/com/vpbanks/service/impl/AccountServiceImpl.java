package vn.com.vpbanks.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;
import vn.com.vpbanks.config.EndpointConfig;
import vn.com.vpbanks.constants.BaseConfigConstants;
import vn.com.vpbanks.dto.common.BaseStoredProduceResponse;
import vn.com.vpbanks.dto.common.PageCustom;
import vn.com.vpbanks.dto.common.ResponseFactory;
import vn.com.vpbanks.dto.request.CancelLnSeRateReq;
import vn.com.vpbanks.dto.request.RegisterLnSeRateReq;
import vn.com.vpbanks.dto.response.CHKDwhResponse;
import vn.com.vpbanks.exception.BizException;
import vn.com.vpbanks.exception.FlexException;
import vn.com.vpbanks.repository.AccountRepository;
import vn.com.vpbanks.repository.WorkingDateRepository;
import vn.com.vpbanks.repository.vo.CurrentDateFlexVO;
import vn.com.vpbanks.repository.vo.LnSeRateAccountDVO;
import vn.com.vpbanks.service.AccountService;
import vn.com.vpbanks.utils.SecurityUtils;

import javax.servlet.http.HttpServletRequest;
import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static vn.com.vpbanks.constants.ErrorConstants.INVALID_CUSTODYCD_ERR_CD;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;
    private final ResponseFactory responseFactory;
    private static final String SEARCH_KEY = "ALL";
    private static final String BEARER = "Bearer";
    private final WorkingDateRepository workingDateRepo;
    private final EndpointConfig endpointConfig;

    @Override
    public ResponseEntity<Object> registerLnSeRate(String accountId, RegisterLnSeRateReq registerLnSeRateReq) {
        Optional<String> custodyCd = SecurityUtils.getCurrentUserLogin();
        if (custodyCd.isEmpty()) {
            throw new BizException(INVALID_CUSTODYCD_ERR_CD);
        }

        registerLnSeRateReq.setCustodyCd(custodyCd.get());
        registerLnSeRateReq.setIpAddress(SecurityUtils.getIPFromRequest(null));

        validateDwh(accountId, registerLnSeRateReq);

        BaseStoredProduceResponse baseStoredProduceResponse = accountRepository.registerLnSeRate(accountId, registerLnSeRateReq);
        if (BaseConfigConstants.SUCCESS_CD.equals(baseStoredProduceResponse.getErrCode())) {
            return responseFactory.success(null);
        }
        throw new FlexException(baseStoredProduceResponse.getErrCode(), baseStoredProduceResponse.getErrMessage());
    }

    private void validateDwh(String accountId, RegisterLnSeRateReq registerLnSeRateReq) {
        CHKDwhResponse response;
        try {
            response = endpointConfig.dwhApiClient()
                    .get()
                    .uri(uriBuilder -> uriBuilder
                            .path(endpointConfig.getDwh().getSpdv())
                            .queryParam("custodyCd", registerLnSeRateReq.getCustodyCd())
                            .queryParam("autoId", registerLnSeRateReq.getLnSeRateId())
                            .queryParam("rmType", registerLnSeRateReq.getProductType())
                            .build())
                    .header(HttpHeaders.AUTHORIZATION, BEARER + getBearerToken())
                    .exchangeToMono(this::handleResponseGeneral)
                    .timeout(Duration.ofMillis(endpointConfig.getTimeout()),
                            Mono.error(new HttpException(HttpStatus.REQUEST_TIMEOUT.toString())))
                    .block();
            log.info("Response dwh: {}", response);
        } catch (Exception e) {
            log.error("Exception validateDwh: ", e);
            throw new FlexException("FCERR20001", getPackageName(accountId, registerLnSeRateReq));
        }
        if (response == null || response.getData() == null || response.getData().getStatus() == null || !response.getData().getStatus().equals("1")) {
            throw new FlexException("FCERR20001", getPackageName(accountId, registerLnSeRateReq));
        }
    }

    private String getBearerToken() {
        try {
            if (Objects.nonNull(RequestContextHolder.getRequestAttributes())) {
                HttpServletRequest request = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getRequest();
                return request.getHeader(HttpHeaders.AUTHORIZATION);
            }
        } catch (Exception e) {
            log.error("Exception getBearerToken: ", e);
        }
        return null;
    }

    private Mono<CHKDwhResponse> handleResponseGeneral(ClientResponse clientResponse) {
        log.info("Http response: {}", clientResponse.statusCode());
        return clientResponse.bodyToMono(CHKDwhResponse.class);
    }

    private String getPackageName(String accountId, RegisterLnSeRateReq registerLnSeRateReq) {
        String message = "Quý khách không thỏa mãn điều kiện tham gia Gói ";
        try {
            List<LnSeRateAccountDVO> lnSeRateAccountDVOS = accountRepository.getStatusLnSeRate(accountId, registerLnSeRateReq.getLnSeRateId(), 0, 10000, registerLnSeRateReq.getProductType());
            log.info("lnSeRateAccountDVOS: {}", lnSeRateAccountDVOS);
            if (lnSeRateAccountDVOS != null && !lnSeRateAccountDVOS.isEmpty() && lnSeRateAccountDVOS.get(0) != null) {
                message = message + lnSeRateAccountDVOS.get(0).getLnSeRateName();
            }
        } catch (Exception e) {
            log.error("Exception getPackageName: ", e);
            return message;
        }
        return message;
    }

    @Override
    public ResponseEntity<Object> cancelLnSeRate(String accountId, CancelLnSeRateReq cancelLnSeRateReq) {
        Optional<String> custodyCd = SecurityUtils.getCurrentUserLogin();
        if (custodyCd.isEmpty()) {
            throw new BizException(INVALID_CUSTODYCD_ERR_CD);
        }
        cancelLnSeRateReq.setCustodyCd(custodyCd.get());
        cancelLnSeRateReq.setIpAddress(SecurityUtils.getIPFromRequest(null));

        BaseStoredProduceResponse spResponse = accountRepository.cancelLnSeRate(accountId, cancelLnSeRateReq);
        if (BaseConfigConstants.SUCCESS_CD.equals(spResponse.getErrCode())) {
            return responseFactory.success(null);
        }

        throw new FlexException(spResponse.getErrCode(), spResponse.getErrMessage());
    }

    @Override
    public ResponseEntity<Object> getStatusLnSeRate(String accountNo, String lnSeRateId, Integer pageIndex, Integer pageSize, String productType) {
        List<LnSeRateAccountDVO> lnSeRateAccountDVOS;

        if (SEARCH_KEY.equals(lnSeRateId)) {
            pageIndex = pageIndex == null ? 0 : pageIndex;
            pageSize = pageSize == null ? 1000000 : pageSize;

            Integer offset = pageIndex * pageSize + 1;
            Integer limit = offset + pageSize - 1;

            lnSeRateAccountDVOS = accountRepository.getStatusLnSeRate(accountNo, lnSeRateId, limit, offset, productType);

            if (CollectionUtils.isEmpty(lnSeRateAccountDVOS)) {
                log.debug("getStatusLnSeRate lnSeRateAccountDVOS is empty ");
                return responseFactory.success(Collections.emptyList());
            }

            Long totalRecord = lnSeRateAccountDVOS.get(0).getTotalRecord().longValue();
            PageCustom<LnSeRateAccountDVO> pageCustom = new PageCustom<>(lnSeRateAccountDVOS, totalRecord, Long.valueOf(pageSize));
            return responseFactory.success(pageCustom);
        }

        lnSeRateAccountDVOS = accountRepository.getStatusLnSeRate(accountNo, lnSeRateId, 0, 10000, productType);
        return responseFactory.success(lnSeRateAccountDVOS);

    }

    @Override
    public ResponseEntity<Object> getCurrentDateFlex() {
        CurrentDateFlexVO result = workingDateRepo.getCurrentDateFlex();
        return responseFactory.success(result);
    }

    @Override
    public ResponseEntity<Object> getListWorkingDay(String fromDate, String toDate, String holiday) {
        return ResponseEntity.ok(workingDateRepo.getListWorkingDay(fromDate, toDate, holiday));
    }
}
