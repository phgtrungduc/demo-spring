package vn.com.vpbanks.service;

import org.springframework.http.ResponseEntity;

public interface LoanSeRateService {
    ResponseEntity<Object> getLnSeRate(String lnSeRateId, Integer pageIndex, Integer pageSize, String productType);

    ResponseEntity<Object> getLndebtlvschm(String lnId);
}
