package vn.com.vpbanks.utils;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.net.InetAddress;
import java.util.*;

@Component
@Slf4j
public class SecurityUtils {
    private static final String PREFERRED_USERNAME = "preferred_username";
    private static final String ACCOUNT_NO = "account_no";
    private static final String REALM_ACCESS = "realm_access";
    public static final String USER_NAME = "user_name";
    private static final String ROLES = "roles";
    private static final String AUTHORIZATION = "Authorization";
    private static final String BEARER = "Bearer ";
    private static final String EMPTY = "";

    // Roles

    private SecurityUtils() {
    }

    /**
     * Get the login of the current user.
     *
     * @return the login of the current user.
     */
    public static Optional<String> getCurrentUserLogin() {
        String accessToken = getAccessTokenFromRequest();
        Optional<JsonObject> payLoadOptional = extractPayloadToken(accessToken);
        if (payLoadOptional.isEmpty()) {
            return Optional.empty();
        }
        JsonObject payLoad = payLoadOptional.get();
        JsonElement eAccount_no = payLoad.get(ACCOUNT_NO);
        if (eAccount_no == null)
            return Optional.empty();

        String account_no = eAccount_no.getAsString();
        return Optional.ofNullable(account_no.toUpperCase());
    }

    public static Optional<String> getCurrentUserLogin(String keyHeader) {
        String accessToken = getAccessTokenFromRequest();
        Optional<JsonObject> payLoadOptional = extractPayloadToken(accessToken);
        if (payLoadOptional.isEmpty()) {
            return Optional.empty();
        }
        JsonObject payLoad = payLoadOptional.get();
        return Optional.ofNullable(payLoad.get(keyHeader).getAsString().toUpperCase());
    }

    public static String currentUserLogin() {

        Optional<String> userLogin = getCurrentUserLogin();
        if (userLogin.isEmpty()) {
            return Strings.EMPTY;
        }

        return userLogin.get();
    }

    public static String currentUserLogin(String keyHeader) {

        Optional<String> userLogin = getCurrentUserLogin(keyHeader);
        if (userLogin.isEmpty()) {
            return Strings.EMPTY;
        }

        return userLogin.get();
    }

    /**
     * Check role
     */
    public static boolean hasRole(String roleName) {
        return hasRoles(roleName);
    }

    public static boolean hasRoles(String... roleNames) {
        String accessToken = getAccessTokenFromRequest();
        return verifyRoleUser(accessToken, roleNames);
    }

    public static boolean verifyRoleUser(String accessToken, String... roleNames) {
        Optional<JsonObject> payLoadOptional = extractPayloadToken(accessToken);
        if (payLoadOptional.isEmpty()) {
            return false;
        }
        JsonObject payLoad = payLoadOptional.get();
        JsonObject realmAccessObject = payLoad.get(REALM_ACCESS).getAsJsonObject();
        JsonArray roles = realmAccessObject.get(ROLES).getAsJsonArray();
        Set<String> roleSet = getAuthoritySet(roles);
        for (String roleName : roleNames) {
            if (roleSet.contains(roleName)) {
                return true;
            }
        }
        return false;
    }

    private static Set<String> getAuthoritySet(JsonArray roles) {
        Set<String> set = new HashSet<>();
        if (Objects.nonNull(roles)) {
            for (JsonElement roleElement : roles) {
                set.add(roleElement.getAsString());
            }
        }
        return set;
    }

    public static Optional<JsonObject> extractPayloadToken(String accessToken) {
        try {
            if (accessToken == null || accessToken.trim().isEmpty()) {
                return Optional.empty();
            }
            String[] parts = accessToken.split("\\.");
            if (parts.length < 1) {
                return Optional.empty();
            }

            String body = new String(Base64.getDecoder().decode(parts[1]));
            Gson gson = new Gson();
            JsonObject payLoad = gson.fromJson(body, JsonObject.class);
            return Optional.ofNullable(payLoad);

        } catch (Exception e) {
            return Optional.empty();
        }
    }

    public static String getAccessTokenFromRequest() {
        try {
            HttpServletRequest request = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getRequest();
            String bearerToken = request.getHeader(AUTHORIZATION);
            if (StringUtils.hasText(bearerToken) && bearerToken.startsWith(BEARER)) {
                return bearerToken.substring(7);
            }
        } catch (Exception e) {
            return EMPTY;
        }
        return null;
    }

    public static Optional<String> getUserId() {
        String accessToken = getAccessTokenFromRequest();
        Optional<JsonObject> payLoadOptional = extractPayloadToken(accessToken);
        if (payLoadOptional.isEmpty()) {
            return Optional.empty();
        }
        JsonObject payLoad = payLoadOptional.get();
        JsonElement eUser_id = payLoad.get(PREFERRED_USERNAME);
        if (eUser_id == null)
            return Optional.empty();

        String user_id = eUser_id.getAsString();
        return Optional.ofNullable(user_id.toUpperCase());
    }

    public static String getUserIdFromToken() {

        Optional<String> userId = getUserId();
        if (userId.isEmpty()) {
            return Strings.EMPTY;
        }

        return userId.get();
    }

    private static final String[] IP_HEADER_CANDIDATES = {
            "X-Forwarded-For",
            "Proxy-Client-IP",
            "WL-Proxy-Client-IP",
            "HTTP_X_FORWARDED_FOR",
            "HTTP_X_FORWARDED",
            "HTTP_X_CLUSTER_CLIENT_IP",
            "HTTP_CLIENT_IP",
            "HTTP_FORWARDED_FOR",
            "HTTP_FORWARDED",
            "HTTP_VIA",
            "REMOTE_ADDR"
    };

    public static String getIPFromRequest(HttpServletRequest request) {
        String ip = null;
        if (request == null) {
            if (RequestContextHolder.getRequestAttributes() == null) {
                return null;
            }
            request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        }

        try {
            ip = InetAddress.getLocalHost().getHostAddress();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (!StringUtils.isEmpty(ip))
            return ip;

        for (String header : IP_HEADER_CANDIDATES) {
            String ipList = request.getHeader(header);
            if (ipList != null && ipList.length() != 0 && !"unknown".equalsIgnoreCase(ipList)) {
                return ipList.split(",")[0];
            }
        }

        return request.getRemoteAddr();
    }
}
