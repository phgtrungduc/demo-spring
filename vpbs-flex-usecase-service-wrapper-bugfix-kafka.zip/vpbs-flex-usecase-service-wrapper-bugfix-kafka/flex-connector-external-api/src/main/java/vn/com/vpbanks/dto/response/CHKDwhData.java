package vn.com.vpbanks.dto.response;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class CHKDwhData {
    private String custodyCd;
    private String status;
    private String note;
}
