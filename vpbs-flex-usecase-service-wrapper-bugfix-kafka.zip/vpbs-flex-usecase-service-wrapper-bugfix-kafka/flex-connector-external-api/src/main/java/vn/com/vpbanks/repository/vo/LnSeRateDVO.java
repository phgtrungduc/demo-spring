package vn.com.vpbanks.repository.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LnSeRateDVO {
    private String id;
    private String lnSeRateName;
    private BigDecimal rate1;
    private BigDecimal rate2;
    private BigDecimal rate3;
    private BigDecimal lnLimitMax;
    private BigDecimal lnAfLimit;
    private String status;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy", timezone = "Asia/Bangkok")
    private Timestamp expiredDate;

    private String afType;
    private String calType;
    private BigDecimal valDay;
    private String productType;

    @JsonIgnore
    private BigDecimal rowNum;

    @JsonIgnore
    private BigDecimal totalRecord;

    private String note;
}
