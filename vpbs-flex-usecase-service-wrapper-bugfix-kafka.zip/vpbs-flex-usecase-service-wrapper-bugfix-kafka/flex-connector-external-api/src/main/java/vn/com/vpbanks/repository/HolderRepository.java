package vn.com.vpbanks.repository;

import vn.com.vpbanks.dto.common.BaseStoredProduceResponse;
import vn.com.vpbanks.dto.request.RegisterHolderReq;
import vn.com.vpbanks.repository.vo.HolderInfoDVO;

import java.util.List;
import java.util.Optional;

public interface HolderRepository {
    BaseStoredProduceResponse registerHolder(RegisterHolderReq registerHolderReq);

    List<HolderInfoDVO> getHolder(String custodyCd, String symbol);
}
