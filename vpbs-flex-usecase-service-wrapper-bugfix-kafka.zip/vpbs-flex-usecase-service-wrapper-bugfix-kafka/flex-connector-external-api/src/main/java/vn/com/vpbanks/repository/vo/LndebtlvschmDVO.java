package vn.com.vpbanks.repository.vo;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Builder
public class LndebtlvschmDVO {
    private String id;
    private BigDecimal fromAmt;
    private BigDecimal toAmt;
    private BigDecimal rate;
}
