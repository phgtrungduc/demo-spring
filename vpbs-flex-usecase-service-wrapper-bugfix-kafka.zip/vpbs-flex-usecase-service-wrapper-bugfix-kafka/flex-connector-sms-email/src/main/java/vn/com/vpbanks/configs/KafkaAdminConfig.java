package vn.com.vpbanks.configs;

import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaAdmin;
import vn.com.vpbanks.configs.properties.KafkaProperties;

import java.util.HashMap;
import java.util.Map;

import static vn.com.vpbanks.constants.FlexTopics.NOTIFICATION_EMAIL_TOPIC;

@Configuration
@RequiredArgsConstructor
public class KafkaAdminConfig {
    private final KafkaProperties kafkaProperties;

    @Bean
    public KafkaAdmin kafkaAdmin() {
        Map<String, Object> configs = new HashMap<>();
        configs.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.getBootstrapServer());
        return new KafkaAdmin(configs);
    }

    @Bean
    public NewTopic smeTopic() {
        return new NewTopic(NOTIFICATION_EMAIL_TOPIC, 1, (short) 1);
    }
}
