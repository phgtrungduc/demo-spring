package vn.com.vpbanks.converter;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ObjectUtils;

import java.io.IOException;

public class StringDateSerializer extends JsonSerializer {

    private final Logger logger = LoggerFactory.getLogger(StringDateSerializer.class);

    @Override
    public void serialize(Object value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
        String date = value.toString();
        if (ObjectUtils.isEmpty(date)) {
            logger.error("String is empty ");
            return;
        }
        try {
            gen.writeString(date.substring(0, 10));
        } catch (Exception exception) {
            logger.error("Cannot convert json ");
            gen.writeString(date);
        }
    }
}