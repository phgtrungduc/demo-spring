package vn.com.vpbanks.repository.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.BeanProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MR0031DVO {

    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "Asia/Bangkok")
    private Date currdate;
    private String custodycd;
    private String afacctno;
    private String symbol;

    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "Asia/Bangkok")
    private Date effdate;

    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "Asia/Bangkok")
    private Date expdate;

    private BigDecimal mrpriceloan_af;
    private BigDecimal mrratioloan_af;
    private BigDecimal mrpricerate_af;
    private BigDecimal mrratiorate_af;
    private BigDecimal mrpriceloan;
    private BigDecimal mrratioloan;
    private BigDecimal mrpricerate;
    private BigDecimal mrratiorate;
}
