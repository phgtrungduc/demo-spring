package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Data
@Entity
public class T327CMessage {
    @Id
    private String custodycd_acctno;
    private String custodycd;
    private String overduedate;
    private String totalamt;
    private String shortbank;
    private String fullbank;
}
