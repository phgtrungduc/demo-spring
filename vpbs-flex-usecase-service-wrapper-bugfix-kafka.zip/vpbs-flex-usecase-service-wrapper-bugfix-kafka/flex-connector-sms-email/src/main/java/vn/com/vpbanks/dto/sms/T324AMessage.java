package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T324AMessage {
    @Id
    private String custodycd_acctno;
    private String amount;
    private String balance;
}
