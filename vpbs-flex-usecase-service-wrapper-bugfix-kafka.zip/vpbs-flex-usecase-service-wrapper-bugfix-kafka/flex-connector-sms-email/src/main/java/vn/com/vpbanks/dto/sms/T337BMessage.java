package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Data
@Entity
public class T337BMessage {
    @Id
    private String custodycd_acctno;
    private String amt;
    private String f_date;
    private String numsday;
    private String typedate;
    private String txday;
    private String intamt;
    private String vatamt;
}
