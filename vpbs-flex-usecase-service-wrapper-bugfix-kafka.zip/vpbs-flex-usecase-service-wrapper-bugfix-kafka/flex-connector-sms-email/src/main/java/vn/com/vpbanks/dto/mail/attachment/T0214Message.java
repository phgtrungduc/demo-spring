package vn.com.vpbanks.dto.mail.attachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T0214Message {
    @Id
    private String custodycd;
    private String fullname;
    private String account;
    private String monthly;
    private String prevdate;
    private String I_DATE;
    private String PV_CUSTODYCD;
    private String PV_AFACCTNO;
    private String AFACCTNO;
    private String PV_AFTYPE;
}
