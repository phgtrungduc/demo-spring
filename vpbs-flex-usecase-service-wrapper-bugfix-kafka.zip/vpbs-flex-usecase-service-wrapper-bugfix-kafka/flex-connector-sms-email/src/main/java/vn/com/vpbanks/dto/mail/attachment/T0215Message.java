package vn.com.vpbanks.dto.mail.attachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T0215Message {
    @Id
    private String custodycd;
    private String fullname;
    private String currdate;
    private String currday;
    private String currmonth;
    private String curryear;
    private String F_DATE;
    private String T_DATE;
    private String PV_CUSTODYCD;
    private String PV_AFACCTNO;
    private String EXECTYPE;
    private String SYMBOL;
    private String VIA;
}
