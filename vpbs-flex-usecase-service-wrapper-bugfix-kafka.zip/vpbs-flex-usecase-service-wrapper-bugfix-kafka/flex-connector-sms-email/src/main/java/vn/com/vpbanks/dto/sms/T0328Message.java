package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T0328Message {
    @Id
    private String custodycd_acctno;
    private String txdate;
    private String shortbank;
    private String fullbank;
    private String custodycd;
}
