package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T384AMessage {
    @Id
    String fullnamekh;
    String custodycdkh;
    String fullnamemg;
    String custodycdmg;
    String frdate;
}
