package vn.com.vpbanks.repository.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class OD0001DVO {
    String custodycd;
    String afacctno;
    String fullname;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    LocalDateTime txdate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    LocalDateTime cleardate;
    String EXECTYPE;
    String CODEID;
    String symbol;
    String exectype_name;
    BigDecimal MATCHPRICE;
    BigDecimal matchqtty;
    BigDecimal VAL_IO;
    BigDecimal feerate;
    BigDecimal TAXRATE;
    BigDecimal FEEAMT;
    BigDecimal taxsellamt;
    BigDecimal numbuy;
    String orderid;
    BigDecimal orderqtty;
    BigDecimal quoteprice;
    BigDecimal RIGHTTAX;
}

