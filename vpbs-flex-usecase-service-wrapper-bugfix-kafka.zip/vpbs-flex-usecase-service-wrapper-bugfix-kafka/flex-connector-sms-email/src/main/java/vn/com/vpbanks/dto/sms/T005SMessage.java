package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
public class T005SMessage {
    @Id
    String custodycd_acctno;
    String marginrate;
    String ovdamount;
    private String custodycd;
    private String shortbank;
    private String fullbank;
}
