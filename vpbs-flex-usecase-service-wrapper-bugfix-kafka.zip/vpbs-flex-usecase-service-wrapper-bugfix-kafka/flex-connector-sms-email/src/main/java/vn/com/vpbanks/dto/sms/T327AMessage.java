package vn.com.vpbanks.dto.sms;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Data;
import vn.com.vpbanks.converter.StringDateSerializer;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Data
@Entity
public class T327AMessage {
    @Id
    private String custodycd_acctno;
    private String moneypay;
    private String amount;

    @JsonSerialize(using = StringDateSerializer.class)
    private String nextdate;
}
