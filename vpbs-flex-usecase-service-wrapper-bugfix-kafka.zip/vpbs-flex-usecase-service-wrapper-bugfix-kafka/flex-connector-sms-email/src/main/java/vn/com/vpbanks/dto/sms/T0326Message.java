package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Data
@Entity
public class T0326Message {
    @Id
    private String custody_afacctno;
    private String pqtty;
    private String symbol;
    private String exprice;
    private String duedate;
    private String todatetransfer;
}
