package vn.com.vpbanks.service.kafka;

public interface EmailHandler {
    void receiveEmailMessage(Integer offset, Integer partition, String message);
}
