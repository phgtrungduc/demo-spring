package vn.com.vpbanks.configs.properties;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@ConfigurationProperties(prefix = "vpbanks.flex.sp")
@Getter
@Setter
@Configuration
@ToString
public class AttachmentProperties {
    private AttachmentT0214 attachmentT0214;
    private AttachmentT0215 attachmentT0215;

    @Data
    public static class AttachmentT0214 {
        String CFD008;
        String CFD0081;
        String CFD0082;
        String CFD0085;
        String CFD0086;
    }

    @Data
    public static class AttachmentT0215 {
        String OD0001;
    }
}
