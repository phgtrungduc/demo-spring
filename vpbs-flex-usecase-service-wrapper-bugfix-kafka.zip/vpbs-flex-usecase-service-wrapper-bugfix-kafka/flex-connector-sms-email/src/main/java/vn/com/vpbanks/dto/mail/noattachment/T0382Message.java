package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T0382Message {
    @Id
    String fullname;
    String custodycdkh;
    String fullnamemg;
    String custodycd;
    String frdate;
}
