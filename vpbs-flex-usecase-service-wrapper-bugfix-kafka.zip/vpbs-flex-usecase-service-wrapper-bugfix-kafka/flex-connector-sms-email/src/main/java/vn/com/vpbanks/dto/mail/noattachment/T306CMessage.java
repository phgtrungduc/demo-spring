package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T306CMessage {
    @Id
    String fullname;
    String custodycd;
    String emailoldvalue;
    String mobileoldvalue;
    String emailnewvalue;
    String mobilenewvalue;
}
