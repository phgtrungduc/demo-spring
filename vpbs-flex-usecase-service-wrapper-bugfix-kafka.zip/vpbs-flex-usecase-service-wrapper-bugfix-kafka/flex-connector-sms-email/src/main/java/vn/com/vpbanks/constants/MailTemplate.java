package vn.com.vpbanks.constants;

import vn.com.vpbanks.dto.mail.attachment.*;
import vn.com.vpbanks.dto.mail.noattachment.*;

import java.util.Arrays;
import java.util.Optional;

public enum MailTemplate {
    T0002("T0002", T0002Message.class),
    T0003("T0003", T0003Message.class),
    T0004("T0004", T0004Message.class),
    T0005("T0005", T0005Message.class),
    T0214("T0214", T0214Message.class),
    T0215("T0215", T0215Message.class),
    T0217("T0217", T0217Message.class),
    T0219("T0219", T0219Message.class),
    T219B("T219B", T219BMessage.class),
    T0223("T0223", T0223Message.class),
    T0224("T0224", T0224Message.class),
    T0380("T0380", T0380Message.class),
    T0382("T0382", T0382Message.class),
    T211A("T211A", T211AMessage.class),
    T213B("T213B", T213BMessage.class),
    T213C("T213C", T213CMessage.class),
    T213E("T213E", T213EMessage.class),
    T216C("T216C", T216CMessage.class),
    T220E("T220E", T220EMessage.class),
    T224B("T224B", T224BMessage.class),
    T306C("T306C", T306CMessage.class),
    T311E("T311E", T311EMessage.class),
    T321A("T321A", T321AMessage.class),
    T326A("T326A", T326AMessage.class),
    T327D("T327D", T327DMessage.class),
    T327E("T327E", T327EMessage.class),
    T381A("T381A", T381AMessage.class),
    T381B("T381B", T381BMessage.class),
    T384A("T384A", T384AMessage.class),
    T384B("T384B", T384BMessage.class),
    T402C("T402C", T402CMessage.class),
    T402D("T402D", T402DMessage.class),
    T403E("T403E", T403EMessage.class),
    T404E("T404E", T404EMessage.class),
    T405E("T405E", T405EMessage.class),
    T406E("T406E", T406EMessage.class),
    T407E("T407E", T407EMessage.class),
    T501E("T501E", T501EMessage.class),
    T502E("T502E", T502EMessage.class),
    T503E("T503E", T503EMessage.class),
    T505E("T505E", T505EMessage.class),
    T028E("T028E", T028EMessage.class),
    T029E("T029E", T029EMessage.class),
    T030E("T030E", T030EMessage.class),
    T031E("T031E", T031EMessage.class),
    T032E("T032E", T032EMessage.class),
    T507E("T507E", T507EMessage.class),
    T507F("T507F", T507FMessage.class),
    T508E("T508E", T508EMessage.class),
    T509E("T509E", T509EMessage.class),
    T504E("T504E", T504EMessage.class);
    private String templateId;
    private Class clazz;

    MailTemplate(String templateId, Class clazz) {
        this.templateId = templateId;
        this.clazz = clazz;
    }

    public Class getClazz() {
        return this.clazz;
    }

    public static Optional<MailTemplate> getTemplate(String templateId) {
        return Arrays.stream(values())
                .filter(item -> item.templateId.equals(templateId))
                .findFirst();
    }
}
