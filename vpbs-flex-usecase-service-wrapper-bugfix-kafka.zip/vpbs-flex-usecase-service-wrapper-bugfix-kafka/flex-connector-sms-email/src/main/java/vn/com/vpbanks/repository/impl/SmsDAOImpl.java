package vn.com.vpbanks.repository.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import vn.com.vpbanks.repository.SmsDAO;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

@Component
@RequiredArgsConstructor
@Slf4j
public class SmsDAOImpl implements SmsDAO {
    private final EntityManager entityManager;

    public Object retrieveData(String sqlQuery, Class clazz) {
        try {
            Query nativeQuery = entityManager.createNativeQuery(this.removeSpecial(sqlQuery), clazz);
            Object object = nativeQuery.getSingleResult();
            return object;
        } catch (NoResultException ex) {
            log.info("Query no result exception {}", ex.getMessage());
            return null;
        }
    }

    private String removeSpecial(String sql) {
        return String.valueOf(sql.charAt(sql.length() - 1)).equals(";")
                ? sql.substring(0, sql.length() - 1)
                : sql;
    }
}
