package vn.com.vpbanks.constants.enums;

import com.fasterxml.jackson.annotation.JsonValue;

public enum SendNoticationFlexType {
    SMS("SMS"), EMAIL("EMAIL");

    public final String value;

    SendNoticationFlexType(String value) {
        this.value = value;
    }

    @JsonValue
    public String getValue() {
        return value;
    }

}
