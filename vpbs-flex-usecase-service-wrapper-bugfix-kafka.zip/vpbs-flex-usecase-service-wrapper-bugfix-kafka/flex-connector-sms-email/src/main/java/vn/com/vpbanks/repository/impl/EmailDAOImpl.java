package vn.com.vpbanks.repository.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.query.procedure.internal.ProcedureParameterImpl;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import vn.com.vpbanks.configs.properties.StoredProcedureProperties;
import vn.com.vpbanks.constants.store.AttachmentStore;
import vn.com.vpbanks.dto.store.InputMR0030DTO;
import vn.com.vpbanks.dto.store.InputMR0031DTO;
import vn.com.vpbanks.dto.store.InputT0214DTO;
import vn.com.vpbanks.dto.store.InputT0215DTO;
import vn.com.vpbanks.repository.EmailDAO;
import vn.com.vpbanks.repository.vo.MR0030DVO;
import vn.com.vpbanks.repository.vo.MR0031DVO;

import javax.persistence.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

import static vn.com.vpbanks.constants.store.AttachmentStore.AttachmentT0214.*;

@Component
@RequiredArgsConstructor
@Slf4j
public class EmailDAOImpl implements EmailDAO {

    private final EntityManager entityManager;

    private final StoredProcedureProperties storedProcedureProperties;

    @Override
    public <T> List<T> getT0214(InputT0214DTO inputT0214DTO, String attachmentCode, Class<T> clazz) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(attachmentCode);
        query.registerStoredProcedureParameter(PV_REFCURSOR, clazz, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter(OPT, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(PV_BRID, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(TLGOUPS, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(TLSCOPE, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(I_DATE, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(PV_CUSTODYCD, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(PV_AFACCTNO, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(PV_AFTYPE, String.class, ParameterMode.IN);

        this.setStoreProcedureEnableNullParameters(query);

        query.setParameter(OPT, inputT0214DTO.getOpt());
        query.setParameter(PV_BRID, inputT0214DTO.getBrid());
        query.setParameter(TLGOUPS, inputT0214DTO.getTlGroups());
        query.setParameter(TLSCOPE, inputT0214DTO.getTlScope());
        query.setParameter(I_DATE, inputT0214DTO.getIDate());
        query.setParameter(PV_CUSTODYCD, inputT0214DTO.getCustoDyCd());
        query.setParameter(PV_AFACCTNO, inputT0214DTO.getAfAcctNo());
        query.setParameter(PV_AFTYPE, inputT0214DTO.getAfType());

        return mapStoredProcedureQuery(query, clazz);
    }

    @Override
    public <T> List<T> getT0215(InputT0215DTO inputT0215DTO, String attachmentCode, Class<T> clazz) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(attachmentCode);
        query.registerStoredProcedureParameter(
                AttachmentStore.AttachmentT0215.PV_REFCURSOR, clazz, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter(
                AttachmentStore.AttachmentT0215.OPT, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(
                AttachmentStore.AttachmentT0215.PV_BRID, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(
                AttachmentStore.AttachmentT0215.TLGOUPS, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(
                AttachmentStore.AttachmentT0215.TLSCOPE, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(
                AttachmentStore.AttachmentT0215.F_DATE, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(
                AttachmentStore.AttachmentT0215.T_DATE, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(
                AttachmentStore.AttachmentT0215.CUSTODYCD, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(
                AttachmentStore.AttachmentT0215.PV_AFACCTNO, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(
                AttachmentStore.AttachmentT0215.EXECTYPE, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(
                AttachmentStore.AttachmentT0215.SYMBOL, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(
                AttachmentStore.AttachmentT0215.TLID, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(
                AttachmentStore.AttachmentT0215.CURRENT_INDEX, Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(
                AttachmentStore.AttachmentT0215.OFFSET_NUMBER, Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(
                AttachmentStore.AttachmentT0215.ONL, String.class, ParameterMode.IN);

        this.setStoreProcedureEnableNullParameters(query);

        query.setParameter(AttachmentStore.AttachmentT0215.OPT, inputT0215DTO.getOpt());
        query.setParameter(AttachmentStore.AttachmentT0215.PV_BRID, inputT0215DTO.getBrid());
        query.setParameter(AttachmentStore.AttachmentT0215.TLGOUPS, inputT0215DTO.getTlGroups());
        query.setParameter(AttachmentStore.AttachmentT0215.TLSCOPE, inputT0215DTO.getTlScope());
        query.setParameter(AttachmentStore.AttachmentT0215.F_DATE, inputT0215DTO.getFDate());
        query.setParameter(AttachmentStore.AttachmentT0215.T_DATE, inputT0215DTO.getTDate());
        query.setParameter(AttachmentStore.AttachmentT0215.CUSTODYCD, inputT0215DTO.getCustoDyCd());
        query.setParameter(AttachmentStore.AttachmentT0215.PV_AFACCTNO, inputT0215DTO.getAfAcctNo());
        query.setParameter(AttachmentStore.AttachmentT0215.EXECTYPE, inputT0215DTO.getExecType());
        query.setParameter(AttachmentStore.AttachmentT0215.SYMBOL, inputT0215DTO.getSymbol());
        query.setParameter(AttachmentStore.AttachmentT0215.TLID, inputT0215DTO.getTlid());
        query.setParameter(
                AttachmentStore.AttachmentT0215.CURRENT_INDEX, inputT0215DTO.getCurrentIndex());
        query.setParameter(
                AttachmentStore.AttachmentT0215.OFFSET_NUMBER, inputT0215DTO.getOffsetNumber());
        query.setParameter(AttachmentStore.AttachmentT0215.ONL, inputT0215DTO.getOnl());

        return mapStoredProcedureQuery(query, clazz);
    }

    @Override
    public void updateEmailLog(BigDecimal autoId, String status, String message) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(storedProcedureProperties.getUpdateEmailLog());
        query.registerStoredProcedureParameter(AttachmentStore.UpdateEmailLog.P_REQUEST_ID, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(AttachmentStore.UpdateEmailLog.P_AUTO_ID, BigDecimal.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(AttachmentStore.UpdateEmailLog.P_STATUS, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(AttachmentStore.UpdateEmailLog.P_MSG_DESC, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(AttachmentStore.UpdateEmailLog.P_ERR_CODE, String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter(AttachmentStore.UpdateEmailLog.P_ERR_MESSAGE, String.class, ParameterMode.INOUT);

        String requestId = UUID.randomUUID().toString();
        query.setParameter(AttachmentStore.UpdateEmailLog.P_REQUEST_ID, requestId);
        query.setParameter(AttachmentStore.UpdateEmailLog.P_AUTO_ID, autoId);
        query.setParameter(AttachmentStore.UpdateEmailLog.P_STATUS, status);
        query.setParameter(AttachmentStore.UpdateEmailLog.P_MSG_DESC, message);
        log.debug("[updateEmailLog] : requestId {}, autoId : {}, status : {} , message {}", requestId, autoId, status, message);
        query.execute();

        log.debug("[updateEmailLog] updated email log");
    }

    @Override
    public List<MR0030DVO> getMr0030(InputMR0030DTO inputMR0030DTO) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(storedProcedureProperties.getMR0030());
        query.registerStoredProcedureParameter(AttachmentStore.MR0030.PV_REF_CURSOR, Void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter(AttachmentStore.MR0030.OPT, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(AttachmentStore.MR0030.pv_BRID, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(AttachmentStore.MR0030.TLGOUPS, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(AttachmentStore.MR0030.TLSCOPE, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(AttachmentStore.MR0030.I_DATE, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(AttachmentStore.MR0030.PV_ACTION, String.class, ParameterMode.IN);

        this.setStoreProcedureEnableNullParameters(query);

        query.setParameter(AttachmentStore.MR0030.OPT, inputMR0030DTO.getOpt());
        query.setParameter(AttachmentStore.MR0030.pv_BRID, inputMR0030DTO.getPvBrid());
        query.setParameter(AttachmentStore.MR0030.TLGOUPS, inputMR0030DTO.getTlGroups());
        query.setParameter(AttachmentStore.MR0030.TLSCOPE, inputMR0030DTO.getTlScope());
        query.setParameter(AttachmentStore.MR0030.I_DATE, inputMR0030DTO.getIDate());
        query.setParameter(AttachmentStore.MR0030.pv_BRID, inputMR0030DTO.getPvBrid());
        query.setParameter(AttachmentStore.MR0030.PV_ACTION, inputMR0030DTO.getPvAction());

        try {
            List<Object[]> result = query.getResultList();
            if (!CollectionUtils.isEmpty(result)) {
                return result.stream()
                        .map(item ->
                                MR0030DVO.builder()
                                        .currdate((Date) item[0])
                                        .autoid((BigDecimal) item[1])
                                        .grpname((String) item[2])
                                        .mrgrptype(String.valueOf(item[3]))
                                        .symbol((String) item[4])
                                        .selimit((BigDecimal) item[5])
                                        .effdate((Date) item[6])
                                        .expdate((Date) item[7])
                                        .warnlimit((BigDecimal) item[8])
                                        .roomlimitamt((BigDecimal) item[9])
                                        .build()
                        )
                        .collect(Collectors.toList());
            }
        } catch (Exception ex) {
            log.error("[getMr0030] got error ", ex.getMessage());
            ex.printStackTrace();
        }

        return Collections.emptyList();
    }

    @Override
    public List<MR0031DVO> getMr0031(InputMR0031DTO inputMR0031DTO) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(storedProcedureProperties.getMR0031());
        query.registerStoredProcedureParameter(AttachmentStore.MR0031.PV_REF_CURSOR, Void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter(AttachmentStore.MR0031.OPT, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(AttachmentStore.MR0031.pv_BRID, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(AttachmentStore.MR0031.TLGOUPS, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(AttachmentStore.MR0031.TLSCOPE, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(AttachmentStore.MR0031.I_DATE, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(AttachmentStore.MR0031.PV_ACTION, String.class, ParameterMode.IN);

        this.setStoreProcedureEnableNullParameters(query);

        query.setParameter(AttachmentStore.MR0030.OPT, inputMR0031DTO.getOpt());
        query.setParameter(AttachmentStore.MR0030.pv_BRID, inputMR0031DTO.getPvBrid());
        query.setParameter(AttachmentStore.MR0030.TLGOUPS, inputMR0031DTO.getTlGroups());
        query.setParameter(AttachmentStore.MR0030.TLSCOPE, inputMR0031DTO.getTlScope());
        query.setParameter(AttachmentStore.MR0030.I_DATE, inputMR0031DTO.getIDate());
        query.setParameter(AttachmentStore.MR0030.pv_BRID, inputMR0031DTO.getPvBrid());
        query.setParameter(AttachmentStore.MR0030.PV_ACTION, inputMR0031DTO.getPvAction());

        try {
            List<Object[]> result = query.getResultList();
            if (!CollectionUtils.isEmpty(result)) {
                return result.stream()
                        .map(item ->
                                MR0031DVO.builder()
                                        .currdate((Date) item[0])
                                        .custodycd((String) item[1])
                                        .afacctno((String) item[2])
                                        .symbol((String) item[3])
                                        .effdate((Date) item[4])
                                        .expdate((Date) item[5])
                                        .mrpriceloan_af((BigDecimal) item[6])
                                        .mrratioloan_af((BigDecimal) item[7])
                                        .mrpricerate_af((BigDecimal) item[8])
                                        .mrratiorate_af((BigDecimal) item[9])
                                        .mrpriceloan((BigDecimal) item[10])
                                        .mrratioloan((BigDecimal) item[11])
                                        .mrpricerate((BigDecimal) item[12])
                                        .mrratiorate((BigDecimal) item[13])
                                        .build()
                        )
                        .collect(Collectors.toList());
            }
        } catch (Exception ex) {
            log.error("[getMr0030] got error ", ex.getMessage());
            ex.printStackTrace();
        }

        return Collections.emptyList();
    }

    public <T> List<T> mapStoredProcedureQuery(StoredProcedureQuery query, Class<T> targetClass) {
        List<Object[]> results = query.getResultList();
        List<T> mappedResults = new ArrayList<>();

        for (Object[] result : results) {
            try {
                Constructor<T> constructor = targetClass.getConstructor();
                T instance = constructor.newInstance();

                Field[] fields = targetClass.getDeclaredFields();
                for (int i = 0; i < result.length; i++) {
                    Field field = fields[i];
                    field.setAccessible(true);
                    field.set(instance, convertTimestamp(result[i]));
                }

                mappedResults.add(instance);
            } catch (NoSuchMethodException
                     | InstantiationException
                     | IllegalAccessException
                     | InvocationTargetException
                     | SecurityException e) {
                e.printStackTrace();
            }
        }

        return mappedResults;
    }

    private Object convertTimestamp(Object object) {
        try {
            return ((Timestamp) object).toLocalDateTime();
        } catch (Exception e) {
            return object;
        }
    }

    public Object retrieveData(String sqlQuery, Class clazz) {
        try {
            Query nativeQuery = entityManager.createNativeQuery(removeSpecial(sqlQuery), clazz);

            Object object = nativeQuery.getSingleResult();
            return object;
        } catch (NoResultException ex) {
            log.info("Query no result exception {}", ex.getMessage());
            return null;
        }
    }

    private String removeSpecial(String sql) {
        return String.valueOf(sql.charAt(sql.length() - 1)).equals(";")
                ? sql.substring(0, sql.length() - 1)
                : sql;
    }

    public void setStoreProcedureEnableNullParameters(StoredProcedureQuery storedProcedureQuery) {
        if (storedProcedureQuery == null || storedProcedureQuery.getParameters() == null) return;

        for (Parameter parameter : storedProcedureQuery.getParameters()) {
            ((ProcedureParameterImpl) parameter).enablePassingNulls(true);
        }
    }
}
