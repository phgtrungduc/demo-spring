package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Data
@Entity
public class T337AMessage {
    @Id
    private String custodycd_acctno;
    private String txdate;
    private String numsday;
    private String typedate;
    private String rate;
    private String amt;
}
