package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
public class T324BMessage {
    @Id
    private String custodycd_acctno;
    private String amount;
    private String balance;
}
