package vn.com.vpbanks.repository.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CFD008DVO {

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    private LocalDateTime inDate;
    private String custodycd;
    private String fullname;
    private String mnemonic;
    private String afProduc;
    private String address;
    private String typeAcctNo;
    private String monthly;
    private String afAcctNo;
    private String symbol;
    private String tradePlace;
    private String tradePlace_name;
    private BigDecimal trade_Amt;
    private BigDecimal blocked_Amt;
    private BigDecimal netting_Amt;
    private BigDecimal emkQtty_Amt;
    private BigDecimal trade_Wft;
    private BigDecimal blocked_Wft;
    private BigDecimal basicPrice;
    private BigDecimal ciBalance;
    private BigDecimal ciBalDefoVD;
    private BigDecimal DFQTTY;
    private BigDecimal RCVDFQTTY;
    private BigDecimal NBAMT;
    private BigDecimal BLOCKED_VSD;
    private BigDecimal bankbalance;
    private BigDecimal bankavlbal;
    private BigDecimal einvestamt;
}
