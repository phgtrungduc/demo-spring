package vn.com.vpbanks.dto.sms;

import lombok.Data;

@Data
public class FlexSmsMessage {
    private String autoId;
    private String phoneNumber;
    private String templateId;
    private String eventType;
    private String query;
}
