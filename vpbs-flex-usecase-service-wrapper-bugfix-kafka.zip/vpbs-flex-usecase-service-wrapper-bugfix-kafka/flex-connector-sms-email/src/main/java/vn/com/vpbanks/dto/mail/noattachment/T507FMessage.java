package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T507FMessage {
    @Id
    private String fullname;
    private String custodycd;
    private String productype;
    private String currdate;
    private String opndate;
    private String overduedate;
    private String lnprintamt;
    private String exrate;
    private String autoid;
    private String shortbank;
    private String fullbank;
}
