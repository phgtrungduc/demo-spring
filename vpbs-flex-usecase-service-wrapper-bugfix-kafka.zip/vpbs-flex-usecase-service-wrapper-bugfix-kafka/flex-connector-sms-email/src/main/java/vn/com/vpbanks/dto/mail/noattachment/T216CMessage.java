package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T216CMessage {
    @Id
    String fullname;
    String custodycd;
    String p_acctno;
    String trade;
    String symbol;
    String l_desc;
    String reportdate;
    String inactiondate;
    String l_desc1;
}
