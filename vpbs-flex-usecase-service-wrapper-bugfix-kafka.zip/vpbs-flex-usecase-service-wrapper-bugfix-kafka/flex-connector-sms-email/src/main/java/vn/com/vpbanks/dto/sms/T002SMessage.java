package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Data
@Entity
public class T002SMessage {
    @Id
    String custodycd_acctno;
    private String custodycd;
    String marginrate;
    String addvnd;
    String lastdate;
    private String shortbank;
    private String fullbank;
    private String llastdate;
}
