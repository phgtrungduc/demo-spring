package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Data
@Entity
public class T503EMessage {
    @Id
    String fullname;
    String custodycd;
    String producttype;
    String f_date;
    String amt;
    String numsday;
    String typedate;
    String txdate;
    String intamt;
    String vatamt;
    String totalamt;
    String txday;
}
