package vn.com.vpbanks.dto.sms;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BaseSmsMessage {
    private String autoId;
    private String templateId;
    private String eventType;
    private Object data;
}
