package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Entity
@Data
public class T0321Message {
    @Id
    private String custodycd_acctno;
    private String qtty;
    private String symbol;
    private String exprice;
    private String begindate;
    private String duedate;
    private String frdatetransfer;
    private String todatetransfer;
}
