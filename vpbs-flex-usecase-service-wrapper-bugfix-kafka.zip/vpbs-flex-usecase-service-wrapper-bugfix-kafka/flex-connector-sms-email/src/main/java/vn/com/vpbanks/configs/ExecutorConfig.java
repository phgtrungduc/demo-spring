package vn.com.vpbanks.configs;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Configuration
public class ExecutorConfig {

    @Bean(name = "kafkaCallbackExecutor")
    public ExecutorService kafkaCallbackExecutor() {
        return Executors.newFixedThreadPool(5);
    }
}
