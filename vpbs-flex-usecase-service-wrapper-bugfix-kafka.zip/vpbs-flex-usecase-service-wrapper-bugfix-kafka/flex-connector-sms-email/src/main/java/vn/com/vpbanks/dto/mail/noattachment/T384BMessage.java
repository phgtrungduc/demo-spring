package vn.com.vpbanks.dto.mail.noattachment;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T384BMessage {
    @Id
    String fullnamemg;
    String custodycdmg;
    String fullnamekh;
    String custodycdkh;
    String frdate;
    String emailtp;
}
