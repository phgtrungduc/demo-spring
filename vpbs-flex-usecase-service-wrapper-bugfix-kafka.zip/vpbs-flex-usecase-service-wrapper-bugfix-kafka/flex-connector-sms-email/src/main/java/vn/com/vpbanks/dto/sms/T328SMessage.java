package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T328SMessage {
    @Id
    private String custodycd_acctno;
    private String custodycd;
    private String txdate;
    private String shortbank;
    private String fullbank;
}
