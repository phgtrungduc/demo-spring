```
├── flex-usecase-service
│   ├── flex-usecase-common                     ------ Common code which can be used by multiple projects 
│   ├   ├── config                              ------ Config class
│   ├   ├── dto                                 ------ Data transfer object(request. response)
│   ├   ├── model                               ------ Domain model
│   ├   ├── entity                              ------ Entity database
│   ├   ├── utils                               ------ Code common
│   ├   ├── exception                           ------ Exception
│   ├── flex-usecase-application                ------ Web API layer
│   │   ├── controller                          ------ API controller
│   │   ├── mapper                              ------ Map DTO to DomainObject (AggreateRoot), suffix `Mapper`, ex: UserDtoMapper
│   ├── flex-usecase-bussiness                  ------ Logic layer
│   │   ├── service                             ------ logic
│   │   ├── mapper                              ------ Map DomainObject to entity, suffix `Mapper`, ex: UserMapper
│   ├── flex-usecase-persiness-read             ------ Persistence layer read only
│   │   ├── repository                          ------ Contains implementation of Domain Repository, ex: UserRepository(implements JPA)
│   │   ├── repositoryImpl                      ------ implementation 
│   ├── flex-usecase-persiness-write            ------ Persistence layer write only
│   │   ├── repository                          ------ Contains implementation of Domain Repository, ex: UserRepository(implements JPA)
│   │   ├── repositoryImpl                      ------ implementation 
│   ├── flex-usecase-tracking                   ------ Persistence mongo
│   │   ├── repository                          ------ Contains implementation of Domain Repository, ex: UserRepository(implements JPA)
│   │   ├── repositoryImpl                      ------ implementation 
│   ├── migration                               ------ Module for Database migration using Liquibase
```
