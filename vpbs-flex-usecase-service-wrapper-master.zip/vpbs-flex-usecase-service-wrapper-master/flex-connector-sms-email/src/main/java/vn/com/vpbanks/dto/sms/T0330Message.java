package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Data
@Entity
public class T0330Message {
    @Id
    private String custodycd_acctno;
    private String qtty;
    private String symbol;
    private String exprice;
    private String begindate;
    private String duedate;
    private String frdatetransfer;
    private String todatetransfer;
}
