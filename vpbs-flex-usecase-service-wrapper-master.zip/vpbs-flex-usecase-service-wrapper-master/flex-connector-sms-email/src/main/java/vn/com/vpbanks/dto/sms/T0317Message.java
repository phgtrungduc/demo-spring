package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Data
@Entity
public class T0317Message {
    @Id
    private String custodycd_acctno;
    private String p_balance;
    private String symbol;
    private String l_exrate;
    private String p_duedate;
}
