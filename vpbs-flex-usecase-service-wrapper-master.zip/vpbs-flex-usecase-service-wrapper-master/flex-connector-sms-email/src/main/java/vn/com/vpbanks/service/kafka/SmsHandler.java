package vn.com.vpbanks.service.kafka;

public interface SmsHandler {
    void receiveSmsMessage(Integer offset, Integer partition, String message);
}
