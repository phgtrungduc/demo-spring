package vn.com.vpbanks.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class FlexTopics {
    public static final String FLEX_EMAIL_TOPIC = "Connector_Flex_EmailNotify";
    public static final String FLEX_SMS_TOPIC = "Connector_Flex_SMSNotify";
    public static final String BASE_SMS_TOPIC = "notification.sms.topic";
    public static final String NOTIFICATION_SMS_TOPIC = "Connector_Flex_SmsEmail";
    public static final String NOTIFICATION_EMAIL_TOPIC = "Connector_Flex_SmsEmail";
    public static final String BASE_EMAIL_TOPIC = "notification.email.topic";

    public static final String PREFIX_SMSEMAIL_TOPIC = "FLEX_";
    public static final String CUSTOMER_CODE = "custodycd";
    public static final String BUILD_OUTPUT_BY_LIST_OBJECT = "genByList";


}
