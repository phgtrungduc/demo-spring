package vn.com.vpbanks.dto.store;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import vn.com.vpbanks.dto.mail.attachment.T031EMessage;
import vn.com.vpbanks.dto.mail.attachment.T032EMessage;

/**
 * Input for MR0031 stored procedure.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class InputMR0031DTO {
    private String opt;
    private String pvBrid;
    private String tlGroups;
    private String tlScope;
    private String iDate;
    private String pvAction;

    public static  InputMR0031DTO buildInputMr0031DTO(T031EMessage t031EMessage) {
        return InputMR0031DTO.builder()
                .opt("A")
                .pvBrid("0001")
                .tlGroups(null)
                .tlScope("A")
                .iDate(t031EMessage.getI_DATE())
                .pvAction(t031EMessage.getPV_ACTION())
                .build();
    }

    public static InputMR0031DTO buildInputMr0031DTO(T032EMessage t032EMessage) {
        return InputMR0031DTO.builder()
                .opt("A")
                .pvBrid("0001")
                .tlGroups(null)
                .tlScope("A")
                .iDate(t032EMessage.getI_DATE())
                .pvAction(t032EMessage.getPV_ACTION())
                .build();
    }
}
