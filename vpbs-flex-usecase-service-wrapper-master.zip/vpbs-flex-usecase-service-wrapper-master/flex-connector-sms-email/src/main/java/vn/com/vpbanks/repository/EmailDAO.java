package vn.com.vpbanks.repository;

import vn.com.vpbanks.dto.store.InputMR0030DTO;
import vn.com.vpbanks.dto.store.InputMR0031DTO;
import vn.com.vpbanks.dto.store.InputT0214DTO;
import vn.com.vpbanks.dto.store.InputT0215DTO;
import vn.com.vpbanks.repository.vo.MR0030DVO;
import vn.com.vpbanks.repository.vo.MR0031DVO;

import java.math.BigDecimal;
import java.util.List;

public interface EmailDAO {
    Object retrieveData(String sqlQuery, Class clazz);

    <T> List<T> getT0214(InputT0214DTO inputT0214DTO, String attachmentCode, Class<T> clazz);

    <T> List<T> getT0215(InputT0215DTO inputT0215DTO, String attachmentCode, Class<T> clazz);

    void updateEmailLog(BigDecimal autoId, String status, String message);

    List<MR0030DVO> getMr0030(InputMR0030DTO inputMR0030DTO);

    List<MR0031DVO> getMr0031(InputMR0031DTO inputMR0031DTO);

}
