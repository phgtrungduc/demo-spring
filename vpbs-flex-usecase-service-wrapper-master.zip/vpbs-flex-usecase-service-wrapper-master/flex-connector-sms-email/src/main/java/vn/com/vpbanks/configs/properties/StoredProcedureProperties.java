package vn.com.vpbanks.configs.properties;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@ConfigurationProperties(prefix = "vpbanks.flex.sp")
@Getter
@Setter
@Configuration
@ToString
public class StoredProcedureProperties {
    private String updateEmailLog;
    private String MR0030;
    private String MR0031;
}
