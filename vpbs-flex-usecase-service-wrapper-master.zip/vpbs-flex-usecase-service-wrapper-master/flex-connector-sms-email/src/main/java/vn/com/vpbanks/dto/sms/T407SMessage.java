package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Data
@Entity
public class T407SMessage {
    @Id
    private String custodycd_cd;
    private String txdate;
    private String amount;
    private String intamt;
    private String vatamt;
}
