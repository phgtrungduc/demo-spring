package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Data
@Entity
public class T0217Message {
    @Id
    String fullname;
    String custodycd;
    String p_acctno;
    String p_balancel;
    String symbol;
    String l_exrate;
    String p_mqtty;
    String p_parvalue;
    String p_duedate;
}
