package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T0323Message {
    @Id
    private String custodycode;
    private String txdate;
    private String detail;
}
