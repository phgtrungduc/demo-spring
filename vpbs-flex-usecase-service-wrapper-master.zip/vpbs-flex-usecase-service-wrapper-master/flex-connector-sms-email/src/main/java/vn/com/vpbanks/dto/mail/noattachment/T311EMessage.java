package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T311EMessage {
    @Id
    String l_fullname;
    String l_sotk;
    String l_class;
    String l_date;
}
