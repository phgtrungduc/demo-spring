package vn.com.vpbanks.constants;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;


public enum AttachmentMapping {
    T0002("T0214", List.of("CFD008", "CFD0081", "CFD0082", "CFD0085", "CFD0086")),
    T503E("T0215", List.of("OD0001")),
    T028E("T028E", List.of("MR0030")),
    T029E("T029E", List.of("MR0030")),
    T030E("T030E", List.of("MR0030")),
    T031E("T031E", List.of("MR0031")),
    T032E("T032E", List.of("MR0031"));
    private final String templateId;
    private final List<String> attachments;

    AttachmentMapping(String templateId, List<String> attachments) {
        this.templateId = templateId;
        this.attachments = attachments;
    }

    public static Optional<AttachmentMapping> getTemplate(String templateId) {
        return Arrays.stream(values())
                .filter(item -> item.templateId.equals(templateId))
                .findFirst();
    }

    public List<String> getAttachments() {
        return this.attachments;
    }
}
