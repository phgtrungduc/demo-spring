package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T402DMessage {
    @Id
    String l_fullname;
    String l_sotk;
    String p_acctno;
    String l_custodycd;
}
