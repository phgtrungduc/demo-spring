package vn.com.vpbanks.constants.enums;

import com.fasterxml.jackson.annotation.JsonValue;

public enum MailAttachment {
    T0214("T0214"),
    T0215("T0215"),
    T028E("T028E"),
    T029E("T029E"),
    T030E("T030E"),
    T031E("T031E"),
    T032E("T032E");

    public final String value;

    MailAttachment(String value) {
        this.value = value;
    }

    @JsonValue
    public String getValue() {
        return value;
    }
}
