package vn.com.vpbanks.constants;

import vn.com.vpbanks.dto.mail.noattachment.T0004Message;
import vn.com.vpbanks.dto.sms.*;
import vn.com.vpbanks.repository.SmsDAO;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public enum SmsTemplate {
    T002S("T002S", T002SMessage.class),
    T003S("T003S", T003SMessage.class),
    T004S("T004S", T004SMessage.class),
    T005S("T005S", T005SMessage.class),
    T0218("T0218", T0218Message.class),
    T0220("T0220", T0220Message.class),
    T0308("T0308", T0308Message.class),
    T0317("T0317", T0317Message.class),
    T0321("T0321", T0321Message.class),
    T0323("T0323", T0323Message.class),
    T0326("T0326", T0326Message.class),
    T0328("T0328", T0328Message.class),
    T0330("T0330", T0330Message.class),
    T0340("T0340", T0340Message.class),
    T0341("T0341", T0341Message.class),
    T0381("T0381", T0381Message.class),
    T0555("T0555", T0555Message.class),
    T0666("T0666", T0666Message.class),
    T220S("T220S", T220SMessage.class),
    T304A("T304A", T304AMessage.class),
    T304B("T304B", T304BMessage.class),
    T304C("T304C", T304CMessage.class),
    T304D("T304D", T304DMessage.class),
    T304S("T304S", T304SMessage.class),
    T306A("T306A", T306AMessage.class),
    T306B("T306B", T306BMessage.class),
    T307S("T307S", T307SMessage.class),
    T311S("T311S", T311SMessage.class),
    T324A("T324A", T324AMessage.class),
    T324B("T324B", T324BMessage.class),
    T325E("T325E", T325EMessage.class),
    T327A("T327A", T327AMessage.class),
    T327B("T327B", T327BMessage.class),
    T327C("T327C", T327CMessage.class),
    T327F("T327F", T327FMessage.class),
    T328S("T328S", T328SMessage.class),
    T337A("T337A", T337AMessage.class),
    T337B("T337B", T337BMessage.class),
    T402A("T402A", T402AMessage.class),
    T402B("T402B", T402BMessage.class),
    T403S("T403S", T403SMessage.class),
    T404S("T404S", T404SMessage.class),
    T405S("T405S", T405SMessage.class),
    T406S("T406S", T406SMessage.class),
    T407S("T407S", T407SMessage.class),
    T503S("T503S", T503SMessage.class),
    T0305("T0305", T0305Message.class),
    T504S("T504S", T504SMessage.class);

    private String templateId;
    private Class clazz;

    SmsTemplate(String templateId, Class clazz) {
        this.templateId = templateId;
        this.clazz = clazz;
    }

    public Class getClazz() {
        return this.clazz;
    }

    public static Optional<SmsTemplate> getTemplate(String templateId) {
        return Arrays.stream(values())
                .filter(item -> item.templateId.equals(templateId))
                .findFirst();
    }
}
