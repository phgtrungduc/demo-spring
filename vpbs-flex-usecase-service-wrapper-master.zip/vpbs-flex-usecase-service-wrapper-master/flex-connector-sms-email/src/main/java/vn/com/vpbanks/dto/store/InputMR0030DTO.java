package vn.com.vpbanks.dto.store;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import vn.com.vpbanks.dto.mail.attachment.T028EMessage;
import vn.com.vpbanks.dto.mail.attachment.T029EMessage;
import vn.com.vpbanks.dto.mail.attachment.T030EMessage;

/**
 * Input for MR0030 stored procedure.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class InputMR0030DTO {
    private String opt;
    private String pvBrid;
    private String tlGroups;
    private String tlScope;
    private String iDate;
    private String pvAction;

    public static InputMR0030DTO buildInputMr0030DTO(T028EMessage t028EMessage) {
        return InputMR0030DTO.builder()
                .opt("A")
                .pvBrid("0001")
                .tlGroups(null)
                .tlScope("A")
                .iDate(t028EMessage.getI_DATE())
                .pvAction(t028EMessage.getPV_ACTION())
                .build();
    }

    public static InputMR0030DTO buildInputMr0030DTO(T029EMessage t029EMessage) {
        return InputMR0030DTO.builder()
                .opt("A")
                .pvBrid("0001")
                .tlGroups(null)
                .tlScope("A")
                .iDate(t029EMessage.getI_DATE())
                .pvAction(t029EMessage.getPV_ACTION())
                .build();
    }

    public static InputMR0030DTO buildInputMr0030DTO(T030EMessage t030EMessage) {
        return InputMR0030DTO.builder()
                .opt("A")
                .pvBrid("0001")
                .tlGroups(null)
                .tlScope("A")
                .iDate(t030EMessage.getI_DATE())
                .pvAction(t030EMessage.getPV_ACTION())
                .build();
    }
}
