package vn.com.vpbanks.dto.mail;

import lombok.Data;

@Data
public class FlexMailMessage {
    private String eventType;
    private String autoId;
    private String templateId;
    private String query;
    private String email;
}
