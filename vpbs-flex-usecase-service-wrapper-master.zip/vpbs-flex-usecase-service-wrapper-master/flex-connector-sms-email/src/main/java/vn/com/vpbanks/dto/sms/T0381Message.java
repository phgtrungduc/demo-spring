package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T0381Message {
    @Id
    private String custodycd_cd;
    private String nameold;
    private String ma_old;
    private String namenew;
    private String ma_new;
    private String frdate;
}
