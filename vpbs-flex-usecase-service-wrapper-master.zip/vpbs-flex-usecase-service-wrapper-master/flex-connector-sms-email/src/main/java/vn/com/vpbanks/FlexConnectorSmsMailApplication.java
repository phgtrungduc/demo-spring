package vn.com.vpbanks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlexConnectorSmsMailApplication {
    public static void main(String[] args) {
        SpringApplication.run(FlexConnectorSmsMailApplication.class, args);
    }
}
