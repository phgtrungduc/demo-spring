package vn.com.vpbanks.dto.sms;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;
import org.springframework.data.util.Pair;
import vn.com.vpbanks.constants.enums.SendNoticationFlexType;

import java.util.List;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class KafkaNotificationMessage {
    String autoId;
    String emailOrPhone;
    String accountNo;
    SendNoticationFlexType type;
    String templateId;
    Object data;
    List<Pair<String,Object>> attachment;
    List<String> ccEmails;
}
