package vn.com.vpbanks.repository.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CFD0086DVO {
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    LocalDateTime i_date;
    String rlstype;
    String custodycd;
    String afacctno;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    LocalDateTime rlsdate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    LocalDateTime overduedate;
    BigDecimal lnschdid;
    BigDecimal rlsprin;
    BigDecimal paid;
    BigDecimal lnprin;
    BigDecimal intamt;
    BigDecimal feeintamt;
    String fullname;
    String mnemonic;
    String brid;
    BigDecimal rate;
}
