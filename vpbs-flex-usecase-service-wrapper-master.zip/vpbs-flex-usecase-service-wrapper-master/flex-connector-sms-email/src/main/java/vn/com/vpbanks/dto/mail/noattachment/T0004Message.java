package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
public class T0004Message {
    @Id
    String fullname;
    String custodycd;
    String cdcontent;
    String currdate;
    String marginrate;
    String addvnd;
    String lastdate;
    String rptmrlrate;
    private String shortbank;
    private String fullbank;
    private String llastdate;
}
