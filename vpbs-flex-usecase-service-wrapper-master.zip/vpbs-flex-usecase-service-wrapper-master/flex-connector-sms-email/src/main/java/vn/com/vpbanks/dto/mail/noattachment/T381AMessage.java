package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T381AMessage {
    @Id
    String fullname;
    String custodycd;
    String nameold;
    String ma_old;
    String namenew;
    String ma_new;
    String frdate;
}
