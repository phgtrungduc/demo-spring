package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Data
@Entity
public class T220EMessage {
    @Id
    String fullname;
    String custodycd;
    String producttype;
    String currdate;
    String amt;
    String feeamt;
}
