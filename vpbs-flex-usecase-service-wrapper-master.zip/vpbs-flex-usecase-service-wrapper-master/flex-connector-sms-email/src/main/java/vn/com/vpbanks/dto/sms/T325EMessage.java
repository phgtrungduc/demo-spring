package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T325EMessage {
    @Id
    private String custodycd_acctno;
    private String txdate;
    private String symbol;
    private String amount;
}
