package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T0219Message {
    @Id
    private String fullname;
    private String custodycd;
    private String producttype;
    private String overduedate;
    private String totalamt;
    private String shortbank;
    private String fullbank;
}
