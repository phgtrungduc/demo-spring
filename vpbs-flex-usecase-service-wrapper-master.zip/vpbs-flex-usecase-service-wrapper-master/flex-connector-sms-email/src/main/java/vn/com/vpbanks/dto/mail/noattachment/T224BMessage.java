package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T224BMessage {
    @Id
    String fullname;
    String custodycd;
    String p_acctno;
    String txdate;
    private String shortbank;
    private String fullbank;
}
