package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Data
@Entity
public class T0223Message {
    @Id
    String fullname;
    String custodycd;
    String p_acctno;
    String pqtty;
    String symbol;
    String exprice;
    String begindate;
    String duedate;
    String frdatetransfer;
    String todatetransfer;
}
