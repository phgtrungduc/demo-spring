package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T0003Message {
    @Id
    private String fullname;
    private String custodycd;
    private String cdcontent;
    private String forcedate;
    private String marginrate;
    private String ovdamount;
    private String shortbank;
    private String fullbank;
}
