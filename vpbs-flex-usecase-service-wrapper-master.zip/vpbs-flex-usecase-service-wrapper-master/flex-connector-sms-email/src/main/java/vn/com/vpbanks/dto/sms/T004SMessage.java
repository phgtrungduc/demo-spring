package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
public class T004SMessage {
    @Id
    String custodycd_acctno;
    private String custodycd;
    String marginrate;
    String addvnd;
    String lastdate;
    private String shortbank;
    private String fullbank;
    private String llastdate;
}
