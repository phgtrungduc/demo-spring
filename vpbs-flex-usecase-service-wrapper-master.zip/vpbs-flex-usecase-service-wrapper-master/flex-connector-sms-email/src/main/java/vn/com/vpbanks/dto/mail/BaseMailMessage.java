package vn.com.vpbanks.dto.mail;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BaseMailMessage {
    private String eventType;
    private String autoId;
    private String templateId;
    private String email;
    private Object data;
}
