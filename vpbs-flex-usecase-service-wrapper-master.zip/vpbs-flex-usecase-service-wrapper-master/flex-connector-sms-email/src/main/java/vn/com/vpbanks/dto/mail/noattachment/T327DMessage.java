package vn.com.vpbanks.dto.mail.noattachment;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Data;
import vn.com.vpbanks.converter.StringDateSerializer;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T327DMessage {
    @Id
    String fullname;
    String custodycd;
    String cdcontend;

    @JsonSerialize(using = StringDateSerializer.class)
    String first_calldate;
    String marginrate;
    String ovdamount;
}
