package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T311SMessage {
    @Id
    private String l_custodycd;
    private String l_class;
    private String l_date;
}
