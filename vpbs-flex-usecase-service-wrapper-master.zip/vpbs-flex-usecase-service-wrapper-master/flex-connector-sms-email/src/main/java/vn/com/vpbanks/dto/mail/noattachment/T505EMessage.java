package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
public class T505EMessage {
    @Id
    private String fullname;
    private String custodycd_acctno;
    private String numsday;
    private String custodycd;
    private String producttype;
    private String acctno;
    private String f_date;
    private String typedate;
    private String amt;
    private String txdate;
    private String intamt;
    private String totalamt;
    private String txday;
    private String vatamt;
}
