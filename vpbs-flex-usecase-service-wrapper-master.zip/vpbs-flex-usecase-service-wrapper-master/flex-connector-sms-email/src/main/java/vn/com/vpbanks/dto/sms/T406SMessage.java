package vn.com.vpbanks.dto.sms;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Entity
@Data
public class T406SMessage {
    @Id
    private String custodycd_cd;
    private String txdate;
    private String amount;
}
