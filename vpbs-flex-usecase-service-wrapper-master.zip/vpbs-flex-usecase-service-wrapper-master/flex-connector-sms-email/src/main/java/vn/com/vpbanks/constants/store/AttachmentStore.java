package vn.com.vpbanks.constants.store;

import lombok.experimental.UtilityClass;

@UtilityClass
public class AttachmentStore {
    public static class AttachmentT0214 {
        public static final String PV_REFCURSOR = "PV_REFCURSOR";
        public static final String OPT = "OPT";
        public static final String PV_BRID = "PV_BRID";
        public static final String TLGOUPS = "TLGOUPS";
        public static final String TLSCOPE = "TLSCOPE";
        public static final String I_DATE = "I_DATE";
        public static final String PV_CUSTODYCD = "PV_CUSTODYCD";
        public static final String PV_AFACCTNO = "PV_AFACCTNO";
        public static final String PV_AFTYPE = "PV_AFTYPE";
    }

    public static class AttachmentT0215 {
        public static final String PV_REFCURSOR = "PV_REFCURSOR";
        public static final String OPT = "OPT";
        public static final String PV_BRID = "pv_BRID";
        public static final String TLGOUPS = "TLGOUPS";
        public static final String TLSCOPE = "TLSCOPE";
        public static final String F_DATE = "F_DATE";
        public static final String T_DATE = "T_DATE";
        public static final String CUSTODYCD = "CUSTODYCD";
        public static final String PV_AFACCTNO = "PV_AFACCTNO";
        public static final String EXECTYPE = "EXECTYPE";
        public static final String SYMBOL = "SYMBOL";
        public static final String TLID = "TLID";
        public static final String CURRENT_INDEX = "CURRENT_INDEX";
        public static final String OFFSET_NUMBER = "OFFSET_NUMBER";
        public static final String ONL = "ONL";
    }

    public static final class UpdateEmailLog {
        public static final String P_REQUEST_ID = "p_requestid";
        public static final String P_AUTO_ID = "p_autoid";
        public static final String P_STATUS = "p_status";
        public static final String P_MSG_DESC = "p_msgdesc";
        public static final String P_ERR_CODE = "p_err_code";
        public static final String P_ERR_MESSAGE = "p_err_message";
    }

    public static final class MR0030 {
        public static final String PV_REF_CURSOR = "PV_REFCURSOR";
        public static final String OPT = "OPT";
        public static final String pv_BRID = "pv_BRID";
        public static final String TLGOUPS = "TLGOUPS";
        public static final String TLSCOPE = "TLSCOPE";
        public static final String I_DATE = "I_DATE";
        public static final String PV_ACTION = "PV_ACTION";
    }

    public static final class MR0031 {
        public static final String PV_REF_CURSOR = "PV_REFCURSOR";
        public static final String OPT = "OPT";
        public static final String pv_BRID = "pv_BRID";
        public static final String TLGOUPS = "TLGOUPS";
        public static final String TLSCOPE = "TLSCOPE";
        public static final String I_DATE = "I_DATE";
        public static final String PV_ACTION = "PV_ACTION";

    }
}
