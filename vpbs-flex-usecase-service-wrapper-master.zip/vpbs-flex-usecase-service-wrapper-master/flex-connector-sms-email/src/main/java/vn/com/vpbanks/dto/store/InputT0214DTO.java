package vn.com.vpbanks.dto.store;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class InputT0214DTO {
    String opt;
    String brid;
    String tlGroups;
    String tlScope;
    String iDate;
    String custoDyCd;
    String afAcctNo;
    String afType;
}
