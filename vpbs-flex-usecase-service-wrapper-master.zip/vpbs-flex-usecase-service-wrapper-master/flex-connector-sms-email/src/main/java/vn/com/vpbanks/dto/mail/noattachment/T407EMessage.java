package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Data
@Entity
public class T407EMessage {
    @Id
    String fullname;
    String custodycd;
    String acctno;
    String txdate;
    String amount;
    String rate;
    String days;
    String intamt;
    String vatamt;
    String amt;
}
