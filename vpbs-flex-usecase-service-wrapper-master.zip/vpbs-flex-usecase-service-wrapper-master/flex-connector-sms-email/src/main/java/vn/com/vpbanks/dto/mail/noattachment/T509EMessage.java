package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
public class T509EMessage {
    @Id
    private String custodycd_acctno;
    private String custodycd;
    private String fullname;
    private String lnseratename;
    private String currdate;
    private String link;
}
