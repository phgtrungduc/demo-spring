package vn.com.vpbanks.constants;

import vn.com.vpbanks.repository.vo.*;

import java.util.Arrays;
import java.util.Optional;

public enum AttachmentTemplate {
    CFD008("CFD008", CFD008DVO.class),
    CFD0081("CFD0081", CFD0081DVO.class),
    CFD0082("CFD0082", CFD0082DVO.class),
    CFD0085("CFD0085", CFD0085DVO.class),
    CFD0086("CFD0086", CFD0086DVO.class),
    OD0001("OD0001", OD0001DVO.class),
    MR0031("MR0031", MR0031DVO.class),
    MR0030("MR0030", MR0030DVO.class);
    private final String templateId;
    private final Class clazz;

    AttachmentTemplate(String templateId, Class clazz) {
        this.templateId = templateId;
        this.clazz = clazz;
    }

    public static Optional<AttachmentTemplate> getAttachmentTemplate(String templateId) {
        return Arrays.stream(values())
                .filter(item -> item.templateId.equals(templateId))
                .findFirst();
    }

    public Class getClazz() {
        return this.clazz;
    }
}
