package vn.com.vpbanks.dto.mail.noattachment;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
public class T504EMessage {
    @Id
    private String custodycd_acctno;
    private String custodycd;
    private String fullname;
    private String producttype;
    private String amt;
    private String tdtype;
    private String f_date;
    private String intamt;
    private String vatamt;
    private String revamt;
    private String t_date;
}
