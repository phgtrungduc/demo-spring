package vn.com.vpbanks.configs.properties;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Configuration
@Setter
@Getter
@ConfigurationProperties("vpbanks.kafka")
public class KafkaProperties {
    private String bootstrapServer;
    private String groupId;
}
