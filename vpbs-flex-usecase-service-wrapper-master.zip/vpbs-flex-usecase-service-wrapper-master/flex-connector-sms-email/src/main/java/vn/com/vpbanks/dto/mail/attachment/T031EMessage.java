package vn.com.vpbanks.dto.mail.attachment;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class T031EMessage {
    @Id
    @JsonProperty("i_date")
    private String I_DATE;
    private String PV_ACTION;
}
