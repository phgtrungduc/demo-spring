package vn.com.vpbanks.repository;

public interface SmsDAO {
    Object retrieveData(String sqlQuery, Class clazz);

}
