package vn.com.vpbanks.flex.usecase.service.business.cash.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BankNoStrResponse {

    @JsonProperty("bankId")
    private String bankId;

    @JsonProperty("bankName")
    private String bankName;

    @JsonProperty("bankAcctNo")
    private String bankAcctNo;

    @JsonProperty("glAccount")
    private String glAccount;
}
