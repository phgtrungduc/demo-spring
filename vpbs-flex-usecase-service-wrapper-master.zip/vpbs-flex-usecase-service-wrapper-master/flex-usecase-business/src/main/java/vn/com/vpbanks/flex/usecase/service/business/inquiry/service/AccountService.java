package vn.com.vpbanks.flex.usecase.service.business.inquiry.service;

import vn.com.vpbanks.flex.usecase.service.business.inquiry.request.AvailableBalanceRequest;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.request.SummaryAccountRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.request.BaseRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.business.cash.request.WithdrawMoneyRequest;

import java.util.List;

public interface AccountService {
    BaseResponse getInformationCus(String custodydc);
    BaseResponse getAccount(String custodycd, String accountId);
    BaseResponse getAccounts(List<String> custodycd, String accountId);
    BaseResponse getSubAccountAvailableBalance(String accountId);

    BaseResponse getSubListAccountAvailableBalance(List<AvailableBalanceRequest> availableBalanceRequest);
    BaseResponse withdrawMoney(BaseRequest<WithdrawMoneyRequest> increaseMoneyRequest  , String ipAddress);

    BaseResponse getAccountForQueue(String cusId, String accountId);

    BaseResponse getSummaryAccount(List<SummaryAccountRequest> accountIds);

}
