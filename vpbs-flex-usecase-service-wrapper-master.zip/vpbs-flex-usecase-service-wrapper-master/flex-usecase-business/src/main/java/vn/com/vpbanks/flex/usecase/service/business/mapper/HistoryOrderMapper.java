package vn.com.vpbanks.flex.usecase.service.business.mapper;

import org.mapstruct.Mapper;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.HistoryOrderMatchDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.HistoryOrderMatchResponse;

@Mapper(componentModel = "spring")
public interface HistoryOrderMapper extends BaseMapper<HistoryOrderMatchDVO, HistoryOrderMatchResponse> {
}
