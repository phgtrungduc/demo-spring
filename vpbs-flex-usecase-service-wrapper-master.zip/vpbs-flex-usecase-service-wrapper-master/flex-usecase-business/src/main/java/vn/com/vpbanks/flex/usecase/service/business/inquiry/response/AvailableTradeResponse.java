package vn.com.vpbanks.flex.usecase.service.business.inquiry.response;

import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AvailableTradeResponse {
    private BigDecimal ppse;
    private BigDecimal maxQtty;
    private BigDecimal trade;
    private String mrRatioLoan;
    private BigDecimal pp0;
    private BigDecimal balance;
    private BigDecimal cashPendingSend;
    private BigDecimal mortgage;

}
