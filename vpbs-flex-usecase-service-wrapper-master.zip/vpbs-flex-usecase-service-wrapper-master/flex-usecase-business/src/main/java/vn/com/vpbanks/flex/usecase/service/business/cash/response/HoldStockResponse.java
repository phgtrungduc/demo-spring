package vn.com.vpbanks.flex.usecase.service.business.cash.response;

import lombok.*;

import java.math.BigDecimal;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class HoldStockResponse {
    private String custodyCd;
    private String customerId;
    private String accountNo;
    private String symbol;
    private BigDecimal trade;
}
