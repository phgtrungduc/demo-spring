package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.AFTypeRepository;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.AFADTypeVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.ODTypeVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.AFTypeResponse;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class AFTypeRepositoryImpl implements AFTypeRepository {

    private static final String SUCCESS_CD = "0";
    private final EntityManager entityManager;

    @Value("${vpbanks.flex.sp.SP_GET_PR_GET_AF_TYPE}")
    private String SP_GET_PR_GET_AF_TYPE;

    @Override
    public AFTypeResponse getAfTypeInfo(String afType) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_PR_GET_AF_TYPE);
        query.registerStoredProcedureParameter("p_refcursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_refcursor2", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_aftype", String.class, ParameterMode.IN);
        query.setParameter("p_aftype", afType);

        query.execute();
        ResultSet resultSet = (ResultSet) query.getOutputParameterValue("p_refcursor");
        AFADTypeVO afadTypeVO = new AFADTypeVO();
        boolean isAfAdTypeNull = false;
        try {
            if(!resultSet.isBeforeFirst()){
                isAfAdTypeNull = true;
            }
            while (resultSet.next()) {
                afadTypeVO.setAfType(resultSet.getString("AFTYPE"));
                afadTypeVO.setAfTypeName(resultSet.getString("AFTYPENAME"));
                afadTypeVO.setAfStatusValue(resultSet.getString("AFSTATUS_VALUE"));
                afadTypeVO.setAfStatus(resultSet.getString("AFSTATUS"));
                afadTypeVO.setStatusValue(resultSet.getString("STATUS_VALUE"));
                afadTypeVO.setStatus(resultSet.getString("STATUS"));
                afadTypeVO.setApprvStsValue(resultSet.getString("APPRV_STS_VALUE"));
                afadTypeVO.setApprvSts(resultSet.getString("APPRV_STS"));
                afadTypeVO.setCiType(resultSet.getString("CITYPE"));
                afadTypeVO.setSeType(resultSet.getString("SETYPE"));
                afadTypeVO.setMrType(resultSet.getString("MRTYPE"));
                afadTypeVO.setLnType(resultSet.getString("LNTYPE"));
                afadTypeVO.setAdType(resultSet.getString("ADTYPE"));
                afadTypeVO.setAdTypeName(resultSet.getString("ADTYPENAME"));
                afadTypeVO.setAdStatusValue(resultSet.getString("ADSTATUS_VALUE"));
                afadTypeVO.setAdStatus(resultSet.getString("ADSTATUS"));
                afadTypeVO.setAdvRate(resultSet.getBigDecimal("ADVRATE"));
                afadTypeVO.setAdvMinFee(resultSet.getBigDecimal("ADVMINFEE"));
                afadTypeVO.setNumsDayValue(resultSet.getString("NUMSDAY_VALUE"));
                afadTypeVO.setNumsDay(resultSet.getString("NUMSDAY"));
            }
        } catch (SQLException ex) {
            log.info("AFTypeRepositoryImpl getAfAdType throw SQLException ", ex.getMessage());
        }

        boolean isOdTypeNull = false;
        List<ODTypeVO> odTypeVOS = new ArrayList<>();
        ResultSet resultSet2 = (ResultSet) query.getOutputParameterValue("p_refcursor2");
        try {
            if(!resultSet2.isBeforeFirst()){
                isOdTypeNull = true;
            }
            while (resultSet2.next()) {
                ODTypeVO odTypeVO = new ODTypeVO();
                odTypeVO.setAfType(resultSet2.getString("AFTYPE"));
                odTypeVO.setOdType(resultSet2.getString("ODTYPE"));
                odTypeVO.setOdTypeName(resultSet2.getString("ODTYPENAME"));
                odTypeVO.setStatusValue(resultSet2.getString("STATUS_VALUE"));
                odTypeVO.setStatus(resultSet2.getString("STATUS"));
                odTypeVO.setApprvStsValue(resultSet2.getString("APPRV_STS_VALUE"));
                odTypeVO.setApprvSts(resultSet2.getString("APPRV_STS"));
                odTypeVO.setDefFeeRate(resultSet2.getBigDecimal("DEFFEERATE"));
                odTypeVOS.add(odTypeVO);
            }
        } catch (SQLException ex) {
            log.info("AFTypeRepositoryImpl getOdType throw SQLException ", ex.getMessage());
        }
        if(isAfAdTypeNull && isOdTypeNull){
            return null;
        }

        afadTypeVO.setOdTypes(odTypeVOS);
        AFTypeResponse afTypeResponse = new AFTypeResponse();
        afTypeResponse.setAfAdType(afadTypeVO);

        return afTypeResponse;
    }

}
