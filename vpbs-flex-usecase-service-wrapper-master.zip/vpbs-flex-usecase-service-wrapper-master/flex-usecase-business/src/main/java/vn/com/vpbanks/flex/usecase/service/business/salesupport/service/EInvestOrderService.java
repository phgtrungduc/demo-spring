package vn.com.vpbanks.flex.usecase.service.business.salesupport.service;

import vn.com.vpbanks.flex.usecase.service.business.salesupport.request.GetEInvestOrderRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;

import java.util.List;

public interface EInvestOrderService {
    BaseResponse getEInvestOrder(GetEInvestOrderRequest getEInvestOrderRequest);
}
