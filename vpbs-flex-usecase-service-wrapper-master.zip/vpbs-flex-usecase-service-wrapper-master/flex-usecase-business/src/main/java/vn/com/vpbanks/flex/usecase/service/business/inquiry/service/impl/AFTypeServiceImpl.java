package vn.com.vpbanks.flex.usecase.service.business.inquiry.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.AFTypeRepository;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.AFTypeResponse;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.service.AFTypeService;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.common.utils.CommonUtils;

@Service
@Slf4j
@RequiredArgsConstructor
public class AFTypeServiceImpl implements AFTypeService {

    @Autowired
    AFTypeRepository afTypeRepository;

    @Override
    public BaseResponse getAFType(String afType) {
        BaseResponse response;
        try{
            AFTypeResponse afTypeResponse = afTypeRepository.getAfTypeInfo(afType);
            response = BaseResponse.ofSucceeded();
            response.setData(afTypeResponse);
            return response;
        }catch (Exception e){
            log.error(CommonUtils.handlerError(e));
            response = BaseResponse.ofFailedException(CommonUtils.handlerError(e));
            return response;
        }
    }
}
