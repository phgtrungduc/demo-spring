package vn.com.vpbanks.flex.usecase.service.business.cf.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import vn.com.vpbanks.flex.usecase.service.business.cf.repository.CFRepository;
import vn.com.vpbanks.flex.usecase.service.business.cf.request.CalCI1202Request;
import vn.com.vpbanks.flex.usecase.service.business.cf.request.OpenCSAccountRequest;
import vn.com.vpbanks.flex.usecase.service.business.cf.service.CFService;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseStoredProcedureResponse;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.StoredProcedureError;

@Service
@Slf4j
@RequiredArgsConstructor
public class CFServiceImpl implements CFService {

    private static final String SUCCESS_CODE = "0";
    private final CFRepository cfRepository;

    @Override
    public BaseResponse openCommissionAccount(OpenCSAccountRequest openCSAccountRequest) {
        BaseStoredProcedureResponse storedProcedureResponse = cfRepository.openCommissionAccount(openCSAccountRequest);

        BaseResponse baseResponse;
        if (SUCCESS_CODE.equals(storedProcedureResponse.getErrCd())) {
            baseResponse = BaseResponse.ofSucceeded(storedProcedureResponse.getData());
            return baseResponse;
        }

        StoredProcedureError storedProcedureError = new StoredProcedureError();
        storedProcedureError.setErrParam(storedProcedureResponse.getErrMsg());
        storedProcedureError.setErrCd(storedProcedureResponse.getErrCd());
        baseResponse = BaseResponse.ofFailedFlexResponse(storedProcedureError);

        return baseResponse;
    }

    @Override
    public BaseResponse calCI1202(CalCI1202Request calCI1202Request) {
        BaseStoredProcedureResponse storedProcedureResponse = cfRepository.calCI1202(calCI1202Request);

        BaseResponse baseResponse;
        if (SUCCESS_CODE.equals(storedProcedureResponse.getErrCd())) {
            baseResponse = BaseResponse.ofSucceeded(storedProcedureResponse.getData());
            return baseResponse;
        }

        StoredProcedureError storedProcedureError = new StoredProcedureError();
        storedProcedureError.setErrParam(storedProcedureResponse.getErrMsg());
        storedProcedureError.setErrCd(storedProcedureResponse.getErrCd());
        baseResponse = BaseResponse.ofFailedFlexResponse(storedProcedureError);

        return baseResponse;
    }
}
