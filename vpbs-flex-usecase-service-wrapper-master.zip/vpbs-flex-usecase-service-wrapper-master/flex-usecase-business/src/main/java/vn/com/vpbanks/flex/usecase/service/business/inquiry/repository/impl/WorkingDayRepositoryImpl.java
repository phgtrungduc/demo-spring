package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.WorkingDayRepository;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.CurrentDateFlexDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.WorkingDayDVO;

import javax.persistence.*;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class WorkingDayRepositoryImpl implements WorkingDayRepository {

    private final EntityManager entityManager;

    @Value("${vpbanks.flex.sp.SP_GET_LIST_WORKING_DAY}")
    private String SP_GET_LIST_WORKING_DAY;

    @Value("${vpbanks.flex.sp.FUNC_GET_CURRENT_DATE}")
    private String FUNC_GET_CURRENT_DATE;

    @Override
    public List<WorkingDayDVO> getListWorkingDay(String fromDate, String toDate, String holiday) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(SP_GET_LIST_WORKING_DAY, WorkingDayDVO.class);
        storedProcedureQuery.registerStoredProcedureParameter("p_refcursor", void.class, ParameterMode.REF_CURSOR);
        storedProcedureQuery.registerStoredProcedureParameter("p_frdate", String.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("p_todate", String.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("p_holiday", String.class, ParameterMode.IN);

        storedProcedureQuery.setParameter("p_frdate", fromDate);
        storedProcedureQuery.setParameter("p_todate", toDate);
        storedProcedureQuery.setParameter("p_holiday", holiday);
        List<WorkingDayDVO> days = new ArrayList<>();
        try {
            days = storedProcedureQuery.getResultList();
        } catch (NoResultException exception) {
            days = Collections.emptyList();
            log.info("WorkingDayRepository getListWorkingDay throw NoResultException ");
        }
        return days;
    }

    @Override
    public CurrentDateFlexDVO getCurrentDateFlex() {
        String currentDateQuery = "SELECT " + FUNC_GET_CURRENT_DATE + " as current_date from dual";
        Query query = entityManager.createNativeQuery(currentDateQuery, CurrentDateFlexDVO.class);
        CurrentDateFlexDVO currentDate = null;

        try {
            currentDate = (CurrentDateFlexDVO) query.getSingleResult();
        } catch (NoResultException exception) {
            log.info("WorkingDayRepository getCurrentDateFlex throw NoResultException ");
        }

        return currentDate;
    }
}
