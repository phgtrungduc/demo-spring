package vn.com.vpbanks.flex.usecase.service.business.order.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Id;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PostOrdersResponseResponse {
    @Id
    @JsonProperty("orderId")
    private List<String> orderIds;

    @JsonProperty("errCode")
    private String errCode;

    @JsonProperty("errParam")
    private String errParam;
}
