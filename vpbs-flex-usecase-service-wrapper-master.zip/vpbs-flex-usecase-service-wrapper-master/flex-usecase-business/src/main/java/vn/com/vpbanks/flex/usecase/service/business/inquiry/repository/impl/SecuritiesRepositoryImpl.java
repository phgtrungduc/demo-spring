package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.SecuritiesRepository;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.SecuritiesInfoDVO;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Repository
@RequiredArgsConstructor
@Slf4j
public class SecuritiesRepositoryImpl implements SecuritiesRepository {

    private final EntityManager entityManager;

    private static final String SUCCESS_CD = "0";

    @Value("${vpbanks.flex.sp.SP_GET_SECURITIES_INFO}")
    private String SP_GET_SECURITIES_INFO;

    public List<SecuritiesInfoDVO> getSecuritiesInfo(String issuerId, String codeId, String symbol, String secTypeName, String tradePlace, Integer offset, Integer limit) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_SECURITIES_INFO);

        query.registerStoredProcedureParameter("pv_refCursor", Class.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_issuerID", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_codeID", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_symbol", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_sectype", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_tradeplace", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_offset", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_limit", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.OUT);

        query.setParameter("p_issuerID", issuerId);
        query.setParameter("p_codeID", codeId);
        query.setParameter("p_symbol", symbol);
        query.setParameter("p_sectype", secTypeName);
        query.setParameter("p_tradeplace", tradePlace);
        query.setParameter("p_offset", offset);
        query.setParameter("p_limit", limit);

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errParam = (String) query.getOutputParameterValue("p_err_param");

        if (SUCCESS_CD.equals(errCode)) {
            try {
                List<Object[]> objects = query.getResultList();
                List<SecuritiesInfoDVO> securitiesInfoDVOS = objects.stream()
                        .map(item -> {
                            SecuritiesInfoDVO securitiesInfoDVO = SecuritiesInfoDVO.builder()
                                    .issuerId((String) item[0])
                                    .issuerFullName((String) item[1])
                                    .codeId((String) item[2])
                                    .symbol((String) item[3])
                                    .secType((String) item[4])
                                    .tradePlace((String) item[5])
                                    .tradePlaceName((String) item[6])
                                    .parValue((BigDecimal) item[7])
                                    .ceilingPrice((BigDecimal) item[8])
                                    .floorPrice((BigDecimal) item[9])
                                    .referencePrice((BigDecimal) item[10])
                                    .currentPrice((BigDecimal) item[11])
                                    .halt((String) item[12])
                                    .tradeLot((BigDecimal) item[13])
                                    .tradeUnit((BigDecimal) item[14])
                                    .issueDate((Timestamp) item[15])
                                    .maturityDate((Timestamp) item[16])
                                    .bondType((String) item[17])
                                    .rowNum((BigDecimal) item[18])
                                    .totalRecord((BigDecimal) item[19])
                                    .build();
                            return securitiesInfoDVO;
                        }).collect(Collectors.toList());
                return securitiesInfoDVOS;
            } catch (NoResultException ex) {
                log.info("getSecuritiesInfo No result exception {}", ex.getMessage());
                return Collections.emptyList();
            }

        }
        log.info("Executed pr_getsecuritiesInfo result : {}, {}", errParam, errParam);
        return Collections.emptyList();
    }
}
