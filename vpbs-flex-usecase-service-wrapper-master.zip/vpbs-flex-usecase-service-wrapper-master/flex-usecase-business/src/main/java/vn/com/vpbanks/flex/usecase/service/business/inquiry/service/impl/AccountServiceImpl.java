package vn.com.vpbanks.flex.usecase.service.business.inquiry.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import vn.com.vpbanks.flex.usecase.service.business.cash.request.WithdrawMoneyRequest;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.AccountRepository;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.impl.AccountsRepository;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.SubAccountAvailableBalanceDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.SummaryAccountVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.request.AvailableBalanceRequest;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.request.SummaryAccountRequest;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.AccountCusResponse;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.AccountNoNotificationResponse;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.AccountResponse;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.SubAccountAvailableBalanceResponse;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.service.AccountService;
import vn.com.vpbanks.flex.usecase.service.business.mapper.SubAccountAvailableBalanceMapper;
import vn.com.vpbanks.flex.usecase.service.common.dto.request.BaseRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.StoredProcedureError;
import vn.com.vpbanks.flex.usecase.service.common.utils.BaseRest;
import vn.com.vpbanks.flex.usecase.service.common.utils.CommonUtils;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


@Service
@Slf4j
@RequiredArgsConstructor
public class AccountServiceImpl implements AccountService {
    private static final String SUCCESS_CODE = "0";
    private final AccountRepository accountRepository;
    private final SubAccountAvailableBalanceMapper subAccountAvailableBalanceMapper;
    @Autowired
    AccountsRepository accountsRepository;


    @Override
    public BaseResponse getInformationCus(String custodycd) {
//        List<AccountCusResponse> accountCusRespList = accountsRepository.getInformationCus(custodycd);
        BaseResponse response;
        try {
            List<AccountCusResponse> res;
            res = accountsRepository.getInformationCus(custodycd);
            response = BaseResponse.ofSucceeded(res);
            return response;
        } catch (Exception e) {
            System.out.println(CommonUtils.handlerError(e));
            log.error(CommonUtils.handlerError(e));
            response = BaseResponse.ofFailedException(e.getMessage());
            return response;
        }
    }

    @Override
    public BaseResponse getAccount(String custodycd, String accountId) {
        BaseResponse response = null;
        try {
            List<AccountCusResponse> accountCusResponseList = accountsRepository.getInformationCus(uppercaseCharacterCus(custodycd));
            if (!Objects.isNull(accountCusResponseList) && accountCusResponseList.size() != 0) {
                String cusId = accountCusResponseList.get(0).getCusId();
                String idCode = accountCusResponseList.get(0).getIdCode();
                String mobileSms = accountCusResponseList.get(0).getMobileSms();
                List<AccountResponse> res;
                res = accountsRepository.getAccount(cusId, accountId);
                log.info("[getAccount] res: {}", res.size());
                if (!Objects.isNull(res) && res.size() != 0) {
                    for (int i = 0; i < res.size(); i++) {
                        res.get(i).setMobileSms(mobileSms);
                        res.get(i).setIdCode(idCode);
                    }
                    response = BaseResponse.ofSucceeded();
                    response.setData(res);
                    response.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_SUCCESS);
                    response.setCode(BaseRest.RESPONSE.OK_CODE);
                    response.setMessage(BaseRest.SUCCESS.SUCCESS);
                    return response;
                } else {
                    response = BaseResponse.ofFailedFlexResponse(res);
                    response.setMessage("Không tìm thấy dữ liệu");
                    return response;
                }
            } else {
                response = BaseResponse.ofFailedFlexResponse(accountCusResponseList);
                response.setMessage("Số TK lưu ký không đúng hoặc không tồn tại: " + custodycd);
                return response;
            }
        } catch (Exception e) {
            System.out.println(CommonUtils.handlerError(e));
            log.error(CommonUtils.handlerError(e));
            response = BaseResponse.ofFailedException(CommonUtils.handlerError(e));
            return response;
        }
    }

    public String uppercaseCharacterCus(String custodycd) {
        String result = "";
        for (int i = 0; i < custodycd.length(); i++) {
            if ((custodycd.charAt(i) >= 'a' && custodycd.charAt(i) <= 'z')) {
                String k = String.valueOf(custodycd.charAt(i));
                result = result + k.toUpperCase();
            } else {
                String k = String.valueOf(custodycd.charAt(i));
                result = result + k;
            }
        }
        return result;
    }

    @Override
    public BaseResponse getAccounts(List<String> custodycd, String accountId) {
        BaseResponse baseResponse = new BaseResponse();
        List<AccountCusResponse> accountCusResponseList = new ArrayList<>();
        List<AccountResponse> accountResponseList = new ArrayList<>();
        List<List<AccountResponse>> accountResLists = new ArrayList<>();
        BaseResponse response = null;
        try {
            for (int i = 0; i < custodycd.size(); i++) {
                accountCusResponseList = accountsRepository.getInformationCus(uppercaseCharacterCus(custodycd.get(i)));
                if (accountCusResponseList.size() == 0) {
                    response = BaseResponse.ofFailedFlexResponse(accountCusResponseList);
                    response.setMessage("Số TK lưu ký không đúng hoặc không tồn tại: " + custodycd.get(i));
                    return response;
                }
//                String idCode = accountCusResponseList.get(0).getIdCode();
//                String mobileSms = accountCusResponseList.get(0).getMobileSms();
                String cusId = accountCusResponseList.get(0).getCusId();
                accountResponseList = accountsRepository.getAccount(cusId, accountId);
//                for (int j = 0; j < accountResponseList.size(); j++) {
//                    accountResponseList.get(j).setMobileSms(mobileSms);
//                    accountResponseList.get(j).setIdCode(idCode);
//                }
                accountResLists.add(accountResponseList);
            }
            response = BaseResponse.ofSucceeded();
            response.setData(accountResLists);
            return response;
        } catch (Exception e) {
            System.out.println(CommonUtils.handlerError(e));
            log.error(CommonUtils.handlerError(e));
            response = BaseResponse.ofFailedException(CommonUtils.handlerError(e));
            return response;
        }

    }

    @Override
    public BaseResponse getSubAccountAvailableBalance(String accountId) {
        BaseResponse baseResponse;
        try {
            SubAccountAvailableBalanceDVO subAccountAvailableBalanceDVO = accountRepository.getSubAccountAvailableBalance(accountId);
            SubAccountAvailableBalanceResponse subAccountAvailableBalanceResponse = subAccountAvailableBalanceMapper.fromSourceToTarget(subAccountAvailableBalanceDVO);

            baseResponse = BaseResponse.ofSucceeded();
            baseResponse.setCode(BaseRest.RESPONSE.OK_CODE);
            baseResponse.setData(subAccountAvailableBalanceResponse);


        } catch (Exception ex) {
            log.error("AccountService getSubAccountAvailableBalance function got an error : {} ", ex.getMessage());
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
        }
        return baseResponse;
    }

    @Override
    public BaseResponse getSubListAccountAvailableBalance(List<AvailableBalanceRequest> availableBalanceRequest) {
        BaseResponse baseResponse;
        try {
            int maxSize = availableBalanceRequest.size();
            if (maxSize <= 10) {
                List<SubAccountAvailableBalanceDVO> list = new ArrayList<>();
                for (int i = 0; i < availableBalanceRequest.size(); i++) {
                    SubAccountAvailableBalanceDVO subAccountAvailableBalanceDVO = accountRepository.getSubAccountAvailableBalance(String.valueOf(availableBalanceRequest.get(i).getAccountId()));
                    list.add(subAccountAvailableBalanceDVO);
                }
                List<SubAccountAvailableBalanceResponse> subAccountAvailableBalanceResponse = subAccountAvailableBalanceMapper.fromListSourceToListTarget(list);
                baseResponse = BaseResponse.ofSucceeded();
                baseResponse.setCode(BaseRest.RESPONSE.OK_CODE);
                baseResponse.setData(subAccountAvailableBalanceResponse);
            } else {
                baseResponse = BaseResponse.ofFailedFlexResponse(maxSize);
                baseResponse.setMessage("Số tiểu khoản accountId truyền tối đa 10 mã");
                baseResponse.setData(null);
            }
        } catch (Exception ex) {
            log.error("AccountService getSubListAccountAvailableBalance function got an error : {} ", ex.getMessage());
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
        }
        return baseResponse;
    }

    @Override
    public BaseResponse withdrawMoney(BaseRequest<WithdrawMoneyRequest> increaseMoneyRequest, String ipAddress) {
        BaseResponse baseResponse;
        try {
            String requestId = increaseMoneyRequest.getRequestId();

            StoredProcedureError response = accountsRepository.getWithdrawMoney(increaseMoneyRequest.getData(), ipAddress, requestId);

            if (SUCCESS_CODE.equals(response.getErrCd())) {
                baseResponse = BaseResponse.ofSucceeded();
                baseResponse.setData(response);
                return baseResponse;
            }
            baseResponse = BaseResponse.ofFailedFlexResponse(response.getErrParam());
            baseResponse.setData(response);
            return baseResponse;
        } catch (Exception ex) {
            log.error("pr_withdraw_money error {}", CommonUtils.handlerError(ex));
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            return baseResponse;
        }
    }

    @Override
    public BaseResponse getAccountForQueue(String cusId, String accountId) {
        BaseResponse response = null;
        try {
            List<AccountResponse> res;
            res = accountsRepository.getAccount(cusId, accountId);
            List<AccountNoNotificationResponse> list = new ArrayList<>();
            if (!Objects.isNull(res) && res.size() != 0) {
                String custodycd = res.get(0).getCusToDyCd();
                List<AccountCusResponse> accountCusResponseList = accountsRepository.getInformationCus(uppercaseCharacterCus(custodycd));
                if (!Objects.isNull(accountCusResponseList) && accountCusResponseList.size() != 0) {
                    String idCode = accountCusResponseList.get(0).getIdCode();
                    String mobileSms = accountCusResponseList.get(0).getMobileSms();
                    AccountNoNotificationResponse accountResponse = new AccountNoNotificationResponse(res.get(0), mobileSms, idCode, cusId);
                    response = BaseResponse.ofSucceeded();
                    response.setData(accountResponse);
                    response.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_SUCCESS);
                    response.setCode(BaseRest.RESPONSE.OK_CODE);
                    response.setMessage(BaseRest.SUCCESS.SUCCESS);
                } else {
                    response = BaseResponse.ofFailedFlexResponse(accountCusResponseList);
                    response.setMessage("Số TK lưu ký không đúng hoặc không tồn tại: " + custodycd);
                }
            } else {
                response = BaseResponse.ofFailedFlexResponse(res);
                response.setMessage("Không tìm thấy dữ liệu");
            }
            return response;
        } catch (Exception e) {
            System.out.println(CommonUtils.handlerError(e));
            log.error(CommonUtils.handlerError(e));
            response = BaseResponse.ofFailedException(CommonUtils.handlerError(e));
            return response;
        }
    }

    @Override
    public BaseResponse getSummaryAccount(List<SummaryAccountRequest> summaryAccounts) {

        BaseResponse response;
        try{
            List<SummaryAccountVO> summaryAccountVOS = new ArrayList<>();
            summaryAccounts.forEach(summaryAccount -> {
                if(!StringUtils.isEmpty(summaryAccount.getAccountId())){
                    SummaryAccountVO summaryAccountVO = accountRepository.getSummaryAccount(summaryAccount.getAccountId());
                    summaryAccountVOS.add(summaryAccountVO);
                }
            });
            response = BaseResponse.ofSucceeded();
            response.setData(summaryAccountVOS);
            return response;
        }catch (Exception e){
            log.error(CommonUtils.handlerError(e));
            response = BaseResponse.ofFailedException(CommonUtils.handlerError(e));
            return response;
        }
    }

}
