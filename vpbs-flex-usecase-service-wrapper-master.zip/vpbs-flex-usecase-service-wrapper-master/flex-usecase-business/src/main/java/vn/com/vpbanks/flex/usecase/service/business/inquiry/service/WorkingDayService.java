package vn.com.vpbanks.flex.usecase.service.business.inquiry.service;

import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.WorkingDayResponse;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;

import java.util.List;

public interface WorkingDayService {

    List<WorkingDayResponse> getListWorkingDay(String fromDate, String toDate, String holiday);

    BaseResponse getCurrentDateFlex();
}
