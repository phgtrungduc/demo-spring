package vn.com.vpbanks.flex.usecase.service.business.inquiry.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import javax.persistence.Column;
import java.io.Serializable;
import java.math.BigDecimal;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SecuritiesPortfolioResponse implements Serializable {
    private static final long serialVersionUID = 1L;
    @JsonProperty("cusToDyCD")
    @Column(name = "CUSTODYCD")
    private String cusToDyCD;

    @JsonProperty("accountID")
    @Column(name = "ACCOUNTID")
    private String accountID;

    @JsonProperty("symbol")
    @Column(name = "SYMBOL")
    private String symbol;

    @JsonProperty("secType")
    @Column(name = "SECTYPE")
    private String secType;

    @JsonProperty("tradePlace")
    @Column(name = "TRADEPLACE")
    private String tradePlace;

    @JsonProperty("total")
    @Column(name = "TOTAL")
    private BigDecimal total;

    @JsonProperty("trade")
    @Column(name = "TRADE")
    private BigDecimal trade;

    @JsonProperty("blocked")
    @Column(name = "BLOCKED")
    private BigDecimal blocked;

    @JsonProperty("vsdMortGage")
    @Column(name = "VSDMORTGAGE")
    private BigDecimal vsdMortGage;

    @JsonProperty("mortGage")
    @Column(name = "MOrtgage")
    private BigDecimal mortGage;

    @JsonProperty("restrict")
    @Column(name = "RESTRICT")
    private BigDecimal restrict;

    @JsonProperty("receivingRight")
    @Column(name = "RECEIVINGRIGHT")
    private BigDecimal receivingRight;

    @JsonProperty("receivingT0")
    @Column(name = "RECEIVINGT0")
    private BigDecimal receivingT0;

    @JsonProperty("receivingT1")
    @Column(name = "RECEIVINGT1")
    private BigDecimal receivingT1;

    @JsonProperty("receivingT2")
    @Column(name = "RECEIVINGT2")
    private BigDecimal receivingT2;

    @JsonProperty("costPrice")
    @Column(name = "COSTPRICE")
    private BigDecimal costPrice;

    @JsonProperty("costPriceAmt")
    @Column(name = "COSTPRICEAMT")
    private BigDecimal costPriceAmt;

    @JsonProperty("basicPrice")
    @Column(name = "BASICPRICE")
    private BigDecimal basicPrice;

    @JsonProperty("basicPriceAmt")
    @Column(name = "BASICPRICEAMT")
    private BigDecimal basicPriceAmt;

    @JsonProperty("marginAmt")
    @Column(name = "MARGINAMT")
    private Character marginAmt;

    @JsonProperty("pnLamt")
    @Column(name = "PNLAMT")
    private BigDecimal pnLamt;

    @JsonProperty("pnlRate")
    @Column(name = "PNLRATE")
    private String pnlRate;

    @JsonProperty("isSell")
    @Column(name = "ISSELL")
    private Character isSell;

    @JsonProperty("closePrice")
    @Column(name = "CLOSEPRICE")
    private BigDecimal closePrice;

    @JsonProperty("withDraw")
    @Column(name = "WITHDRAW")
    private BigDecimal withDraw;

    @JsonProperty("matchIngAmt")
    @Column(name = "MATCHINGAMT")
    private BigDecimal matchIngAmt;

    @JsonProperty("totalPnl")
    @Column(name = "TOTALPNL")
    private BigDecimal totalPnl;

    @JsonProperty("productTypeName")
    @Column(name = "PRODUCTTYPENAME")
    private String productTypeName;

    @JsonProperty("fullName")
    @Column(name = "FULLNAME")
    private String fullName;

    @JsonProperty("r")
    @Column(name = "R")
    private BigDecimal R;

    @JsonProperty("lCount")
    @Column(name = "lCount")
    private BigDecimal lCount;
}
