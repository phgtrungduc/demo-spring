package vn.com.vpbanks.flex.usecase.service.business.order.request;

import org.apache.logging.log4j.util.Strings;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public enum StockOrderStatus {


    COMPLETED,
    WAIT_MATCH,
    CANCELLED,
    EXPIRED,
    CONFIRMED,

    ALL,
    SENT,
    WATCHED,

    REJECT,
    MATCHED,

    DELETE,
    PENDING,
    ACTIVE;

    public static List<String> toStrings(List<StockOrderStatus> stockOrderStatuses) {
        List<String> output = new ArrayList<>();
        if (CollectionUtils.isEmpty(stockOrderStatuses)) {
            return output;
        }

        return stockOrderStatuses.stream()
                .filter(Objects::nonNull)
                .map(Enum::name)
                .collect(Collectors.toList());
    }

    public static String toString(List<StockOrderStatus> stockOrderStatuses) {
        String output = Strings.EMPTY;
        if (CollectionUtils.isEmpty(stockOrderStatuses)) {
            return output;
        }

        for (StockOrderStatus stockOrderStatus : stockOrderStatuses) {
            if (!Strings.isEmpty(output)) {
                output = output.concat(", ");
            }

            output = output.concat(stockOrderStatus.name());
        }
        return output;
    }
}
