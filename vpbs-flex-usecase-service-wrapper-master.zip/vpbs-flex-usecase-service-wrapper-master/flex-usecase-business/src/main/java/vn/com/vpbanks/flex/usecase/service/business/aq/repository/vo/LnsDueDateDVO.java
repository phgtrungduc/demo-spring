package vn.com.vpbanks.flex.usecase.service.business.aq.repository.vo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class LnsDueDateDVO implements Serializable {
    @JsonIgnore
    private String TEMPLATEID;

    private String CODE_CO;

    private String CUSTODYCD;

    private String CUSTID;

    private String AFACCTNO;

    private BigDecimal AUTOID;

    private String OVERDUEDATE;

    private String PRINAMT;

    private String DEBTINTEREST;

    private String DEBTFEE;

    private String TOTALDEBT;
    private String shortbank;
    private String fullbank;
}
