package vn.com.vpbanks.flex.usecase.service.business.customer.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import vn.com.vpbanks.flex.usecase.service.business.customer.repository.CustomerRepository;
import vn.com.vpbanks.flex.usecase.service.business.customer.repository.vo.BeneficiaryAccountDVO;
import vn.com.vpbanks.flex.usecase.service.business.customer.service.CustomerService;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;

    @Override
    public BaseResponse getBeneficiaryAccount(String custId) {
        BaseResponse baseResponse;
        List<BeneficiaryAccountDVO> beneficiaryAccountDVOS = customerRepository.getBeneficiaryAccount(custId);
        baseResponse = BaseResponse.ofSucceeded(beneficiaryAccountDVOS);
        return baseResponse;
    }
}
