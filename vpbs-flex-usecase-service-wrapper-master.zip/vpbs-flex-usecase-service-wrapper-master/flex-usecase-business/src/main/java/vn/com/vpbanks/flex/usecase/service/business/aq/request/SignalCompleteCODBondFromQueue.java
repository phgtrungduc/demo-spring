package vn.com.vpbanks.flex.usecase.service.business.aq.request;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class SignalCompleteCODBondFromQueue {
    private String EVENTTYPE;
    private String TRANSACTIONID;
    private BigDecimal AMOUNT;
    private String TRANSACTIONDATE;
    private String CUSTODYCD;
    private String REMARK;
    private String ACCOUNTNO;
}
