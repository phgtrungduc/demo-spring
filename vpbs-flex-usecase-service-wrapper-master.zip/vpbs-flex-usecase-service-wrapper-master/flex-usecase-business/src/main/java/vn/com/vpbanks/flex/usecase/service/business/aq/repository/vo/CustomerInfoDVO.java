package vn.com.vpbanks.flex.usecase.service.business.aq.repository.vo;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
public class CustomerInfoDVO {
    @Id
    private String CUSTID;
    private String FULLNAME;
    private String ADDRESS;
    private String IDCODE;
    private String IDPLACE;
    private String EMAIL;
    private String MOBILESMS;
    private String STATUS;
}
