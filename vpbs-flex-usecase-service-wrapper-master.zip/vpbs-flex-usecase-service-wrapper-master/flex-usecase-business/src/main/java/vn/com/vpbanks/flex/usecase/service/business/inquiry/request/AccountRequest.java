package vn.com.vpbanks.flex.usecase.service.business.inquiry.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AccountRequest {
    @Id
    @JsonProperty("CFTYPE")
    @Column(name = "CFTYPE")
    private String cfType;

    @JsonProperty("CUSTODYCD")
    @Column(name = "CUSTODYCD")
    private String cusToDyCd;

    @JsonProperty("p_err_param")
    @Column(name = "p_err_param")
    private String pErrParam;
}
