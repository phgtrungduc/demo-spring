package vn.com.vpbanks.flex.usecase.service.business.inquiry.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.SecuritiesRepository;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.impl.SecuritiesPortfolioRepository;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.SecuritiesInfoDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.SecuritiesPortfolioResponse;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.service.SecuritiesPortfolioService;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.PageCustom;
import vn.com.vpbanks.flex.usecase.service.common.utils.BaseRest;
import vn.com.vpbanks.flex.usecase.service.common.utils.CommonUtils;

import java.util.List;


@Service
@Slf4j
@RequiredArgsConstructor
public class SecuritiesPortfolioImpl implements SecuritiesPortfolioService {

    private final SecuritiesRepository securitiesRepository;

    @Autowired
    SecuritiesPortfolioRepository securitiesPortfolioRepository;

    @Override
    public BaseResponse getSecuritiesPortfolio(String pAccountId, String pSymbol, int p_offset, int p_limit) {
        BaseResponse response = null;
        try {
            if ("".equals(pSymbol)) {
                BaseResponse responses = new BaseResponse();
                responses.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_ERROR);
                responses.setMessage(BaseRest.ERROR_MESSAGE.INPUT_NO_VALIT);
                responses.setCode(BaseRest.ERROR_CODE.ERR400);
                responses.setData("");
                return responses;
            }
            List<SecuritiesPortfolioResponse> res;
            res = securitiesPortfolioRepository.getSecuritiesPortfolio(pAccountId, pSymbol, p_offset, p_limit);
            if (res != null) {
                response = BaseResponse.ofSucceeded();
                response.setData(res);
                response.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_SUCCESS);
                response.setCode(BaseRest.RESPONSE.OK_CODE);
                response.setMessage(BaseRest.SUCCESS.SUCCESS);
            } else if (res == null) {
                response = BaseResponse.ofSucceeded();
                response.setData(res);
                response.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_SUCCESS);
                response.setCode(BaseRest.RESPONSE.OK_CODE);
                response.setMessage(BaseRest.SUCCESS.SUCCESS);
            } else {
                response = BaseResponse.ofFailedFlexResponse(res);
            }
            return response;
        } catch (Exception e) {
            System.out.println(CommonUtils.handlerError(e));
            log.error(CommonUtils.handlerError(e));
            response = BaseResponse.ofFailedException(CommonUtils.handlerError(e));
            return response;
        }
    }

    @Override
    public BaseResponse getSecuritiesInfo(String issuerId, String codeId, String symbol, String secTypeName, String tradePlace, Integer pageIndex, Integer pageSize) {
        pageIndex = pageIndex == null ? 0 : pageIndex;
        pageSize = pageSize == null ? 1000000 : pageSize;

        //todo convert pageIndex , pageSize to offset, limit.
        Integer offset = pageIndex * pageSize + 1;
        Integer limit = offset + pageSize - 1;
        List<SecuritiesInfoDVO> securitiesInfoDVOS = securitiesRepository.getSecuritiesInfo(issuerId, codeId, symbol, secTypeName, tradePlace, offset, limit);

        if (!CollectionUtils.isEmpty(securitiesInfoDVOS)) {
            Long totalRecord = securitiesInfoDVOS.get(0).getTotalRecord().longValue();
            PageCustom pageCustom = new PageCustom(securitiesInfoDVOS, totalRecord, Long.valueOf(pageSize));
            return BaseResponse.ofSucceeded(pageCustom);
        }
        return BaseResponse.ofSucceeded();
    }

}
