package vn.com.vpbanks.flex.usecase.service.business.salesupport.service;

import vn.com.vpbanks.flex.usecase.service.business.salesupport.request.CustomerDirectIndirectIn;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.request.CustomerOfBrokerRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import java.util.List;

public interface CustomerService {
    BaseResponse getCustomersDirectIndirect(CustomerDirectIndirectIn customerDirectIndirectIn);
    BaseResponse getOrderCustomerDirectIndirect(CustomerDirectIndirectIn customerDirectIndirectIn);
    BaseResponse getCustomerDirectIndirectDetail(String agencyNo,String preBrokerNo, String accountNo);

    BaseResponse getCustomersByBroker(CustomerOfBrokerRequest request);
}
