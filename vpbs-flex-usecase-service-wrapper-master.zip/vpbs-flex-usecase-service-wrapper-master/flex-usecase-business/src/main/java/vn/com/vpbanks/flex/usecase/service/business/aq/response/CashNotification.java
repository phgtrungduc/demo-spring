package vn.com.vpbanks.flex.usecase.service.business.aq.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import vn.com.vpbanks.flex.usecase.service.business.aq.request.CashNotificationFromQueue;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CashNotification {
    private String eventType;
    private String custoDyCd;
    private String afAcctNo;
    private Number balance;
    private Number balDefOvd;
    private Number avlAdvance;

    public CashNotification(CashNotificationFromQueue queue) {
        this.eventType = queue.getEVENTTYPE();
        this.custoDyCd = queue.getCUSTODYCD();
        this.afAcctNo = queue.getAFACCTNO();
        this.balance = queue.getBALANCE();
        this.balDefOvd = queue.getBALDEFOVD();
        this.avlAdvance = queue.getAVLADVANCE();
    }
}
