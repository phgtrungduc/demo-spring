package vn.com.vpbanks.flex.usecase.service.business.order.request;

import vn.com.vpbanks.flex.usecase.service.common.dto.request.BaseRequest;

public class BaseCancelOrdersRequest extends BaseRequest<CancelOrderRequest> {
}
