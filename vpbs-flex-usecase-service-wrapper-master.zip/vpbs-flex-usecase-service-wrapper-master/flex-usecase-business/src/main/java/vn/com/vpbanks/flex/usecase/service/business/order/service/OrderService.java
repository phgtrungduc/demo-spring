package vn.com.vpbanks.flex.usecase.service.business.order.service;

import vn.com.vpbanks.flex.usecase.service.business.order.request.StockOrderFilter;
import vn.com.vpbanks.flex.usecase.service.common.dto.request.BaseRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.business.order.request.CancelOrderRequest;
import vn.com.vpbanks.flex.usecase.service.business.order.request.OrderUpdateReq;
import vn.com.vpbanks.flex.usecase.service.business.order.request.PostOrdersRequests;

import java.util.List;

public interface OrderService {
    BaseResponse cancelOrder(String requestId, String accountId, String orderIds, String cusId, String via, String remoteHost, String validationType, String device, String deviceType);

    BaseResponse getHistoryOrderMatch(String accountId, String fromDate, String toDate, String symbol, String execType, Integer offset, Integer limit);

    BaseResponse cancelOrderByID(String requestId, String accountId, String orderId, String cusId, String via, String remoteHost, String validationType, String device, String deviceType);

    BaseResponse cancelOrder(BaseRequest<CancelOrderRequest> cancelOrderRequestBaseRequest,String ipAddress);

    BaseResponse updateOrder(BaseRequest<OrderUpdateReq> orderUpdateReq);

    void postOrderKafka(BaseRequest<PostOrdersRequests> postOrderRequest);

    void cancelOrderKafka(BaseRequest<CancelOrderRequest> cancelOrderRequest);

    BaseResponse saveOder(BaseRequest<PostOrdersRequests> postOrdersDTO,String ipAddress);

    BaseResponse getHistoryOrderMatchByListSubAccounts(List<String> accountIds, String fromDate, String toDate, String symbol, String execType);

    void postOrderConditionKafka(BaseRequest<PostOrdersRequests> postOrderRequest);

    void cancelOrderConditionKafka(BaseRequest<CancelOrderRequest> cancelOrderRequest);
    BaseResponse getHistoryOrder(String accountId, String fromDate, String toDate, String symbol, String execType, String orsStatus, Integer offset, Integer limit);
    BaseResponse orderBooks(StockOrderFilter stockOrderFilter);

}
