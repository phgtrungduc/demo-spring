package vn.com.vpbanks.flex.usecase.service.business.inquiry.service;

import org.springframework.data.domain.Pageable;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;

import javax.validation.constraints.Min;
import java.util.List;

public interface FlexInquiryOrderService {

    /**
     * @param accountId   accountNo
     * @param orderId     order Id : ma lenh
     * @param orderType   loai lenh
     * @param symbol      ma chung khoan
     * @param orderStatus Trang thai lenh
     * @return Danh sach so lenh trong ngay.
     */

    BaseResponse getDetailOrder(String accountId, String orderId, String orderType, String symbol, String orderStatus);

    BaseResponse getOrder(String accountId, String orderId, String orderType, String symbol, String orderStatus, Long offset, Long limit);

    BaseResponse getGetRightOffList(String accountId);

    BaseResponse getAvailableTrade(String accountId, String symbol, String quotePrice);


    BaseResponse getUnderBroker(String custodycd, String searchkey, String dept, String underCustodycd, String getCurren);

    BaseResponse getDepartment(String custId, String code, String name);

    BaseResponse getCurrentDepartment(List<String> listReCustodycd, String reFullName, Integer page, Integer size);

}
