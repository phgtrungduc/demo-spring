package vn.com.vpbanks.flex.usecase.service.business.cf.response;

import lombok.Data;

@Data
public class OpenCSAccountResponse {
}
