package vn.com.vpbanks.flex.usecase.service.business.order.repository.vo;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.io.Serializable;

@Data
@Entity
public class CodeDVO implements Serializable {

    @Column(name = "CDTYPE")
    private String cdType;

    @Column(name = "CDNAME")
    private String cdName;

    @Id
    @Column(name = "CDVAL")
    private String cdVal;

    @Column(name = "EN_CDCONTENT")
    private String cdContent;

//    @Column(name = "")
//    private Integer lstOdr;
//
//    @Column(name = "")
//    private String cdUser;
//
//    @Column(name = "")
//    private String enCdContent;

    @Column(name = "CHSTATUS")
    private String chStatus;
}
