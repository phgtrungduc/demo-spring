package vn.com.vpbanks.flex.usecase.service.business.inquiry.request;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
public class AvailableBalanceRequest {
    private String accountId;
}
