package vn.com.vpbanks.flex.usecase.service.business.aq.repository;

import vn.com.vpbanks.flex.usecase.service.business.aq.repository.vo.*;

import java.util.List;
import java.util.Optional;

public interface NotificationAQRepository {
    List<CwetfExpriedDVO> getListCwetfExpried();

    List<CustRightToBuyDVO> getListCustRightToBuy();

    List<Mr0002DVO> getListMr0002();

    List<Mr0003DVO> getListMr0003();

    List<LnsDueDateDVO> getListLnsDueDate();

    List<ConfirmOrderDVO> getListConfirmOrder(String afAcctNo);

    public Optional<CustomerInfoDVO> getCustomerInfoFromCusToDyCd(String cusToDyCd);

    public List<SubAccountInfoDVO> getListSubAccountNo(String custId, String accountId);

    void generateTemplate(String messageType, String keyValue);
}
