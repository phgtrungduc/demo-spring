package vn.com.vpbanks.flex.usecase.service.business.inquiry.service;

import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;

import java.sql.SQLException;

public interface AFTypeService {
    BaseResponse getAFType(String afType);
}
