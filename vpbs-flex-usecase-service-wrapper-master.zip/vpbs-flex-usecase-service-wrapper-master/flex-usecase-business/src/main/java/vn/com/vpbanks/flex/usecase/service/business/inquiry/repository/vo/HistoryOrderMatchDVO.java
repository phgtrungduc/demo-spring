package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class HistoryOrderMatchDVO {

    @Id
    @Column(name = "ORDERID")
    private String orderId;

    @Column(name = "TXDATE")
    private String txDate;

    @Column(name = "SYMBOL")
    private String symbol;

    @Column(name = "EXECTYPE")
    private String execType;

    @Column(name = "SIDE")
    private String side;

    @Column(name = "PRICETYPE")
    private String priceType;

    @Column(name = "MATCHTYPE_VALUE")
    private String matchTypeValue;

    @Column(name = "MATCHQTTY")
    private BigDecimal matchQtty;

    @Column(name = "MATCHPRICE")
    private BigDecimal matchPrice;

    @Column(name = "MATCHAMT")
    private BigDecimal matchAmt;

    @Column(name = "FEEAMT")
    private BigDecimal feeAmt;

    @Column(name = "VAT")
    private BigDecimal vat;

    @Column(name = "VIA")
    private String via;

    @Column(name = "SELLTAXAMT")
    private BigDecimal sellTaxAmt;

    @Column(name = "MAKERNAME")
    private String makerName;

    @Column(name = "AFACCTNO")
    private String afAcctNo;

    @Column(name = "CUSTODYCD")
    private String custoDyCd;

    @Column(name = "FULLNAME")
    private String fullName;

    @Column(name = "FROMDATE")
    private String fromDate;

    @Column(name = "TODATE")
    private String toDate;

    @Column(name = "MATCHTYPE_CODE")
    private String matchTypeCode;

    @Column(name = "VIA_CODE")
    private String viaCode;

    @Column(name = "FEERATE")
    private BigDecimal feeRate;

    @Column(name = "R")
    private BigDecimal r;

    @Column(name = "L_COUNT")
    private BigDecimal lCount;
}
