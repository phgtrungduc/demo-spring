package vn.com.vpbanks.flex.usecase.service.business.mapper;

import org.mapstruct.Mapper;
import vn.com.vpbanks.flex.usecase.service.business.cash.repository.vo.CashStatementHistVO;
import vn.com.vpbanks.flex.usecase.service.business.cash.response.CashStatementHistResponse;

@Mapper(componentModel = "spring")
public interface CashMapper extends BaseMapper<CashStatementHistVO, CashStatementHistResponse>{

}
