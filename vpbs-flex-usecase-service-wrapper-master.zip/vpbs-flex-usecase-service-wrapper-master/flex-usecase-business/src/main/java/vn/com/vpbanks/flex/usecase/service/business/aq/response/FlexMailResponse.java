package vn.com.vpbanks.flex.usecase.service.business.aq.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FlexMailResponse {
    private String autoId;
    private String email;
    private String templateId;
    private String eventType;
    private String query;
}
