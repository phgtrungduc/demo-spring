package vn.com.vpbanks.flex.usecase.service.business.order.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Data
public class CancelOrderResponse implements Serializable {

    List<SuccessOrder> successList = new ArrayList<>();

    List<ErrorOrder> errorLists = new ArrayList<>();

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class SuccessOrder {
        String orderId;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
   public static class ErrorOrder {
        String orderId;
        String errCd;
        String errMsg;
    }
}
