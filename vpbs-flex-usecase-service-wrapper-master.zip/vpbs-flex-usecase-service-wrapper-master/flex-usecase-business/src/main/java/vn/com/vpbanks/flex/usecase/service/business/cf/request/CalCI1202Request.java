package vn.com.vpbanks.flex.usecase.service.business.cf.request;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import java.math.BigDecimal;

@Data
public class CalCI1202Request {

    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String acctNo;

    @Positive(message = "{validation.positive_number}")
    @NotNull(message = "{validation.not_null}")
    private BigDecimal amount;

    private String desc;
}
