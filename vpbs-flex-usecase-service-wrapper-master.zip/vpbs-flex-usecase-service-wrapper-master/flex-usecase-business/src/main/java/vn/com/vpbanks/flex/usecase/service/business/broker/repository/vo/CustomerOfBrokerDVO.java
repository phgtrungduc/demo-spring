package vn.com.vpbanks.flex.usecase.service.business.broker.repository.vo;

import lombok.Data;

@Data
public class CustomerOfBrokerDVO {
    private String cusToDyCd;

    public CustomerOfBrokerDVO(String customer) {
        this.cusToDyCd = customer;
    }
}
