package vn.com.vpbanks.flex.usecase.service.business.order.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StockOrderFilter {
    private String sortType;
    private StockOrderStatus status;
    private List<String> customerAccountNumbers;
    private List<String> stockSymbols;
    private String symbol;
    private List<SubAccount> subAccounts;
    private List<Order> orderSides;
    private List<OrderCode> orderCodes;
    private List<Timeline> timelines;
    private String startDate;
    private String endDate;
    private String toDate;
    private List<ChannelFlex> channels;
    private String customerAccountNumber;
    private ConfirmStatus confirmStatus;
    private List<String> flexStatus;
    private Day day;
    private Integer page;
    private Integer size;

}
