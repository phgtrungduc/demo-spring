package vn.com.vpbanks.flex.usecase.service.business.aq.request;

import lombok.Data;

@Data
public class ChangePasswordNotificationFromQueue {
    private String EVENTTYPE;
    private String USERLOGIN;
    private String CUSTID;
    private String CUSTODYCD;
}
