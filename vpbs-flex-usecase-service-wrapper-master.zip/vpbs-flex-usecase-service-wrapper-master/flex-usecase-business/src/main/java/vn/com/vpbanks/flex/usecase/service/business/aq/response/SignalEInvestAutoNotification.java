package vn.com.vpbanks.flex.usecase.service.business.aq.response;

import lombok.Data;
import vn.com.vpbanks.flex.usecase.service.business.aq.request.SignalEInvestAutoFromQueue;

@Data
public class SignalEInvestAutoNotification {

    private String eventType;

    private String custId;

    private String custoDyCd;

    private String fullName;

    private String ciMode;

    public SignalEInvestAutoNotification(SignalEInvestAutoFromQueue signalEInvest) {
        this.eventType = signalEInvest.getEVENTTYPE();
        this.custId = signalEInvest.getCUSTID();
        this.custoDyCd = signalEInvest.getCUSTODYCD();
        this.fullName = signalEInvest.getFULLNAME();
        this.ciMode = signalEInvest.getCIMODE();
    }
}
