package vn.com.vpbanks.flex.usecase.service.business.customer.service;

import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;

public interface CustomerService {
    BaseResponse getBeneficiaryAccount(String custId);
}
