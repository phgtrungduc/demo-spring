package vn.com.vpbanks.flex.usecase.service.business.mapper;

import org.mapstruct.Mapper;
import vn.com.vpbanks.flex.usecase.service.business.cash.repository.vo.BankNoStroDVO;
import vn.com.vpbanks.flex.usecase.service.business.cash.response.BankNoStrResponse;

@Mapper(componentModel = "spring")
public interface BankNoStroMapper extends BaseMapper<BankNoStroDVO, BankNoStrResponse> {
}
