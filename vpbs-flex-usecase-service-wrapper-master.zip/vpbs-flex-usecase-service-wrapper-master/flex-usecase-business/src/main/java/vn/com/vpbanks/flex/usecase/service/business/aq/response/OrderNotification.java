package vn.com.vpbanks.flex.usecase.service.business.aq.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import vn.com.vpbanks.flex.usecase.service.business.aq.request.OrderNotificationFromQueue;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderNotification implements Serializable {
    private String execType;

    private String afAcctNo;

    private String price;

    private BigDecimal quotePrice;

    private String orStatus;

    private String autoId;

    private BigDecimal cancelQtty;

    private String orderId;

    private String timeTypeValue;

    private String via;

    private String custoDyCd;

    private String priceType;

    private String eventType;

    private BigDecimal execQtty;

    private String feedbackMsg;

    private String symbol;

    private BigDecimal adjustQtty;

    private String applyTime;

    private BigDecimal orderQtty;

    private String orStatusValue;

    private BigDecimal remainQtty;

    private Timestamp logTime;

    private BigDecimal execPrice;

    private String requestId;

    private String foVia;

    public OrderNotification(OrderNotificationFromQueue queue) {
        this.eventType = queue.getEVENTTYPE();
        this.autoId = queue.getAUTOID();
        this.orderId = queue.getACCTNO();
        this.custoDyCd = queue.getCUSTODYCD();
        this.afAcctNo = queue.getAFACCTNO();
        this.logTime = queue.getLOGTIME();
        this.applyTime = queue.getAPPLYTIME();
        this.symbol = queue.getSYMBOL();
        this.quotePrice = queue.getQUOTEPRICE();
        this.execType = queue.getEXECTYPE();
        this.execQtty = queue.getEXECQTTY();
        this.orStatusValue = queue.getORSTATUSVALUE();
        this.orStatus = queue.getORSTATUS();
        this.remainQtty = queue.getREMAINQTTY();
        this.priceType = queue.getPRICETYPE();
        this.price = queue.getPRICE();
        this.cancelQtty = queue.getCANCELQTTY();
        this.adjustQtty = queue.getADJUSTQTTY();
        this.via = queue.getVIA();
        this.feedbackMsg = queue.getFEEDBACKMSG();
        this.orderQtty = queue.getORDERQTTY();
        this.timeTypeValue = queue.getTIMETYPEVALUE();
        this.execPrice = queue.getEXECPRICE();
        this.requestId = queue.getREQUESTID();
        this.foVia = queue.getFOVIA();
    }
}
