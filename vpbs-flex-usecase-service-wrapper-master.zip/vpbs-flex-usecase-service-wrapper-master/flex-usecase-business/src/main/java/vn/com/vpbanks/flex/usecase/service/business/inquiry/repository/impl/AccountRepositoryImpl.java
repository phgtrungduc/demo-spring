package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.AccountRepository;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.SubAccountAvailableBalanceDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.SummaryAccountVO;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

@Component
@RequiredArgsConstructor
@Slf4j
public class AccountRepositoryImpl implements AccountRepository {

    private final EntityManager entityManager;

    @Value("${vpbanks.flex.sp.SP_SUB_ACCOUNT_AVAILABLE_BALANCE}")
    private String SP_SUB_ACCOUNT_AVAILABLE_BALANCE;

    @Value("${vpbanks.flex.sp.SP_GET_SUMMARY_ACCOUNT}")
    private String SP_GET_SUMMARY_ACCOUNT;


    @Override
    public SubAccountAvailableBalanceDVO getSubAccountAvailableBalance(String accountId) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_SUB_ACCOUNT_AVAILABLE_BALANCE, SubAccountAvailableBalanceDVO.class);

        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_accountId", String.class, ParameterMode.IN);

        query.setParameter("p_accountId", accountId);

        SubAccountAvailableBalanceDVO subAccountAvailableBalanceDVO;
        try {
            subAccountAvailableBalanceDVO = (SubAccountAvailableBalanceDVO) query.getSingleResult();
        } catch (NoResultException ex) {
            subAccountAvailableBalanceDVO = null;
            log.error("[Error] getSubAccountAvailableBalance function NoResultException " + ex.getMessage());
        }
        return subAccountAvailableBalanceDVO;
    }

    @Override
    public SummaryAccountVO getSummaryAccount(String accountId) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_SUMMARY_ACCOUNT);
        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_accountId", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.OUT);

        query.setParameter("p_accountId", accountId);

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        if("1".equals(errCode)){
            return null;
        }

        SummaryAccountVO summaryAccountVO;
        try {
            summaryAccountVO = new SummaryAccountVO((Object[]) query.getSingleResult());
            summaryAccountVO.setAccountNumber(accountId);
            log.info("getSummaryAccount: {}", summaryAccountVO);
        } catch (NoResultException ex) {
            summaryAccountVO = null;
            log.error("[Error] getSummaryAccount function NoResultException " + ex.getMessage());
        }
        return summaryAccountVO;
    }
}
