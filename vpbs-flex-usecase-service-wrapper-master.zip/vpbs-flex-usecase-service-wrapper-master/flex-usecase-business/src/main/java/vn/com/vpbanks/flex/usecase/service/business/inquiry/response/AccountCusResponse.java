package vn.com.vpbanks.flex.usecase.service.business.inquiry.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class AccountCusResponse {
    @Id
    @JsonProperty("cusId")
    @Column(name = "CUSTID")
    private String cusId;

    @JsonProperty("fullName")
    @Column(name = "FULLNAME")
    private String fullName;

    @JsonProperty("address")
    @Column(name = "ADDRESS")
    private String address;

    @JsonProperty("idCode")
    @Column(name = "IDCODE")
    private String idCode;

    @JsonProperty("idPlace")
    @Column(name = "IDPLACE")
    private String idPlace;

    @JsonProperty("email")
    @Column(name = "EMAIL")
    private String email;

    @JsonProperty("mobileSms")
    @Column(name = "MOBILESMS")
    private String mobileSms;

    @JsonProperty("status")
    @Column(name = "STATUS")
    private String status;

    @JsonProperty("dateOfBirth")
    @Column(name = "DATEOFBIRTH")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy", timezone = "Asia/Bangkok")
    private Date dateOfBirth;

    @JsonProperty("idType")
    @Column(name = "IDTYPE")
    private String idType;

    @JsonProperty("idDate")
    @Column(name = "IDDATE")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy", timezone = "Asia/Bangkok")
    private Date idDate;

    @JsonProperty("idExpired")
    @Column(name = "IDEXPIRED")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy", timezone = "Asia/Bangkok")
    private Date idExpired;

    @JsonProperty("country")
    @Column(name = "COUNTRY")
    private String country;

    @JsonProperty("sex")
    @Column(name = "SEX")
    private String sex;

    @JsonProperty("brid")
    @Column(name = "BRID")
    private String brid;

    @JsonProperty("careBy")
    @Column(name = "CAREBY")
    private String careBy;
}
