package vn.com.vpbanks.flex.usecase.service.business.broker.repository;

import vn.com.vpbanks.flex.usecase.service.business.broker.repository.vo.HolderInfoDVO;

import java.util.List;

public interface HolderRepository {
    List<HolderInfoDVO> getHolder(String custodyCd, String symbol);
}

