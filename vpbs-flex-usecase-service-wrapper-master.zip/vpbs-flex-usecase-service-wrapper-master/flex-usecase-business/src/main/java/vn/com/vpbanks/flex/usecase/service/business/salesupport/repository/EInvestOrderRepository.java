package vn.com.vpbanks.flex.usecase.service.business.salesupport.repository;

import vn.com.vpbanks.flex.usecase.service.common.dto.Flex.GetEInvestOrderDto;

import java.util.List;

public interface EInvestOrderRepository {
    GetEInvestOrderDto getEInvestOrder(List<String> afacctno, List<String> txnum, List<String> status, Integer page, Integer size);
}
