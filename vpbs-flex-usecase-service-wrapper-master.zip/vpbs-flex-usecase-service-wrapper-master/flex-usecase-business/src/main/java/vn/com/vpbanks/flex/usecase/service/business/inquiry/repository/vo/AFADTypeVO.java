package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AFADTypeVO {

    @Id
    @Column(name = "AFTYPE")
    private String afType;
    @Column(name = "AFTYPENAME")
    private String afTypeName;
    @Column(name = "AFSTATUS_VALUE")
    private String afStatusValue;
    @Column(name = "AFSTATUS")
    private String afStatus;
    @Column(name = "STATUS_VALUE")
    private String statusValue;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "APPRV_STS_VALUE")
    private String apprvStsValue;
    @Column(name = "APPRV_STS")
    private String apprvSts;
    @Column(name = "CITYPE")
    private String ciType;
    @Column(name = "SETYPE")
    private String seType;
    @Column(name = "MRTYPE")
    private String mrType;
    @Column(name = "LNTYPE")
    private String lnType;
    @Column(name = "ADTYPE")
    private String adType;
    @Column(name = "ADTYPENAME")
    private String adTypeName;
    @Column(name = "ADSTATUS_VALUE")
    private String adStatusValue;
    @Column(name = "ADSTATUS")
    private String adStatus;
    @Column(name = "ADVRATE")
    private BigDecimal advRate;
    @Column(name = "ADVMINFEE")
    private BigDecimal advMinFee;
    @Column(name = "NUMSDAY_VALUE")
    private String numsDayValue;
    @Column(name = "NUMSDAY")
    private String numsDay;
    private List<ODTypeVO> odTypes;

}
