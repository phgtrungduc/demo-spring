package vn.com.vpbanks.flex.usecase.service.business.broker.repository.vo;

import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HolderInfoDVO {
    private String custodyCd;
    private String symbol;
    private String isShareHolder;
    private String registerType;
    private String registerDate;
    private String registerTypeDescription;
}
