package vn.com.vpbanks.flex.usecase.service.business.inquiry.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class HistoryOrderMatchResponse implements Serializable {
    @JsonProperty("orderId")
    private String orderId;

    @JsonProperty("txDate")
    private String txDate;

    @JsonProperty("symbol")
    private String symbol;

    @JsonProperty("execType")
    private String execType;

    @JsonProperty("side")
    private String side;

    @JsonProperty("priceType")
    private String priceType;

    @JsonProperty("matchTypeValue")
    private String matchTypeValue;

    @JsonProperty("matchQtty")
    private BigDecimal matchQtty;

    @JsonProperty("matchPrice")
    private BigDecimal matchPrice;

    @JsonProperty("matchAmt")
    private BigDecimal matchAmt;

    @JsonProperty("feeAmt")
    private BigDecimal feeAmt;

    @JsonProperty("vat")
    private BigDecimal vat;

    @JsonProperty("via")
    private String via;

    @JsonProperty("sellTaxAmt")
    private BigDecimal sellTaxAmt;

    @JsonProperty("makerName")
    private String makerName;

    @JsonProperty("afAcctNo")
    private String afAcctNo;

    @JsonProperty("custoDyCd")
    private String custoDyCd;

    @JsonProperty("fullName")
    private String fullName;

    @JsonProperty("fromDate")
    private String fromDate;

    @JsonProperty("toDate")
    private String toDate;

    @JsonProperty("matchTypeCode")
    private String matchTypeCode;

    @JsonProperty("viaCode")
    private String viaCode;

    @JsonProperty("feeRate")
    private BigDecimal feeRate;

    @JsonProperty("r")
    private BigDecimal r;

    @JsonProperty("lcount")
    private BigDecimal lCount;
}
