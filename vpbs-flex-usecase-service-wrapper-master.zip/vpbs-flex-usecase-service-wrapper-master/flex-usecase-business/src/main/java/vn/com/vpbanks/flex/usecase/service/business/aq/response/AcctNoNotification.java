package vn.com.vpbanks.flex.usecase.service.business.aq.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import vn.com.vpbanks.flex.usecase.service.business.aq.request.AcctNoNotificationFromQueue;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AcctNoNotification {
    private String eventType;
    private String custId;
    private String acctNo;
    private String status;

    private String custoDyCd;

    public AcctNoNotification(AcctNoNotificationFromQueue queue) {
        this.eventType = queue.getEVENTTYPE();
        this.custId = queue.getCUSTID();
        this.acctNo = queue.getACCTNO();
        this.status = queue.getSTATUS();
        this.custoDyCd = queue.getCUSTODYCD();
    }
}
