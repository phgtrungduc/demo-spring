package vn.com.vpbanks.flex.usecase.service.business.broker.repository.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class BrokerGroupDVO implements Serializable {
    private BigDecimal brokerGroupId;
    private String brokerGroupName;
    private BigDecimal brokerGroupMasterId;
    private String brokerGroupMasterName;

    public BrokerGroupDVO(Object[] object) {
        this.brokerGroupId = (BigDecimal) object[0];
        this.brokerGroupName = (String) object[1];
        this.brokerGroupMasterId = (BigDecimal) object[2];
        this.brokerGroupMasterName = (String) object[3];

    }
}
