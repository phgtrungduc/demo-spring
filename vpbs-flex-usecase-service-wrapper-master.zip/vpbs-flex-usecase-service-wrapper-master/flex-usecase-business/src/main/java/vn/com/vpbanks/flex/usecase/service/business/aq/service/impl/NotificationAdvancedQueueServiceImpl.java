package vn.com.vpbanks.flex.usecase.service.business.aq.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import vn.com.vpbanks.flex.usecase.service.business.aq.repository.NotificationAQRepository;
import vn.com.vpbanks.flex.usecase.service.business.aq.repository.vo.*;
import vn.com.vpbanks.flex.usecase.service.business.aq.response.FlexMailResponse;
import vn.com.vpbanks.flex.usecase.service.business.aq.response.FlexSMSResponse;
import vn.com.vpbanks.flex.usecase.service.business.aq.service.NotificationAdvancedQueueService;
import vn.com.vpbanks.flex.usecase.service.common.constants.KafkaTopicConstants;

import java.util.List;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class NotificationAdvancedQueueServiceImpl implements NotificationAdvancedQueueService {

    @Value("${vpbanks.kafka.properties.topics.flex.notifyQueue}")
    private String notifyQueueTopic;
    private final KafkaTemplate kafkaTemplate;

    @Qualifier("objectTemplate")
    private final KafkaTemplate kafkaObjectTemplate;

    @Value("${vpbanks.kafka.properties.topics.flex.signalEODTopic}")
    private String signalEODTopic;

    private final NotificationAQRepository notificationAQRepository;
    private final ObjectMapper objectMapperForSendNotification;

    private final String REF_ID_CLOSE = "CLOSE";
    private final String REF_ID_OPEN = "OPEN";
    private final String EVENT_TYPE_MSG = "MSG";
    private final String EVENT_TYPE_SYS = "SYS";
    private final String EVENT_TYPE_CFMOD = "CFMOD";
    private static final String EVENT_TYPE_GENERATE_SMS_EMAIL = "NOTIFY";
    private static final String EVENT_TYPE_SEND_SMS_EMAIL = "SME";

    private static final List<String> excludeTemplates = List.of("T336A", "T336B", "T336C", "T336D", "T336E", "T336F");


    @Override
    public void handleNotificationQueue(Map<String, String> message) {
        String eventType = message.get("EVENTTYPE");
        log.debug("eventType : {}, message : {} ", eventType, message);
        switch (eventType) {
            case EVENT_TYPE_MSG: {
                this.writeJsonAndSendToKafka(message);
                break;
            }
            case EVENT_TYPE_SYS: {
                // send signal EOD to kafka.
                try {
                    String jsonMessage = objectMapperForSendNotification.writeValueAsString(message);
                    kafkaTemplate.send(signalEODTopic, jsonMessage);
                } catch (JsonProcessingException e) {
                    log.error("JsonProcessingException message : {}", e.getMessage());
                }

                String refId = message.get("REFID");
                if (REF_ID_OPEN.equals(refId)) {
                    this.sendNotificationQueue();
                }
                break;
            }
            case EVENT_TYPE_CFMOD: {
                String afAcctNo = message.get("AFACCTNO");
                this.sendConfirmOrderNotification(afAcctNo);
                break;
            }
            case EVENT_TYPE_GENERATE_SMS_EMAIL: {
                String messageType = message.get("MSGTYPE");
                String keyValue = message.get("KEYVALUE");
                log.info("EVENT_TYPE_SMS : {} , messageType : {} , keyValue : {} ", eventType, messageType, keyValue);
                this.generateTemplate(messageType, keyValue);
                break;
            }
            case EVENT_TYPE_SEND_SMS_EMAIL: {
                this.sendToSmsMailService(message);
                break;
            }
            default: {
                log.info("Event Type unknown : {}", eventType);
            }
        }
    }

    private void sendToSmsMailService(Map<String, String> message) {
        String eventType = message.get("EVENTTYPE");
        String autoId = message.get("AUTOID");
        String templateId = message.get("TEMPLATEID");
        String query = message.get("DATASOURCE");

        if (excludeTemplates.contains(templateId)) {
            log.info("Don't handle templateId : {} ", templateId);
            return;
        }

        if (smsTemplateCodes.contains(templateId)) {
            String phoneNumber = message.get("EMAIL");
            FlexSMSResponse flexSmsResponse = FlexSMSResponse.builder()
                    .autoId(autoId)
                    .phoneNumber(phoneNumber)
                    .eventType(eventType)
                    .templateId(templateId)
                    .query(query).build();
            log.info("flexSmsResponse : {} ", flexSmsResponse);
            kafkaObjectTemplate.send(KafkaTopicConstants.FLEX_SMS_TOPIC, flexSmsResponse);

        } else if (emailTemplateCodes.contains(templateId)) {
            String email = message.get("EMAIL");
            FlexMailResponse flexMailResponse = FlexMailResponse.builder()
                    .eventType(eventType)
                    .email(email)
                    .query(query)
                    .autoId(autoId)
                    .templateId(templateId).build();
            log.info("flexMailResponse : {} ", flexMailResponse);
            kafkaObjectTemplate.send(KafkaTopicConstants.FLEX_EMAIL_TOPIC, flexMailResponse);
        } else {
            log.info("Template ID {} doesn't include in sms/mail list . Please check .... ", templateId);
        }

    }

    private void generateTemplate(String messageType, String keyValue) {
        notificationAQRepository.generateTemplate(messageType, keyValue);
    }

    private void sendConfirmOrderNotification(String afAcctNo) {
        List<ConfirmOrderDVO> confirmOrderDVOS = notificationAQRepository.getListConfirmOrder(afAcctNo);
        if (!ObjectUtils.isEmpty(confirmOrderDVOS)) {
            confirmOrderDVOS.forEach(confirmOrderItem -> {
                this.writeJsonAndSendToKafka(confirmOrderItem);
            });
        }
    }

    public void sendNotificationQueue() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setPropertyNamingStrategy(PropertyNamingStrategies.UPPER_SNAKE_CASE);

        // Mã ETF/CW sắp đến ngày đáo hạn
        List<CwetfExpriedDVO> cwetfExpriedDVOS = notificationAQRepository.getListCwetfExpried();
        if (!ObjectUtils.isEmpty(cwetfExpriedDVOS)) {
            cwetfExpriedDVOS.forEach(item -> {
                this.writeJsonAndSendToKafka(item);
            });
        }

        // Danh sách quyền mua sắp đến ngày mua
        List<CustRightToBuyDVO> custRightToBuyDVOS = notificationAQRepository.getListCustRightToBuy();
        if (!ObjectUtils.isEmpty(custRightToBuyDVOS)) {
            custRightToBuyDVOS.forEach(item -> {
                this.writeJsonAndSendToKafka(item);
            });
        }

        // Danh sách tài khoản bị thông báo bổ sung tài sản đảm bảo
        List<Mr0002DVO> mr0002DVOS = notificationAQRepository.getListMr0002();
        if (!ObjectUtils.isEmpty(mr0002DVOS)) {
            mr0002DVOS.forEach(item -> {
                this.writeJsonAndSendToKafka(item);
            });
        }

        // Danh sách tài khoản bị xử lý bán tài sản đảm bảo.
        List<Mr0003DVO> mr0003DVOS = notificationAQRepository.getListMr0003();
        if (!ObjectUtils.isEmpty(mr0003DVOS)) {
            mr0003DVOS.forEach(item -> {
                this.writeJsonAndSendToKafka(item);
            });
        }

        // Thông báo món vay sắp đến hạn
        List<LnsDueDateDVO> lnsDueDateDVOS = notificationAQRepository.getListLnsDueDate();
        if (!ObjectUtils.isEmpty(lnsDueDateDVOS)) {
            lnsDueDateDVOS.forEach(item -> {
                this.writeJsonAndSendToKafka(item);
            });
        }
    }


    private void writeJsonAndSendToKafka(Object object) {
        try {
            String jsonResponse = objectMapperForSendNotification.writeValueAsString(object);
            log.debug(jsonResponse);
            kafkaTemplate.send(notifyQueueTopic, jsonResponse);
        } catch (JsonProcessingException e) {
            log.error("There is an error during json processing , message : {}", e.getMessage());
            throw new RuntimeException(e);
        }
    }

    private static final List<String> smsTemplateCodes = List.of("T002S"
            , "T003S"
            , "T004S"
            , "T005S"
            , "T0218"
            , "T0220"
            , "T0308"
            , "T0317"
            , "T0321"
            , "T0323"
            , "T0326"
            , "T0328"
            , "T0330"
            , "T0340"
            , "T0341"
            , "T0381"
            , "T0555"
            , "T0666"
            , "T220S"
            , "T304A"
            , "T304B"
            , "T304C"
            , "T304D"
            , "T304S"
            , "T306A"
            , "T306B"
            , "T307S"
            , "T311S"
            , "T324A"
            , "T324B"
            , "T325E"
            , "T327A"
            , "T327B"
            , "T327C"
            , "T327F"
            , "T328S"
            , "T337A"
            , "T337B"
            , "T402A"
            , "T402B"
            , "T403S"
            , "T404S"
            , "T405S"
            , "T406S"
            , "T407S"
            , "T503S"
            , "T0305"
            , "T504S");

    private static final List<String> emailTemplateCodes = List.of("T0002"
            , "T0003"
            , "T0004"
            , "T0005"
            , "T0217"
            , "T0219"
            , "T0223"
            , "T0224"
            , "T0380"
            , "T0382"
            , "T211A"
            , "T213B"
            , "T213C"
            , "T213E"
            , "T216C"
            , "T219B"
            , "T220E"
            , "T224B"
            , "T306C"
            , "T311E"
            , "T321A"
            , "T326A"
            , "T327D"
            , "T327E"
            , "T381A"
            , "T381B"
            , "T384A"
            , "T384B"
            , "T402C"
            , "T402D"
            , "T403E"
            , "T404E"
            , "T405E"
            , "T406E"
            , "T407E"
            , "T501E"
            , "T502E"
            , "T503E"
            , "T0214"
            , "T0215"
            , "T505E"
            , "T028E"
            , "T029E"
            , "T030E"
            , "T031E"
            , "T032E"
            , "T507E"
            , "T504E"
            , "T508E"
            , "T507F"
            , "T509E");
}
