package vn.com.vpbanks.flex.usecase.service.business.order.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CancelOrderRequest implements Serializable {

    @JsonProperty("requestId")
    private String requestId;

    @JsonProperty("accountId")
    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String accountId;

    @JsonProperty("orderId")
    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String orderId;

    @JsonProperty("cusId")
    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String cusId;

    @JsonProperty("via")
    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String via;

    @JsonProperty("ipAddress")
    private String ipAddress;

    @JsonProperty("validationType")
    private String validationType;

    @JsonProperty("device")
    private String device;

    @JsonProperty("deviceType")
    private String deviceType;
}
