package vn.com.vpbanks.flex.usecase.service.business.salesupport.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class CustomerOfBrokerRequest {
    @JsonProperty("reCustodyCds")
    private List<String> reCustodyCds;

    @JsonProperty("custodyCds")
    private List<String> custodyCds;

    @JsonProperty("depts")
    private List<String> depts;

    @JsonProperty("page")
    private Integer page;

    @JsonProperty("size")
    private Integer size;

    @JsonProperty("filterCustomerType")
    private String filterCustomerType;
}
