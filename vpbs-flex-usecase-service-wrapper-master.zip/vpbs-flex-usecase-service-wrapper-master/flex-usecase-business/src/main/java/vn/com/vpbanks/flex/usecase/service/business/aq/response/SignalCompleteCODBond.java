package vn.com.vpbanks.flex.usecase.service.business.aq.response;

import lombok.Data;
import vn.com.vpbanks.flex.usecase.service.business.aq.request.SignalCompleteCODBondFromQueue;

import java.math.BigDecimal;

@Data
public class SignalCompleteCODBond {
    private String eventType;
    private String transactionId;
    private BigDecimal amount;
    private String transactionDate;
    private String custoDyCd;
    private String remark;
    private String accountNo;

    public SignalCompleteCODBond(SignalCompleteCODBondFromQueue message) {
        this.eventType = message.getEVENTTYPE();
        this.transactionId = message.getTRANSACTIONID();
        this.amount = message.getAMOUNT();
        this.transactionDate = message.getTRANSACTIONDATE();
        this.custoDyCd = message.getCUSTODYCD();
        this.remark = message.getREMARK();
        this.accountNo = message.getACCOUNTNO();
    }
}
