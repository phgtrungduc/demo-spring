package vn.com.vpbanks.flex.usecase.service.business.order.request;

import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public enum OrderCode {
    LO("LO", "LIMIT"),
    MP("MP", "MARKET"),
    ATO("ATO", "MARKET"),
    ATC("ATC", "MARKET"),
    A24_7("A24_7", "MARKET"),
    PLO("PLO", "MARKET"),
    MTL("MTL", "MARKET"),
    MOK("MOK", "MARKET"),
    MAK("MAK", "MARKET"),
    GTC("GTC", "MARKET");



    private final String orderCode;
    private final String type;

    public String getOrderCode(){return orderCode;}

    OrderCode(String orderCode, String type) {
        this.orderCode = orderCode;
        this.type = type;

    }

    public static String findType(String orderCode) {
        for (OrderCode s : values()) {
            if (s.orderCode.equals(orderCode)) {
                return s.type;
            }
        }
        return null;
    }

    public static List<String> toStrings(List<OrderCode> orderCodes) {
        List<String> output = new ArrayList<>();
        if (CollectionUtils.isEmpty(orderCodes)) {
            return output;
        }

        return orderCodes.stream()
                .filter(Objects::nonNull)
                .map(Enum::name)
                .collect(Collectors.toList());
    }
}
