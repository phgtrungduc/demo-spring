package vn.com.vpbanks.flex.usecase.service.business.aq.response;

import lombok.Data;
import vn.com.vpbanks.flex.usecase.service.business.aq.request.SignalOpenBondAccountIAMFromQueue;

@Data
public class SignalOpenBondAccountIAM {
    private String eventType;
    private String custId;
    private String custoDyCd;
    private String fullName;
    private String custType;
    private String idType;
    private String idCode;
    private String mobile;

    private String email;
    private String isBond;
    private String status;

    public SignalOpenBondAccountIAM(SignalOpenBondAccountIAMFromQueue message) {
        this.eventType = message.getEVENTTYPE();
        this.custId = message.getCUSTID();
        this.custoDyCd = message.getCUSTODYCD();
        this.fullName = message.getFULLNAME();
        this.custType = message.getCUSTTYPE();
        this.idType = message.getIDTYPE();
        this.idCode = message.getIDCODE();
        this.mobile = message.getMOBILE();
        this.email = message.getEMAIL();
        this.isBond = message.getISBOND();
        this.status = message.getSTATUS();
    }
}
