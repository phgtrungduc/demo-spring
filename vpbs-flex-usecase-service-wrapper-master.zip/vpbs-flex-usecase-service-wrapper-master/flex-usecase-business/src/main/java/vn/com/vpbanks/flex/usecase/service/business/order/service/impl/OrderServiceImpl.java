package vn.com.vpbanks.flex.usecase.service.business.order.service.impl;

import com.google.gson.Gson;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.InquiryOrderRepository;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.HistoryOrderDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo.HistoryOrderMatchDVO;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.HistoryOrderMatchResponse;
import vn.com.vpbanks.flex.usecase.service.business.mapper.HistoryOrderMapper;
import vn.com.vpbanks.flex.usecase.service.business.order.repository.OrderRepository;
import vn.com.vpbanks.flex.usecase.service.business.order.request.CancelOrderRequest;
import vn.com.vpbanks.flex.usecase.service.business.order.request.OrderUpdateReq;
import vn.com.vpbanks.flex.usecase.service.business.order.request.PostOrdersRequests;
import vn.com.vpbanks.flex.usecase.service.business.order.request.StockOrderFilter;
import vn.com.vpbanks.flex.usecase.service.business.order.response.*;
import vn.com.vpbanks.flex.usecase.service.business.order.service.OrderService;
import vn.com.vpbanks.flex.usecase.service.common.constants.KafkaTopicConstants;
import vn.com.vpbanks.flex.usecase.service.common.constants.ViaCode;
import vn.com.vpbanks.flex.usecase.service.common.dto.request.BaseRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.*;
import vn.com.vpbanks.flex.usecase.service.common.utils.BaseRest;
import vn.com.vpbanks.flex.usecase.service.common.utils.CommonUtils;
import vn.com.vpbanks.flex.usecase.service.common.utils.Constants;
import vn.com.vpbanks.flex.usecase.service.common.utils.MessageUtil;
import vn.com.vpbanks.flex.usecase.service.trackings.entities.Trackings;
import vn.com.vpbanks.flex.usecase.service.trackings.services.TrackingService;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private static final int DEFAULT_OFFSET_VALUE = 0;
    private static final int DEFAULT_LIMIT_VALUE = 1000000000;
    private final OrderRepository orderRepository;
    private final InquiryOrderRepository inquiryOrderRepository;
    private final String COMMA = ",";
    private final String SUCCESS = "0";
    private final TrackingService trackingService;
    private final KafkaTemplate<String, String> kafkaTemplate;

    private final HistoryOrderMapper historyOrderMapper;

    private final MessageUtil messageUtil;

    @Value("${vpbanks.kafka.properties.topics.flex.ordersResult}")
    private String orderResult;
    @Value("${vpbanks.kafka.properties.topics.flex.cancelOrdersResult}")
    private String cancelOrdersResult;

    @Value("${vpbanks.kafka.properties.topics.flex.postConditionOrderResult}")
    private String postConditionOrderResult;

    @Value("${vpbanks.kafka.properties.topics.flex.cancelConditionOrderResult}")
    private String cancelConditionOrderResult;


    @Override
    public BaseResponse cancelOrder(String requestId, String accountId, String orderIds, String cusId, String via, String ipAddress, String validationType, String device, String deviceType) {

        BaseResponse baseResponse;

        CancelOrderResponse cancelOrderResponse = new CancelOrderResponse();

        try {
            List<String> listOrderId = Arrays.asList(orderIds.split(COMMA));
            listOrderId.stream().forEach(orderId -> {
                StoredProcedureError storedResponse = orderRepository.cancelOrder(requestId, accountId, orderId, cusId, ipAddress, via, validationType, device, deviceType);
                if (SUCCESS.equals(storedResponse.getErrCd())) {
                    cancelOrderResponse.getSuccessList().add(new CancelOrderResponse.SuccessOrder(orderId));
                } else {
                    CancelOrderResponse.ErrorOrder errorOrder = new CancelOrderResponse.ErrorOrder();
                    errorOrder.setOrderId(orderId);
                    errorOrder.setErrCd(storedResponse.getErrCd());
                    errorOrder.setErrMsg(storedResponse.getErrParam());
                    cancelOrderResponse.getErrorLists().add(errorOrder);
                }
            });

            CancelOrderListResponse cancelOrderListResponse = new CancelOrderListResponse();
            cancelOrderListResponse.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_SUCCESS);
            cancelOrderListResponse.setCode(BaseRest.RESPONSE.OK_CODE);
            cancelOrderListResponse.setData(cancelOrderResponse);

            baseResponse = cancelOrderListResponse;

        } catch (Exception ex) {
            log.error("OrderService error : {} ", ex.getMessage());
            baseResponse = BaseResponse.ofFailedException(" OrderService cancelOrder : " + ex.getMessage());
        }

        return baseResponse;
    }

    @Override
    public BaseResponse getHistoryOrderMatch(String accountId, String fromDate, String toDate, String symbol, String execType, Integer offset, Integer limit) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        offset = offset == null ? DEFAULT_OFFSET_VALUE : offset;
        limit = limit == null ? DEFAULT_LIMIT_VALUE : limit;

        BaseStoredProcedureResponse storedProcedureResponse = inquiryOrderRepository.getHistoryOrderMatch(accountId, fromDate, toDate, symbol, execType, offset, limit);

        if (SUCCESS.equals(storedProcedureResponse.getErrCd())) {
            List<HistoryOrderMatchDVO> historyOrderMatchDVOS = (List<HistoryOrderMatchDVO>) storedProcedureResponse.getData();
            List<HistoryOrderMatchResponse> historyOrderMatchResponses = historyOrderMapper.fromListSourceToListTarget(historyOrderMatchDVOS);
            baseResponse.setData(historyOrderMatchResponses);
        } else {
            baseResponse.setData(Collections.emptyList());
        }
        return baseResponse;
    }

    @Override
    public BaseResponse getHistoryOrder(String accountId, String fromDate, String toDate, String symbol, String execType, String orsStatus, Integer offset, Integer limit) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        offset = offset == null ? DEFAULT_OFFSET_VALUE : offset;
        limit = limit == null ? DEFAULT_LIMIT_VALUE : limit;

        BaseStoredProcedureResponse storedProcedureResponse = inquiryOrderRepository.getHistoryOrder(accountId, fromDate, toDate, symbol, execType, orsStatus, offset, limit);

        if (SUCCESS.equals(storedProcedureResponse.getErrCd())) {
            List<HistoryOrderDVO> historyOrderMatchDVOS = (List<HistoryOrderDVO>) storedProcedureResponse.getData();
            baseResponse.setData(historyOrderMatchDVOS);
        } else {
            baseResponse.setData(Collections.emptyList());
        }
        return baseResponse;
    }

    @Override
    public BaseResponse orderBooks(StockOrderFilter stockOrderFilter) {
        BaseResponse baseResponse = BaseResponse.ofSucceeded();
        baseResponse.setData(inquiryOrderRepository.orderBooks(stockOrderFilter));
        return baseResponse;
    }

    @Override
    public BaseResponse cancelOrderByID(String requestId, String accountId, String orderId, String cusId, String via, String ipAddress, String validationType, String device, String deviceType) {

        BaseResponse baseResponse;

        try {
            StoredProcedureError storedResponse = orderRepository.cancelOrder(requestId, accountId, orderId, cusId, ipAddress, via, validationType, device, deviceType);
            if (SUCCESS.equals(storedResponse.getErrCd())) {
                baseResponse = BaseResponse.ofSucceeded();
                baseResponse.setCode(BaseRest.RESPONSE.OK_CODE);
                baseResponse.setData(storedResponse);
                return baseResponse;
            }
            baseResponse = BaseResponse.ofFailedFlexResponse(storedResponse);

        } catch (Exception ex) {
            log.error("OrderService cancelOrderByID function error : {} ", ex.getMessage());
            baseResponse = BaseResponse.ofFailedException(" OrderServiceImpl cancelOrder : " + ex.getMessage());
        }

        return baseResponse;
    }

    @Override
    public BaseResponse cancelOrder(BaseRequest<CancelOrderRequest> cancelOrderRequestBaseRequest, String ipAddress) {
        String requestId = cancelOrderRequestBaseRequest.getRequestId();
        String cusId = cancelOrderRequestBaseRequest.getData().getCusId();
        String accountId = cancelOrderRequestBaseRequest.getData().getAccountId();
        String orderId = cancelOrderRequestBaseRequest.getData().getOrderId();
        String via = cancelOrderRequestBaseRequest.getData().getVia();
        String validationType = cancelOrderRequestBaseRequest.getData().getValidationType();
        String device = cancelOrderRequestBaseRequest.getData().getDevice();
        String deviceType = cancelOrderRequestBaseRequest.getData().getDeviceType();
        BaseResponse baseResponse;

        try {
            StoredProcedureError storedResponse = orderRepository.cancelOrder(requestId, accountId, orderId, cusId, ipAddress, via, validationType, device, deviceType);
            if (SUCCESS.equals(storedResponse.getErrCd())) {
                baseResponse = BaseResponse.ofSucceeded();
                baseResponse.setCode(BaseRest.RESPONSE.OK_CODE);
                baseResponse.setData(storedResponse);
                return baseResponse;
            }
            baseResponse = BaseResponse.ofFailedFlexResponse(storedResponse);

        } catch (Exception ex) {
            log.error("OrderService cancelOrderByID function error : {} ", ex.getMessage());
            baseResponse = BaseResponse.ofFailedException(" OrderServiceImpl cancelOrder : " + ex.getMessage());
        }
        return baseResponse;
    }


    @Override
    public BaseResponse updateOrder(BaseRequest<OrderUpdateReq> orderUpdateRequest) {
        OrderUpdateReq orderUpdateReq = orderUpdateRequest.getData();
        String requestId = orderUpdateRequest.getRequestId();
        String accountId = orderUpdateReq.getAccountId();
        String orderId = orderUpdateReq.getOrderId();
        String custId = orderUpdateReq.getCusId();
        Integer qty = orderUpdateReq.getQty();
        String ipAddress = orderUpdateReq.getIpAddress();
        Integer limitPrice = orderUpdateReq.getLimitPrice();
        String via = orderUpdateReq.getVia();
        String validationType = orderUpdateReq.getValidationType();
        String device = orderUpdateReq.getDevice();
        String deviceType = orderUpdateReq.getDeviceType();

        BaseResponse baseResponse;
        try {
            long startTime = System.nanoTime();
            StoredProcedureError storedResponse = orderRepository.editOrder(requestId, accountId, orderId, custId, qty, limitPrice, ipAddress, via, validationType, device, deviceType);
            long endTime = System.nanoTime();
            log.info("UpdateOrder Execution SP time - {}", (endTime - startTime));
            if (SUCCESS.equals(storedResponse.getErrCd())) {
                baseResponse = BaseResponse.ofSucceeded();
                baseResponse.setCode(BaseRest.RESPONSE.OK_CODE);
                baseResponse.setData(storedResponse);
                return baseResponse;
            }

            baseResponse = BaseResponse.ofFailedFlexResponse(storedResponse);

        } catch (Exception ex) {
            log.error("OrderService editOrder function error : {} ", ex.getMessage());
            baseResponse = BaseResponse.ofFailedException(" OrderService editOrder function error : " + ex.getMessage());
        }
        return baseResponse;
    }

    @Override
    public void postOrderKafka(BaseRequest<PostOrdersRequests> postOrderReq) {
        KafkaBaseResponse response;

        KafkaResponseData data;
        data = new KafkaResponseData();
        data.setServiceName(postOrderReq.getServiceName());
        data.setRequestId(postOrderReq.getRequestId());
        try {
            String ipAddress = postOrderReq.getData().getIpAddress();
            PostOrdersResponseResponse res;
            res = orderRepository.saveOder(postOrderReq, ipAddress);
            //data.setDetail(response);

            if ("0".equals(res.getErrCode())) {
                var listOrderId = res.getOrderIds();
                PostOrderKafkaResponse postOrderKafkaResponse = new PostOrderKafkaResponse();
                postOrderKafkaResponse.setErrCd(res.getErrCode());
                postOrderKafkaResponse.setErrParam(res.getErrParam());
                List<PostOrderSPResponse> postOrderSPResponses = new ArrayList<>();
                for (String orderId : listOrderId) {
                    PostOrderSPResponse postOrderSPResponse = new PostOrderSPResponse();
                    postOrderSPResponse.setOrderId(orderId);

                    postOrderSPResponses.add(postOrderSPResponse);

                    //insert to log
                    PostOrderLogResponse outPutLog = new PostOrderLogResponse();
                    outPutLog.setOrderId(orderId);
                    outPutLog.setErrCode(res.getErrCode());
                    outPutLog.setErrParam(res.getErrParam());

                    trackingService.insertLog(postOrderReq, outPutLog, Constants.TRACKING_ACTION.CREATE, Constants.TRACKING_RESULT.SUCCESS);
                }
                postOrderKafkaResponse.setOrder(postOrderSPResponses);
                data.setDetail(postOrderKafkaResponse);

                //push to kafka
                response = KafkaBaseResponse.ofSucceeded();
                response.setData(data);

                Gson gson = new Gson();
                String msg = gson.toJson(response);
                this.sendPostOrderResultToKafka(msg, data.getServiceName());
                log.info("Send post order result success to kafka {}", msg);
            } else {
                data.setDetail(res);
                response = KafkaBaseResponse.ofFailedFlexResponse(res);
                response.setData(res);

                //set log
                trackingService.insertLog(postOrderReq, response, Constants.TRACKING_ACTION.CREATE, Constants.TRACKING_RESULT.FAIL);

                //push to kafka
                response.setData(data);
                response.setCode(BaseRest.RESPONSE.FAIL);

                Gson gson = new Gson();
                String msg = gson.toJson(response);
                this.sendPostOrderResultToKafka(msg, data.getServiceName());
                log.info("Send post order result fail to kafka {}", msg);
            }
        } catch (Exception ex) {
            log.error("Kafka postOrder error : {} ", ex.getMessage());

            //response data kafka
            response = KafkaBaseResponse.ofFailedException(CommonUtils.handlerError(ex));

            //save to log
            trackingService.insertLog(postOrderReq, response, Constants.TRACKING_ACTION.CREATE, Constants.TRACKING_RESULT.FAIL);

            //push to kafka
            response.setData(data);
            Gson gson = new Gson();
            String msg = gson.toJson(response);
            this.sendPostOrderResultToKafka(msg, data.getServiceName());
            log.info("Send post order result exception to kafka {}", msg);
        }
    }

    @Override
    public void cancelOrderKafka(BaseRequest<CancelOrderRequest> cancelOrderRequest) {
        Trackings tracking = new Trackings();
        tracking.setServiceName(cancelOrderRequest.getServiceName());
        tracking.setRequestId(cancelOrderRequest.getRequestId());
        tracking.setInput(cancelOrderRequest.getData());
        tracking.setAction(Constants.TRACKING_ACTION.CANCEL);
        tracking.setCreatedAt(new Date());

        KafkaBaseResponse response;

        KafkaResponseData data;
        data = new KafkaResponseData();
        data.setServiceName(cancelOrderRequest.getServiceName());
        data.setRequestId(cancelOrderRequest.getRequestId());

        try {
            String ipAddress = cancelOrderRequest.getData().getIpAddress();
            String requestId = cancelOrderRequest.getRequestId();
            String cusId = cancelOrderRequest.getData().getCusId();
            String accountId = cancelOrderRequest.getData().getAccountId();
            String orderId = cancelOrderRequest.getData().getOrderId();
            String via = cancelOrderRequest.getData().getVia();
            String validationType = cancelOrderRequest.getData().getValidationType();
            String device = cancelOrderRequest.getData().getDevice();
            String deviceType = cancelOrderRequest.getData().getDeviceType();

            var dbRes = cancelOrderByID(requestId, accountId, orderId, cusId, via, ipAddress, validationType, device, deviceType);
            data.setDetail(dbRes.getData());

            if (dbRes.getStatus().equals(BaseRest.FLEX_RESPONSE.STATUS_CODE_SUCCESS)) {
                //Map to kafka response
                response = KafkaBaseResponse.ofSucceeded();

                //save to log
                tracking.setStatus(Constants.TRACKING_RESULT.SUCCESS);
                tracking.setOutput(dbRes.getData());
                trackingService.insert(tracking);

                //push to kafka
                response.setData(data);
                Gson gson = new Gson();
                String msg = gson.toJson(response);
                this.sendCancelOrderResultToKafka(msg, data.getServiceName());
                log.info("Send cancel order result success to kafka {}", msg);
            } else {
                //set log
                tracking.setOutput(dbRes);
                tracking.setStatus(Constants.TRACKING_RESULT.FAIL);
                trackingService.insert(tracking);

                //Map to kafka response
                response = KafkaBaseResponse.ofFailedFlexResponse(data);

                //push to kafka
                Gson gson = new Gson();
                String msg = gson.toJson(response);
                this.sendCancelOrderResultToKafka(msg, data.getServiceName());
                log.info("Send cancel order result fail to kafka {}", msg);
            }
        } catch (Exception ex) {
            log.error("Kafka cancelOrder error : {} ", ex.getMessage());

            //response data kafka
            response = KafkaBaseResponse.ofFailedException(CommonUtils.handlerError(ex));

            //save to log
            tracking.setOutput(response);
            tracking.setStatus(Constants.TRACKING_RESULT.FAIL);
            trackingService.insert(tracking);

            //push to kafka
            response.setData(data);
            Gson gson = new Gson();
            String msg = gson.toJson(response);
            this.sendCancelOrderResultToKafka(msg, data.getServiceName());
            log.info("Send cancel order result exception to kafka {}", msg);
        }
    }

    private void sendPostOrderResultToKafka(String message, String serviceName) {
        ViaCode viaCode = ViaCode.valueOf(serviceName);
        switch (viaCode) {
            case COVERED_WARRANT: {
                kafkaTemplate.send(KafkaTopicConstants.FLEX_POST_ORDER_RESULT_CW_TOPIC, message);
                break;
            }
            default: {
                kafkaTemplate.send(orderResult, message);
                break;
            }
        }
    }

    private void sendCancelOrderResultToKafka(String message, String serviceName) {
        ViaCode viaCode = ViaCode.valueOf(serviceName);
        switch (viaCode) {
            case COVERED_WARRANT: {
                kafkaTemplate.send(KafkaTopicConstants.FLEX_CANCEL_ORDER_CW_RESULT_TOPIC, message);
                break;
            }
            default: {
                kafkaTemplate.send(cancelOrdersResult, message);
                break;
            }
        }
    }


    public Boolean checkType(String type) {
        boolean check = true;
        if (type.equals("limit")) {
            check = false;
        } else if (type.equals("market")) {
            check = false;
        } else if (type.equals("LIMIT")) {
            check = false;
        } else if (type.equals("MARKET")) {
            check = false;
        }
        return check;
    }

    @Override
    public BaseResponse saveOder(BaseRequest<PostOrdersRequests> postOrdersDTO, String ipAddress) {
        BaseResponse response = new BaseResponse();
        PostOrderKafkaResponse postOrderKafkaResponse = new PostOrderKafkaResponse();
        try {
            Long qty = postOrdersDTO.getData().getQty().longValue();
            String type = postOrdersDTO.getData().getType();
            PostOrdersResponseResponse res;
            res = orderRepository.saveOder(postOrdersDTO, ipAddress);
            log.info("ErrCode" + res.getErrCode());
            if ("0".equals(res.getErrCode())) {
                var listOrderId = res.getOrderIds();
                postOrderKafkaResponse.setErrCd(res.getErrCode());
                postOrderKafkaResponse.setErrParam(res.getErrParam());
                List<PostOrderSPResponse> postOrderSPResponses = new ArrayList<>();
                for (String orderId : listOrderId) {
                    PostOrderSPResponse postOrderSPResponse = new PostOrderSPResponse();
                    postOrderSPResponse.setOrderId(orderId);

                    postOrderSPResponses.add(postOrderSPResponse);

                    //insert to log
                    PostOrderLogResponse outPutLog = new PostOrderLogResponse();
                    outPutLog.setOrderId(orderId);
                    outPutLog.setErrCode(res.getErrCode());
                    outPutLog.setErrParam(res.getErrParam());

                    trackingService.insertLog(postOrdersDTO, outPutLog, Constants.TRACKING_ACTION.CREATE, Constants.TRACKING_RESULT.SUCCESS);
                }
                postOrderKafkaResponse.setOrder(postOrderSPResponses);
                response = BaseResponse.ofSucceeded();
                response.setData(postOrderKafkaResponse);
            } else {
                if (postOrdersDTO.getData().getUserName().equals("")) {
                    response.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_ERROR);
                    response.setCode(BaseRest.ERROR_CODE.ERR400);
                    response.setMessage("Mã khách hàng không tồn tại");
                    response.setData(res);
                    return response;
                } else if (qty <= 0) {
                    response.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_ERROR);
                    response.setCode(BaseRest.ERROR_CODE.ERR400);
                    response.setMessage("Số lượng phải lớn hơn 0");
                    response.setData(res);
                    return response;
                } else if (checkType(type)) {
                    response.setStatus(BaseRest.FLEX_RESPONSE.STATUS_CODE_ERROR);
                    response.setCode(BaseRest.ERROR_CODE.ERR400);
                    response.setMessage("Loại giá không hợp lệ");
                    response.setData(res);
                    return response;
                }
                response = BaseResponse.ofFailedFlexResponse(res);

                trackingService.insertLog(postOrdersDTO, response, Constants.TRACKING_ACTION.CREATE, Constants.TRACKING_RESULT.FAIL);
            }
            return response;
        } catch (Exception e) {
            log.error(CommonUtils.handlerError(e));
            response = BaseResponse.ofFailedException(e.getMessage());
            trackingService.insertLog(postOrdersDTO, response, Constants.TRACKING_ACTION.CREATE, Constants.TRACKING_RESULT.FAIL);
            return response;
        }

    }

    @Override
    public BaseResponse getHistoryOrderMatchByListSubAccounts(List<String> accountIds, String fromDate, String toDate, String symbol, String execType) {
        if (accountIds.size() > 10) {
            return BaseResponse.ofFailedFlexResponse(messageUtil.getMessage("ERR101003"));
        }
        List<List<?>> response =
                accountIds.stream().map(accountId -> {
                    BaseStoredProcedureResponse storedProcedureResponse = inquiryOrderRepository.getHistoryOrderMatch(accountId, fromDate, toDate, symbol, execType, DEFAULT_OFFSET_VALUE, DEFAULT_LIMIT_VALUE);
                    if (SUCCESS.equals(storedProcedureResponse.getErrCd())) {
                        List<HistoryOrderMatchDVO> historyOrderMatchDVOS = (List<HistoryOrderMatchDVO>) storedProcedureResponse.getData();
                        List<HistoryOrderMatchResponse> historyOrderMatchResponses = historyOrderMapper.fromListSourceToListTarget(historyOrderMatchDVOS);
                        return historyOrderMatchResponses;
                    } else {
                        return Collections.emptyList();
                    }
                }).collect(Collectors.toList());

        BaseResponse baseResponse;
        baseResponse = BaseResponse.ofSucceeded();
        baseResponse.setCode(BaseRest.RESPONSE.OK_CODE);
        baseResponse.setData(response);
        return baseResponse;
    }

    @Override
    public void postOrderConditionKafka(BaseRequest<PostOrdersRequests> postOrderReq) {
        KafkaBaseResponse response;

        KafkaResponseData data;
        data = new KafkaResponseData();
        data.setServiceName(postOrderReq.getServiceName());
        data.setRequestId(postOrderReq.getRequestId());
        try {
            String ipAddress = postOrderReq.getData().getIpAddress();
            PostOrdersResponseResponse res;
            res = orderRepository.saveOder(postOrderReq, ipAddress);
            //data.setDetail(response);

            if ("0".equals(res.getErrCode())) {
                var listOrderId = res.getOrderIds();
                PostOrderConditionKafkaResponse postOrderConditionKafkaResponse = new PostOrderConditionKafkaResponse();
                postOrderConditionKafkaResponse.setErrCode(res.getErrCode());
                postOrderConditionKafkaResponse.setErrParam(res.getErrParam());
                List<PostOrderSPResponse> postOrderSPResponses = new ArrayList<>();
                for (String orderId : listOrderId) {
                    PostOrderSPResponse postOrderSPResponse = new PostOrderSPResponse();
                    postOrderSPResponse.setOrderId(orderId);

                    postOrderSPResponses.add(postOrderSPResponse);

                    //insert to log
                    PostOrderLogResponse outPutLog = new PostOrderLogResponse();
                    outPutLog.setOrderId(orderId);
                    outPutLog.setErrCode(res.getErrCode());
                    outPutLog.setErrParam(res.getErrParam());

                    trackingService.insertLog(postOrderReq, outPutLog, Constants.TRACKING_ACTION.CREATE, Constants.TRACKING_RESULT.SUCCESS);
                }
                postOrderConditionKafkaResponse.setOrder(postOrderSPResponses);
                data.setDetail(postOrderConditionKafkaResponse);

                //push to kafka
                response = KafkaBaseResponse.ofSucceeded();
                response.setData(data);

                Gson gson = new Gson();
                String msg = gson.toJson(response);
                kafkaTemplate.send(postConditionOrderResult, msg);
                log.info("Send post order result success to kafka {}", msg);
            } else {
                data.setDetail(res);
                response = KafkaBaseResponse.ofFailedFlexResponse(res);
                response.setData(res);

                //set log
                trackingService.insertLog(postOrderReq, response, Constants.TRACKING_ACTION.CREATE, Constants.TRACKING_RESULT.FAIL);

                //push to kafka
                response.setData(data);
                response.setCode(BaseRest.RESPONSE.FAIL);

                Gson gson = new Gson();
                String msg = gson.toJson(response);
                kafkaTemplate.send(postConditionOrderResult, msg);
                log.info("Send post order result fail to kafka {}", msg);
            }
        } catch (Exception ex) {
            log.error("Kafka postOrder error : {} ", ex.getMessage());

            //response data kafka
            response = KafkaBaseResponse.ofFailedException(CommonUtils.handlerError(ex));

            //save to log
            trackingService.insertLog(postOrderReq, response, Constants.TRACKING_ACTION.CREATE, Constants.TRACKING_RESULT.FAIL);

            //push to kafka
            response.setData(data);
            Gson gson = new Gson();
            String msg = gson.toJson(response);
            kafkaTemplate.send(postConditionOrderResult, msg);
            log.info("Send post order result exception to kafka {}", msg);
        }
    }


    @Override
    public void cancelOrderConditionKafka(BaseRequest<CancelOrderRequest> cancelOrderRequest) {
        Trackings tracking = new Trackings();
        tracking.setServiceName(cancelOrderRequest.getServiceName());
        tracking.setRequestId(cancelOrderRequest.getRequestId());
        tracking.setInput(cancelOrderRequest.getData());
        tracking.setAction(Constants.TRACKING_ACTION.CANCEL);
        tracking.setCreatedAt(new Date());

        KafkaBaseResponse response;

        KafkaResponseData data;
        data = new KafkaResponseData();
        data.setServiceName(cancelOrderRequest.getServiceName());
        data.setRequestId(cancelOrderRequest.getRequestId());

        try {
            String ipAddress = cancelOrderRequest.getData().getIpAddress();
            String requestId = cancelOrderRequest.getRequestId();
            String cusId = cancelOrderRequest.getData().getCusId();
            String accountId = cancelOrderRequest.getData().getAccountId();
            String orderId = cancelOrderRequest.getData().getOrderId();
            String via = cancelOrderRequest.getData().getVia();
            String validationType = cancelOrderRequest.getData().getValidationType();
            String device = cancelOrderRequest.getData().getDevice();
            String deviceType = cancelOrderRequest.getData().getDeviceType();

            var dbRes = cancelOrderByID(requestId, accountId, orderId, cusId, via, ipAddress, validationType, device, deviceType);
            data.setDetail(dbRes.getData());

            if (dbRes.getStatus().equals(BaseRest.FLEX_RESPONSE.STATUS_CODE_SUCCESS)) {
                //Map to kafka response
                response = KafkaBaseResponse.ofSucceeded();

                //save to log
                tracking.setStatus(Constants.TRACKING_RESULT.SUCCESS);
                tracking.setOutput(dbRes.getData());
                trackingService.insert(tracking);

                //push to kafka
                response.setData(data);
                Gson gson = new Gson();
                String msg = gson.toJson(response);
                kafkaTemplate.send(cancelConditionOrderResult, msg);
                log.info("Send cancel order result success to kafka {}", msg);
            } else {
                //set log
                tracking.setOutput(dbRes);
                tracking.setStatus(Constants.TRACKING_RESULT.FAIL);
                trackingService.insert(tracking);

                //Map to kafka response
                response = KafkaBaseResponse.ofFailedFlexResponse(data);

                //push to kafka
                Gson gson = new Gson();
                String msg = gson.toJson(response);
                kafkaTemplate.send(cancelConditionOrderResult, msg);
                log.info("Send cancel order result fail to kafka {}", msg);
            }
        } catch (Exception ex) {
            log.error("Kafka cancelOrder error : {} ", ex.getMessage());

            //response data kafka
            response = KafkaBaseResponse.ofFailedException(CommonUtils.handlerError(ex));

            //save to log
            tracking.setOutput(response);
            tracking.setStatus(Constants.TRACKING_RESULT.FAIL);
            trackingService.insert(tracking);

            //push to kafka
            response.setData(data);
            Gson gson = new Gson();
            String msg = gson.toJson(response);
            kafkaTemplate.send(cancelConditionOrderResult, msg);
            log.info("Send cancel order result exception to kafka {}", msg);
        }
    }
}
