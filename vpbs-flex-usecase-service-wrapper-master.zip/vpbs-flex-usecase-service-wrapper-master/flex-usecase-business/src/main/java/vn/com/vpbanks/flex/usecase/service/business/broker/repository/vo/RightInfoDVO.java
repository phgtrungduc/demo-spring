package vn.com.vpbanks.flex.usecase.service.business.broker.repository.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.math.BigDecimal;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class RightInfoDVO {
    private String acctNo;
    private String custoDyCd;
    private String fullName;
    private String mobile;
    private String idCode;
    private String caMastId;
    private BigDecimal slCkSh;
    private String rate;
    private String caType;
    private String status;
    private BigDecimal amt;
    private String symbol;
    private String toSymbol;
    private String toCodeId;

    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "Asia/Bangkok")
    private Date rePortDate;
    private BigDecimal slCkCv;
    private BigDecimal stCv;

    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "Asia/Bangkok")

    private Date actionDate;
    private String codeId;
    private String caStatus;
    private String rightOffRate;
    private BigDecimal pQtty;
    private BigDecimal exPrice;
    private String isRegis;

    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "Asia/Bangkok")
    private Date dueDate;

    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "Asia/Bangkok")
    private Date khqDate;

    private String typeCa;

    private String statusId;

    private String caStatusDesc;
}
