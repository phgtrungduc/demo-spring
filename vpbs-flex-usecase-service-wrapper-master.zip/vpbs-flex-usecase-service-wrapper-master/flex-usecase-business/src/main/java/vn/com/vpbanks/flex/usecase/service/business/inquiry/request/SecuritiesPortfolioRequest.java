package vn.com.vpbanks.flex.usecase.service.business.inquiry.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class SecuritiesPortfolioRequest implements Serializable {
    @Id
    @JsonProperty("cusToDyCD")
    @Column(name = "CUSTODYCD")
    private String cusToDyCD;

    @JsonProperty("accountID")
    @Column(name = "ACCOUNTID")
    private String accountID;

    @JsonProperty("symbol")
    @Column(name = "SYMBOL")
    private String symbol;

    @JsonProperty("secType")
    @Column(name = "SECTYPE")
    private String secType;

    @JsonProperty("tradePlace")
    @Column(name = "TRADEPLACE")
    private String tradePlace;

    @JsonProperty("total")
    @Column(name = "TOTAL")
    private BigDecimal total;

    @JsonProperty("trade")
    @Column(name = "TRADE")
    private BigDecimal trade;

    @JsonProperty("blocked")
    @Column(name = "BLOCKED")
    private BigDecimal blocked;

    @JsonProperty("vsdMortGage")
    @Column(name = "VSDMORTGAGE")
    private BigDecimal vsdMortGage;

    @JsonProperty("mortGage")
    @Column(name = "MOrtgage")
    private BigDecimal mortGage;

    @JsonProperty("restrict")
    @Column(name = "RESTRICT")
    private BigDecimal restrict;

    @JsonProperty("receivingRight")
    @Column(name = "RECEIVINGRIGHT")
    private BigDecimal receivingRight;

    @JsonProperty("receivingT0")
    @Column(name = "RECEIVINGT0")
    private BigDecimal receivingT0;

    @JsonProperty("receivingT1")
    @Column(name = "RECEIVINGT1")
    private BigDecimal receivingT1;

    @JsonProperty("receivingT2")
    @Column(name = "RECEIVINGT2")
    private BigDecimal receivingT2;

    @JsonProperty("costPrice")
    @Column(name = "COSTPRICE")
    private BigDecimal costPrice;

    @JsonProperty("costPriceAmt")
    @Column(name = "COSTPRICEAMT")
    private BigDecimal costPriceAmt;

    @JsonProperty("basicPriceAmt")
    @Column(name = "BASICPRICEAMT")
    private BigDecimal basicPriceAmt;

    @JsonProperty("marginAmt")
    @Column(name = "MARGINAMT")
    private BigDecimal marginAmt;

    @JsonProperty("pnLamt")
    @Column(name = "PNLAMT")
    private BigDecimal pnLamt;

    @JsonProperty("pnlRate")
    @Column(name = "PNLRATE")
    private String pnlRate;

    @JsonProperty("isSell")
    @Column(name = "ISSELL")
    private String isSell;

    @JsonProperty("closePrice")
    @Column(name = "CLOSEPRICE")
    private BigDecimal closePrice;

    @JsonProperty("withDraw")
    @Column(name = "WITHDRAW")
    private BigDecimal withDraw;

    @JsonProperty("matchIngAmt")
    @Column(name = "MATCHINGAMT")
    private BigDecimal matchIngAmt;

    @JsonProperty("totalPnl")
    @Column(name = "TOTALPNL")
    private BigDecimal totalPnl;

    @JsonProperty("productTypeName")
    @Column(name = "PRODUCTTYPENAME")
    private String productTypeName;

    @JsonProperty("fullName")
    @Column(name = "FULLNAME")
    private String fullName;

    @JsonProperty("basicPrice")
    @Column(name = "BASICPRICE")
    private BigDecimal basicPrice;


}
