package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.impl;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.request.SecuritiesPortfolioRequest;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.SecuritiesPortfolioResponse;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Repository
@Log4j2
public class SecuritiesPortfolioRepository {
    private static final Object FAIL_CODE = "1";
    @Autowired
    EntityManager entityManager;

    @Value("${vpbanks.flex.sp.SP_GET_SECURITIES_PORTFOLIO}")
    private String SP_GET_SECURITIES_PORTFOLIO;

    public List<SecuritiesPortfolioResponse> getSecuritiesPortfolio(String pAccountId, String pSymbol, int p_offset, int p_limit) {
        List<SecuritiesPortfolioRequest> securitiesPortfolioRequest = new ArrayList<>();
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_SECURITIES_PORTFOLIO);

        query.registerStoredProcedureParameter("pv_refCursor", Class.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_accountId", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_symbol", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_offset", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_limit", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.OUT);
        query.setParameter("p_accountId", pAccountId);
        query.setParameter("p_symbol", pSymbol);
        query.setParameter("p_offset", p_offset);
        query.setParameter("p_limit", p_limit);
        query.execute();

        List<SecuritiesPortfolioResponse> securitiesPortfolioResponses = null;
        List<Object[]> availableTrades = query.getResultList();
        securitiesPortfolioResponses = availableTrades.stream().map(item -> {
            SecuritiesPortfolioResponse.SecuritiesPortfolioResponseBuilder builder = SecuritiesPortfolioResponse.builder();
            builder.cusToDyCD((String) item[0])
                    .accountID((String) item[1])
                    .symbol((String) item[2])
                    .secType((String) item[3])
                    .tradePlace((String) item[4])
                    .total((BigDecimal) item[5])
                    .trade((BigDecimal) item[6])
                    .blocked((BigDecimal) item[7])
                    .vsdMortGage((BigDecimal) item[8])
                    .mortGage((BigDecimal) item[9])
                    .restrict((BigDecimal) item[10])
                    .receivingRight((BigDecimal) item[11])
                    .receivingT0((BigDecimal) item[12])
                    .receivingT1((BigDecimal) item[13])
                    .receivingT2((BigDecimal) item[14])
                    .costPrice((BigDecimal) item[15])
                    .costPriceAmt((BigDecimal) item[16])
                    .basicPrice((BigDecimal) item[17])
                    .basicPriceAmt((BigDecimal) item[18])
                    .marginAmt((Character) item[19])
                    .pnLamt((BigDecimal) item[20])
                    .pnlRate((String) item[21])
                    .isSell((Character) item[22])
                    .closePrice(BigDecimal.valueOf(Integer.parseInt((String) item[23])))
                    .withDraw((BigDecimal) item[24])
                    .matchIngAmt((BigDecimal) item[25])
                    .totalPnl((BigDecimal) item[26])
                    .productTypeName((String) item[27])
                    .fullName((String) item[28])
                    .R((BigDecimal) item[29])
                    .lCount((BigDecimal) item[30])
            ;
            return builder.build();
        }).collect(Collectors.toList());
        return securitiesPortfolioResponses;
    }
}
