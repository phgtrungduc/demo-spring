package vn.com.vpbanks.flex.usecase.service.business.broker.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import vn.com.vpbanks.flex.usecase.service.common.annotation.NotEmptyCharacter;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ReGrpLnkRequest {

    @NotEmptyCharacter
    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String requestId;

    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String cusToDyCdBroker;

    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String cusToDyCdMaster;

    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String via;
}
