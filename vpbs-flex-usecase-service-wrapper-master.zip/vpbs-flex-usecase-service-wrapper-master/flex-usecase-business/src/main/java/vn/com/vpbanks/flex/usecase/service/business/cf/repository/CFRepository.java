package vn.com.vpbanks.flex.usecase.service.business.cf.repository;

import vn.com.vpbanks.flex.usecase.service.business.cf.request.CalCI1202Request;
import vn.com.vpbanks.flex.usecase.service.business.cf.request.OpenCSAccountRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseStoredProcedureResponse;

public interface CFRepository {
    BaseStoredProcedureResponse openCommissionAccount(OpenCSAccountRequest openCSAccountRequest);

    BaseStoredProcedureResponse calCI1202(CalCI1202Request calCI1202Request);
}
