package vn.com.vpbanks.flex.usecase.service.business.salesupport.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OrderCustomerDirectIndirect implements Serializable {

    @JsonProperty("custodyCd")
    private String custodyCd;

    @JsonProperty("custodyFullName")
    private String custodyFullName;

    @JsonProperty("reCustodyCd")
    private String reCustodyCd;

    @JsonProperty("reFullName")
    private String reFullName;

    @JsonProperty("dept")
    private String dept;
}
