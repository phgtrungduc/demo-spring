package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ODTypeVO {

    @Column(name = "AFTYPE")
    private String afType;
    @Column(name = "ODTYPE")
    private String odType;
    @Column(name = "ODTYPENAME")
    private String odTypeName;
    @Column(name = "STATUS_VALUE")
    private String statusValue;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "APPRV_STS_VALUE")
    private String apprvStsValue;
    @Column(name = "APPRV_STS")
    private String apprvSts;
    @Column(name = "DEFFEERATE")
    private BigDecimal defFeeRate;
}
