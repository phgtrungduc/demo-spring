package vn.com.vpbanks.flex.usecase.service.business.order.repository;

import vn.com.vpbanks.flex.usecase.service.business.order.request.PostOrdersRequests;
import vn.com.vpbanks.flex.usecase.service.business.order.response.PostOrdersResponseResponse;
import vn.com.vpbanks.flex.usecase.service.common.dto.request.BaseRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.StoredProcedureError;

public interface OrderRepository {
    StoredProcedureError cancelOrder(String requestId, String accountNo, String orderId, String cusId, String ipAddress, String channel, String validationType, String device, String deviceType);

    PostOrdersResponseResponse saveOder(BaseRequest<PostOrdersRequests> postOrdersDTO, String ipAddress);

    StoredProcedureError editOrder(String requestId, String accountId, String orderId, String cusId, Integer qty, Integer limitPrice, String ipAddress, String via, String validationType, String device, String deviceType);
}
