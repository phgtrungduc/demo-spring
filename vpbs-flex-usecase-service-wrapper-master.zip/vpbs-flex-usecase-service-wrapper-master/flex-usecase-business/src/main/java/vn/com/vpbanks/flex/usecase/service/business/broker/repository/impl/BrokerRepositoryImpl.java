package vn.com.vpbanks.flex.usecase.service.business.broker.repository.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import vn.com.vpbanks.flex.usecase.service.business.broker.repository.BrokerRepository;
import vn.com.vpbanks.flex.usecase.service.business.broker.repository.vo.BrokerGroupDVO;
import vn.com.vpbanks.flex.usecase.service.business.broker.repository.vo.BrokerInfoDVO;
import vn.com.vpbanks.flex.usecase.service.business.broker.repository.vo.CustomerOfBrokerDVO;
import vn.com.vpbanks.flex.usecase.service.business.broker.repository.vo.RightInfoDVO;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.BrokerRequest;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.ReGrpLnkRequest;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.RightOffRegisterRequest;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.TransferStockRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseStoredProcedureResponse;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.StoredProcedureError;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Component
@Slf4j
public class BrokerRepositoryImpl implements BrokerRepository {

    private final EntityManager entityManager;
    private final ObjectMapper objectMapper;
    private static final String SUCCESS_CD = "0";

    @Value("${vpbanks.flex.sp.SP_ADD_BROKER}")
    private String SP_ADD_BROKER;

    @Value("${vpbanks.flex.sp.SP_ADD_BROKER_GROUP_LINK}")
    private String SP_ADD_BROKER_GROUP_LINK;

    @Value("${vpbanks.flex.sp.SP_INTERNAL_STOCK_TRANSFER}")
    private String SP_INTERNAL_STOCK_TRANSFER;

    @Value("${vpbanks.flex.sp.SP_RIGHT_OFF_REGISTER}")
    private String SP_RIGHT_OFF_REGISTER;

    @Value("${vpbanks.flex.sp.SP_GET_CUSTOMER_OF_BROKER}")
    private String SP_GET_CUSTOMER_OF_BROKER;

    @Value("${vpbanks.flex.sp.SP_GET_BROKER_INFO}")
    private String SP_GET_BROKER_INFO;

    @Value("${vpbanks.flex.sp.SP_GET_RIGHT_INFO}")
    private String SP_GET_RIGHT_INFO;

    @Override
    public StoredProcedureError addBroker(BrokerRequest brokerRequest, String ipAddress, String requestId) {
        Gson gson = new Gson();
        String req = gson.toJson(brokerRequest);
        log.debug("addBroker: {}", req);
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_ADD_BROKER);

        query.registerStoredProcedureParameter("p_requestid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_custodycd", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_retype", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_rerole", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_via", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_ipaddress", String.class, ParameterMode.IN);

        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_message", String.class, ParameterMode.INOUT);


        //set param
        query.setParameter("p_requestid", requestId);
        query.setParameter("p_custodycd", brokerRequest.getAccountNo());
        query.setParameter("p_retype", brokerRequest.getActype());
        query.setParameter("p_rerole", !StringUtils.isEmpty(brokerRequest.getRole()) ? brokerRequest.getRole() : "R");
        query.setParameter("p_via", brokerRequest.getVia().toUpperCase());
        query.setParameter("p_ipaddress", ipAddress);

        query.execute();

        String errCd = (String) query.getOutputParameterValue("p_err_code");
        String errMsg = (String) query.getOutputParameterValue("p_err_message");

        StoredProcedureError storedProcedureError = new StoredProcedureError();
        storedProcedureError.setErrCd(errCd);
        storedProcedureError.setErrParam(errMsg);

        return storedProcedureError;
    }

    @Override
    public BaseStoredProcedureResponse<BrokerGroupDVO> addReGrpLink(ReGrpLnkRequest reGrpLnkRequest, String ipAddress) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_ADD_BROKER_GROUP_LINK);
        query.registerStoredProcedureParameter("p_requestid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_custodycd_broker", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_custodycd_master", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_via", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_ipaddress", String.class, ParameterMode.IN);

        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_message", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("pv_cursor", void.class, ParameterMode.REF_CURSOR);

        query.setParameter("p_requestid", reGrpLnkRequest.getRequestId());
        query.setParameter("p_custodycd_broker", reGrpLnkRequest.getCusToDyCdBroker());
        query.setParameter("p_custodycd_master", reGrpLnkRequest.getCusToDyCdMaster());
        query.setParameter("p_via", reGrpLnkRequest.getVia());
        query.setParameter("p_ipaddress", ipAddress);

        query.execute();

        String errCd = (String) query.getOutputParameterValue("p_err_code");
        String errMsg = (String) query.getOutputParameterValue("p_err_message");

        BaseStoredProcedureResponse baseStoredProcedureResponse = new BaseStoredProcedureResponse();
        baseStoredProcedureResponse.setErrMsg(errMsg);
        baseStoredProcedureResponse.setErrCd(errCd);

        if (SUCCESS_CD.equals(errCd)) {
            Object[] result = (Object[]) query.getSingleResult();
            BrokerGroupDVO brokerGroupDVO = new BrokerGroupDVO(result);
            baseStoredProcedureResponse.setData(brokerGroupDVO);
            return baseStoredProcedureResponse;
        }

        baseStoredProcedureResponse.setData(null);

        return baseStoredProcedureResponse;
    }

    @Override
    public BaseStoredProcedureResponse<List<CustomerOfBrokerDVO>> getCustomerOfBroker(String reCusToDyCd) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_CUSTOMER_OF_BROKER);
        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("pv_recustodycd", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.INOUT);

        query.setParameter("pv_recustodycd", reCusToDyCd);

        query.execute();

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errParam = (String) query.getOutputParameterValue("p_err_param");
        List<CustomerOfBrokerDVO> customers = new ArrayList<>();
        if (SUCCESS_CD.equals(errCode)) {
            List<String> resultSet = query.getResultList();
            for (String customer : resultSet) {
                customers.add(new CustomerOfBrokerDVO(customer));
            }
        }

        BaseStoredProcedureResponse storedProcedureResponse = new BaseStoredProcedureResponse();
        storedProcedureResponse.setErrCd(errCode);
        storedProcedureResponse.setErrMsg(errParam);
        storedProcedureResponse.setData(customers);

        return storedProcedureResponse;
    }

    @Override
    public BaseStoredProcedureResponse getBrokerInfo(String custoDyCd) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_BROKER_INFO, BrokerInfoDVO.class);
        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("pv_custodycd", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.INOUT);

        query.setParameter("pv_custodycd", custoDyCd);

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errParam = (String) query.getOutputParameterValue("p_err_param");

        BaseStoredProcedureResponse storedProcedureResponse = new BaseStoredProcedureResponse();
        if (SUCCESS_CD.equals(errCode)) {
            try {
                BrokerInfoDVO brokerInfoDVO = (BrokerInfoDVO) query.getSingleResult();
                storedProcedureResponse.setData(brokerInfoDVO);
            } catch (NoResultException exception) {
                log.info("getBrokerInfo fopks_connectorinquiry.pr_get_broker no result exception ");
                storedProcedureResponse.setData(Collections.EMPTY_LIST);
            }
        }

        storedProcedureResponse.setErrCd(errCode);
        storedProcedureResponse.setErrMsg(errParam);
        return storedProcedureResponse;
    }

    @Override
    public BaseStoredProcedureResponse getRightInfo(String fromDate, String toDate, String afAcctNo, String isCom, String symbol, String caType) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_GET_RIGHT_INFO);
        query.registerStoredProcedureParameter("p_refcursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("F_DATE", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("T_DATE", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("PV_CUSTODYCD", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("PV_AFACCTNO", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("ISCOM", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("SYMBOL", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("CATYPE", String.class, ParameterMode.IN);

        query.setParameter("F_DATE", fromDate);
        query.setParameter("T_DATE", toDate);
        query.setParameter("PV_CUSTODYCD", "ALL");
        query.setParameter("PV_AFACCTNO", afAcctNo);
        query.setParameter("ISCOM", isCom);
        query.setParameter("SYMBOL", symbol == null ? "ALL" : symbol);
        query.setParameter("CATYPE", caType == null ? "ALL" : caType);

        BaseStoredProcedureResponse baseStoredProcedureResponse = new BaseStoredProcedureResponse();
        try {

            List<Object[]> objects = query.getResultList();
            List<RightInfoDVO> rightInfoDVOS = objects.stream().map(object -> {
                RightInfoDVO rightInfoDVO = new RightInfoDVO().builder()
                        .acctNo((String) object[0])
                        .custoDyCd((String) object[1])
                        .fullName((String) object[2])
                        .mobile((String) object[3])
                        .idCode((String) object[4])
                        .slCkSh((BigDecimal) object[5])
                        .rate((String) object[6])
                        .caType((String) object[7])
                        .status((String) object[8])
                        .caMastId((String) object[9])
                        .amt((BigDecimal) object[10])
                        .symbol((String) object[11])
                        .toSymbol((String) object[12])
                        .toCodeId((String) object[13])
                        .rePortDate((Date) object[14])
                        .slCkCv((BigDecimal) object[15])
                        .stCv((BigDecimal) object[16])
                        .actionDate((Date) object[17])
                        .codeId((String) object[18])
                        .caStatus((String) object[19])
                        .rightOffRate((String) object[21])
                        .pQtty((BigDecimal) object[22])
                        .exPrice((BigDecimal) object[23])
                        .isRegis(String.valueOf(object[24]))
                        .dueDate((Date) object[25])
                        .khqDate((Date) object[28])
                        .typeCa((String) object[29])
                        .statusId((String) object[30])
                        .caStatusDesc((String) object[31])
                        .build();
                return rightInfoDVO;
            }).collect(Collectors.toList());
            baseStoredProcedureResponse.setData(rightInfoDVOS);

        } catch (NoResultException exception) {
            baseStoredProcedureResponse.setData(Collections.EMPTY_LIST);
            log.error("getRightInfo throw NoResultException {}", exception.getMessage());
        }
        return baseStoredProcedureResponse;
    }

    @Override
    public StoredProcedureError addTransferStock(TransferStockRequest transferStockRequest, String ipAddress, String requestId) {
        Gson gson = new Gson();
        String req = gson.toJson(transferStockRequest);
        log.debug("addTransferStock: {}", req);
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_INTERNAL_STOCK_TRANSFER);

        query.registerStoredProcedureParameter("p_requestid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_accountId", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_receiveAccount", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_symbol", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_qtty", BigDecimal.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_desc", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_ipaddress", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_via", String.class, ParameterMode.IN);

        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_message", String.class, ParameterMode.INOUT);


        //set param
        query.setParameter("p_requestid", requestId);
        query.setParameter("p_accountId", transferStockRequest.getAccountId());
        query.setParameter("p_receiveAccount", transferStockRequest.getReceiveAccount());
        query.setParameter("p_symbol", transferStockRequest.getSymbol());
        query.setParameter("p_qtty", transferStockRequest.getQtty());
        query.setParameter("p_desc", transferStockRequest.getDesc() == null ? "" : transferStockRequest.getDesc());
        query.setParameter("p_ipaddress", ipAddress);
        query.setParameter("p_via", transferStockRequest.getVia().toUpperCase());

        query.execute();

        String errCd = (String) query.getOutputParameterValue("p_err_code");
        String errMsg = (String) query.getOutputParameterValue("p_err_message");

        StoredProcedureError storedProcedureError = new StoredProcedureError();
        storedProcedureError.setErrCd(errCd);
        storedProcedureError.setErrParam(errMsg);

        return storedProcedureError;
    }

    @Override
    public StoredProcedureError addRightOffRegister(RightOffRegisterRequest rightOffRegisterRequest, String ipAddress, String requestId) {
        Gson gson = new Gson();
        String req = gson.toJson(rightOffRegisterRequest);
        log.debug("addRightOffRegiter: {}", req);
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(SP_RIGHT_OFF_REGISTER);

        query.registerStoredProcedureParameter("p_requestid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_accountId", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_camastId", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_qtty", BigDecimal.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_desc", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_ipaddress", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_via", String.class, ParameterMode.IN);

        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.INOUT);
        query.registerStoredProcedureParameter("p_err_message", String.class, ParameterMode.INOUT);


        //set param
        query.setParameter("p_requestid", requestId);
        query.setParameter("p_accountId", rightOffRegisterRequest.getAccountId());
        query.setParameter("p_camastId", rightOffRegisterRequest.getCaMastId());
        query.setParameter("p_qtty", rightOffRegisterRequest.getQtty());
        query.setParameter("p_desc", rightOffRegisterRequest.getDesc() == null ? "" : rightOffRegisterRequest.getDesc());
        query.setParameter("p_ipaddress", ipAddress);
        query.setParameter("p_via", rightOffRegisterRequest.getVia().toUpperCase());

        query.execute();

        String errCd = (String) query.getOutputParameterValue("p_err_code");
        String errMsg = (String) query.getOutputParameterValue("p_err_message");

        StoredProcedureError storedProcedureError = new StoredProcedureError();
        storedProcedureError.setErrCd(errCd);
        storedProcedureError.setErrParam(errMsg);

        return storedProcedureError;
    }
}
