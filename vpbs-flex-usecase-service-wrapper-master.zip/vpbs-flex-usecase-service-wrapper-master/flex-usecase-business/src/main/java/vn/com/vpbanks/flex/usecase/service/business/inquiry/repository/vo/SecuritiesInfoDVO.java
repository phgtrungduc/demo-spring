package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import java.math.BigDecimal;
import java.sql.Timestamp;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SecuritiesInfoDVO {
    private String issuerId;
    private String issuerFullName;
    private String codeId;
    private String symbol;
    private String secType;
    private String tradePlace;
    private String tradePlaceName;
    private BigDecimal parValue;
    private BigDecimal ceilingPrice;
    private BigDecimal floorPrice;
    private BigDecimal referencePrice;
    private BigDecimal currentPrice;
    private String halt;
    private BigDecimal tradeLot;
    private BigDecimal tradeUnit;

    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "Asia/Bangkok")
    private Timestamp issueDate;

    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "Asia/Bangkok")
    private Timestamp maturityDate;

    private String bondType;

    @JsonIgnore
    private BigDecimal rowNum;

    @JsonIgnore
    private BigDecimal totalRecord;
}
