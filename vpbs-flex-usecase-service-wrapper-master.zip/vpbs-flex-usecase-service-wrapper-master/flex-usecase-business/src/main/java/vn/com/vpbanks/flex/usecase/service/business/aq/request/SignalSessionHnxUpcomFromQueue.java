package vn.com.vpbanks.flex.usecase.service.business.aq.request;

import lombok.Data;

@Data
public class SignalSessionHnxUpcomFromQueue {
    private String eventType;
    private String exchange;
    private String sessions;
    private String tradingSessionId;

}
