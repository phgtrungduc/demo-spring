package vn.com.vpbanks.flex.usecase.service.business.order.repository;

import vn.com.vpbanks.flex.usecase.service.business.order.repository.vo.CodeDVO;

import java.util.List;

public interface AllCodeDAO {
    List<CodeDVO> findCodeByCdTypeAndCdName(String cdType, String cdName);
}
