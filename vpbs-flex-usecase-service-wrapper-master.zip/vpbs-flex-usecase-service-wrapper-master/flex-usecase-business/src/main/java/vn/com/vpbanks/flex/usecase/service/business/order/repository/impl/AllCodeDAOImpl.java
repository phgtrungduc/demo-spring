package vn.com.vpbanks.flex.usecase.service.business.order.repository.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import vn.com.vpbanks.flex.usecase.service.business.order.repository.AllCodeDAO;
import vn.com.vpbanks.flex.usecase.service.business.order.repository.vo.CodeDVO;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;

@Component
@RequiredArgsConstructor
public class AllCodeDAOImpl implements AllCodeDAO {

    private final EntityManager entityManager;
    @Value("${spring.datasource.hikari.schema}")
    private String schema;

    @Override
    public List<CodeDVO> findCodeByCdTypeAndCdName(String cdType, String cdName) {

        StringBuilder queryBuilder = new StringBuilder();
        queryBuilder
                .append("  SELECT CDTYPE, CDNAME, CDVAL, CDCONTENT, EN_CDCONTENT, CHSTATUS          ")
                .append("  FROM " + schema + ".ALLCODE                                                  ")
                .append("  WHERE CDNAME = :cdName                                                   ")
                .append("  	AND CDTYPE = :cdType                                                    ");

        Query query = entityManager.createNativeQuery(queryBuilder.toString(), CodeDVO.class);
        query.setParameter("cdName", cdName);
        query.setParameter("cdType", cdType);
        List<CodeDVO> codeDVOS = query.getResultList();
        return codeDVOS;
    }
}
