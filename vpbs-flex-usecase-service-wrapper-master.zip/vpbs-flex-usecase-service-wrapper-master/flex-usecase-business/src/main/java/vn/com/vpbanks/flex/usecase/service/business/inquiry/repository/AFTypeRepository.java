package vn.com.vpbanks.flex.usecase.service.business.inquiry.repository;

import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.AFTypeResponse;

public interface AFTypeRepository {
    AFTypeResponse getAfTypeInfo(String afType);
}
