package vn.com.vpbanks.flex.usecase.service.business.cash.repository;

import vn.com.vpbanks.flex.usecase.service.business.cash.repository.vo.BankNoStroDVO;
import vn.com.vpbanks.flex.usecase.service.business.cash.repository.vo.CashStatementHistVO;
import vn.com.vpbanks.flex.usecase.service.business.cash.request.*;
import vn.com.vpbanks.flex.usecase.service.business.cash.response.HoldBalanceResponse;
import vn.com.vpbanks.flex.usecase.service.business.cash.response.HoldStockResponse;
import vn.com.vpbanks.flex.usecase.service.business.cash.response.SecuritiesStatementResponse;
import vn.com.vpbanks.flex.usecase.service.business.cash.response.UnHoldEODResponse;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.StoredProcedureError;

import java.util.List;

public interface CashRepository {

    List<BankNoStroDVO> getBankNoStro();

    StoredProcedureError increaseMoney(String requestId, String custId, String accountId, String bankId, Long amount, String desc, String isNotiSms, String via, String ipAddress);

    StoredProcedureError internalTransfer(InternalTransferRequest internalTransferRequest, String ipAddress, String requestId);

    StoredProcedureError blockAmount(BlockAmountRequest blockAmountRequest, String ipAddress, String requestId);

    StoredProcedureError unBlockAmount(BlockAmountRequest blockAmountRequest, String ipAddress, String requestId);

    List<SecuritiesStatementResponse> getSecuritiesStatement(String accountId, String fromDate, String toDate, String symbol);

    List<CashStatementHistVO> getCashStatementHist(CashStatementHistRequest cashStatementHistRequest);

    StoredProcedureError unHoldStock(UnHoldStockRequest unHoldStockRequest);

    StoredProcedureError holdStock(HoldStockRequest holdStockRequest);

    StoredProcedureError unHoldBalance(UnHoldBalanceRequest unHoldBalanceRequest);

    StoredProcedureError holdBalance(HoldBalanceRequest holdBalanceRequest);

    List<HoldStockResponse> getHoldStock(String custodyCd, String accountNo);

    List<UnHoldEODResponse> getUnHoldEOD();

    List<HoldBalanceResponse> getHoldBalance(String custodyCd, String accountNo);
}
