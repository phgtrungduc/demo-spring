package vn.com.vpbanks.flex.usecase.service.business.broker.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import vn.com.vpbanks.flex.usecase.service.business.broker.repository.BrokerRepository;
import vn.com.vpbanks.flex.usecase.service.business.broker.repository.vo.CustomerOfBrokerDVO;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.BrokerRequest;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.ReGrpLnkRequest;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.RightOffRegisterRequest;
import vn.com.vpbanks.flex.usecase.service.business.broker.request.TransferStockRequest;
import vn.com.vpbanks.flex.usecase.service.business.broker.service.BrokerService;
import vn.com.vpbanks.flex.usecase.service.common.dto.request.BaseRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseStoredProcedureResponse;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.StoredProcedureError;
import vn.com.vpbanks.flex.usecase.service.common.utils.CommonUtils;

import javax.transaction.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class BrokerServiceImpl implements BrokerService {

    private final BrokerRepository brokerRepository;

    private static final String SUCCESS_CODE = "0";

    @Override
    public BaseResponse addBroker(BaseRequest<BrokerRequest> brokerRequest, String ipAddress) {
        BaseResponse baseResponse;
        try {
            BrokerRequest data = brokerRequest.getData();
            String requestId = brokerRequest.getRequestId();

            StoredProcedureError response = brokerRepository.addBroker(data, ipAddress, requestId);

            if (SUCCESS_CODE.equals(response.getErrCd())) {
                baseResponse = BaseResponse.ofSucceeded();
                baseResponse.setData(response);
                return baseResponse;
            }
            baseResponse = BaseResponse.ofFailedFlexResponse(response.getErrParam());
            baseResponse.setData(response);
            return baseResponse;
        } catch (Exception ex) {
            log.error("add broker error {}", CommonUtils.handlerError(ex));
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            return baseResponse;
        }
    }

    @Override
    public BaseResponse addReGrpLink(ReGrpLnkRequest reGrpLnkRequest, String ipAddress) {
        BaseResponse baseResponse;
        BaseStoredProcedureResponse baseStoredProcedureResponse = brokerRepository.addReGrpLink(reGrpLnkRequest, ipAddress);
        if (SUCCESS_CODE.equals(baseStoredProcedureResponse.getErrCd())) {
            baseResponse = BaseResponse.ofSucceeded();
            baseResponse.setData(baseStoredProcedureResponse.getData());
            return baseResponse;
        }
        StoredProcedureError storedProcedureError = new StoredProcedureError();
        storedProcedureError.setErrParam(baseStoredProcedureResponse.getErrMsg());
        storedProcedureError.setErrCd(baseStoredProcedureResponse.getErrCd());

        baseResponse = BaseResponse.ofFailedFlexResponse(storedProcedureError);
        return baseResponse;
    }

    @Override
    public BaseResponse internalStockTransfer(TransferStockRequest transferStockRequest, String ipAddress) {
        BaseResponse baseResponse;
        try {
            String requestId = transferStockRequest.getRequestId();
            StoredProcedureError response = brokerRepository.addTransferStock(transferStockRequest, ipAddress, requestId);

            if (SUCCESS_CODE.equals(response.getErrCd())) {
                baseResponse = BaseResponse.ofSucceeded();
                baseResponse.setData(response);
                return baseResponse;
            }
            baseResponse = BaseResponse.ofFailedFlexResponse(response.getErrParam());
            baseResponse.setData(response);
            return baseResponse;
        } catch (Exception ex) {
            log.error("add addTransferStock error {}", CommonUtils.handlerError(ex));
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            return baseResponse;
        }
    }

    @Override
    public BaseResponse addRightOffRegister(RightOffRegisterRequest rightOffRegisterRequest, String ipAddress) {
        BaseResponse baseResponse;
        try {
            String requestId = rightOffRegisterRequest.getRequestId();
            StoredProcedureError response = brokerRepository.addRightOffRegister(rightOffRegisterRequest, ipAddress, requestId);

            if (SUCCESS_CODE.equals(response.getErrCd())) {
                baseResponse = BaseResponse.ofSucceeded();
                baseResponse.setData(response);
                return baseResponse;
            }
            baseResponse = BaseResponse.ofFailedFlexResponse(response.getErrParam());
            baseResponse.setData(response);
            return baseResponse;
        } catch (Exception ex) {
            log.error("add addRightOffRegiter error {}", CommonUtils.handlerError(ex));
            baseResponse = BaseResponse.ofFailedException(ex.getMessage());
            return baseResponse;
        }
    }

    @Override
    public BaseResponse getCustomerOfBroker(String reCusToDyCd) {
        BaseResponse baseResponse;
        BaseStoredProcedureResponse storedProcedureResponse = brokerRepository.getCustomerOfBroker(reCusToDyCd);

        if (SUCCESS_CODE.equals(storedProcedureResponse.getErrCd())) {
            baseResponse = BaseResponse.ofSucceeded(storedProcedureResponse.getData());
            return baseResponse;
        }

        StoredProcedureError storedProcedureError = new StoredProcedureError();
        storedProcedureError.setErrCd(storedProcedureResponse.getErrCd());
        storedProcedureError.setErrParam(storedProcedureResponse.getErrMsg());
        baseResponse = BaseResponse.ofFailedFlexResponse(storedProcedureError);

        return baseResponse;
    }

    @Override
    public BaseResponse getBrokerInfo(String custoDyCd) {
        BaseResponse baseResponse;
        BaseStoredProcedureResponse storedProcedureResponse = brokerRepository.getBrokerInfo(custoDyCd);

        if (SUCCESS_CODE.equals(storedProcedureResponse.getErrCd())) {
            baseResponse = BaseResponse.ofSucceeded(storedProcedureResponse.getData());
            return baseResponse;
        }

        StoredProcedureError storedProcedureError = new StoredProcedureError();
        storedProcedureError.setErrCd(storedProcedureResponse.getErrCd());
        storedProcedureError.setErrParam(storedProcedureResponse.getErrMsg());
        baseResponse = BaseResponse.ofFailedFlexResponse(storedProcedureError);

        return baseResponse;
    }

    @Override
    public BaseResponse getRightInfo(String fromDate, String toDate, String afAcctNo, String isCom, String symbol, String caType) {

        BaseStoredProcedureResponse storedProcedureResponse = brokerRepository.getRightInfo(fromDate, toDate, afAcctNo, isCom, symbol, caType);

        BaseResponse baseResponse = BaseResponse.ofSucceeded(storedProcedureResponse.getData());
        return baseResponse;
    }
}
