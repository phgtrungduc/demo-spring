package vn.com.vpbanks.flex.usecase.service.business.aq.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import vn.com.vpbanks.flex.usecase.service.business.aq.request.SmartOtpMessageFromQueue;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SmartOtpNotification implements Serializable {
    private String eventType;
    private String custId;
    private String custoDyCd;
    private String status;

    public SmartOtpNotification(SmartOtpMessageFromQueue smartOtpMessageFromQueue) {
        this.eventType = smartOtpMessageFromQueue.getEVENTTYPE();
        this.custId = smartOtpMessageFromQueue.getCUSTID();
        this.custoDyCd = smartOtpMessageFromQueue.getCUSTODYCD();
        this.status = smartOtpMessageFromQueue.getSTATUS();
    }
}
