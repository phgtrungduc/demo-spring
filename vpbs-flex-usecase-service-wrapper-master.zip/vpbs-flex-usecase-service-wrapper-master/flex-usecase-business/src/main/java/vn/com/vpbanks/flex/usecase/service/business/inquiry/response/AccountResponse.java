package vn.com.vpbanks.flex.usecase.service.business.inquiry.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;
import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class AccountResponse implements Serializable {

    @Id
    @JsonProperty("id")
    @Column(name = "ID")
    private String id;

    @JsonProperty("cfType")
    @Column(name = "CFTYPE")
    private String cfType;

    @JsonProperty("cusToDyCd")
    @Column(name = "CUSTODYCD")
    private String cusToDyCd;


    @JsonProperty("name")
    @Column(name = "NAME")
    private String name;

    @JsonProperty("currency")
    @Column(name = "CURRENCY")
    private String currency;

    @JsonProperty("coreBank")
    @Column(name = "COREBANK")
    private String coreBank;

    @JsonProperty("productTypeName")
    @Column(name = "PRODUCTTYPENAME")
    private String productTypeName;

    @JsonProperty("enProductTypeName")
    @Column(name = "EN_PRODUCTTYPENAME")
    private String enProductTypeName;

    @JsonProperty("typeName")
    @Column(name = "TYPENAME")
    private String typeName;

    @JsonProperty("enTypeName")
    @Column(name = "ENTYPENAME")
    private String enTypeName;

    @JsonProperty("afAcctNoExt")
    @Column(name = "AFACCTNO_EXT")
    private String afAcctNoExt;

    @JsonProperty("enAfAcctNoExt")
    @Column(name = "EN_AFACCTNO_EXT")
    private String enAfAcctNoExt;

    @JsonProperty("productType")
    @Column(name = "PRODUCTTYPE")
    private String productType;

    @JsonProperty("isFcBond")
    @Column(name = "ISFCBOND")
    private String isFcBond;

    @JsonProperty("accountType")
    @Column(name = "ACCOUNTTYPE")
    private String accountType;

    @JsonProperty("status")
    @Column(name = "STATUS")
    private String status;

    @JsonProperty("afType")
    @Column(name = "aftype")
    private String afType;

    @Transient
    private String mobileSms;

    @Transient
    private String idCode;

}
