package vn.com.vpbanks.flex.usecase.service.business.aq.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CashNotificationFromQueue {
    private String EVENTTYPE;
    private String CUSTODYCD;
    private String AFACCTNO;
    private Number BALANCE;
    private Number BALDEFOVD;
    private Number AVLADVANCE;
}
