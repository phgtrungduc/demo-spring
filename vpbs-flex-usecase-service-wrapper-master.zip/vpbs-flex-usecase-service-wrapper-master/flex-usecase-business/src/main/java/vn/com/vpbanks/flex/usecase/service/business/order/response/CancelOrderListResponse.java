package vn.com.vpbanks.flex.usecase.service.business.order.response;

import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;

public class CancelOrderListResponse extends BaseResponse<CancelOrderResponse> {

}


