package vn.com.vpbanks.flex.usecase.service.business.aq.request;

import lombok.Data;

@Data
public class OpenAccountVSDNotificationFromQueue {
    private String EVENTTYPE;
    private String TYPE;
    private String STATUS;
    private String CUSTODYCD;
    private String IDNUMBER;
}
