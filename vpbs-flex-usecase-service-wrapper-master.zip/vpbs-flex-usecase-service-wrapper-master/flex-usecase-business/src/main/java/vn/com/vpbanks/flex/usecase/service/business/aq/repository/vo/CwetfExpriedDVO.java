package vn.com.vpbanks.flex.usecase.service.business.aq.repository.vo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class CwetfExpriedDVO implements Serializable {
    private String CUSTODYCD;
    private String CUSTID;
    private String ACCTNO;
    private String CODE_CO;
    private String SYMBOL;
    private String EXPDATE;
    private String TRADEPLACE;

    @JsonIgnore
    private String TEMPLATEID;

    public CwetfExpriedDVO(Object[] objects) {
        this.CUSTODYCD = (String) objects[0];
        this.CUSTID = (String) objects[1];
        this.ACCTNO = (String) objects[2];
        this.TEMPLATEID = (String) objects[3];
        this.SYMBOL = (String) objects[4];
        this.EXPDATE = (String) objects[5];
        this.TRADEPLACE = (String) objects[6];
        this.CODE_CO = (String) objects[7];
    }
}
