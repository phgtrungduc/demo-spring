package vn.com.vpbanks.flex.usecase.service.business.salesupport.repository.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.aggregation.StringOperators;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.repository.CustomersRepository;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.request.CustomerDirectIndirectIn;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.response.CustomerByBroker;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.response.CustomerDirectIndirect;
import vn.com.vpbanks.flex.usecase.service.business.salesupport.response.CustomerDirectIndirectDetail;
import vn.com.vpbanks.flex.usecase.service.common.constants.FilterCustomerType;
import vn.com.vpbanks.flex.usecase.service.common.utils.CommonUtils;
import vn.com.vpbanks.flex.usecase.service.common.utils.Constants;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class CustomersRepositoryImpl implements CustomersRepository {

    private final EntityManager entityManager;

    @Value("${spring.datasource.hikari.schema}")
    private String schema;

    private List<CustomerDirectIndirect> getCustomerDirectIndirectInfo(CustomerDirectIndirectIn customerDirectIndirectIn) {
        StringBuilder sql = new StringBuilder(Constants.SQL.WITH);

        sql.append(customerDirectIndirect());
        sql.append(Constants.SQL.COMMA);
        sql.append(departmentOfCustomer(customerDirectIndirectIn));

        sql.append(" SELECT null as custId, null as CUSTODYCD, null as reCustodyCd, null as reFullName, null as debt, count(*) total, null as subCusName");
        sql.append(" FROM allCustomersByBroker  customer LEFT JOIN excuteDepartment department on customer.brokerCustodyCd = department.broCustoryCd  ");
        Map<String, Object> valueParam = conđitionComstomers(sql, customerDirectIndirectIn, null, false);
        sql.append(" UNION ALL   ");
        sql.append(" (SELECT DISTINCT customer.custId as custId, customer.cusCustomer as CUSTODYCD, customer.brokerCustodyCd as reCustodyCd, customer.brokerFullName as reFullName, department.departmentName as debt, 0 total, customer.cusFullName subCusName ");
        sql.append(" from allCustomersByBroker customer LEFT JOIN excuteDepartment department on customer.brokerCustodyCd = department.broCustoryCd ");
        valueParam = conđitionComstomers(sql, customerDirectIndirectIn, valueParam, true);
//        sql.append(" order by ");
//        if(!CollectionUtils.isEmpty(customerDirectIndirectIn.getCustomerFavourites())){
//            sql.append(" CASE WHEN customer.cusCustomer in :orderBys THEN 1 ELSE 2 END, ");
//            valueParam.put("orderBys", customerDirectIndirectIn.getCustomerFavourites());
//        }
//        sql.append("  customer.cusFullName ASC ");
        if (null != customerDirectIndirectIn.getPage() && null != customerDirectIndirectIn.getSize()) {
            sql.append(" OFFSET :page ROWS FETCH NEXT :size ROWS ONLY ");
        }
        sql.append(" ) ");

        try {

            Query query = entityManager.createNativeQuery(sql.toString());
            if (null != customerDirectIndirectIn.getPage() && null != customerDirectIndirectIn.getSize()) {
                query.setParameter("page", customerDirectIndirectIn.getPage() * customerDirectIndirectIn.getSize());
                query.setParameter("size", customerDirectIndirectIn.getSize());
            }
            mappingParamSql(valueParam, query);

            List<Object[]> rows = query.getResultList();
            if (CollectionUtils.isEmpty(rows)) {
                return null;
            }
            List<CustomerDirectIndirect> customerDirectIndirects = new ArrayList<>(rows.size());
            for (Object[] row : rows) {
                CustomerDirectIndirect customerDirectIndirect = new CustomerDirectIndirect();
                customerDirectIndirect.setUserId(CommonUtils.safeToString(row[0]));
                customerDirectIndirect.setAccountNo(CommonUtils.safeToString(row[1]));
                customerDirectIndirect.setReCustodyCd(CommonUtils.safeToString(row[2]));
                customerDirectIndirect.setReFullName(CommonUtils.safeToString(row[3]));
                customerDirectIndirect.setDept(CommonUtils.safeToStringSplit(row[4], ","));
                customerDirectIndirect.setTotalRecord(CommonUtils.safeToBigDecimal(row[5]));
                customerDirectIndirects.add(customerDirectIndirect);
            }
            return customerDirectIndirects;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    private List<String> getAllAccountNoByCustId(List<String> custIds) {
        StringBuilder sql = new StringBuilder();
        sql.append(allAccountByCustId());
        try {

            Query query = entityManager.createNativeQuery(sql.toString());
            query.setParameter("custIds", custIds);

            List<Object[]> rows = query.getResultList();
            if (CollectionUtils.isEmpty(rows)) {
                return null;
            }
            List<String> accountNos = new ArrayList<>();
            for (Object row : rows) {
                accountNos.add(CommonUtils.safeToString(row));

            }
            return accountNos;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    private List<String> getCustId(List<CustomerDirectIndirect> customersDirectIndirect) {
        if (CollectionUtils.isEmpty(customersDirectIndirect)) {
            return Arrays.asList();
        }

        return customersDirectIndirect.stream().filter(Objects::nonNull).map(CustomerDirectIndirect::getUserId).collect(Collectors.toList());
    }

    private void getAssetsCustomer(List<CustomerDirectIndirect> customersDirectIndirect, CustomerDirectIndirectIn customerDirectIndirectIn, List<String> accountNos) {
        if (CollectionUtils.isEmpty(customersDirectIndirect)) {
            return;
        }
        try {

            StringBuilder sql = assets();
            Map<String, Object> conditionSql = new HashMap<>();
            if (!Strings.isEmpty(customerDirectIndirectIn.getFromNav())) {
                sql.append(" AND (balance + CIBALANCE) >= :fromNav ");
                conditionSql.put("fromNav", CommonUtils.safeToInteger(customerDirectIndirectIn.getFromNav()));
            }

            if (!Strings.isEmpty(customerDirectIndirectIn.getToNav())) {
                sql.append(" AND (balance + CIBALANCE) <= :toNav ");
                conditionSql.put("toNav", CommonUtils.safeToInteger(customerDirectIndirectIn.getToNav()));
            }

            if (!Strings.isEmpty(customerDirectIndirectIn.getFromMar())) {
                sql.append(" AND marginAmt >= :fromMar ");
                conditionSql.put("fromMar", CommonUtils.safeToInteger(customerDirectIndirectIn.getFromMar()));
            }

            if (!Strings.isEmpty(customerDirectIndirectIn.getToMar())) {
                sql.append(" AND marginAmt <= :toMar ");
                conditionSql.put("toMar", CommonUtils.safeToInteger(customerDirectIndirectIn.getToMar()));
            }

            Query query = entityManager.createNativeQuery(sql.toString());
            query.setParameter("accountIds", accountNos);
            mappingParamSql(conditionSql, query);


            List<Object[]> rows = query.getResultList();
            if (CollectionUtils.isEmpty(rows)) {
                customersDirectIndirect.clear();
                return;
            }

            Map<String, CustomerDirectIndirect> map = new HashMap<>();
            for (CustomerDirectIndirect customerDirectIndirect : customersDirectIndirect) {
                if (Objects.isNull(customerDirectIndirect)) {
                    continue;
                }
                map.put(customerDirectIndirect.getAccountNo(), customerDirectIndirect);

            }

            String afacctno;
            for (Object[] row : rows) {
                afacctno = CommonUtils.safeToString(row[0]);
                if (Strings.isEmpty(afacctno)) {
                    continue;
                }
                CustomerDirectIndirect customerDirectIndirect = map.get(afacctno);

                customerDirectIndirect.setNav(CommonUtils.safeToBigDecimal(row[1]).add(CommonUtils.safeToBigDecimal(row[2])));
                customerDirectIndirect.setCasa(CommonUtils.safeToBigDecimal(row[2]));
                customerDirectIndirect.setDebt(CommonUtils.safeToBigDecimal(row[15]).add(CommonUtils.safeToBigDecimal(row[18])).add(CommonUtils.safeToBigDecimal(row[26])).add(CommonUtils.safeToBigDecimal(row[31])).add(CommonUtils.safeToBigDecimal(row[14])).add(CommonUtils.safeToBigDecimal(row[13])).add(CommonUtils.safeToBigDecimal(row[16])));
                customerDirectIndirect.setMargin(CommonUtils.safeToBigDecimal(row[13]));


                customerDirectIndirect.setIseInvest("Y");
                if (CommonUtils.safeToBigDecimal(row[37]).equals(BigDecimal.ZERO) && CommonUtils.safeToBigDecimal(row[36]).equals(BigDecimal.ZERO)) {
                    customerDirectIndirect.setIseInvest("N");
                }
            }
//            return customerDirectIndirects;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
//        return null;
    }

    private void mappingParamSql(Map<String, Object> paramValue, Query query) {
        if (CollectionUtils.isEmpty(paramValue)) {
            return;
        }

        paramValue.entrySet().stream().filter(Objects::nonNull).forEach(param -> {
            query.setParameter(param.getKey(), param.getValue());
        });

    }

    private Map<String, Object> conđitionComstomers(StringBuilder sql, CustomerDirectIndirectIn customerDirectIndirectIn, Map<String, Object> valueParam, boolean isCondition) {
        if (CollectionUtils.isEmpty(valueParam)) {
            valueParam = new HashMap<>();
        }
        if (Objects.isNull(customerDirectIndirectIn)) {
            return valueParam;
        }
        sql.append("WHERE 1 = 1 ");
        valueParam.put("custodyCd", CommonUtils.toUpper(customerDirectIndirectIn.getAccountNo()));
        if (!Strings.isEmpty(customerDirectIndirectIn.getOrderBroker())) {
            valueParam.put("orderBroker", CommonUtils.toUpper(customerDirectIndirectIn.getOrderBroker()));
        }

        if (!Strings.isEmpty(customerDirectIndirectIn.getAccount())) {
            sql.append(" AND ( ");
            sql.append(" cusCustomer LIKE :account ");
            sql.append(" OR cusMobile LIKE :account  ");
            sql.append(" OR cusFullName LIKE  :account  ");
            sql.append(" OR cusIdCode LIKE :account  ");
            sql.append(" ) ");
            valueParam.put("account", "%" + CommonUtils.toUpper(customerDirectIndirectIn.getAccount()) + "%");
        }
        if (isCondition && !CollectionUtils.isEmpty(customerDirectIndirectIn.getDepts())) {
            sql.append(" AND ( ");
            for (int index = 0; index < customerDirectIndirectIn.getDepts().size(); index++) {
                if (index > 0) {
                    sql.append(" OR");
                }
                sql.append(" department.departmentName LIKE :dept");
                sql.append(index);
                sql.append(" ");
                valueParam.put("dept" + index, "%" + CommonUtils.toUpper(customerDirectIndirectIn.getDepts().get(index)) + "%");
            }
            sql.append(" ) ");
        }
        if (!CollectionUtils.isEmpty(customerDirectIndirectIn.getCus())) {
            sql.append(" AND ( ");
            sql.append(" cusCustomer IN ( :customerCds ) )");
            valueParam.put("customerCds", CommonUtils.toUpper(customerDirectIndirectIn.getCus()));
        }

        if (!CollectionUtils.isEmpty(customerDirectIndirectIn.getReCustodyCd())) {
            sql.append(" AND ( ");
            sql.append(" brokerCustodyCd IN ( :reCustomerCds ) )");
            valueParam.put("reCustomerCds", customerDirectIndirectIn.getReCustodyCd());
        }

        return valueParam;
    }

    @Override
    public List<CustomerDirectIndirect> getCustomerDirectIndirect(CustomerDirectIndirectIn customerDirectIndirectIn) {

        List<CustomerDirectIndirect> customersDirectIndirect = getCustomerDirectIndirectInfo(customerDirectIndirectIn);
//        List<String> accountNos = getAllAccountNoByCustId(getCustId(customersDirectIndirect));
//        getAssetsCustomer(customersDirectIndirect, customerDirectIndirectIn, accountNos);

        return customersDirectIndirect;
    }

    @Override
    public List<CustomerDirectIndirect> getOrderCustomerDirectIndirect(CustomerDirectIndirectIn customerDirectIndirectIn) {
        StringBuilder sql = new StringBuilder(Constants.SQL.WITH);

        sql.append(customerDirectIndirect());
        sql.append(Constants.SQL.COMMA);
        sql.append(departmentOfCustomer(customerDirectIndirectIn));
        sql.append(", createBy (orderCustodyCd, orderName,  orderid) as ( select cf.CUSTODYCD, cf.FULLNAME, od1.orderid \n" +
                "from " + schema + ".ODMAST od1\n" +
                "         INNER JOIN " + schema + ".RECFLNK rec ON od1.TLID = rec.TLID\n" +
                "         INNER JOIN " + schema + ".CFMAST cf ON rec.CUSTID = cf.CUSTID AND od1.orderid = :orderId \n" +
                "UNION\n" +
                "select cf.CUSTODYCD, cf.FULLNAME, od2.orderid \n" +
                "from " + schema + ".ODMASTHIST od2\n" +
                "         INNER JOIN " + schema + ".RECFLNK rec ON od2.TLID = rec.TLID\n" +
                "         INNER JOIN " + schema + ".CFMAST cf ON rec.CUSTID = cf.CUSTID AND od2.orderid = :orderId  ORDER BY orderid DESC OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY ) ");

        if (!Objects.isNull(customerDirectIndirectIn) && !Strings.isEmpty(customerDirectIndirectIn.getOrderBroker())) {
            sql.append(" ( SELECT null as custId, cf.CUSTODYCD as CUSTODYCD, cf.FULLNAME as cusFullName, null as reCustodyCd, null as reFullName, null as debt, null subCusName,  'orderBroker' as status, null as orderCustodyCd, null as orderName ");
            sql.append(" FROM " + schema + ".CFMAST cf WHERE cf.CUSTODYCD = :orderBroker  ) ");
            sql.append(" union all ");

        }
        sql.append(" (SELECT DISTINCT customer.custId as custId, customer.cusCustomer as CUSTODYCD, customer.cusFullName      as cusFullName, customer.brokerCustodyCd as reCustodyCd, customer.brokerFullName as reFullName, department.departmentName as debt, customer.cusFullName subCusName, 'broker' as status , (SELECT orderCustodyCd FROM createBy OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY) as orderCustodyCd, (SELECT orderName   FROM createBy OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY) as orderName ");
        sql.append(" from allCustomersByBroker customer LEFT JOIN excuteDepartment department on customer.brokerCustodyCd = department.broCustoryCd ");
        Map<String, Object> valueParam = conđitionComstomers(sql, customerDirectIndirectIn, null, true);

        sql.append(" ) ");

        sql.append(" order by ");
        if (!CollectionUtils.isEmpty(customerDirectIndirectIn.getCustomerFavourites())) {
            sql.append(" CASE WHEN customer.cusCustomer in :orderBys THEN 1 ELSE 2 END, ");
            valueParam.put("orderBys", customerDirectIndirectIn.getCustomerFavourites());
        }
        sql.append("  CUSTODYCD ASC ");
        if (null != customerDirectIndirectIn.getPage() && null != customerDirectIndirectIn.getSize()) {
            sql.append(" OFFSET :page ROWS FETCH NEXT :size ROWS ONLY ");
        }

        try {

            valueParam.put("orderId", Strings.isEmpty(customerDirectIndirectIn.getOrderId()) ? Strings.EMPTY : customerDirectIndirectIn.getOrderId());
            Query query = entityManager.createNativeQuery(sql.toString());
            if (null != customerDirectIndirectIn.getPage() && null != customerDirectIndirectIn.getSize()) {
                query.setParameter("page", customerDirectIndirectIn.getPage() * customerDirectIndirectIn.getSize());
                query.setParameter("size", customerDirectIndirectIn.getSize());
            }
            mappingParamSql(valueParam, query);

            List<Object[]> rows = query.getResultList();
            if (CollectionUtils.isEmpty(rows)) {
                return null;
            }
            List<CustomerDirectIndirect> customerDirectIndirects = new ArrayList<>(rows.size());
            for (Object[] row : rows) {
                CustomerDirectIndirect customerDirectIndirect = new CustomerDirectIndirect();
                customerDirectIndirect.setUserId(CommonUtils.safeToString(row[0]));
                customerDirectIndirect.setAccountNo(CommonUtils.safeToString(row[1]));
                customerDirectIndirect.setCusFullName(CommonUtils.safeToString(row[2]));
                customerDirectIndirect.setReCustodyCd(CommonUtils.safeToString(row[3]));
                customerDirectIndirect.setReFullName(CommonUtils.safeToString(row[4]));
                customerDirectIndirect.setDept(CommonUtils.safeToStringSplit(row[5], ","));
                customerDirectIndirect.setStatus(CommonUtils.safeToString(row[7]));
                customerDirectIndirect.setOrderCustodyCd(CommonUtils.safeToString(row[8]));
                customerDirectIndirect.setOrderName(CommonUtils.safeToString(row[9]));
                customerDirectIndirects.add(customerDirectIndirect);
            }
            return customerDirectIndirects;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    @Override
    public CustomerDirectIndirectDetail getCustomerDirectIndirectDetail(String agencyNo, String preBrokerNo, String customerAccountNo) {
        StringBuilder sql = new StringBuilder(Constants.SQL.WITH);
        sql.append(customerDirectIndirect());

        sql.append(" SELECT  DISTINCT  cusCustomer cusCustomer, idBrocker idBrocker, brokerCustodyCd brokerCustodyCd, brokerFullName brokerFullName");
        sql.append(" FROM allCustomersByBroker  WHERE cusCustomer = :customerCustodyCd AND brokerCustodyCd = :preBrokerNo  ");
        sql.append(" OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY\n ");
        try {
            Query query = entityManager.createNativeQuery(sql.toString());
            query.setParameter("preBrokerNo", preBrokerNo);
            query.setParameter("customerCustodyCd", customerAccountNo);
            query.setParameter("custodyCd", agencyNo);

            List<Object[]> rows = query.getResultList();
            if (Objects.isNull(rows)) {
                return null;
            }
            for (Object[] row : rows) {
                if (Objects.isNull(row)) {
                    continue;
                }
                CustomerDirectIndirectDetail customerDirectIndirectDetail = new CustomerDirectIndirectDetail();
                customerDirectIndirectDetail.setAccountNo(CommonUtils.safeToString(row[0]));
                customerDirectIndirectDetail.setReUserId(CommonUtils.safeToString(row[1]));
                customerDirectIndirectDetail.setReCustodyCd(CommonUtils.safeToString(row[2]));
                customerDirectIndirectDetail.setReFullName(CommonUtils.safeToString(row[3]));

                return customerDirectIndirectDetail;
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }


    private String customerDirectIndirect() {
        return " cte (AUTOID, PRGRPID, FULLNAME, CUSTID)\n" +
                "    AS (select r.AUTOID,\n" +
                "               R.PRGRPID,\n" +
                "               R.FULLNAME,\n" +
                "               cf.CUSTID\n" +
                "        from " + schema + ".REGRP R\n" +
                "                 INNER JOIN " + schema + ".CFMAST cf ON R.CUSTID = cf.CUSTID\n" +
                "            and R.STATUS = 'A'\n" +
                "            AND cf.CUSTODYCD = :custodyCd\n" +
                "        UNION ALL\n" +
                "        SELECT b.AUTOID,\n" +
                "               b.PRGRPID,\n" +
                "               b.FULLNAME,\n" +
                "               b.CUSTID\n" +
                "        FROM " + schema + ".REGRP b\n" +
                "                 INNER JOIN cte c\n" +
                "                            ON c.AUTOID = b.PRGRPID\n" +
                "        where b.STATUS = 'A')\n" +
                "   , cte2 (AUTOID, PRGRPID, FULLNAME, CUSTID)\n" +
                "    AS (select RF.AUTOID, NULL PRGRPID, NULL FULLNAME, cf.CUSTID\n" +
                "        from " + schema + ".REGRPLNK RF\n" +
                "                 INNER JOIN " + schema + ".CFMAST cf\n" +
                "                            ON RF.STATUS = 'A' AND RF.CUSTID = CF.CUSTID AND cf.CUSTODYCD = :custodyCd)\n" +
                "   , allBrocker (AUTOID, PRGRPID, FULLNAME, CUSTID) AS (select RF.AUTOID, null, cf.FULLNAME, cf.CUSTID\n" +
                "                                                        from cte c\n" +
                "                                                                 INNER JOIN " + schema + ".REGRPLNK RF ON c.AUTOID = RF.REFRECFLNKID AND RF.STATUS = 'A'\n" +
                "                                                                 INNER JOIN " + schema + ".CFMAST cf ON RF.CUSTID = CF.CUSTID  UNION  SELECT * FROM cte )\n" +
                "   , allBrocker2 (AUTOID, PRGRPID, FULLNAME, CUSTID) AS (select * from allBrocker UNION SELECT * FROM cte2 UNION \n" +
                "                                                                         (select r.AUTOID, \n" +
                "                                                                                 R.PRGRPID, \n" +
                "                                                                                 R.FULLNAME, \n" +
                "                                                                                 cf.CUSTID \n" +
                "                                                                          from " + schema + ".REGRP R \n" +
                "                                                                                   INNER JOIN " + schema + ".CFMAST cf \n" +
                "                                                                                              ON R.CUSTID = cf.CUSTID \n" +
                "                                                                                                  and R.STATUS = 'A' \n" +
                "                                                                                                  AND cf.CUSTODYCD = :custodyCd) )\n" +
                "   , allCustomersByBroker as (SELECT DISTINCT CFCUST.CUSTID    custId,\n" +
                "                                              CFCUST.CUSTODYCD cusCustomer,\n" +
                "                                              CFCUST.MOBILESMS CUSMOBILE,\n" +
                "                                              CFCUST.FULLNAME  cusFullName,\n" +
                "                                              CFCUST.IDCODE    cusIdCode,\n" +
                "                                              CFRE.CUSTID      idBrocker,\n" +
                "                                              CFRE.CUSTODYCD   brokerCustodyCd,\n" +
                "                                              CFRE.FULLNAME    brokerFullName,\n" +
                "                                              1                departmentId\n" +
                "                              FROM " + schema + ".REAFLNK LNK\n" +
                "                                       INNER JOIN " + schema + ".CFMAST CFCUST ON CFCUST.CUSTID = LNK.AFACCTNO\n" +
                "                                       INNER JOIN " + schema + ".REMAST MST ON MST.ACCTNO = LNK.REACCTNO\n" +
                "                                       INNER JOIN " + schema + ".RETYPE TYP ON MST.ACTYPE = TYP.ACTYPE\n" +
                "                                       LEFT JOIN " + schema + ".CFMAST CFRE ON MST.CUSTID = CFRE.CUSTID\n" +
                "                                       INNER JOIN " + schema + ".RECFLNK RF ON LNK.refrecflnkid = RF.autoid\n" +
                "                                       INNER JOIN " + schema + ".brgrp br ON br.brid = cfcust.brid\n" +
                "\n" +
                "                              WHERE LNK.STATUS = 'A'\n" +
                "                                AND CFRE.CUSTID IN (SELECT CUSTID\n" +
                "                                                    FROM allBrocker2)) ";
    }

    private String departmentOfCustomer(CustomerDirectIndirectIn customerDirectIndirectIn) {
        String sql = new String();
        sql += "  department (CUSTID, AUTOID, PRGRPID, ACTYPE, FULLNAME, broCustoryCd)\n" +
                "    as (SELECT RL.CUSTID, R.AUTOID AUTOID, R.PRGRPID, R.ACTYPE, R.FULLNAME, cf.CUSTODYCD\n" +
                "        FROM " + schema + ".REGRPLNK RL\n" +
                "                 LEFT JOIN " + schema + ".REGRP R ON R.AUTOID = RL.REFRECFLNKID --AND r.CUSTID = rl.CUSTID\n" +
                "                 INNER JOIN " + schema + ".CFMAST cf ON RL.CUSTID = cf.CUSTID\n" +
                "        WHERE RL.STATUS = 'A'\n" +
                "          and R.STATUS = 'A'\n" +
                "          AND (cf.CUSTODYCD IN (select brokerCustodyCd from allCustomersByBroker";
        if (!Objects.isNull(customerDirectIndirectIn) && !Strings.isEmpty(customerDirectIndirectIn.getOrderBroker())) {

            sql += "  UNION ALL SELECT ";
            sql += " :orderBroker ";
            sql += "  brokerCustodyCd FROM DUAL ";
        }

        sql += " ))\n" +
                "        UNION ALL\n" +
                "        SELECT pb.CUSTID, pb.AUTOID, R.PRGRPID PRGRPID, R.ACTYPE, R.FULLNAME, pb.broCustoryCd\n" +
                "        FROM department pb\n" +
                "                 INNER JOIN " + schema + ".REGRP R\n" +
                "                            ON pb.PRGRPID = R.AUTOID AND R.STATUS = 'A')\n" +
                "" +
                "" +
                ", department1 (CUSTID, AUTOID, PRGRPID, ACTYPE, FULLNAME, broCustoryCd) \n" +
                "   as (SELECT R.CUSTID, R.AUTOID AUTOID, R.PRGRPID, R.ACTYPE, R.FULLNAME, cf.CUSTODYCD \n" +
                "       FROM " + schema + ".REGRP R \n" +

                "                INNER JOIN " + schema + ".CFMAST cf ON R.CUSTID = cf.CUSTID \n" +
                "       WHERE  R.STATUS = 'A' \n" +
                "         AND (cf.CUSTODYCD IN ( select brokerCustodyCd from allCustomersByBroker)) \n" +

                "       UNION ALL \n" +

                "       SELECT pb.CUSTID, pb.AUTOID, R.PRGRPID PRGRPID, R.ACTYPE, R.FULLNAME, pb.broCustoryCd \n" +

                "       FROM department1 pb \n" +

                "                INNER JOIN " + schema + ".REGRP R \n" +
                "                           ON pb.PRGRPID = R.AUTOID AND R.STATUS = 'A') \n" +

                "   , excuteDepartment (broCustoryCd, departmentName) as (select broCustoryCd, LISTAGG(FULLNAME, ',') WITHIN GROUP (ORDER BY FULLNAME) departmentName\n" +
                "                                                         from department\n" +
                "                                                         WHERE ACTYPE IN ('0001', '0005') group by  broCustoryCd " +
                " UNION select broCustoryCd,  LISTAGG(FULLNAME, ',') WITHIN GROUP (ORDER BY FULLNAME) departmentName from department1 \n" +
                "  WHERE ACTYPE IN ('0001', '0005') group by broCustoryCd )\n" +
                "  ";
        return sql;
    }

    private String allAccountByCustId() {
        return "SELECT af.acctno id\n" +
                "FROM  " + schema + ".AFMAST AF," + schema + ".CFMAST CF, " + schema + ".ALLCODE A0\n" +
                "WHERE AF.CUSTID=CF.CUSTID\n" +
                "  AND CF.custid IN :custIds \n" +
                "  AND AF.ISFIXACCOUNT='N'\n" +
                "  AND af.status <> 'C'\n" +
                "  AND A0.CDTYPE = 'CF' AND A0.CDNAME = 'PRODUCTTYPE' AND A0.CDVAL = AF.PRODUCTTYPE\n" +
                "UNION ALL\n" +
                "SELECT af.acctno id\n" +
                "\n" +
                "FROM (SELECT AUTHCUSTID,cfcustid, max(via) via, max(SERIALNUMSIG) SERIALNUMSIG, max(authtype) authtype\n" +
                "      from " + schema + ".otright\n" +
                "      where deltd <> 'Y' AND  TO_DATE(CURRENT_DATE, 'DD/MM/RRRR') <= EXPDATE AND NVL(CHSTATUS,'C') <> 'A'\n" +
                "      group BY  AUTHCUSTID,cfcustid) R, " + schema + ".AFMAST AF, " + schema + ".CFMAST CF, " + schema + ".CFMAST CFCUS, " + schema + ".ALLCODE A0\n" +
                "WHERE AF.CUSTID=CF.CUSTID\n" +
                "  AND R.AUTHCUSTID = CFCUS.custid\n" +
                "  AND R.cfcustid = CF.CUSTID\n" +
                "  AND R.AUTHCUSTID <> CF.CUSTID\n" +
                "  AND CFCUS.custid IN :custIds \n" +
                "  AND af.status <> 'C'\n" +
                "  AND AF.ISFIXACCOUNT='N'\n" +
                "  AND A0.CDTYPE = 'CF' AND A0.CDNAME = 'PRODUCTTYPE' AND A0.CDVAL = AF.PRODUCTTYPE\n";
    }

    private StringBuilder assets() {
        StringBuilder sql = new StringBuilder();
        sql.append("select\n" +
                "    CUSTODYCD,\n" +
                "    --1.Tien tren tieu khoan\n" +
                "    sum(CASE WHEN corebank = 'Y' THEN rcvamt + mst.careceiving  ELSE BALANCE - holdbalance +  mst.careceiving  END)  balance, --Tien tren tieu khoan\n" +
                "    -- Tien khong ky han\n" +
                "    SUM(CASE WHEN corebank = 'Y' THEN 0 ELSE cibalance - holdbalance END) CIBALANCE ,\n" +
                "    -- Tien co ky han\n" +
                "    SUM(TDBALANCE) ,\n" +
                "    -- Lai tien gui chua thanh toan\n" +
                "    SUM(INTBALANCE) interestBalance,\n" +
                "    -- Tien co tuc cho ve\n" +
                "    SUM(mst.careceiving),\n" +
                "    ---Tien cho ve T1\n" +
                "    SUM(mst.avladv_t1) receivingT1,\n" +
                "    ---Tien cho ve T2\n" +
                "    SUM(mst.avladv_t2) receivingT2,\n" +
                "    -----Tien cho ve T3\n" +
                "    SUM(mst.avladv_t3) receivingT3,\n" +
                "    --2.Tong gia tri chung khoan\n" +
                "    SUM(TOTALSEAMT)    securitiesAmt,\n" +
                "    --3.Tong phai tra\n" +
                "    SUM(TOTALODAMT)     totalDebtAmt, --Tong phai tra\n" +
                "    --3.1 No T3 chua thanh toan, ky quy\n" +
                "    SUM(execbuyamt + trfbuyamt)  secureamt , --No ky quy T3  + mua da khop trong ngay\n" +
                "    --3.0 No T3\n" +
                "    SUM(trfbuyamt),\n" +
                "    --3.3 No vay margin\n" +
                "    SUM(MRAMT)         marginAmt,\n" +
                "    --3.2 No bao lanh\n" +
                "    SUM(T0AMT)        t0DebtAmt, --No bao lanh\n" +
                "    --3.4 No vay ung truoc\n" +
                "    SUM(rcvadvamt)     advancedAmt,\n" +
                "    --3.5 No vay cam co chung khoan\n" +
                "    SUM(dfodamt)       dfDebtAmt,\n" +
                "    --3.6 Vay cam co tien gui\n" +
                "    SUM(TDODAMT)       tdDebtAmt,\n" +
                "    --3.7 No vay phi luu ky\n" +
                "    SUM(DEPOFEEAMT)    ciDepoFeeAcr,\n" +
                "    --3.7.1 No phi luu ky khong lam tron cho team copytrade\n" +
                "    SUM(DEPOFEEAMT_CT),\n" +
                "    --4. Tai san thuc co = 1+2-3\n" +
                "    SUM(balance - holdbalance + totalseamt - totalodamt +  mst.careceiving) netAssetValue,\n" +
                "    --6. Ky quy hien co\n" +
                "    --6.3 Tien gui co ky han ky quy\n" +
                "    SUM(mrcrlimit) ,\n" +
                "    --6.5 No phai tra\n" +
                "    SUM(-(totalodamt-dfodamt+paidamt)) debtAmt,\n" +
                "    --6.7 phi ung truoc toi da\n" +
                "    SUM(-AdvandFee) advanceMaxAmtFee,\n" +
                "    --6.6 Tien cho ve\n" +
                "    SUM(rcvamt)     receivingAmt,\n" +
                "    --8. Ty le ky quy hien tai\n" +
                "    SUM(marginRate),\n" +
                "    --10.No Phi dich vu SMS cua tai khoan\n" +
                "    SUM(smsfeeamt),\n" +
                "    -- Phi dich vu iBroker\n" +
                "    SUM(ibrokerfeeamt),\n" +
                "    SUM(holdbalance),\n" +
                "    --Ty le an toan\n" +
                "    SUM(mrirate),\n" +
                "    -- Ty le duy tri\n" +
                "    SUM(mrmrate),\n" +
                "    --Phi luu ky cong don\n" +
                "    SUM(cidepofeeacr) cidepofee,\n" +
                "    --Lai tam tinh Ibonds\n" +
                "    SUM(tdintamt),\n" +
                "    --So tien can nop them bo sung ve Rat\n" +
                "    SUM(ADDVND),\n" +
                "    --So tien can nop them bo sung ve Rdt\n" +
                "    SUM(ADDVND1),\n" +
                "--     SUM(corebank), SUM(bankacctno), SUM(bankname,\n" +
                "    --So tien phong toa\n" +
                "    SUM(emkamt),\n" +
                "    --So tien co the rut\n" +
                "    --     l_BALDEFOVD BALDEFOVD,\n" +
                "    SUM(eInvestAmt),\n" +
                "    SUM(einvestFix) --uyen.ntt them ASCEXT-1042\n" +
                "from\n" +
                "    (\n" +
                "        select\n" +
                "                                       --1.Tien tren tieu khoan\n" +
                "                                       round(nvl (ci.balance,0) + /*nvl (ci.emkamt,0)*/ +  nvl (ci.bamt,0)  + nvl (ci.rcvamt,0) + nvl (td.tdbalance,0) /*+ ci.crintacr + ci.tdintamt +  nvl(td.TDREPOINTAMT,0)*/) BALANCE, --Tien tren tieu khoan khoan bao gom lai tien gui va lai ibonds\n" +
                "                                       --1.1 --Tien khong ky han (bao gom tien phong toa)\n" +
                "                                       nvl (ci.balance,0) + /*nvl (ci.emkamt,0)*/ +  nvl (ci.bamt,0) CIBALANCE,\n" +
                "                                       --1.2 Tien co ky han\n" +
                "                                       nvl (td.tdbalance,0) TDBALANCE,\n" +
                "                                       --1.3 Tien cho ve\n" +
                "                                       ci.rcvamt, -- Tien ban cho nhan ve\n" +
                "                                       --1.4 Lai tien gui chua thanh toan\n" +
                "                                       round(nvl(ci.crintacr,0) + nvl(td.tdintamt,0)) INTBALANCE,\n" +
                "                                       --2.Tong gia tri chung khoan\n" +
                "                                       TOTALSEAMT,\n" +
                "                                       --3.Tong phai tra\n" +
                "                                       ci.dfodamt + ci.t0odamt + ci.mrodamt\n" +
                "                                           + round(ci.ovdcidepofee) + ci.execbuyamt + ci.trfbuyamt + ci.rcvadvamt + round(ci.cidepofeeacr)  TOTALODAMT, --Tong phai tra --3.0.0.0 --ASCEXT-1073 uyen.ntt\n" +
                "                                       --3.1 No T3\n" +
                "                                       ci.trfbuyamt,\n" +
                "                                       --3.2 No bao lanh\n" +
                "                                       ci.t0odamt T0AMT, --No bao lanh\n" +
                "                                       ----3.3 No ky quy\n" +
                "                                       ci.execbuyamt , --No ky quy da khop\n" +
                "                                       ci.bamt secureamt, --No ky quy da khop + chua khop\n" +
                "                                       --3.3 No vay margin\n" +
                "                                       ci.mrodamt MRAMT, --No Margin\n" +
                "                                       --3.4 No vay ung truoc\n" +
                "                                       ci.rcvadvamt,\n" +
                "                                       --3.5 No vay cam co chung khoan, phai tra ban deal\n" +
                "                                       ci.dfodamt,ci.paidamt,\n" +
                "                                       --3.6 Vay cam co tien gui\n" +
                "                                       0 TDODAMT, --3.0.0.0\n" +
                "                                       --3.7 No vay phi luu ky\n" +
                "                                       round(ci.ovdcidepofee) + round(ci.cidepofeeacr) DEPOFEEAMT, --No phi luu ky + phi lưu ky den han ASCEXT-1073 uyen.ntt\n" +
                "                                       --3.7.1 No phi luu ky khong lam tron cho team CTRF_CUTOFFTIME\n" +
                "                                       ci.ovdcidepofee + ci.cidepofeeacr DEPOFEEAMT_CT,\n" +
                "                                       --4. Tai san thuc co = 1+2-3\n" +
                "                                       --6. Ky quy hien co\n" +
                "                                       --6.3 Tien gui co ky han ky quy tiet kiem\n" +
                "                                       nvl( td.tdbalance,0) mrcrlimit,\n" +
                "                                       --6.7 Ph?ng tru?c t?i da\n" +
                "                                       -- nvl(ci.maxadvfee,0)  AdvandFee,\n" +
                "                                       -(ci.avladvance-(ci.avladv_t1+ci.avladv_t2+ci.avladv_t3- ci.rcvadvamt)) AdvandFee,\n" +
                "                                       --No phai tra\n" +
                "                                       --7. Thang du tai san\n" +
                "                                       --Ky quy hien co - Ky quy yeu cau\n" +
                "                                       --8. Ty le ky quy hien tai\n" +
                "            /*ci.marginrate_ex*/ ci.marginrate marginrate,\n" +
                "                                       --Ky quy hien co / Chung khoan duoc phep ky quy\n" +
                "                                       af.mrcrlimitmax,\n" +
                "                                       ci.advanceline,\n" +
                "                                       ci.avllimit,\n" +
                "                                       cim.holdbalance,\n" +
                "                                       --Tien cho ve T1\n" +
                "                                       ci.avladv_t1,\n" +
                "                                       ---Tien cho ve T2\n" +
                "                                       ci.avladv_t2,\n" +
                "                                       -----Tien cho ve T3\n" +
                "                                       ci.avladv_t3,\n" +
                "                                       ---Tien co tuc cho ve\n" +
                "                                       nvl(ca.careceiving,0) careceiving,\n" +
                "                                       ---No phi SMS\n" +
                "                                       nvl(sms.fee,0) smsfeeamt,\n" +
                "                                       0 ibrokerfeeamt,\n" +
                "                                       --ty le an toan\n" +
                "                                       ci.mrirate,\n" +
                "                                       --Ty le duy tri\n" +
                "                                       af.MRCRATE mrmrate, --uyen.ntt ASCEXT-772\n" +
                "                                       --Phi luu ky\n" +
                "                                       ci.cidepofeeacr,\n" +
                "                                       --Lai tam tinh Ibonds\n" +
                "            /*nvl(td.TDREPOINTAMT,0)*/ nvl(td.TDINTAMT,0) TDINTAMT,\n" +
                "                                       --So tien can nop them bo sung ve Rat\n" +
                "                                       case when aft.mnemonic<>'T3' then\n" +
                "                                                round((case when nvl(ci.marginrate,0) * af.mrmrate =0 then - nvl(ci.se_outstanding,0) else greatest( 0,- nvl(ci.se_outstanding,0) - nvl(ci.se_navaccount,0)\n" +
                "                                                                                                                                                                                        *100/AF.MRIRATE) end),0)\n" +
                "                                            else\n" +
                "                                                0\n" +
                "                                           end ADDVND,\n" +
                "                                       --So tien can nop them bo sung ve Rdt\n" +
                "                                       case when aft.mnemonic<>'T3' then --uyen.ntt ASCEXT-772 so tien nop bo sung ve Rdb\n" +
                "                                                round((case when nvl(ci.marginrate,0) * af.mrmrate =0 then - nvl(  LEAST( ci.se_outstanding+ ci.dclamtlimit,0)  ,0) else greatest( 0,- LEAST( ci.se_outstanding+ ci.dclamtlimit,0)  - nvl(ci.se_navaccount,0) *100/AF.MRCRATE) end),0)\n" +
                "                                            else 0\n" +
                "                                           end ADDVND1,\n" +
                "                                       af.corebank, af.bankacctno, af.bankname, ci.emkamt,\n" +
                "                                       NVL(trfeod.amt, 0) eInvestAmt,\n" +
                "                                       ci.afacctno afacctno,\n" +
                "                                       CUSTODYCD CUSTODYCD,\n" +
                "                                       --uyen.ntt them  einvestfix\n" +
                "                                       nvl(td.orgamt,0) einvestFix\n" +
                "        from " + schema + ".buf_ci_account ci, " + schema + ".afmast af, " + schema + ".cimast cim,\n" +
                "             (select afacctno,\n" +
                "                     sum((TRADE + DFTRADING + ABSTANDING + RESTRICTQTTY + BLOCKED + (buyqtty - buyingqtty) + se.receiving -( nvl(securities_receiving_t1,0)+nvl(securities_receiving_t2,0)+nvl(securities_receiving_t3,0)\n" +
                "                         +nvl(securities_receiving_t0,0)\n" +
                "                         ) + nvl(securities_receiving_t0,0) + nvl(securities_receiving_t1,0) +\n" +
                "                          nvl(securities_receiving_t2,0) +  greatest(se.remainqtty,0) - buyingqtty)*\n" +
                "                         --CASE WHEN nvl(to_number(inf.closeprice),0) <> 0 THEN to_number(inf.closeprice)\n" +
                "                         CASE WHEN nvl(si.basicprice,0) <> 0 THEN si.basicprice\n" +
                "                              ELSE se.costprice END\n" +
                "                         ) TOTALSEAMT\n" +
                "              from " + schema + ".buf_se_account se , securities_info si --, (SELECT * FROM stockinfor WHERE to_date(tradingdate,'dd/mm/rrrr') = v_currdate) inf\n" +
                "              where se.symbol = si.symbol --AND se.symbol = inf.symbol(+)\n" +
                "              group by se.afacctno\n" +
                "             ) sec, " + schema + "aftype aft,\n" +
                "             (SELECT sc.CUSTID, sum(SC.FEEAMT + SC.VATAMT - SC.PAIDFEEAMT- PAIDVATAMT) fee\n" +
                "              FROM  " + schema + ".smsfeeschd sc\n" +
                "              WHERE SC.FEEAMT + SC.VATAMT - SC.PAIDFEEAMT- PAIDVATAMT <> 0\n" +
                "              group by CUSTID) sms,\n" +
                "             (SELECT afacctno, SUM(AMT) AMT FROM " + schema + ".CITRFEOD WHERE status = 'P' AND afacctno IN ( :accountIds  ) group by afacctno) trfeod,\n" +
                "             (select mst.afacctno, sum(MST.BALANCE) TDBALANCE, SUM(MST.BALANCE)+ NVL(sum(MST.BLOCKAMT),0) ORGAMT,\n" +
                "                     sum(FN_TDMASTINTRATIO(MST.ACCTNO,current_date, MST.BALANCE)) TDINTAMT\n" +
                "              from " + schema + ".tdmast mst\n" +
                "              where  MST.DELTD<>'Y' AND MST.status in ('N','A') and mst.afacctno IN ( :accountIds )\n" +
                "              group by mst.afacctno) td,\n" +
                "             (SELECT SUM(case when cf.VAT = 'Y' then (cas.AMT - round(cam.pitrate * cas.amt / 100)) else cas.AMT end) careceiving, CAS.afacctno\n" +
                "              FROM " + schema + ".caschd CAS, " + schema + ".CAMAST CAM, " + schema + ".AFMAST AF, " + schema + ".CFMAST CF\n" +
                "              WHERE  CAS.status IN ('I','S','H') AND CAS.ISEXEC ='Y' AND CAM.CAMASTID = CAS.CAMASTID\n" +
                "                AND CAS.afacctno = AF.ACCTNO AND AF.CUSTID = CF.CUSTID\n" +
                "                AND afacctno IN ( :accountIds )\n" +
                "              GROUP BY afacctno) ca\n" +
                "        where ci.afacctno IN ( :accountIds ) and ci.afacctno = af.acctno\n" +
                "          and af.acctno = cim.acctno and af.custid = sms.custid(+)\n" +
                "          and  ci.afacctno = sec.afacctno(+)\n" +
                "          and ci.afacctno = td.afacctno(+)\n" +
                "          AND af.actype= aft.actype\n" +
                "          AND ci.afacctno = ca.afacctno(+)\n" +
                "          AND ci.afacctno = trfeod.afacctno(+)\n" +
                "    ) MST WHERE 1 = 1 group by CUSTODYCD ");
        return sql;
    }



    public List<CustomerByBroker> getCustomersByBroker(String filterCustomerType, List<String> preCustodyCds, List<String> listCustodyCd, List<String> listDept, Integer page, Integer size) {
        StringBuilder sql = new StringBuilder();

        if (FilterCustomerType.ALL.getcode().equalsIgnoreCase(filterCustomerType)) {
            sql.append(queryCustomersByBroker());
        } else if (FilterCustomerType.DIRECT.getcode().equalsIgnoreCase(filterCustomerType)) {
            sql.append(queryCustomerDirectByBroker());
        } else if (FilterCustomerType.INDIRECT.getcode().equalsIgnoreCase(filterCustomerType)) {
            return new ArrayList<>();
        }

        sql.append(Constants.SQL.COMMA);
        sql.append(departmentOfCustomerByBroker());

        Map<String, Object> valueParam = new HashMap<>();
        sql.append(" select DISTINCT data.* from ( SELECT DISTINCT customer.custId as custId, customer.cusCustomer as CUSTODYCD, customer.brokerCustodyCd as reCustodyCd, customer.brokerFullName as reFullName" +
                ", department.deptid,department.deptname ");
        sql.append(" from allCustomersByBroker customer " +
                "LEFT JOIN excuteDepartment department on customer.brokerCustodyCd = department.broCustoryCd "
        );
        valueParam = conditionComstomersByBroker(sql, preCustodyCds, listCustodyCd, listDept, valueParam);
        sql.append(" order by SUBSTR(customer.cusFullName, 0, 1) asc ) data ");
        if (!Objects.isNull(page) && !Objects.isNull(size)) {
            sql.append(" OFFSET :page ROWS FETCH NEXT :size ROWS ONLY ");
        }

        try {

            Query query = entityManager.createNativeQuery(sql.toString());
            if (!Objects.isNull(page) && !Objects.isNull(size)) {
                query.setParameter("page", page * size);
                query.setParameter("size", size);
            }

            mappingParamSql(valueParam, query);

            List<Object[]> rows = query.getResultList();
            if (CollectionUtils.isEmpty(rows)) {
                return null;
            }
            List<CustomerByBroker> customerDirectIndirects = new ArrayList<>(rows.size());
            for (Object[] row : rows) {
                CustomerByBroker customerDirectIndirect = new CustomerByBroker();
                customerDirectIndirect.setUserId(CommonUtils.safeToString(row[0]));
                customerDirectIndirect.setAccountNo(CommonUtils.safeToString(row[1]));
                customerDirectIndirect.setReCustodyCd(CommonUtils.safeToString(row[2]));
                customerDirectIndirect.setDeptId(CommonUtils.safeToString(row[3]));
                customerDirectIndirect.setDeptName(CommonUtils.safeToString(row[4]));
                customerDirectIndirects.add(customerDirectIndirect);
            }
            return customerDirectIndirects;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    private Map<String, Object> conditionComstomersByBroker(StringBuilder sql, List<String> preCustodyCds, List<String> listCustodyCd, List<String> listDept, Map<String, Object> valueParam) {
        if (CollectionUtils.isEmpty(valueParam)) {
            valueParam = new HashMap<>();
        }
        if (CollectionUtils.isEmpty(preCustodyCds)) {
            return valueParam;
        }

        sql.append("WHERE 1 = 1 ");
        valueParam.put("custodyCd", CommonUtils.toUpper(preCustodyCds));

        if (!CollectionUtils.isEmpty(listCustodyCd)) {
            sql.append(" AND ( ");
            sql.append(" cusCustomer IN ( :customerCds ) )");
            valueParam.put("customerCds", CommonUtils.toUpper(listCustodyCd));
        }

        if (!CollectionUtils.isEmpty(listDept)) {
            sql.append(" AND ( ");
            sql.append(" department.deptid IN ( :listDept ) )");
            valueParam.put("listDept", CommonUtils.toUpper(listDept));
        }

        return valueParam;
    }

    private String queryCustomersByBroker() {
        return "WITH  cte (AUTOID, PRGRPID, FULLNAME, CUSTID)\n" +
                "    AS (select r.AUTOID,\n" +
                "               R.PRGRPID,\n" +
                "               R.FULLNAME,\n" +
                "               cf.CUSTID\n" +
                "        from " + schema + ".REGRP R\n" +
                "                 INNER JOIN " + schema + ".CFMAST cf ON R.CUSTID = cf.CUSTID\n" +
                "            and R.STATUS = 'A'\n" +
                "            AND cf.CUSTODYCD IN ( :custodyCd ) \n" +
                "        UNION ALL\n" +
                "        SELECT b.AUTOID,\n" +
                "               b.PRGRPID,\n" +
                "               b.FULLNAME,\n" +
                "               b.CUSTID\n" +
                "        FROM " + schema + ".REGRP b\n" +
                "                 INNER JOIN cte c\n" +
                "--                             ON c.PRGRPID = b.AUTOID\n" +
                "                            ON c.AUTOID = b.PRGRPID\n" +
                "        where b.STATUS = 'A')\n" +
                "   , cte2 (AUTOID, PRGRPID, FULLNAME, CUSTID)\n" +
                "    AS (select RF.AUTOID, NULL PRGRPID, NULL FULLNAME, cf.CUSTID\n" +
                "        from " + schema + ".REGRPLNK RF\n" +
                "                 INNER JOIN " + schema + ".CFMAST cf\n" +
                "                            ON RF.STATUS = 'A' AND RF.CUSTID = CF.CUSTID AND cf.CUSTODYCD = :custodyCd )\n" +
                "   , allBrocker (AUTOID, PRGRPID, FULLNAME, CUSTID) AS (select RF.AUTOID, null, cf.FULLNAME, cf.CUSTID\n" +
                "                                                        from cte c\n" +
                "                                                                 INNER JOIN " + schema + ".REGRPLNK RF ON c.AUTOID = RF.REFRECFLNKID AND RF.STATUS = 'A'\n" +
                "                                                                 INNER JOIN " + schema + ".CFMAST cf ON RF.CUSTID = CF.CUSTID)\n" +
                "   , allBrocker2 (AUTOID, PRGRPID, FULLNAME, CUSTID) AS (select * from allBrocker UNION SELECT * FROM cte2 UNION \n" +
                "                                                                         (select r.AUTOID,\n" +
                "                                                                                 R.PRGRPID,\n" +
                "                                                                                 R.FULLNAME,\n" +
                "                                                                                 cf.CUSTID\n" +
                "                                                                          from " + schema + ".REGRP R\n" +
                "                                                                                   INNER JOIN " + schema + ".CFMAST cf\n" +
                "                                                                                              ON R.CUSTID = cf.CUSTID\n" +
                "                                                                                                  and R.STATUS = 'A'\n" +
                "                                                                                                  AND cf.CUSTODYCD = :custodyCd))\n" +
                "   , allCustomersByBroker as (SELECT DISTINCT CFCUST.CUSTID    custId,\n" +
                "                                              CFCUST.CUSTODYCD cusCustomer,\n" +
                "                                              CFCUST.MOBILESMS CUSMOBILE,\n" +
                "                                              CFCUST.FULLNAME  cusFullName,\n" +
                "                                              CFCUST.IDCODE    cusIdCode,\n" +
                "                                              CFRE.CUSTID      idBrocker,\n" +
                "                                              CFRE.CUSTODYCD   brokerCustodyCd,\n" +
                "                                              CFRE.FULLNAME    brokerFullName,\n" +
                "                                              1                departmentId\n" +
                "                              FROM " + schema + ".REAFLNK LNK\n" +
                "                                       INNER JOIN " + schema + ".CFMAST CFCUST ON CFCUST.CUSTID = LNK.AFACCTNO\n" +
                "                                       INNER JOIN " + schema + ".REMAST MST ON MST.ACCTNO = LNK.REACCTNO\n" +
                "                                       INNER JOIN " + schema + ".RETYPE TYP ON MST.ACTYPE = TYP.ACTYPE\n" +
                "                                       LEFT JOIN " + schema + ".CFMAST CFRE ON MST.CUSTID = CFRE.CUSTID\n" +
                "                                       INNER JOIN " + schema + ".RECFLNK RF ON LNK.refrecflnkid = RF.autoid\n" +
                "                                       INNER JOIN " + schema + ".brgrp br ON br.brid = cfcust.brid\n" +
                "\n" +
                "                              WHERE LNK.STATUS = 'A'\n" +
                "                                AND CFRE.CUSTID IN (SELECT CUSTID\n" +
                "                                                    FROM allBrocker2)) ";

    }


    private String queryCustomerDirectByBroker() {
        String query = "WITH  cte (AUTOID, PRGRPID, FULLNAME, CUSTID)\n" +
                "    AS (select r.AUTOID,\n" +
                "               null PRGRPID,\n" +
                "               null FULLNAME,\n" +
                "               cf.CUSTID\n" +
                "        from " + schema + ".REGRPLNK R\n" +
                "                 INNER JOIN " + schema + ".CFMAST cf ON R.CUSTID = cf.CUSTID\n" +
                "            and R.STATUS = 'A'\n" +
                "            AND cf.CUSTODYCD IN ( :custodyCd ) \n" +
                "        )\n" +
                "   , allCustomersByBroker as (SELECT DISTINCT CFCUST.CUSTID    custId,\n" +
                "                                              CFCUST.CUSTODYCD cusCustomer,\n" +
                "                                              CFCUST.MOBILESMS CUSMOBILE,\n" +
                "                                              CFCUST.FULLNAME  cusFullName,\n" +
                "                                              CFCUST.IDCODE    cusIdCode,\n" +
                "                                              CFRE.CUSTID      idBrocker,\n" +
                "                                              CFRE.CUSTODYCD   brokerCustodyCd,\n" +
                "                                              CFRE.FULLNAME    brokerFullName,\n" +
                "                                              1                departmentId\n" +
                "                              FROM " + schema + ".REAFLNK LNK\n" +
                "                                       INNER JOIN " + schema + ".CFMAST CFCUST ON CFCUST.CUSTID = LNK.AFACCTNO\n" +
                "                                       INNER JOIN " + schema + ".REMAST MST ON MST.ACCTNO = LNK.REACCTNO\n" +
                "                                       INNER JOIN " + schema + ".RETYPE TYP ON MST.ACTYPE = TYP.ACTYPE\n" +
                "                                       LEFT JOIN " + schema + ".CFMAST CFRE ON MST.CUSTID = CFRE.CUSTID\n" +
                "                                       INNER JOIN " + schema + ".RECFLNK RF ON LNK.refrecflnkid = RF.autoid\n" +
                "                                       INNER JOIN " + schema + ".brgrp br ON br.brid = cfcust.brid\n" +
                "\n" +
                "                              WHERE LNK.STATUS = 'A'\n" +
                "                                AND CFRE.CUSTID IN (SELECT CUSTID\n" +
                "                                                    FROM cte)) ";

        return query;
    }

    private String departmentOfCustomerByBroker() {
        String sql = new String();
        sql += "  department (CUSTID, AUTOID, PRGRPID, ACTYPE, FULLNAME, broCustoryCd)\n" +
                "    as (SELECT RL.CUSTID, R.AUTOID AUTOID, R.PRGRPID, R.ACTYPE, R.FULLNAME, cf.CUSTODYCD\n" +
                "        FROM " + schema + ".REGRPLNK RL\n" +
                "                 LEFT JOIN " + schema + ".REGRP R ON R.AUTOID = RL.REFRECFLNKID --AND r.CUSTID = rl.CUSTID\n" +
                "                 INNER JOIN " + schema + ".CFMAST cf ON RL.CUSTID = cf.CUSTID\n" +
                "        WHERE RL.STATUS = 'A'\n" +
                "          and R.STATUS = 'A'\n" +
                "          AND (cf.CUSTODYCD IN (select brokerCustodyCd from allCustomersByBroker";

        sql += " ))\n" +
                "        UNION ALL\n" +
                "        SELECT pb.CUSTID, pb.AUTOID, R.PRGRPID PRGRPID, R.ACTYPE, R.FULLNAME, pb.broCustoryCd\n" +
                "        FROM department pb\n" +
                "                 INNER JOIN " + schema + ".REGRP R\n" +
                "                            ON pb.PRGRPID = R.AUTOID AND R.STATUS = 'A')\n" +
                "   , excutedepartment (\n" +
                "    brocustorycd,\n" +
                "    deptname,\n" +
                "    deptid\n" +
                ") AS (\n" +
                "    SELECT\n" +
                "        department.brocustorycd,\n" +
                "        department.fullname deptname,\n" +
                "        CASE\n" +
                "            WHEN department.fullname LIKE '%VIP%' THEN\n" +
                "                'VIP'\n" +
                "            WHEN department.fullname LIKE '%EPartner%' THEN\n" +
                "                'ePartner'\n" +
                "            ELSE\n" +
                "                substr(department.fullname, 18, 4)\n" +
                "        END      deptid\n" +
                "    FROM\n" +
                "             department\n" +
                "        INNER JOIN (\n" +
                "            SELECT\n" +
                "                MIN(department.actype) AS min_actype,\n" +
                "                department.brocustorycd\n" +
                "            FROM\n" +
                "                department\n" +
                "            WHERE\n" +
                "                ( department.actype = '0001'\n" +
                "                  OR department.actype = '0005' )\n" +
                "            GROUP BY\n" +
                "                department.brocustorycd\n" +
                "        ) bptemp ON bptemp.brocustorycd = department.brocustorycd\n" +
                "                    AND bptemp.min_actype = department.actype\n" +
                "    WHERE\n" +
                "        department.actype IN ( '0001', '0005' )\n" +
                "    GROUP BY\n" +
                "        department.brocustorycd,\n" +
                "        department.fullname\n" +
                ") ";
        return sql;
    }
}
