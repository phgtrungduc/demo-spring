package vn.com.vpbanks.flex.usecase.service.business.broker.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import vn.com.vpbanks.flex.usecase.service.common.annotation.NotEmptyCharacter;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RightOffRegisterRequest {
    @NotEmptyCharacter
    @JsonProperty("requestId")
    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String requestId;

    @JsonProperty("accountId")
    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String accountId;

    @JsonProperty("caMastId")
    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String caMastId;

    @JsonProperty("qtty")
    @NotNull(message = "{validation.not_null}")
    private BigDecimal qtty;

    @JsonProperty("desc")
    private String desc;

    @JsonProperty("via")
    @NotNull(message = "{validation.not_null}")
    @NotEmpty(message = "{validation.not_empty}")
    private String via;
}
