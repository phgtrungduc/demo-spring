package vn.com.vpbanks.flex.usecase.service.business.cf.service;

import vn.com.vpbanks.flex.usecase.service.business.cf.request.CalCI1202Request;
import vn.com.vpbanks.flex.usecase.service.business.cf.request.OpenCSAccountRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;

public interface CFService {
    BaseResponse openCommissionAccount(OpenCSAccountRequest openCSAccountRequest);

    BaseResponse calCI1202(CalCI1202Request calCI1202Request);
}
