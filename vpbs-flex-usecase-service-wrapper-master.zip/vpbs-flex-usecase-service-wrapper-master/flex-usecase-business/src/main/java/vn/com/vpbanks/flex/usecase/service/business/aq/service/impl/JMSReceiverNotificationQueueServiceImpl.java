package vn.com.vpbanks.flex.usecase.service.business.aq.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import vn.com.vpbanks.flex.usecase.service.business.aq.request.*;
import vn.com.vpbanks.flex.usecase.service.business.aq.response.*;
import vn.com.vpbanks.flex.usecase.service.business.aq.service.JMSReceiverNotificationQueueService;
import vn.com.vpbanks.flex.usecase.service.business.order.response.OrderNotificationKafkaResponse;
import vn.com.vpbanks.flex.usecase.service.common.constants.SessionHnxUpcomCode;
import vn.com.vpbanks.flex.usecase.service.common.constants.SessionHsxCode;
import vn.com.vpbanks.flex.usecase.service.common.constants.SessionHsxOddLotCode;
import vn.com.vpbanks.flex.usecase.service.common.constants.ViaCode;
import vn.com.vpbanks.flex.usecase.service.common.utils.CommonUtils;

import java.util.Map;

import static vn.com.vpbanks.flex.usecase.service.common.constants.KafkaTopicConstants.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class JMSReceiverNotificationQueueServiceImpl implements JMSReceiverNotificationQueueService {
    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;

    @Value("${vpbanks.kafka.properties.topics.flex.orderNotification}")
    private String orderNotificationTopic;

    @Value("${vpbanks.kafka.properties.topics.flex.cashNotification}")
    private String cashNotificationTopic;

    @Value("${vpbanks.kafka.properties.topics.flex.accountNotification}")
    private String accountNotificationTopic;

    @Value("${vpbanks.kafka.properties.topics.flex.acctNoNotification}")
    private String acctNoNotificationTopic;

    @Value("${vpbanks.kafka.properties.topics.flex.smartOtpNotificationTopic}")
    private String smartOtpNotificationTopic;

    @Value("${vpbanks.kafka.properties.topics.flex.openAccountVsdNotificationTopic}")
    private String openAccountVsdNotificationTopic;

    @Value("${vpbanks.kafka.properties.topics.flex.signalChangePasswordTopic}")
    private String signalChangePasswordTopic;
    @Value("${vpbanks.kafka.properties.topics.flex.signalSyncSETopic}")
    private String signalSyncSETopic;
    @Value("${vpbanks.kafka.properties.topics.flex.signalSyncCATopic}")
    private String signalSyncCATopic;
    @Value("${vpbanks.kafka.properties.topics.flex.signalBatch1Topic}")
    private String signalBatch1Topic;

    @Value("${vpbanks.kafka.properties.topics.flex.signalEInvestTopic}")
    private String signalEInvestTopic;

    @Value("${vpbanks.kafka.properties.topics.flex.orderCash}")
    private String orderCash;

    @Value("${vpbanks.kafka.properties.topics.flex.orderMargin}")
    private String orderMargin;

    @Value("${vpbanks.kafka.properties.topics.flex.orderCopyTrade}")
    private String orderCopyTrade;

    @Value("${vpbanks.kafka.properties.topics.flex.orderSaleSupport}")
    private String orderSaleSupport;

    @Value("${vpbanks.kafka.properties.topics.flex.orderAll}")
    private String orderAll;

    @Value("${vpbanks.kafka.properties.topics.flex.customerCare}")
    private String CustomerCare;
    @Value("${vpbanks.kafka.properties.topics.flex.conditionOrder}")
    private String conditionOrder;


    public void JMSNotificationQueue(Map<String, String> hashMap) {
        try {
            GsonBuilder gsonBuilder = new GsonBuilder();
            Gson gson = gsonBuilder.create();
            String jsonString = gson.toJson(hashMap);
            String eventType = String.valueOf(hashMap.get("EVENTTYPE")).toUpperCase();
            log.info("event type from AQ: {}", eventType);

            switch (eventType) {
                case "OD": {
                    this.handleSignalOrder(jsonString);
                    break;
                }
                case "CI":
                    CashNotificationFromQueue cashNotificationFromQueue = gson.fromJson(jsonString, CashNotificationFromQueue.class);
                    CashNotification cashNotification = new CashNotification(cashNotificationFromQueue);
                    String msgCashNotification = gson.toJson(cashNotification);
                    kafkaTemplate.send(cashNotificationTopic, msgCashNotification);
                    break;
                case "CF":
                    AccountNotificationFromQueue accountNotificationFromQueue = gson.fromJson(jsonString, AccountNotificationFromQueue.class);
                    AccountNotification accountNotification = new AccountNotification(accountNotificationFromQueue);
                    String msgAccountNotification = gson.toJson(accountNotification);
                    kafkaTemplate.send(accountNotificationTopic, msgAccountNotification);
                    break;
                case "AF": {
                    AcctNoNotificationFromQueue acctNoNotificationFromQueue = gson.fromJson(jsonString, AcctNoNotificationFromQueue.class);
                    AcctNoNotification acctNoNotification = new AcctNoNotification(acctNoNotificationFromQueue);
                    String msgAcctNoNotification = gson.toJson(acctNoNotification);
                    kafkaTemplate.send(acctNoNotificationTopic, msgAcctNoNotification);
                    break;
                }
                case "SMARTOTP": {
                    SmartOtpMessageFromQueue smartOtpMessageFromQueue = gson.fromJson(jsonString, SmartOtpMessageFromQueue.class);
                    SmartOtpNotification smartOtpNotification = new SmartOtpNotification(smartOtpMessageFromQueue);
                    String smartOtpNotificationMessage = gson.toJson(smartOtpNotification);
                    kafkaTemplate.send(smartOtpNotificationTopic, smartOtpNotificationMessage);
                    break;
                }
                case "IAMCF": {
                    OpenAccountVSDNotificationFromQueue openAccountVSDNotificationFromQueue = gson.fromJson(jsonString, OpenAccountVSDNotificationFromQueue.class);
                    OpenAccountVSDNotification openAccountVSDNotification = new OpenAccountVSDNotification(openAccountVSDNotificationFromQueue);
                    String openAccountVsdMessage = gson.toJson(openAccountVSDNotification);
                    kafkaTemplate.send(openAccountVsdNotificationTopic, openAccountVsdMessage);
                    break;
                }
                case "CPW": {
                    ChangePasswordNotificationFromQueue changePasswordNotificationFromQueue = gson.fromJson(jsonString, ChangePasswordNotificationFromQueue.class);
                    ChangePasswordNotification changePasswordNotification = new ChangePasswordNotification(changePasswordNotificationFromQueue);
                    String changePasswordMessage = gson.toJson(changePasswordNotification);
                    kafkaTemplate.send(signalChangePasswordTopic, changePasswordMessage);
                    break;
                }
                case "SE": {
                    SyncSecuritiesFromQueue syncSecuritiesFromQueue = gson.fromJson(jsonString, SyncSecuritiesFromQueue.class);
                    SyncSecuritiesNotification syncSecuritiesNotification = new SyncSecuritiesNotification(syncSecuritiesFromQueue);
                    String syncSecuritiesMessage = gson.toJson(syncSecuritiesNotification);
                    kafkaTemplate.send(signalSyncSETopic, syncSecuritiesMessage);
                    break;
                }
                case "CA": {
                    SyncCAFromQueue syncCAFromQueue = gson.fromJson(jsonString, SyncCAFromQueue.class);
                    SyncCANotification syncCANotification = new SyncCANotification(syncCAFromQueue);
                    String message = gson.toJson(syncCANotification);
                    kafkaTemplate.send(signalSyncCATopic, message);
                    break;
                }
                case "BFSYS": {
                    SignalBatch1FromQueue signalBatch1FromQueue = gson.fromJson(jsonString, SignalBatch1FromQueue.class);
                    SignalBatch1Notification signalBatch1Notification = new SignalBatch1Notification(signalBatch1FromQueue);
                    String message = gson.toJson(signalBatch1Notification);
                    kafkaTemplate.send(signalBatch1Topic, message);
                    break;
                }
                case "CIMODE": {
                    SignalEInvestAutoFromQueue signalEInvestAutoFromQueue = gson.fromJson(jsonString, SignalEInvestAutoFromQueue.class);
                    SignalEInvestAutoNotification signalEInvestAutoNotification = new SignalEInvestAutoNotification(signalEInvestAutoFromQueue);
                    String message = gson.toJson(signalEInvestAutoNotification);
                    kafkaTemplate.send(signalEInvestTopic, message);
                    break;
                }
                case "MK": {
                    this.handleSignalSession(hashMap);
                    break;
                }
                case "CFBOND": {
                    SignalOpenBondAccountIAMFromQueue signalOpenBondAccountIAMFromQueue = gson.fromJson(jsonString, SignalOpenBondAccountIAMFromQueue.class);
                    SignalOpenBondAccountIAM signalOpenBondAccountIAM = new SignalOpenBondAccountIAM(signalOpenBondAccountIAMFromQueue);
                    this.convertAndSendMessage(FLEX_SIGNAL_OPEN_BOND_ACCT_IAM_TOPIC, signalOpenBondAccountIAM);
                    break;
                }
                case "TCDBOND": {
                    SignalCompleteCODBondFromQueue signalCompleteCODBondFromQueue = gson.fromJson(jsonString, SignalCompleteCODBondFromQueue.class);
                    SignalCompleteCODBond signalCompleteCODBond = new SignalCompleteCODBond(signalCompleteCODBondFromQueue);
                    this.convertAndSendMessage(FLEX_SIGNAL_COMP_COD_BOND_TOPIC, signalCompleteCODBond);
                }
                default:
                    log.info("other notification: {}, {}", eventType, hashMap);
                    break;
            }
        } catch (Exception e) {
            log.error("error converting message {}", CommonUtils.handlerError(e));
            System.out.println("error converting message " + e.getMessage());
        }
    }

    private void handleSignalOrder(String signalOD) {
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        OrderNotificationFromQueue orderNotification = gson.fromJson(signalOD, OrderNotificationFromQueue.class);
        OrderNotification order = new OrderNotification(orderNotification);
        String foVia = orderNotification.getFOVIA();
        String requestId = orderNotification.getREQUESTID();
        log.info("[Signal OD] foVia = {} , requestId = {} ", foVia, requestId);

        // Mapping via to service name.
        String serviceName = ViaCode.getServiceName(foVia.toUpperCase());

        OrderNotificationKafkaResponse orderNotificationKafkaResponse = new OrderNotificationKafkaResponse();
        orderNotificationKafkaResponse.setServiceName(serviceName);
        orderNotificationKafkaResponse.setRequestId(requestId);
        orderNotificationKafkaResponse.setData(order);

        // 1. Send signalOD to orderAll topic.
        String msg = gson.toJson(orderNotificationKafkaResponse);
        kafkaTemplate.send(orderAll, msg);

        //2. Send to specific service.
        if (serviceName != null) {
            switch (serviceName) {
                case "CASH":
                    kafkaTemplate.send(orderCash, msg);
                    break;
                case "MARGIN":
                    kafkaTemplate.send(orderMargin, msg);
                    break;
                case "COPY_TRADE":
                    kafkaTemplate.send(orderCopyTrade, msg);
                    break;
                case "SALE_SUPPORT":
                    kafkaTemplate.send(orderSaleSupport, msg);
                    break;
                case "CUSTOMER_CARE":
                    kafkaTemplate.send(CustomerCare, msg);
                    break;
                case "CONDITION_ORDER":
                    kafkaTemplate.send(conditionOrder, msg);
                    break;
                case "COVERED_WARRANT":
                    kafkaTemplate.send(FLEX_SIGNAL_ORDER_RESULT_CW_TOPIC, order.getOrderId(), msg);
            }
        }
    }

    private void handleSignalSession(Map<String, String> event) {
        String exchange = event.get("EXCHANGE");
        log.info("Get SignalSession : {}", exchange);
        if ("HNX".equals(exchange) || "UPCOM".equals(exchange)) {
            String sessionId = String.valueOf(event.get("SESSIONIS"));
            String tradingSessionId = String.valueOf(event.get("TRADINGSESSIONID"));
            String session = "";
            if ("1".equals(sessionId) && "CONT".equals(tradingSessionId)) {
                session = SessionHnxUpcomCode.OPEN.getValue();
            } else if ("1".equals(sessionId) && "CONTUP".equals(tradingSessionId)) {
                session = SessionHnxUpcomCode.OPEN.getValue();
            } else if ("1".equals(sessionId) && "CLOSE".equals(tradingSessionId)) {
                session = SessionHnxUpcomCode.ATC.getValue();
            } else if ("1".equals(sessionId) && "PCLOSE".equals(tradingSessionId)) {
                session = SessionHnxUpcomCode.PLO.getValue();
            } else if ("13".equals(sessionId) && "PCLOSE".equals(tradingSessionId)) {
                session = SessionHnxUpcomCode.END_PLO.getValue();
            } else if ("2".equals(sessionId) && "CONT".equals(tradingSessionId)) {
                session = SessionHnxUpcomCode.INTERMISSION.getValue();
            } else if ("2".equals(sessionId) && "CONTUP".equals(tradingSessionId)) {
                session = SessionHnxUpcomCode.INTERMISSION.getValue();
            } else if ("97".equals(sessionId)) {
                session = SessionHnxUpcomCode.CLOSED.getValue();
            } else if ("13".equals(sessionId) && "CONTUP".equals(tradingSessionId)) {
                session = SessionHnxUpcomCode.CLOSED.getValue();
            } else {
                log.info("Unknown type for mapping session .Please check ...");
            }

            log.info("Session HNX, UPCOM sessionId : {} , tradingSessionId {} mapped to session {} ", sessionId, tradingSessionId, session);

            SignalSession signalSession = new SignalSession();
            signalSession.setEventType("MK");
            signalSession.setExchange(exchange);
            signalSession.setSession(session);
            convertAndSendMessage(FLEX_SIGNAL_SESSION_TOPIC, signalSession);

        } else if ("HOSE_ODD".equals(exchange)) {
            String session = String.valueOf(event.get("SESSIONIS"));
            String mappedValue = SessionHsxOddLotCode.findValueByCode(session);
            SignalSession signalSession = new SignalSession();
            signalSession.setEventType("MK");
            signalSession.setExchange(exchange);
            signalSession.setSession(mappedValue);

            log.info("HOSE_ODD session Hsx {} , mappedValue {} ", session, mappedValue);
            convertAndSendMessage(FLEX_SIGNAL_SESSION_TOPIC, signalSession);
        } else {
            String session = String.valueOf(event.get("SESSIONIS"));
            String mappedValue = SessionHsxCode.findValueByCode(session);
            SignalSession signalSession = new SignalSession();
            signalSession.setEventType("MK");
            signalSession.setExchange(exchange);
            signalSession.setSession(mappedValue);

            log.info("session Hsx {} , mappedValue {} ", session, mappedValue);
            convertAndSendMessage(FLEX_SIGNAL_SESSION_TOPIC, signalSession);
        }
    }

    private void convertAndSendMessage(String topicName, Object message) {
        try {
            String jsonMessage = objectMapper.writeValueAsString(message);
            log.debug("Json message : {}", jsonMessage);
            kafkaTemplate.send(topicName, jsonMessage);
        } catch (JsonProcessingException e) {
            log.error("Have error during convert json");
            throw new RuntimeException(e);
        }
    }
}
