package vn.com.vpbanks.flex.usecase.service.business.cash.repository.vo;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
@Builder
public class CashStatementHistVO {

    private String afAcctNo;
    private Timestamp busDate;
    private String transactionNum;
    private String transactionCode;
    private String tlTxDesc;
    private BigDecimal creditAmt;
    private BigDecimal debitAmt;
    private String txDesc;
    private BigDecimal beginingBalance;
    private BigDecimal ciReceivingBal;
    private BigDecimal ciEmkAmtBal;
    private BigDecimal ciDfDebtAmtBal;
    private BigDecimal odBuySecu;
    private BigDecimal ciAvailBal;
    private BigDecimal endingBalance;
    private BigDecimal available;
    private BigDecimal dueAmt;

}
