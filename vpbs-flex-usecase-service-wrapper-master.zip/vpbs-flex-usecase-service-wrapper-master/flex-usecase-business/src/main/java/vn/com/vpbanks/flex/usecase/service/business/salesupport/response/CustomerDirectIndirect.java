package vn.com.vpbanks.flex.usecase.service.business.salesupport.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDirectIndirect implements Serializable {
    @JsonProperty("userId")
    private String userId;

    @JsonProperty("accountNo")
    private String accountNo;

    @JsonProperty("cusFullName")
    private String cusFullName;

    @JsonProperty("isFavorite")
    private String isFavorite;

    @JsonProperty("reCustodyCd")
    private String reCustodyCd;

    @JsonProperty("reFullName")
    private String reFullName;

    @JsonProperty("debt")
    private BigDecimal debt;

    @JsonProperty("dept")
    private String dept;

    @JsonProperty("nav")
    private BigDecimal nav;

    @JsonProperty("margin")
    private BigDecimal margin;

    @JsonProperty("value")
    private BigDecimal value;

    @JsonProperty("casa")
    private BigDecimal casa;

    @JsonProperty("iseInvest")
    private String iseInvest;

    @JsonProperty("totalRecord")
    private BigDecimal totalRecord;

    @JsonProperty("status")
    private String status;

    @JsonProperty("orderCustodyCd")
    private String orderCustodyCd;

    @JsonProperty("orderName")
    private String orderName;
}
