package vn.com.vpbanks.flex.usecase.service.business.broker.repository.vo;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class BrokerInfoDVO {
    @Id
    @Column(name = "REID")
    private String reId;

    @Column(name = "RECUSTODYCD")
    private String reCustoDyCd;

    @Column(name = "REFULLNAME")
    private String reFullName;

    @Column(name = "REMOBILE")
    private String reMobile;

    @Column(name = "REMAIL")
    private String reMail;

    @Column(name = "ISCERTIFICATE")
    private String isCertificate;

    @Column(name = "LEADERID")
    private String leaderId;

    @Column(name = "LEADERCUSTODYCD")
    private String leaderCustoDyCd;

    @Column(name = "LEADERNAME")
    private String leaderName;

    @Column(name = "GRID")
    private String groupId;

    @Column(name = "GRNAME")
    private String groupName;
}
