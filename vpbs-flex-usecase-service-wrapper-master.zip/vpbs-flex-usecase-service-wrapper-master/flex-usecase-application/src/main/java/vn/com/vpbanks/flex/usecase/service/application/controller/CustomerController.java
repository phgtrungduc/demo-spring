package vn.com.vpbanks.flex.usecase.service.application.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import vn.com.vpbanks.flex.usecase.service.business.customer.service.CustomerService;
import vn.com.vpbanks.flex.usecase.service.common.constants.UrlConstants;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.common.utils.BaseUrl;

@Slf4j
@RestController
@RequestMapping(BaseUrl.FLEX_USECASE_SERVICE.V1 + "/flex" + UrlConstants.CUSTOMER)
@RequiredArgsConstructor
public class CustomerController {

    private final CustomerService customerService;

    @GetMapping("{customerId}/beneficiaries")
    public BaseResponse getBeneficiaryAccount(@PathVariable(name = "customerId") String customerId) {
        return customerService.getBeneficiaryAccount(customerId);
    }
}
