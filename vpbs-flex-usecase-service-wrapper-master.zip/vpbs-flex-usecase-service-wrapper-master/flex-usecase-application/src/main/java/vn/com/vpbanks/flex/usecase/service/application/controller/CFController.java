package vn.com.vpbanks.flex.usecase.service.application.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import vn.com.vpbanks.flex.usecase.service.business.cf.request.CalCI1202Request;
import vn.com.vpbanks.flex.usecase.service.business.cf.request.OpenCSAccountRequest;
import vn.com.vpbanks.flex.usecase.service.business.cf.service.CFService;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.common.utils.BaseUrl;

import javax.validation.Valid;

@Slf4j
@RestController
@RequestMapping(BaseUrl.FLEX_USECASE_SERVICE.V1 + "/flex")
@RequiredArgsConstructor
public class CFController {

    private final CFService cfService;

    /**
     * Mở tài khoản ủy thác
     *
     * @param openCSAccountRequest
     * @return
     */
    @PostMapping("openCommissionAccount")
    public BaseResponse openCommissionAccount(@Valid @RequestBody OpenCSAccountRequest openCSAccountRequest) {
        return cfService.openCommissionAccount(openCSAccountRequest);
    }

    /**
     * Api cắt phí ủy thác .
     * Màn giao dịch 1202
     *
     * @param calCI1202Request
     * @return
     */
    @PostMapping("calFeeCsAccount")
    public BaseResponse calCI1202(@Valid @RequestBody CalCI1202Request calCI1202Request) {
        return cfService.calCI1202(calCI1202Request);
    }
}
