package vn.com.vpbanks.flex.usecase.service.application.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import vn.com.vpbanks.flex.usecase.service.business.cash.request.*;
import vn.com.vpbanks.flex.usecase.service.business.cash.service.CashService;
import vn.com.vpbanks.flex.usecase.service.common.dto.request.BaseRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.request.ValidateRequestBodyList;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.common.utils.BaseUrl;
import vn.com.vpbanks.flex.usecase.service.trackings.aspect.Tracking;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;

@Slf4j
@RestController
@RequestMapping(BaseUrl.FLEX_USECASE_SERVICE.V1 + "/flex")
@RequiredArgsConstructor
public class CashController {

    private final CashService cashService;

    @GetMapping("getBankNoStro")
    public BaseResponse getBankNoStro() {
        return cashService.getBankNoStro();
    }

    @PostMapping("increaseMoney")
    @Tracking(action = "CREATE")
    public BaseResponse increaseMoney(@Valid @RequestBody BaseRequest<IncreaseMoneyRequest> increaseMoneyRequestBaseRequest) {
        String ipAddress = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest().getRemoteAddr();
        return cashService.increaseMoney(increaseMoneyRequestBaseRequest, ipAddress);
    }

    @PostMapping("internalTransfer")
    @Tracking(action = "CREATE")
    public BaseResponse internalTransfer(@Valid @RequestBody BaseRequest<InternalTransferRequest> internalTransfer) {
        String ipAddress = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest().getRemoteAddr();
        return cashService.internalTransfer(internalTransfer, ipAddress);
    }

    @PostMapping("blockAmount")
    @Tracking(action = "CREATE")
    public BaseResponse blockAmount(@Valid @RequestBody BaseRequest<BlockAmountRequest> blockAmountRequest) {
        String ipAddress = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest().getRemoteAddr();
        return cashService.blockAmount(blockAmountRequest, ipAddress);
    }


    @PostMapping("unBlockAmount")
    @Tracking(action = "UPDATE")
    public BaseResponse unBlockAmount(@Valid @RequestBody BaseRequest<BlockAmountRequest> blockAmountRequest, HttpServletRequest httpServletRequest) {
        String ipAddress = httpServletRequest.getHeader("x-forwarded-for");
        if (ipAddress == null) {
            ipAddress = httpServletRequest.getRemoteAddr();
        }
        return cashService.unBlockAmount(blockAmountRequest, ipAddress);
    }


    @GetMapping("getSecuritiesStatement")
    public BaseResponse getSecuritiesStatement(@RequestParam(name = "accountId", required = true) String accountId,
                                               @RequestParam(name = "fromDate", required = true) String fromDate,
                                               @RequestParam(name = "toDate", required = true) String toDate,
                                               @RequestParam String symbol) {
        return cashService.getSecuritiesStatement(accountId, fromDate, toDate, symbol);
    }

    @PostMapping("report/accounts/cashStatementHist")
    public BaseResponse getCashStatementHist(@Valid @RequestBody ValidateRequestBodyList<CashStatementHistRequest> cashStatementHistRequest) {
        List<CashStatementHistRequest> cashStatementHistRequestList = cashStatementHistRequest.getDataBody();
        return cashService.getCashStatementHist(cashStatementHistRequestList);
    }

    @GetMapping("getHoldBalance")
    public BaseResponse<Object> getHoldBalance(@RequestParam String custodyCd,
                                               @RequestParam String accountNo) {
        return cashService.getHoldBalance(custodyCd, accountNo);
    }

    @GetMapping("getHoldStock")
    public BaseResponse<Object> getHoldStock(@RequestParam String custodyCd,
                                             @RequestParam String accountNo) {
        return cashService.getHoldStock(custodyCd, accountNo);
    }

    @GetMapping("getUnHoldEOD")
    public BaseResponse<Object> getUnHoldEOD() {
        return cashService.getUnHoldEOD();
    }

    @PostMapping("holdBalance")
    public BaseResponse<Object> holdBalance(@Valid @RequestBody HoldBalanceRequest holdBalanceRequest) {
        return cashService.holdBalance(holdBalanceRequest);
    }

    @PostMapping("unHoldBalance")
    public BaseResponse<Object> unHoldBalance(@Valid @RequestBody UnHoldBalanceRequest unHoldBalanceRequest) {
        return cashService.unHoldBalance(unHoldBalanceRequest);
    }

    @PostMapping("holdStock")
    public BaseResponse<Object> holdStock(@Valid @RequestBody HoldStockRequest holdStockRequest) {
        return cashService.holdStock(holdStockRequest);
    }

    @PostMapping("unHoldStock")
    public BaseResponse<Object> unHoldStock(@Valid @RequestBody UnHoldStockRequest unHoldStockRequest) {
        return cashService.unHoldStock(unHoldStockRequest);
    }
}
