package vn.com.vpbanks.flex.usecase.service.application.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.service.AFTypeService;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.common.utils.BaseUrl;

import java.sql.SQLException;

@Slf4j
@RestController
@RequestMapping(BaseUrl.FLEX_USECASE_SERVICE.V1 + "/flex")
@RequiredArgsConstructor
public class AFTypeController {

    private final AFTypeService afTypeService;

    @GetMapping(value = "/getAFType")
    public BaseResponse getAFType(@RequestParam(required = true) String afType) {
        return afTypeService.getAFType(afType);
    }
}
