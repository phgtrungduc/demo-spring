package vn.com.vpbanks.flex.usecase.service.application.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.request.AvailableBalanceRequest;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.request.SummaryAccountRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.request.BaseRequest;
import vn.com.vpbanks.flex.usecase.service.common.dto.request.ValidateRequestBodyList;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.common.utils.BaseUrl;
import vn.com.vpbanks.flex.usecase.service.trackings.aspect.Tracking;
import vn.com.vpbanks.flex.usecase.service.business.cash.request.WithdrawMoneyRequest;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.service.AccountService;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.service.FlexInquiryOrderService;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.service.SecuritiesPortfolioService;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.Positive;
import javax.validation.constraints.PositiveOrZero;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@RestController
@RequestMapping(BaseUrl.FLEX_USECASE_SERVICE.V1 + "/flex")
@RequiredArgsConstructor
@Validated
public class FlexInquiryController {
    private final FlexInquiryOrderService flexInquiryOrderService;
    private final SecuritiesPortfolioService securitiesPortfolioService;
    private final AccountService accountService;

    @GetMapping(value = "/inq/order")
    public BaseResponse getInquiryOrder(@RequestParam String accountId,
                                                            @RequestParam String orderId,
                                                            @RequestParam String orderType,
                                                            @RequestParam String orderStatus,
                                                            @RequestParam String symbol,
                                                            @RequestParam(required = false) Long offset,
                                                            @RequestParam(required = false) Long limit) {
        return flexInquiryOrderService.getOrder(accountId, orderId, orderType, symbol, orderStatus, offset, limit);
    }

    @GetMapping(value = "/getSecuritiesPortfolio")
    public BaseResponse getSecuritiesPortfolio(@RequestParam String accountId,
                                               @RequestParam String symbol,
                                               @RequestParam Integer offset,
                                               @RequestParam Integer limit) {
        return securitiesPortfolioService.getSecuritiesPortfolio(accountId, symbol, offset, limit);
    }

    @GetMapping(value = "/getAccount")
    public BaseResponse getAccount(@RequestParam(name = "custodycd", required = true) String custodycd,
                                   @RequestParam(name = "accountId", required = false) String accountId) {
        return accountService.getAccount(custodycd,accountId);
    }

    @GetMapping(value = "/getAccounts")
    public BaseResponse getAccounts(@RequestParam List<String> cusToDyCd) {
        BaseResponse response = null;
        String accountId = "";
        if (cusToDyCd.size() <= 10) {
            return accountService.getAccounts(cusToDyCd,accountId);
        } else {
            response = BaseResponse.ofFailedFlexResponse(cusToDyCd);
            response.setMessage("Số TK lưu ký cusToDyCd truyền tối đa 10 mã");
            return response;
        }
    }

    @GetMapping("accounts/{accountId}/available-balance")
    public BaseResponse getSubAccountAvailableBalance(@PathVariable("accountId") String accountId) {
        return accountService.getSubAccountAvailableBalance(accountId);
    }

    @PostMapping("accounts/available-balance")
    public BaseResponse getSubListAccountAvailableBalance(@RequestBody List<AvailableBalanceRequest> availableBalanceRequest) {
        log.info("getSubListAccountAvailableBalance");
        return accountService.getSubListAccountAvailableBalance(availableBalanceRequest);
    }

    @GetMapping(value = "/getInformationCus")
    public BaseResponse getInformationCus(@RequestParam(name = "custodycd", required = true) String custodycd) {
        return accountService.getInformationCus(custodycd);
    }

    @PostMapping("/withdrawMoney")
    @Tracking(action = "CREATE")
    public BaseResponse withdrawMoney(@Valid @RequestBody BaseRequest<WithdrawMoneyRequest> withdrawMoneyRequestBaseRequest, HttpServletRequest httpServletRequest) {
        String ipAddress = httpServletRequest.getHeader("x-forwarded-for");
        if (ipAddress == null) {
            ipAddress = httpServletRequest.getRemoteAddr();
        }
        return accountService.withdrawMoney(withdrawMoneyRequestBaseRequest, ipAddress);
    }


    @GetMapping(value = "/getRightOffList")
    public BaseResponse getRightOffList(@RequestParam(name = "accountId", required = true) String accountId) {
        return flexInquiryOrderService.getGetRightOffList(accountId);
    }

    @PostMapping("/accounts/summaryAccounts")
    public BaseResponse summaryAccounts(@Valid @RequestBody ValidateRequestBodyList<SummaryAccountRequest> summaryAccounts) {

        List<SummaryAccountRequest> listSummaryAccountRequests = summaryAccounts.getDataBody();
        return accountService.getSummaryAccount(listSummaryAccountRequests);
    }

    @GetMapping(value = "inq/accounts/{accountId}/availableTrade")
    public BaseResponse getAvailableTrade(@PathVariable("accountId") String accountId,
                                          @RequestParam(name = "symbol", required = false) String symbol,
                                          @RequestParam(name = "quotePrice", required = false) String quotePrice) {
        log.info("[getAvailableTrade] accountId: {},symbol : {}, quotePrice: {}", accountId, symbol, quotePrice);
        return flexInquiryOrderService.getAvailableTrade(accountId, symbol, quotePrice);
    }

    @GetMapping("inq/securitiesInfo")
    public BaseResponse getSecuritiesInfo(@RequestParam(required = false, defaultValue = "ALL") String issuerId,
                                          @RequestParam(required = false, defaultValue = "ALL") String codeId,
                                          @RequestParam(required = false, defaultValue = "ALL") String symbol,
                                          @RequestParam(required = false, defaultValue = "ALL") String secTypeName,
                                          @RequestParam(required = false, defaultValue = "ALL") String tradePlace,
                                          @RequestParam(required = false) @Valid @PositiveOrZero(message = "{validation.positive_number}") Integer pageIndex,
                                          @RequestParam(required = false) @Valid @Positive(message = "{validation.positive_number}") Integer pageSize) {
        return securitiesPortfolioService.getSecuritiesInfo(issuerId, codeId, symbol, secTypeName, tradePlace, pageIndex, pageSize);
    }


    //SAL-2012
    @GetMapping("/getUnderBroker")
    public BaseResponse getSecuritiesInfo(
            @RequestParam(required = false, name = "custodycd") String custodycd,
            @RequestParam(required = false, name = "searchkey") String searchkey,
            @RequestParam(required = false, name = "dept") String dept,
            @RequestParam(required = false, name = "underCustodycd") String underCustodycd,
            @RequestParam(required = false, name = "getCurren") String getCurren
    ) {
        return flexInquiryOrderService.getUnderBroker(custodycd, searchkey, dept, underCustodycd, getCurren);
    }

    @GetMapping("/getDepartment")
    public BaseResponse getDepartment(
            @RequestParam(required = false, name = "custId") String custId,
            @RequestParam(required = false, name = "deptId") String deptId,
            @RequestParam(required = false, name = "deptName") String deptName) {
        return flexInquiryOrderService.getDepartment(custId, deptId, deptName);
    }

    @GetMapping("/getCurrentDepartment")
    public BaseResponse getDirectManagement(
            @RequestParam(required = false, name = "reCustodycd") String reCustodycd,
            @RequestParam(required = false, name = "reFullName") String reFullName,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size) {
        return flexInquiryOrderService.getCurrentDepartment(
                StringUtils.isEmpty(reCustodycd) ? null : Arrays.stream(reCustodycd.split(",")).collect(Collectors.toList())
                , reFullName
                , page
                , size);
    }
}
