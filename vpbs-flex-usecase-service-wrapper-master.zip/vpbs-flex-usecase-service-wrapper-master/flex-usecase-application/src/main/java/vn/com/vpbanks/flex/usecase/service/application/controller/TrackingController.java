package vn.com.vpbanks.flex.usecase.service.application.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.common.utils.BaseRest;
import vn.com.vpbanks.flex.usecase.service.common.utils.BaseUrl;
import vn.com.vpbanks.flex.usecase.service.common.utils.CommonUtils;
import vn.com.vpbanks.flex.usecase.service.trackings.entities.Trackings;
import vn.com.vpbanks.flex.usecase.service.trackings.services.TrackingService;

import java.util.List;

@Slf4j
@RestController
@RequestMapping(BaseUrl.FLEX_USECASE_SERVICE.V1 + "/flex")
@RequiredArgsConstructor
public class TrackingController {
    private final TrackingService trackingService;

    @GetMapping(value = "/tracking/{serviceName}/{requestId}")
    public BaseResponse getByRequestId(@PathVariable String serviceName, @PathVariable String requestId) {
        BaseResponse response;
        try {
            List<Trackings> res = trackingService.findByRequestId(serviceName.toUpperCase(), requestId);

            response = BaseResponse.ofSucceeded();
            response.setData(res);
            response.setCode(BaseRest.RESPONSE.OK_CODE);

            return response;
        } catch (Exception e) {
            System.out.println(CommonUtils.handlerError(e));
            log.error(CommonUtils.handlerError(e));
            response = BaseResponse.ofFailedException(CommonUtils.handlerError(e));

            return response;
        }
    }
}
