package vn.com.vpbanks.flex.usecase.service.application.aq;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import oracle.jms.AQjmsTextMessage;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;
import vn.com.vpbanks.flex.usecase.service.common.utils.CommonUtils;
import vn.com.vpbanks.flex.usecase.service.business.aq.service.JMSReceiverNotificationQueueService;


import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import java.util.Map;


@Component
@Slf4j
@RequiredArgsConstructor
@ConditionalOnProperty(prefix = "vpbanks.flex.features", name = "synchronization-queue-enabled", havingValue = "true")
public class JMSReceiver  {
    private final JMSReceiverNotificationQueueService jmsReceiverNotificationQueueService;
    @JmsListener(destination = "${vpbanks.aq.synchronizationQueue}", containerFactory = "jmsListenerContainerFactory")
    public void onMessage(Message message, Session session) throws JMSException {
        AQjmsTextMessage objectMessage = (AQjmsTextMessage) message;
        String data = objectMessage.getText();
        log.info("received data from AQ: {}", data);
        Map<String, String> hashMap = CommonUtils.handleAQMessage(data);
        jmsReceiverNotificationQueueService.JMSNotificationQueue(hashMap);
    }
}