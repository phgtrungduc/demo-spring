package vn.com.vpbanks.flex.usecase.service.application.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.response.WorkingDayResponse;
import vn.com.vpbanks.flex.usecase.service.business.inquiry.service.WorkingDayService;
import vn.com.vpbanks.flex.usecase.service.common.annotation.ValidFormatDate;
import vn.com.vpbanks.flex.usecase.service.common.dto.response.BaseResponse;
import vn.com.vpbanks.flex.usecase.service.common.utils.BaseUrl;

import javax.validation.Valid;
import java.util.List;

@Slf4j
@RestController
@RequestMapping(BaseUrl.FLEX_USECASE_SERVICE.V1 + "/flex")
@RequiredArgsConstructor
@Validated
public class CommonController {

    private final WorkingDayService workingDayService;

    @GetMapping(value = "/getWorkingDay")
    public BaseResponse get(@RequestParam @Valid @ValidFormatDate String fromDate,
                            @RequestParam @Valid @ValidFormatDate String toDate,
                            @RequestParam(required = false, defaultValue = "ALL") String holiday) {
        List<WorkingDayResponse> workingDayResponseList = workingDayService.getListWorkingDay(fromDate, toDate, holiday);
        return BaseResponse.ofSucceeded(workingDayResponseList);
    }

    @GetMapping("getCurrentDate")
    public BaseResponse getCurrentDateFlex() {
        return workingDayService.getCurrentDateFlex();
    }

}
