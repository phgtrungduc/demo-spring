package vn.com.vpbanks.flex.query.application.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import vn.com.vpbanks.flex.query.application.response.FlexErrorResponse;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.zip.GZIPOutputStream;

@Slf4j
@UtilityClass
public class CommonUtils {

    private static ObjectMapper objectMapper = new ObjectMapper();


    public static String replaceWithMap(String path, Map<String, String> map) {
        String pathCopy = String.valueOf(path);
        for (Map.Entry<String, String> entry : map.entrySet()) {
            pathCopy = pathCopy.replace(entry.getKey(), entry.getValue());
        }

        return pathCopy;
    }

    public static String handlerError(WebClientResponseException e) {
        try {
            var response = objectMapper.readValue(e.getResponseBodyAsString(), FlexErrorResponse.class);
            if (Objects.nonNull(response)) {
                return response.getErrorMessage();
            }

        } catch (JsonProcessingException ex) {
            log.error(e.getMessage(), ex);
            return e.getResponseBodyAsString();
        }
        return Strings.EMPTY;
    }

    public static String handlerError(Exception e) {
        return e.getMessage();
    }

    public static Map<String, Object> toValueMap(Object obj) {
        if (objectMapper == null) {
            objectMapper = new ObjectMapper();
        }

        return objectMapper.convertValue(obj, new TypeReference<Map<String, Object>>() {
        });
    }

    public static MultiValueMap<String, String> toMultiValueMap(Object obj) {
        if (objectMapper == null) {
            objectMapper = new ObjectMapper();
        }

        return objectMapper.convertValue(obj, new TypeReference<MultiValueMap<String, String>>() {
        });
    }

    public static String DateToString(Date dt, String pattern) {
        DateFormat df = new SimpleDateFormat(pattern);

        return df.format(dt);
    }

    public static Map<String, String> handleAQMessage(String message) {
        String prefix = "8=FIX..\\u0001";
        String charPrefix = "\\u0001";

        String[] data = message.split(prefix);
        if (3 == data.length) {
            Map<String, String> hashMap = new HashMap();
            String[] col = data[1].split(charPrefix);
            String[] val = data[2].split(charPrefix);

            for (int i = 0; i < col.length; i++) {
                hashMap.put(col[i], val[i]);
            }

            return hashMap;
        }

        return null;
    }

    public static String safeToString(Object value) {
        if (Objects.isNull(value)) {
            return Strings.EMPTY;
        }
        return String.valueOf(value);
    }

    public static String safeToStringSplit(Object value, String character) {
        if (Objects.isNull(value)) {
            return Strings.EMPTY;
        }
        String valueString = String.valueOf(value);
        if (Strings.isEmpty(valueString)) {
            return Strings.EMPTY;
        }
        String[] arrs = valueString.split(",");
        if (null == arrs || Strings.isEmpty(arrs[0])) {
            return Strings.EMPTY;
        }
        return arrs[0];
    }

    public static Integer safeToInteger(Object value) {
        if (Objects.isNull(value)) {
            return 0;
        }
        try {
            return (Integer) value;
        } catch (Exception ex) {
            return 0;
        }
    }

    public static BigDecimal safeToBigDecimal(Object value) {
        if (Objects.isNull(value)) {
            return BigDecimal.ZERO;
        }
        try {
            return (BigDecimal) value;
        } catch (Exception ex) {
            return BigDecimal.ZERO;
        }
    }

    public static BigDecimal safeToInteger(String value) {
        if (Objects.isNull(value)) {
            return BigDecimal.ZERO;
        }
        try {
            return new BigDecimal(value);
        } catch (Exception ex) {
            return BigDecimal.ZERO;
        }
    }

    public static String toUpper(String value) {

        if (Strings.isEmpty(value)) {
            return value;
        }

        return value.toUpperCase();
    }

    public static List<String> toUpper(List<String> values) {

        if (CollectionUtils.isEmpty(values)) {
            return values;
        }

        return values.stream().filter(Objects::nonNull).map(String::toUpperCase).collect(Collectors.toList());
    }

    public static byte[] zipObject(Object object) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            GZIPOutputStream gzipOut = new GZIPOutputStream(baos);
            ObjectOutputStream objectOut = new ObjectOutputStream(gzipOut);
            objectOut.writeObject(object);
            objectOut.close();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return baos.toByteArray();
    }

}
