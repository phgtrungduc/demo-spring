package vn.com.vpbanks.flex.query.application.utils.enums;

public enum FilterCustomerType {
    ALL("ALL", "Tất cả"),
    DIRECT("1", "Trực tiếp"),
    INDIRECT("2", "Gián tiếp"),
    ;

    private String code;

    private String text;

    FilterCustomerType(String code, String text) {
        this.code = code;
        this.text = text;
    }

    public String getcode() {
        return this.code;
    }
}
