package vn.com.vpbanks.flex.query.application.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class FlexErrorResponse implements Serializable {
    @JsonProperty("s")
    private String statusCode;

    @JsonProperty("errcode")
    private String errorCode;

    @JsonProperty("errmsg")
    private String errorMessage;
}
