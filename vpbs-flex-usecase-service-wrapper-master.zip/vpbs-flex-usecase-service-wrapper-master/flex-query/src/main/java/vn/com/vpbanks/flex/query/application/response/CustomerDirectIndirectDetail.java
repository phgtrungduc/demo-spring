package vn.com.vpbanks.flex.query.application.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDirectIndirectDetail implements Serializable {

    @JsonProperty("accountNo")
    private String accountNo;

    @JsonProperty("reCustodyCd")
    private String reCustodyCd;

    @JsonProperty("reFullName")
    private String reFullName;

    @JsonProperty("reUserId")
    private String reUserId;

}
