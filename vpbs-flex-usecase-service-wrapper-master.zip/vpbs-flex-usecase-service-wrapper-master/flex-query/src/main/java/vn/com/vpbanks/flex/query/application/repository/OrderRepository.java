package vn.com.vpbanks.flex.query.application.repository;

import vn.com.vpbanks.flex.query.application.request.StockOrderFilter;
import vn.com.vpbanks.flex.query.application.response.StockFilterResponseDTO;
import vn.com.vpbanks.flex.query.application.response.StockOrderDetailResponse;

import java.util.List;

public interface OrderRepository {


    List<StockFilterResponseDTO> orderBooks(StockOrderFilter stockOrderFilter);
    List<StockOrderDetailResponse> orderBook(String orderId, String custodyCd);

    List<StockFilterResponseDTO> orderBookMobiles(StockOrderFilter stockOrderFilter);
    List<StockFilterResponseDTO> histOrderBookMobiles(StockOrderFilter stockOrderFilter);
    List<StockFilterResponseDTO> allOrderBookMobiles(StockOrderFilter stockOrderFilter);
    List<StockFilterResponseDTO> confirmOrderBookMobiles(StockOrderFilter stockOrderFilter);
    List<StockFilterResponseDTO> confirmHistOrderBookMobiles(StockOrderFilter stockOrderFilter);
    List<StockFilterResponseDTO> confirmAllOrderBookMobiles(StockOrderFilter stockOrderFilter);
}
