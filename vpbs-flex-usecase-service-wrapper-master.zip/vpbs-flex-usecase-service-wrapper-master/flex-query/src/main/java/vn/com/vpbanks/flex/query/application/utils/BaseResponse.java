package vn.com.vpbanks.flex.query.application.utils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BaseResponse<T> {

    @JsonProperty("status")
    private String status;

    @JsonProperty("code")
    private String code;

    @JsonProperty("message")
    private String message;

    @JsonProperty("internalMessage")
    private String internalMessage;

    @JsonProperty("data")
    private T data;


    public static <T> BaseResponse<T> ofSucceeded(T data) {
        BaseResponse<T> response = new BaseResponse<>();
        response.setData(data);
        response.setCode(BaseRest.RESPONSE.OK_CODE);
        response.setStatus(BaseRest.RESPONSE.SUCCESS);
        return response;
    }

    public static <T> BaseResponse<T> ofSucceeded() {
        BaseResponse<T> response = new BaseResponse<>();
        response.setCode(BaseRest.RESPONSE.OK_CODE);
        response.setStatus(BaseRest.RESPONSE.SUCCESS);
        return response;
    }

    public static <T> BaseResponse<T> ofFailed(String message) {
        BaseResponse<T> response = new BaseResponse<>();
        response.code = BaseRest.RESPONSE.FAIL;
        response.message = message;
        return response;
    }
//    public static BaseResponse<Void> ofFailed(String message) {
//        BaseResponse<Void> response = new BaseResponse<>();
//        response.code = BaseRest.RESPONSE.FALL;
//        response.message = message;
//        return response;
//    }

    public static BaseResponse<Void> ofFailed(Exception error) {

        return ofFailed(error, "Internal server error");
    }

    public static BaseResponse<Void> ofFailed(Exception error, String message) {

        BaseResponse<Void> response = new BaseResponse<>();
        response.setCode(BaseRest.RESPONSE.INTERNAL_ERROR_CODE);
        response.setStatus(BaseRest.RESPONSE.FAIL);
        response.setMessage(message);
        response.setInternalMessage(error.getMessage().toString());
        return response;
    }
}
