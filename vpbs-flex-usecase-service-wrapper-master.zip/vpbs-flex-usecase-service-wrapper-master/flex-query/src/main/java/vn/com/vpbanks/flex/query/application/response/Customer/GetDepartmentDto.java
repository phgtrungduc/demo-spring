package vn.com.vpbanks.flex.query.application.response.Customer;

import lombok.Data;

import java.util.List;

@Data
public class GetDepartmentDto {
    private Long totalOfRecord;
    private List<DepartmentDto> listData;
}
