package vn.com.vpbanks.flex.query.application.utils.enums;

import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public enum SubAccount {
    NORMAL,
    MARGIN;

    public static List<String> toStringDot(List<SubAccount> subAccounts) {
        List<String> output = new ArrayList<>();
        if (CollectionUtils.isEmpty(subAccounts)) {
            return output;
        }

        return subAccounts.stream()
                .filter(Objects::nonNull)
                .map(value ->{
                    return "."+value.name();
                })
                .collect(Collectors.toList());
    }
}
