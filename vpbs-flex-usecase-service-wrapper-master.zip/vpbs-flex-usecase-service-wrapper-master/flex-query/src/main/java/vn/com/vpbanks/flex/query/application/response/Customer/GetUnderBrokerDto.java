package vn.com.vpbanks.flex.query.application.response.Customer;

import lombok.Data;

import java.util.List;

@Data
public class GetUnderBrokerDto {
    private Long totalOfRecord;
    private List<UnderBrokerDto> listData;
}
