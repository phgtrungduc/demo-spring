package vn.com.vpbanks.flex.query.application.response.Customer;

import lombok.Data;

@Data
public class UnderBrokerDto {
    private String custodyCd;
    private String fullName;
    private String uRank;
    private String mobile;
    private String custId;
    private String dept;
}
