package vn.com.vpbanks.flex.query.application.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import vn.com.vpbanks.flex.query.application.request.CustomerDirectIndirectIn;
import vn.com.vpbanks.flex.query.application.request.CustomerOfBrokerRequest;
import vn.com.vpbanks.flex.query.application.response.BaseResponse;
import vn.com.vpbanks.flex.query.application.service.CustomerService;

import vn.com.vpbanks.flex.query.application.utils.BaseUrl;

import java.util.Arrays;
import java.util.stream.Collectors;

@Slf4j
@RestController
@RequestMapping(BaseUrl.FLEX_USECASE_SERVICE.V1 + "/")
@RequiredArgsConstructor
public class CustomerController {

    private final CustomerService customerService;

    @PostMapping("direct-indirect/customers")
    public BaseResponse customers(@RequestBody CustomerDirectIndirectIn customerDirectIndirectIn) {
        return customerService.getCustomersDirectIndirect(customerDirectIndirectIn);
    }

    @PostMapping("order/direct-indirect/customers")
    public BaseResponse OrderCustomerDirectIndirects(@RequestBody CustomerDirectIndirectIn customerDirectIndirectIn) {
        return customerService.getOrderCustomerDirectIndirect(customerDirectIndirectIn);
    }

    @GetMapping("agency/{agencyNo}-{preBrokerNo}/direct-indirect/customers/{accountNo}")
    public BaseResponse customersDetail(@PathVariable String agencyNo, @PathVariable String preBrokerNo, @PathVariable String accountNo) {
        return customerService.getCustomerDirectIndirectDetail(agencyNo, preBrokerNo, accountNo);
    }

    //SAL-2012
    @PostMapping("direct-indirect/brokes/customers")
    public BaseResponse getCustomersByBroker(@RequestBody CustomerOfBrokerRequest customerDirectIndirectIn) {
        return customerService.getCustomersByBroker(customerDirectIndirectIn);
    }

    @GetMapping("/getUnderBroker")
    public BaseResponse getSecuritiesInfo(
            @RequestParam(required = false, name = "custodycd") String custodycd,
            @RequestParam(required = false, name = "searchkey") String searchkey,
            @RequestParam(required = false, name = "dept") String dept,
            @RequestParam(required = false, name = "underCustodycd") String underCustodycd,
            @RequestParam(required = false, name = "getCurren") String getCurren
    ) {
        return customerService.getUnderBroker(custodycd, searchkey, dept, underCustodycd, getCurren);
    }

    @GetMapping("/getDepartment")
    public BaseResponse getDepartment(
            @RequestParam(required = false, name = "custId") String custId,
            @RequestParam(required = false, name = "deptId") String deptId,
            @RequestParam(required = false, name = "deptName") String deptName) {
        return customerService.getDepartment(custId, deptId, deptName);
    }

    @GetMapping("/getCurrentDepartment")
    public BaseResponse getDirectManagement(
            @RequestParam(required = false, name = "reCustodycd") String reCustodycd,
            @RequestParam(required = false, name = "reFullName") String reFullName,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size) {
        return customerService.getCurrentDepartment(
                StringUtils.isEmpty(reCustodycd) ? null : Arrays.stream(reCustodycd.split(",")).collect(Collectors.toList())
                , reFullName
                , page
                , size);
    }
}
