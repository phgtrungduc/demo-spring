package vn.com.vpbanks.flex.query.application.utils;

public interface BaseUrl {
    interface BOND_USECASE_SERVICE {
        String V1 = "/V1";
    }

    interface FLEX_USECASE_SERVICE {
        String V1 = "/V1";
        String V2 = "/V2";
    }
}
