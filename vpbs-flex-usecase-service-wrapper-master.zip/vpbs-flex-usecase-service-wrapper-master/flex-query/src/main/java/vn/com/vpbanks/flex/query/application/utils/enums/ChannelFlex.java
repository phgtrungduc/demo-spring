package vn.com.vpbanks.flex.query.application.utils.enums;

import org.apache.logging.log4j.util.Strings;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public enum ChannelFlex {
    CUSTOMER(List.of("Z", "Y", "M", "O"), "Mobile, Web new", Channel.CUSTOMER),
    BROKER(List.of("H"), "Home Trading", Channel.BROKER),
    COUNTER(List.of("F"), "Counter", Channel.COUNTER);

    private final List<String> values;
    private final String text;

    private final Channel channel;

    ChannelFlex(List<String> values, String text, Channel channel) {
        this.values = values;
        this.text = text;
        this.channel = channel;
    }

    public static List<String> toStrings(List<ChannelFlex> channels) {
        List<String> output = new ArrayList<>();
        if (CollectionUtils.isEmpty(channels)) {
            return output;
        }

        channels.stream()
                .filter(Objects::nonNull)
                .forEach(value -> output.addAll(value.getValues()));
        return output;
    }

    public static String mappingFormFlex(String channel) {
        if (Strings.isEmpty(channel)) {
            return Strings.EMPTY;
        }
        if (CUSTOMER.getValues().contains(channel)) {
            return CUSTOMER.name();
        }
        if (BROKER.getValues().contains(channel)) {
            return BROKER.name();
        }
        if (COUNTER.getValues().contains(channel)) {
            return COUNTER.name();
        }
        return Strings.EMPTY;
    }

    public static Channel mappingChannelFlex(String channel) {
        if (Strings.isEmpty(channel)) {
            return CUSTOMER.channel;
        }
        if (CUSTOMER.getValues().contains(channel)) {
            return CUSTOMER.channel;
        }
        if (BROKER.getValues().contains(channel)) {
            return BROKER.channel;
        }
        if (COUNTER.getValues().contains(channel)) {
            return COUNTER.channel;
        }
        return CUSTOMER.channel;
    }

    public List<String> getValues() {
        return values;
    }
}
