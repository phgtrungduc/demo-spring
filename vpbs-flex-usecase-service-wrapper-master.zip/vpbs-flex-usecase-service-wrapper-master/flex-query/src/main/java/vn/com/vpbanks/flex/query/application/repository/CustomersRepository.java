package vn.com.vpbanks.flex.query.application.repository;

import org.springframework.data.domain.Pageable;
import vn.com.vpbanks.flex.query.application.request.CustomerDirectIndirectIn;
import vn.com.vpbanks.flex.query.application.response.Customer.CurrentDepartmentDto;
import vn.com.vpbanks.flex.query.application.response.Customer.GetDepartmentDto;
import vn.com.vpbanks.flex.query.application.response.Customer.GetUnderBrokerDto;
import vn.com.vpbanks.flex.query.application.response.CustomerByBroker;
import vn.com.vpbanks.flex.query.application.response.CustomerDirectIndirect;
import vn.com.vpbanks.flex.query.application.response.CustomerDirectIndirectDetail;

import java.util.List;

public interface CustomersRepository {

    List<CustomerDirectIndirect> getCustomerDirectIndirect(CustomerDirectIndirectIn customerDirectIndirectIn);

    List<CustomerDirectIndirect> getOrderCustomerDirectIndirect(CustomerDirectIndirectIn customerDirectIndirectIn);

    CustomerDirectIndirectDetail getCustomerDirectIndirectDetail(String agencyNo, String preBrokerNo, String accountNo);

    List<CustomerByBroker> getCustomersByBroker(String customerType, List<String> preCustodyCds, List<String> custodyCds, List<String> listDept, Integer page, Integer size);

    GetUnderBrokerDto getUnderBroker(String custId, String searchkey, List<String> listDept, List<String> listUnderCustodycd, String getCurren);

    GetDepartmentDto getDepartment(String custId, String code, String name);

    List<CurrentDepartmentDto> getCurrentDepartment(List<String> listReCustodycd, String reFullName, Pageable page);


}
