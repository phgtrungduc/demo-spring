package vn.com.vpbanks.flex.query.application.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import vn.com.vpbanks.flex.query.application.utils.enums.ChannelFlex;
import vn.com.vpbanks.flex.query.application.utils.enums.ConfirmStatus;
import vn.com.vpbanks.flex.query.application.utils.enums.Day;
import vn.com.vpbanks.flex.query.application.utils.enums.Order;
import vn.com.vpbanks.flex.query.application.utils.enums.OrderCode;
import vn.com.vpbanks.flex.query.application.utils.enums.StockOrderStatus;
import vn.com.vpbanks.flex.query.application.utils.enums.SubAccount;
import vn.com.vpbanks.flex.query.application.utils.enums.Timeline;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StockOrderFilter {

    //order book
    private String sortType;
    private StockOrderStatus status;
    private List<String> customerAccountNumbers; //cus
    private List<String> stockSymbols;
    private String symbol;
    private List<SubAccount> subAccounts;
    private List<Order> orderSides;
    private List<OrderCode> orderCodes;
    private List<Timeline> timelines;
    private String startDate;
    private String endDate;
    private String toDate;
    private List<ChannelFlex> channels;
    private String customerAccountNumber;
    private ConfirmStatus confirmStatus;
    private List<String> flexStatus;
    private Day day;
    private Integer page;
    private Integer size;

    //customer
    private String accountNo;
    private String account;
    private List<String> dept;
    private List<String> reCustodyCd;

}
