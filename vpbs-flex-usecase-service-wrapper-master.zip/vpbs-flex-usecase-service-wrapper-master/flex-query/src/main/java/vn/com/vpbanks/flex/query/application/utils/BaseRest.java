package vn.com.vpbanks.flex.query.application.utils;

public interface BaseRest {
    interface RESPONSE {
        String SUCCESS = "1";
        String FAIL = "0";
        String OK_CODE = "FCBINF200";
        String INTERNAL_ERROR_CODE = "200";
    }

    interface AUTHEN {
        String BEARER_TOKEN = "Bearer ";
        String AUTHORIZATION = "Authorization";

    }

    interface FLEX_RESPONSE {
        Integer STATUS_CODE_SUCCESS = 1;
        Integer STATUS_CODE_ERROR = 0;
    }

    interface ERROR_CODE {
        String NO_RESULT = "001";
        String EXCEPTION = "002";
        String ERR400 = "FCBERR400";
        String ERR404 = "FCBERR404";

        String ERR500 = "FCBERR500";
    }

    interface SUCCESS {
        String SUCCESS = "Thành công";
    }

    interface ERROR_MESSAGE {
        String NO_RESULT = "NO_RESULT";
        String EXCEPTION = "EXCEPTION";
        String BAD_REQUEST = "Yêu cầu bị từ chối";
        String NOT_FOUND = "Không tìm thấy";

        String INTERNAL_SERVER_ERROR = "Lỗi hệ thống";
        String INPUT_NO_VALIT = "Symbol không được để trống vui lòng kiểm tra lại" ;
        String INPUT_FROMDATE = "fromDate không được để trống vui lòng kiểm tra lại" ;

        String INPUT_TODATE = "toDate không được để trống vui lòng kiểm tra lại" ;

        String INPUT_ACCOUNTID = "accountId không được để trống vui lòng kiểm tra lại" ;

        String VALIDATE_FROMDATE = "nhập sai định dạng fromDate";

        String VALIDATE_TODATE = "nhập sai định dạng toDate";

        String VALID_AMOUNT = "amount là số nguyên vui lòng nhập lại";

        String CHECKFROMDATE = "Yêu cầu fromDate < toDate";

        String SYMBOL = "Mã CK không tồn tại hoặc KH không sở hữu";
    }

    interface ERROR_MESSAGE_DETAIL {
        String FLEX_INIT_TRANSACTION = "[FlexClient] initVerifyTransaction function: ";
        String FLEX_ORDER_CONFIRM = "[FlexClient] orderConfirm function: ";
        String FLEX_ORDER_PRE_CHECK = "[FlexClient] orderPreCheck function: ";
        String FLEX_ORDER_SAVE = "[FlexClient] saveOrder function: ";
        String FLEX_ORDER_CONDITION_SAVE = "[FlexClient] saveOrderCondition function: ";
        String FLEX_ORDER_UPDATE = "[FlexClient] updateOrder function: ";
        String FLEX_ORDER_CONFIRM_PRE_CHECK = "[FlexClient] preCheckOrderConfirm function: ";

        /*FLEX REPORT*/
        String FLEX_REPORT_CASHSTATEMENT_HIST = "[FlexClient] reportCashStatementHist function: ";
        String FLEX_REPORT_ORDERMATCH = "[FlexClient] reportOrderMatch function: ";
        String FLEX_REPORT_CONDITION_ORDERLIST = "[FlexClient] conditionOrderList function: ";
        String FLEX_REPORT_AGREEMENT_ORDER = "[FlexClient] agreementOrder function: ";
        String FLEX_REPORT_SECURITIES_STATEMENT = "[FlexClient] securitiesStatement function: ";
        String FLEX_REPORT_SECURITIES_OVERTIME = "[FlexClient] securitiesOverTime function: ";
        String FLEX_REPORT_NPLCASH = "[FlexClient] nplCash function: ";
        String FLEX_REPORT_NPLDEBIT = "[FlexClient] nplDebit function: ";
        String FLEX_REPORT_NPLSE = "[FlexClient] nplSe function: ";
        String FLEX_REPORT_NPLSECURITIES_CHANGE = "[FlexClient] nplSecuritiesChange function: ";
        String FLEX_REPORT_NPLCASH_CHANGE = "[FlexClient] nplCashChange function: ";
        String FLEX_REPORT_REPAYMENT_HIST = "[FlexClient] repaymentHist function: ";
        String FLEX_REPORT_CONFIRM_ORDERS_INFOR = "[FlexClient] confirmOrdersInfor function: ";
        String FLEX_REPORT_CONFIRM_ORDERS = "[FlexClient] confirmOrders function: ";
        String FLEX_REPORT_RIGHT_INFO = "[FlexClient] rightInfo function: ";
        String FLEX_REPORT_RIGHTOFF_STATEMENT = "[FlexClient] rightOffStatement function: ";
        String FLEX_REPORT_SELL_ODDLOT_HIST = "[FlexClient] sellOddlotHist function: ";
        String FLEX_REPORT_ADVANCED_STATEMENT = "[FlexClient] advancedStatement function: ";
        String FLEX_REPORT_ACCOUNT_SET_TRANSFER = "[FlexClient] accountSetTransfer function: ";
        String FLEX_REPORT_ACCOUNT_DEPOSIT_HISTORY = "[FlexClient] depositHistory function: ";
        String FLEX_REPORT_CASH_TRANSFER = "[FlexClient] cashTransfer function: ";
        String FLEX_REPORT_INFO_CHANGELOG = "[FlexClient] infoChangeLog function: ";
        String FLEX_REPORT_CUST_INFOR_REMISER = "[FlexClient] custInforRemiser function: ";

        /* FLEX INQUIRY*/
        String FLEX_REPORT_AFACCTNOINFOR = "[FlexClient] afAccTnoInFor function: ";
        String FLEX_INQUIRY_ACCOUNT_SECURITIES_PORTFOLIO = "[FlexClient] securitiesPortfolio function: ";

        String FLEX_INQUIRY_ORDER = "[FlexClient] inquiryOrder function: ";

        /*FLEX USER DATA */
        String FLEX_USER_DATA_WATCH_LIST = "[FlexClient] getWatchList function : ";
        String FLEX_USER_DATA_CREATE_WATCH_LIST = "[FlexClient] createWatchList function : ";
        String FLEX_USER_DATA_UPDATE_WATCH_LIST = "[FlexClient] updateWatchList function : ";
        String FLEX_USER_DATA_EKYC_REG_OPEN_ACCOUNT = "[FlexClient] regOpenAccount function : ";
        String FLEX_USER_DATA_EKYC_CHECK_OPEN_ACCOUNT = "[FlexClient] checkOpenAccount function : ";
        String FLEX_USER_DATA_EKYC_ADD_REGISTER = "[FlexClient] addRegister function : ";
        String FLEX_USER_DATA_EKYC_OPEN_ACCOUNT = "[FlexClient] openAccount function : ";
        String FLEX_USER_DATA_EKYC_CHECK_EKYC_AI = "[FlexClient] checkEkyc function : ";
        String FLEX_USER_DATA_EKYC_ID_ATTACH = "[FlexClient] attachIdentification function : ";
        String FLEX_USER_DATA_EKYC_CHECK_EXIST_ACCOUNT = "[FlexClient] checkExistAccount function : ";
        String FLEX_USER_DATA_EKYC_LIST_BRANCH = "[FlexClient] listBranch function : ";
        String FLEX_USER_DATA_EKYC_LIST_COUNTRY = "[FlexClient] listCountry function : ";
    }

}
