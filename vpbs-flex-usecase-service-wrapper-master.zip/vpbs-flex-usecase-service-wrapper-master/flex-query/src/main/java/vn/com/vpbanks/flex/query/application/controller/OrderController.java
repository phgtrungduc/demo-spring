package vn.com.vpbanks.flex.query.application.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import vn.com.vpbanks.flex.query.application.request.StockOrderFilter;
import vn.com.vpbanks.flex.query.application.response.BaseResponse;
import vn.com.vpbanks.flex.query.application.service.OrderService;
import vn.com.vpbanks.flex.query.application.utils.BaseUrl;

@Slf4j
@RestController
@RequestMapping(BaseUrl.FLEX_USECASE_SERVICE.V1 + "/")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;

    @PostMapping("/orderBook-mobile")
    public BaseResponse orderBooks(@RequestBody StockOrderFilter stockOrderFilter) {
        return orderService.orderBooks(stockOrderFilter);
    }

    @GetMapping("/orderBook-mobile")
    public BaseResponse orderBook(@PathVariable("orderId") String orderId, @PathVariable String custodyCd) {
        return orderService.orderBook(orderId, custodyCd);
    }
}
