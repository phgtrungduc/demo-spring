package vn.com.vpbanks.flex.query.application.utils.enums;

import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public enum Order {
    BUY("Mua"),
    SELL("Bán");

    private final String text;

    Order(String text) {
        this.text = text;
    }

    public static List<String> toStrings(List<Order> orders) {
        List<String> output = new ArrayList<>();
        if (CollectionUtils.isEmpty(orders)) {
            return output;
        }

        return orders.stream()
                .filter(Objects::nonNull)
                .map(Enum::name)
                .collect(Collectors.toList());
    }

    public String getText() {
        return text;
    }
}
