package vn.com.vpbanks.flex.query.application.utils;

import org.apache.logging.log4j.util.Strings;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class DataUtils {
    public static String toString(Object value) {
        if (Objects.isNull(value)) {
            return Strings.EMPTY;
        }
        return String.valueOf(value);
    }

    public static String safeToString(Object value) {
        if (Objects.isNull(value)) {
            return Strings.EMPTY;
        }
        return String.valueOf(value);
    }

    public static String safeToStringNull(Object value) {
        if (Objects.isNull(value)) {
            return null;
        }
        return String.valueOf(value);
    }

    public static BigDecimal safeToBigDecimal(Object value) {
        if (Objects.isNull(value)) {
            return BigDecimal.ZERO;
        }
        return new BigDecimal(value.toString());
    }

    public static Long safeToLong(Object value) {
        if (Objects.isNull(value)) {
            return null;
        }
        String stringToConvert = String.valueOf(value);
        Long convertedLong = Long.parseLong(stringToConvert);
        return convertedLong;
    }

    public static Long toLong(Object value) {
        if (Objects.isNull(value)) {
            return null;
        }
        String stringToConvert = String.valueOf(value);
        Long convertedLong = Long.parseLong(stringToConvert);
        return convertedLong;
    }

    public static List<String> toUpper(List<String> values) {

        if (CollectionUtils.isEmpty(values)) {
            return values;
        }

        return values.stream().filter(Objects::nonNull)
                .map(String::toUpperCase)
                .collect(Collectors.toList());
    }

    public static String toUpper(String value) {

        if (Strings.isEmpty(value)) {
            return value;
        }

        return value.toUpperCase();
    }

    public static Instant safeToInstant(Object value) {
        if (Objects.isNull(value)) {
            return null;
        }
        String stringToConvert = String.valueOf(value);
        LocalDate timeStart = DateTimeUtils.convertStringToLocalDate(stringToConvert);

        return timeStart.atStartOfDay().toInstant(ZoneOffset.UTC);
    }

    public static String safeToStringIndex(Object value, int index) {
        if (Objects.isNull(value)) {
            return Strings.EMPTY;
        }
        String result = String.valueOf(value);
        if (Strings.isEmpty(result)) {
            return result;
        }
        return result.substring(index, result.length());
    }

    public static Integer safeToInteger(String value) {
        if (Strings.isEmpty(value)) {
            return 0;
        }
        try {
            return Integer.valueOf(value);
        } catch (Exception ex) {
            return 0;
        }
    }

    public static Integer safeToInteger(Object value) {
        if (Objects.isNull(value)) {
            return 0;
        }
        try {
            return (Integer) value;
        } catch (Exception ex) {
            return 0;
        }
    }
}
