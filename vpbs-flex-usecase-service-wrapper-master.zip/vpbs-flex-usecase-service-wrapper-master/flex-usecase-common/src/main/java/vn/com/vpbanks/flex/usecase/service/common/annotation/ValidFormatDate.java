package vn.com.vpbanks.flex.usecase.service.common.annotation;

import vn.com.vpbanks.flex.usecase.service.common.validator.DateTimeValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Target({FIELD, ANNOTATION_TYPE, PARAMETER})
@Retention(RUNTIME)
@Documented
@Constraint(validatedBy = DateTimeValidator.class)
public @interface ValidFormatDate {
    String message() default "{validation.invalid_format_date}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String pattern() default "dd/MM/yyyy";
}
