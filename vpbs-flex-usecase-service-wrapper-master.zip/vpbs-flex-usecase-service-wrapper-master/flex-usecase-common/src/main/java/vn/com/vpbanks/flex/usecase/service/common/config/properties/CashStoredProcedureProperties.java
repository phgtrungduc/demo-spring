package vn.com.vpbanks.flex.usecase.service.common.config.properties;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
@Setter
@ConfigurationProperties(prefix = "vpbanks.flex.sp")
public class CashStoredProcedureProperties {
    private String SP_GET_HOLD_BALANCE;
    private String SP_GET_HOLD_STOCK;
    private String SP_GET_UN_HOLD_EOD;
    private String SP_HOLD_BALANCE;
    private String SP_UN_HOLD_BALANCE;
    private String SP_HOLD_STOCK;
    private String SP_UN_HOLD_STOCK;
}
