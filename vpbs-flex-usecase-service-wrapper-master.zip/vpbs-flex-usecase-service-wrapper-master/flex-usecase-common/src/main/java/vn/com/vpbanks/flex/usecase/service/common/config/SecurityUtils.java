package vn.com.vpbanks.flex.usecase.service.common.config;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Base64;
import java.util.HashSet;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/**
 * Utility class for Spring Security.
 */
@Component
public final class SecurityUtils {

    private static final String PREFERRED_USERNAME = "preferred_username";
    private static final String ACCOUNT_NO = "account_no";
    private static final String REALM_ACCESS = "realm_access";
    private static final String ROLES = "roles";
    private static final String AUTHORIZATION = "Authorization";
    private static final String BEARER = "Bearer ";
    private static final String EMPTY = "";

    // Roles
    public static final String ROLE_RM = "RM";
    public static final String ROLE_MG = "MG";

    private SecurityUtils() {
    }

    /**
     * Get the login of the current user.
     *
     * @return the login of the current user.
     */
    public static Optional<String> getCurrentUserLogin() {
        String accessToken = getAccessTokenFromRequest();
        Optional<JsonObject> payLoadOptional = extractPayloadToken(accessToken);
        if (payLoadOptional.isEmpty()) {
            return Optional.empty();
        }
        JsonObject payLoad = payLoadOptional.get();
        JsonElement eAccount_no = payLoad.get(ACCOUNT_NO);
        if (eAccount_no == null)
            return Optional.empty();

        String account_no = eAccount_no.getAsString();
        return Optional.ofNullable(account_no.toUpperCase());
    }

    public static Optional<String> getCurrentUserLogin(String keyHeader) {
        String accessToken = getAccessTokenFromRequest();
        Optional<JsonObject> payLoadOptional = extractPayloadToken(accessToken);
        if (payLoadOptional.isEmpty()) {
            return Optional.empty();
        }
        JsonObject payLoad = payLoadOptional.get();
        return Optional.ofNullable(payLoad.get(keyHeader).getAsString().toUpperCase());
    }

    public static String currentUserLogin() {

        Optional<String> userLogin = getCurrentUserLogin();
        if (userLogin.isEmpty()) {
            return Strings.EMPTY;
        }

        return userLogin.get();
    }

    public static String currentUserLogin(String keyHeader) {

        Optional<String> userLogin = getCurrentUserLogin(keyHeader);
        if (userLogin.isEmpty()) {
            return Strings.EMPTY;
        }

        return userLogin.get();
    }

    /**
     * Check role
     */
    public static boolean hasRole(String roleName) {
        return hasRoles(roleName);
    }

    public static boolean hasRoles(String... roleNames) {
        String accessToken = getAccessTokenFromRequest();
        return verifyRoleUser(accessToken, roleNames);
    }

    public static boolean verifyRoleUser(String accessToken, String... roleNames) {
        Optional<JsonObject> payLoadOptional = extractPayloadToken(accessToken);
        if (payLoadOptional.isEmpty()) {
            return false;
        }
        JsonObject payLoad = payLoadOptional.get();
        JsonObject realmAccessObject = payLoad.get(REALM_ACCESS).getAsJsonObject();
        JsonArray roles = realmAccessObject.get(ROLES).getAsJsonArray();
        Set<String> roleSet = getAuthoritySet(roles);
        for (String roleName : roleNames) {
            if (roleSet.contains(roleName)) {
                return true;
            }
        }
        return false;
    }

    private static Set<String> getAuthoritySet(JsonArray roles) {
        Set<String> set = new HashSet<>();
        if (Objects.nonNull(roles)) {
            for (JsonElement roleElement : roles) {
                set.add(roleElement.getAsString());
            }
        }
        return set;
    }

    public static Optional<JsonObject> extractPayloadToken(String accessToken) {
        try {
            if (accessToken == null || accessToken.trim().isEmpty()) {
                return Optional.empty();
            }
            String[] parts = accessToken.split("\\.");
            if (parts.length < 1) {
                return Optional.empty();
            }

            String body = new String(Base64.getDecoder().decode(parts[1]));
            Gson gson = new Gson();
            JsonObject payLoad = gson.fromJson(body, JsonObject.class);
            return Optional.ofNullable(payLoad);

        } catch (Exception e) {
            return Optional.empty();
        }
    }

    public static String getAccessTokenFromRequest() {
        try {
            HttpServletRequest request = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getRequest();
            String bearerToken = request.getHeader(AUTHORIZATION);
            if (StringUtils.hasText(bearerToken) && bearerToken.startsWith(BEARER)) {
                return bearerToken.substring(7);
            }
        } catch (Exception e) {
            return EMPTY;
        }
        return null;
    }
}
