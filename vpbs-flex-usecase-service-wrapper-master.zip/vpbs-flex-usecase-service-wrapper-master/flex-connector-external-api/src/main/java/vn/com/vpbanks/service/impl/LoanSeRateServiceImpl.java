package vn.com.vpbanks.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import vn.com.vpbanks.dto.common.PageCustom;
import vn.com.vpbanks.dto.common.ResponseFactory;
import vn.com.vpbanks.dto.response.LnSeRateRes;
import vn.com.vpbanks.repository.LoanSecuritiesRateRepository;
import vn.com.vpbanks.repository.vo.LnSeRateDVO;
import vn.com.vpbanks.repository.vo.LndebtlvschmDVO;
import vn.com.vpbanks.repository.vo.SymbolLnSeRateDVO;
import vn.com.vpbanks.service.LoanSeRateService;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static vn.com.vpbanks.constants.BaseConfigConstants.SEARCH_KEY_ALL;

@Service
@RequiredArgsConstructor
public class LoanSeRateServiceImpl implements LoanSeRateService {

    private final ResponseFactory responseFactory;
    private final LoanSecuritiesRateRepository loanSecuritiesRateRepository;

    @Override
    public ResponseEntity<Object> getLnSeRate(String lnSeRateId, Integer pageIndex, Integer pageSize, String productType) {
        List<LnSeRateDVO> lnSeRateDVOS;

        // search all
        if (SEARCH_KEY_ALL.equals(lnSeRateId)) {
            pageIndex = pageIndex == null ? 0 : pageIndex;
            pageSize = pageSize == null ? 1000000 : pageSize;

            Integer offset = pageIndex * pageSize + 1;
            Integer limit = offset + pageSize - 1;

            lnSeRateDVOS = loanSecuritiesRateRepository.getLnSeRate(lnSeRateId, offset, limit, productType);

            if (CollectionUtils.isEmpty(lnSeRateDVOS)) {
                return responseFactory.success(Collections.emptyList());
            }

            List<LnSeRateRes> lnSeRateResList = lnSeRateDVOS.stream()
                    .map(item -> {
                        List<SymbolLnSeRateDVO> symbols = null;
                        if ("DM".equals(productType)) {
                            symbols = loanSecuritiesRateRepository.getSymbolOfLnSeRate(item.getId());
                        }

                        List<LndebtlvschmDVO> lndebtlvschms = null;
                        if ("IR".equals(productType)) {
                            lndebtlvschms = loanSecuritiesRateRepository.getLndebtlvschm(item.getId());
                        }

                        return LnSeRateRes.builder()
                                .id(item.getId())
                                .lnSeRateName(item.getLnSeRateName())
                                .rate1(item.getRate1())
                                .rate2(item.getRate2())
                                .rate3(item.getRate3())
                                .lnLimitMax(item.getLnLimitMax())
                                .lnAfLimit(item.getLnAfLimit())
                                .status(item.getStatus())
                                .expiredDate(item.getExpiredDate())
                                .symbols(symbols)
                                .loanRates(lndebtlvschms)
                                .afType(item.getAfType())
                                .valDay(item.getValDay())
                                .productType(item.getProductType())
                                .calType(item.getCalType())
                                .note(item.getNote())
                                .build();
                    }).collect(Collectors.toList());

            Long totalRecord = lnSeRateDVOS.get(0).getTotalRecord().longValue();
            PageCustom<LnSeRateRes> pageCustom = new PageCustom<>(lnSeRateResList, totalRecord, Long.valueOf(pageSize));
            return responseFactory.success(pageCustom);
        }

        // search by ID
        lnSeRateDVOS = loanSecuritiesRateRepository.getLnSeRate(lnSeRateId, 0, 1000000, productType);

        if (CollectionUtils.isEmpty(lnSeRateDVOS)) {
            return responseFactory.success(null);
        }

        LnSeRateDVO lnSeRateDVO = lnSeRateDVOS.get(0);
        LnSeRateRes lnSeRateRes = new LnSeRateRes();
        BeanUtils.copyProperties(lnSeRateDVO, lnSeRateRes);
        if ("DM".equals(productType)) {
            List<SymbolLnSeRateDVO> symbols = loanSecuritiesRateRepository.getSymbolOfLnSeRate(lnSeRateDVO.getId());
            lnSeRateRes.setSymbols(symbols);
        }

        if ("IR".equals(productType)) {
            List<LndebtlvschmDVO> lndebtlvschms = loanSecuritiesRateRepository.getLndebtlvschm(lnSeRateDVO.getId());
            lnSeRateRes.setLoanRates(lndebtlvschms);
        }

        return responseFactory.success(lnSeRateRes);
    }

    @Override
    public ResponseEntity<Object> getLndebtlvschm(String lnId) {
        List<LndebtlvschmDVO> lndebtlvschms = loanSecuritiesRateRepository.getLndebtlvschm(lnId);
        return responseFactory.success(lndebtlvschms);
    }
}
