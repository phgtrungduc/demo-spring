package vn.com.vpbanks.repository.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.procedure.ProcedureOutputs;
import org.springframework.stereotype.Component;
import vn.com.vpbanks.config.properties.StoredProduceProperties;
import vn.com.vpbanks.dto.common.BaseStoredProduceResponse;
import vn.com.vpbanks.dto.request.CancelLnSeRateReq;
import vn.com.vpbanks.dto.request.RegisterLnSeRateReq;
import vn.com.vpbanks.repository.AccountRepository;
import vn.com.vpbanks.repository.vo.LnSeRateAccountDVO;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static vn.com.vpbanks.constants.BaseConfigConstants.SEARCH_KEY_ALL;

@Component
@RequiredArgsConstructor
@Slf4j
public class AccountRepositoryImpl implements AccountRepository {

    private final EntityManager entityManager;
    private final StoredProduceProperties storedProduceProperties;
    private static final String SUCCESS_CODE = "0";

    @Override
    public BaseStoredProduceResponse registerLnSeRate(String accountId, RegisterLnSeRateReq registerLnSeRateReq) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(storedProduceProperties.getSP_REGISTER_LNSERATE());
        query.registerStoredProcedureParameter("p_requestid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_custodycd", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_accountId", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_lnserateid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_via", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_ipaddress", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_prmprotype", String.class, ParameterMode.IN);

        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter("p_err_message", String.class, ParameterMode.OUT);

        query.setParameter("p_requestid", registerLnSeRateReq.getRequestId());
        query.setParameter("p_custodycd", registerLnSeRateReq.getCustodyCd());
        query.setParameter("p_accountId", accountId);
        query.setParameter("p_lnserateid", registerLnSeRateReq.getLnSeRateId());
        query.setParameter("p_via", registerLnSeRateReq.getVia().toUpperCase());
        query.setParameter("p_ipaddress", registerLnSeRateReq.getIpAddress());
        query.setParameter("p_prmprotype", registerLnSeRateReq.getProductType());

        query.execute();

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errMessage = (String) query.getOutputParameterValue("p_err_message");

        BaseStoredProduceResponse baseStoredProduceResponse = new BaseStoredProduceResponse();
        baseStoredProduceResponse.setErrCode(errCode);
        baseStoredProduceResponse.setErrMessage(errMessage);

        return baseStoredProduceResponse;
    }

    @Override
    public BaseStoredProduceResponse cancelLnSeRate(String accountId, CancelLnSeRateReq cancelLnSeRateReq) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(storedProduceProperties.getSP_CANCEL_LNSERATE());
        query.registerStoredProcedureParameter("p_requestid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_custodycd", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_accountId", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_lnserateid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_via", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_ipaddress", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_prmprotype", String.class, ParameterMode.IN);

        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter("p_err_message", String.class, ParameterMode.OUT);

        query.setParameter("p_requestid", cancelLnSeRateReq.getRequestId());
        query.setParameter("p_custodycd", cancelLnSeRateReq.getCustodyCd());
        query.setParameter("p_accountId", accountId);
        query.setParameter("p_lnserateid", cancelLnSeRateReq.getLnSeRateId());
        query.setParameter("p_via", cancelLnSeRateReq.getVia().toUpperCase());
        query.setParameter("p_ipaddress", cancelLnSeRateReq.getIpAddress());
        query.setParameter("p_prmprotype", cancelLnSeRateReq.getProductType());

        query.execute();

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errMessage = (String) query.getOutputParameterValue("p_err_message");

        BaseStoredProduceResponse baseStoredProduceResponse = new BaseStoredProduceResponse();
        baseStoredProduceResponse.setErrCode(errCode);
        baseStoredProduceResponse.setErrMessage(errMessage);

        return baseStoredProduceResponse;
    }

    @Override
    public List<LnSeRateAccountDVO> getStatusLnSeRate(String accountNo, String lnSeRateId, Integer limit, Integer offset, String productType) {
        log.debug("getStatusLnSeRate sp {}", storedProduceProperties.getSP_GET_STATUS_LNSERATE());
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(storedProduceProperties.getSP_GET_STATUS_LNSERATE());
        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_acctno", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_lnserateid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_offset", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_limit", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_prmprotype", String.class, ParameterMode.IN);

        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.OUT);

        query.setParameter("p_acctno", accountNo);
        query.setParameter("p_lnserateid", lnSeRateId);
        query.setParameter("p_offset", offset);
        query.setParameter("p_limit", limit);
        query.setParameter("p_prmprotype", productType);


        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errMessage = (String) query.getOutputParameterValue("p_err_param");

        try {
            if (SUCCESS_CODE.equals(errCode)) {
                List<Object[]> objects = query.getResultList();
                if (SEARCH_KEY_ALL.equals(lnSeRateId)) {
                    switch (productType) {
                        case "DM": {
                            return objects.stream()
                                    .map(item ->
                                            LnSeRateAccountDVO.builder()
                                                    .id((String) item[0])
                                                    .lnSeRateName((String) item[1])
                                                    .rate1((BigDecimal) item[2])
                                                    .rate2((BigDecimal) item[3])
                                                    .rate3((BigDecimal) item[4])
                                                    .lnLimitMax((BigDecimal) item[5])
                                                    .lnAfLimit((BigDecimal) item[6])
                                                    .via((String) item[7])
                                                    .status((String) item[8])
                                                    .effectiveDate((Timestamp) item[9])
                                                    .expiredDate((Timestamp) item[10])
                                                    .accUserStatus((BigDecimal) item[11])
                                                    .rowNum((BigDecimal) item[12])
                                                    .totalRecord((BigDecimal) item[13])
                                                    .build()
                                    ).collect(Collectors.toList());
                        }
                        case "TN": {
                            return objects.stream()
                                    .map(item ->
                                            LnSeRateAccountDVO.builder()
                                                    .id((String) item[0])
                                                    .lnSeRateName((String) item[1])
                                                    .calType((String) item[2])
                                                    .valDay((BigDecimal) item[3])
                                                    .tnLimitMax((BigDecimal) item[4])
                                                    .status((String) item[5])
                                                    .effectiveDate((Timestamp) item[6])
                                                    .expiredDate((Timestamp) item[7])
                                                    .accUserStatus((BigDecimal) item[8])
                                                    .rowNum((BigDecimal) item[9])
                                                    .totalRecord((BigDecimal) item[10])
                                                    .build()
                                    ).collect(Collectors.toList());
                        }
                        case "IR": {
                            return objects.stream()
                                    .map(item ->
                                            LnSeRateAccountDVO.builder()
                                                    .id((String) item[0])
                                                    .lnSeRateName((String) item[1])
                                                    .valDay((BigDecimal) item[2])
                                                    .status((String) item[3])
                                                    .effectiveDate((Timestamp) item[4])
                                                    .expiredDate((Timestamp) item[5])
                                                    .accUserStatus((BigDecimal) item[6])
                                                    .rowNum((BigDecimal) item[7])
                                                    .totalRecord((BigDecimal) item[8])
                                                    .build()
                                    ).collect(Collectors.toList());
                        }
                        default: {
                            log.error("wrong productType :{} ", productType);
                            return null;
                        }
                    }
                } else {
                    switch (productType) {
                        case "DM": {
                            return objects.stream()
                                    .map(item ->
                                            LnSeRateAccountDVO.builder()
                                                    .id((String) item[0])
                                                    .lnSeRateName((String) item[1])
                                                    .rate1((BigDecimal) item[2])
                                                    .rate2((BigDecimal) item[3])
                                                    .rate3((BigDecimal) item[4])
                                                    .lnLimitMax((BigDecimal) item[5])
                                                    .lnAfLimit((BigDecimal) item[6])
                                                    .via((String) item[7])
                                                    .status((String) item[8])
                                                    .effectiveDate((Timestamp) item[9])
                                                    .expiredDate((Timestamp) item[10])
                                                    .accUserStatus((BigDecimal) item[11])
                                                    .build()
                                    ).collect(Collectors.toList());
                        }
                        case "TN": {
                            return objects.stream()
                                    .map(item ->
                                            LnSeRateAccountDVO.builder()
                                                    .id((String) item[0])
                                                    .lnSeRateName((String) item[1])
                                                    .calType((String) item[2])
                                                    .valDay((BigDecimal) item[3])
                                                    .tnLimitMax((BigDecimal) item[4])
                                                    .status((String) item[5])
                                                    .effectiveDate((Timestamp) item[6])
                                                    .expiredDate((Timestamp) item[7])
                                                    .accUserStatus((BigDecimal) item[8])
                                                    .build()
                                    ).collect(Collectors.toList());
                        }
                        case "IR": {
                            return objects.stream()
                                    .map(item ->
                                            LnSeRateAccountDVO.builder()
                                                    .id((String) item[0])
                                                    .lnSeRateName((String) item[1])
                                                    .valDay((BigDecimal) item[2])
                                                    .status((String) item[3])
                                                    .effectiveDate((Timestamp) item[4])
                                                    .expiredDate((Timestamp) item[5])
                                                    .accUserStatus((BigDecimal) item[6])
                                                    .build()
                                    ).collect(Collectors.toList());
                        }
                        default: {
                            log.error("wrong productType :{} ", productType);
                            return Collections.emptyList();
                        }
                    }
                }
            } else {
                log.error("getStatusLnSeRate call with error : {} , message {} ", errCode, errMessage);
                return Collections.emptyList();
            }

        } catch (Exception ex) {
            log.error("getStatusLnSeRate got exception : {} ", ex.getMessage());
            return Collections.emptyList();
        }finally {
            query.unwrap(ProcedureOutputs.class).release();
        }
    }
}
