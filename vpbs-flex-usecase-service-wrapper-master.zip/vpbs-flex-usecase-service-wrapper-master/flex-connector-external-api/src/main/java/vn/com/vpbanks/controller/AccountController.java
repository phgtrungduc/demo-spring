package vn.com.vpbanks.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.com.vpbanks.constants.UrlConstants;
import vn.com.vpbanks.dto.request.CancelLnSeRateReq;
import vn.com.vpbanks.dto.request.RegisterLnSeRateReq;
import vn.com.vpbanks.service.AccountService;

import javax.validation.Valid;

import static vn.com.vpbanks.constants.BaseConfigConstants.SEARCH_KEY_ALL;

@RequiredArgsConstructor
@RestController
@RequestMapping(UrlConstants.V1_BASIC_EXTERNAL_URL + UrlConstants.ACCOUNTS)
public class AccountController {

    private final AccountService accountService;

    @PostMapping("{accountId}/lnSeRate")
    public ResponseEntity<Object> registerLnSeRate(@PathVariable String accountId,
                                                   @Valid @RequestBody RegisterLnSeRateReq registerLnSeRateReq) {
        return accountService.registerLnSeRate(accountId, registerLnSeRateReq);
    }

    @PutMapping("{accountId}/lnSeRate")
    public ResponseEntity<Object> cancelLnSeRate(@PathVariable String accountId,
                                                 @Valid @RequestBody CancelLnSeRateReq cancelLnSeRateReq) {
        return accountService.cancelLnSeRate(accountId, cancelLnSeRateReq);
    }

    @GetMapping("{accountNo}/lnSeRate")
    public ResponseEntity<Object> getStatusLnSeRate(@PathVariable String accountNo,
                                                    @RequestParam(defaultValue = SEARCH_KEY_ALL) String lnSeRateId,
                                                    @RequestParam(required = false) Integer pageIndex,
                                                    @RequestParam(required = false) Integer pageSize,
                                                    @RequestParam String productType) {
        return accountService.getStatusLnSeRate(accountNo, lnSeRateId, pageIndex, pageSize, productType);
    }
}
