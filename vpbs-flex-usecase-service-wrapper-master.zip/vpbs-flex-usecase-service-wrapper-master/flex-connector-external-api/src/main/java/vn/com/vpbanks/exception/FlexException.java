package vn.com.vpbanks.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FlexException extends RuntimeException {
    private String code;

    private String message;

    private Object data;

    private Object[] msgArgs;

    public FlexException(String code, String message, Object data, Object[] messageArgs) {
        this.code = code;
        this.message = message;
        this.data = data;
        this.msgArgs = messageArgs;
    }

    public FlexException(String code, Object[] messageArgs) {
        this.code = code;
        this.msgArgs = messageArgs;
    }

    public FlexException(String code, String message) {
        this.code = code;
        this.message = message;
    }


    public FlexException(String code) {
        this.code = code;
    }

    public FlexException(String message, Throwable cause) {
        super(message, cause);
    }

    public FlexException(Throwable cause) {
        super(cause);
    }

    protected FlexException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
