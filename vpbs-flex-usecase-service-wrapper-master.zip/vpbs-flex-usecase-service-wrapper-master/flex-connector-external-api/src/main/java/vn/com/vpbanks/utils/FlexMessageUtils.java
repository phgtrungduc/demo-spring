package vn.com.vpbanks.utils;

import lombok.experimental.UtilityClass;

@UtilityClass
public class FlexMessageUtils {

    public static String getContentMessage(String message) {
        String content = "";
        try {
            content = message.substring(message.indexOf(":") + 1).trim();
        } catch (Exception ex) {
            content = message;
        }
        return content;
    }
}
