package vn.com.vpbanks.repository.vo;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
public class WorkingDayDVO {
    @Id
    @Column(name = "AUTOID")
    private Long autoId;

    @Column(name = "SBDATE")
    private String sbDate;

    @Column(name = "HOLIDAY")
    private String holiday;
}
