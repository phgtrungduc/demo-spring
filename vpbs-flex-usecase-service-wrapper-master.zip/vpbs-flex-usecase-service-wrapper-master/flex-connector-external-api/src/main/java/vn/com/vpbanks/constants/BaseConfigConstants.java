package vn.com.vpbanks.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class BaseConfigConstants {
    public static final int RESPONSE_STATUS_SUCCESS = 1;
    public static final int RESPONSE_STATUS_FAIL = 0;
    public static final String SUCCESS_CD = "0";
    public static final String SEARCH_KEY_ALL = "ALL";
}
