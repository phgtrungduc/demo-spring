package vn.com.vpbanks.utils;

import lombok.RequiredArgsConstructor;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import java.util.Locale;

@Component
@RequiredArgsConstructor
public class MessageUtils {

    private final MessageSource messageSource;


    public String getMessage(String msgCd) {
        return getMessage(msgCd, null, LocaleContextHolder.getLocale());
    }

    public String getMessage(String msgCd, Object[] args, Locale locale) {
        return messageSource.getMessage(msgCd, args, locale);
    }

    public String getMessage(String msgCd, Object[] args) {
        return messageSource.getMessage(msgCd, args, LocaleContextHolder.getLocale());
    }

    public String getMessage(String msgCd, Object[] args, String defaultMessage) {
        return messageSource.getMessage(msgCd, args, defaultMessage, LocaleContextHolder.getLocale());
    }

    public String getMessage(String msgCd, Object[] args, String defaultMessage, Locale locale) {
        return messageSource.getMessage(msgCd, args, defaultMessage, locale);
    }

}
