package vn.com.vpbanks.repository;

import vn.com.vpbanks.dto.common.BaseStoredProduceResponse;
import vn.com.vpbanks.dto.request.CancelLnSeRateReq;
import vn.com.vpbanks.dto.request.RegisterLnSeRateReq;
import vn.com.vpbanks.repository.vo.LnSeRateAccountDVO;

import java.util.List;

public interface AccountRepository {
    BaseStoredProduceResponse registerLnSeRate(String accountId, RegisterLnSeRateReq registerLnSeRateReq);

    BaseStoredProduceResponse cancelLnSeRate(String accountId, CancelLnSeRateReq cancelLnSeRateReq);

    List<LnSeRateAccountDVO> getStatusLnSeRate(String accountNo, String lnSeRateId, Integer limit, Integer offset, String productType);
}
