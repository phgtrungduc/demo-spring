package vn.com.vpbanks.repository;

import vn.com.vpbanks.repository.vo.LnSeRateDVO;
import vn.com.vpbanks.repository.vo.LndebtlvschmDVO;
import vn.com.vpbanks.repository.vo.SymbolLnSeRateDVO;

import java.util.List;

public interface LoanSecuritiesRateRepository {

    List<LnSeRateDVO> getLnSeRate(String lnSeRateId, Integer offset, Integer limit, String productType);

    List<SymbolLnSeRateDVO> getSymbolOfLnSeRate(String lnSeRateId);

    List<LndebtlvschmDVO> getLndebtlvschm(String lnId);
}
