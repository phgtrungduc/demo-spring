package vn.com.vpbanks.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import vn.com.vpbanks.dto.common.BaseStoredProduceResponse;
import vn.com.vpbanks.dto.common.ResponseFactory;
import vn.com.vpbanks.dto.request.RegisterHolderReq;
import vn.com.vpbanks.exception.BizException;
import vn.com.vpbanks.exception.FlexException;
import vn.com.vpbanks.repository.HolderRepository;
import vn.com.vpbanks.repository.vo.HolderInfoDVO;
import vn.com.vpbanks.service.HolderService;
import vn.com.vpbanks.utils.SecurityUtils;

import java.util.List;
import java.util.Optional;

import static vn.com.vpbanks.constants.ErrorConstants.INVALID_CUSTODYCD_ERR_CD;

@RequiredArgsConstructor
@Slf4j
@Service
public class HolderServiceImpl implements HolderService {

    private final HolderRepository holderRepository;
    private final ResponseFactory responseFactory;
    private static final String SUCCESS_CD = "0";

    @Override
    public ResponseEntity<Object> registerHolder(RegisterHolderReq registerHolderReq) {
        Optional<String> custodyCd = SecurityUtils.getCurrentUserLogin();
        if (custodyCd.isEmpty()) {
            log.error("[registerHolder] The bear token don't contain custodyCd. Please check....");
            throw new BizException(INVALID_CUSTODYCD_ERR_CD);
        }
        registerHolderReq.setIpAddress(SecurityUtils.getIPFromRequest(null));
        registerHolderReq.setCustodyCd(custodyCd.get());

        log.info("[registerHolder] registerHolderReq: {}", registerHolderReq);
        BaseStoredProduceResponse storedProduceResponse = holderRepository.registerHolder(registerHolderReq);
        log.debug("[registerHolder] requestId : {}, response :{}", registerHolderReq.getRequestId(), storedProduceResponse);

        if (!SUCCESS_CD.equals(storedProduceResponse.getErrCode())) {
            throw new FlexException(storedProduceResponse.getErrCode(), storedProduceResponse.getErrMessage());
        }
        return responseFactory.success(null);
    }

    @Override
    public ResponseEntity<Object> getHolder(String symbol) {
        Optional<String> custodyCd = SecurityUtils.getCurrentUserLogin();
        if (custodyCd.isEmpty()) {
            log.error("[getHolder] The bear token don't contain custodyCd. Please check....");
            throw new BizException(INVALID_CUSTODYCD_ERR_CD);
        }

        log.info("[getHolder] custodyCd= {},symbol={}", custodyCd.get(), symbol);
        List<HolderInfoDVO> holderInfoDVOS = holderRepository.getHolder(custodyCd.get(), symbol);
        return responseFactory.success(holderInfoDVOS);
    }
}
