package vn.com.vpbanks.dto.common;

import lombok.*;
import org.springframework.data.domain.Page;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PageCustom<T> {

    private Integer totalPage;
    private Long totalItem;
    private List<T> content;

    public PageCustom(Page<T> page) {
        this.totalPage = page.getTotalPages();
        this.totalItem = page.getTotalElements();
        this.content = page.getContent();
    }

    public PageCustom(List<T> lstData, Long totalItem) {
        this.totalItem = totalItem;
        this.content = lstData;
    }

    public PageCustom(List<T> lstData, Long totalItem, Long pageSize) {
        this.totalItem = totalItem;
        this.totalPage = pageSize == 0 ? 1 : (int) Math.ceil((double) totalItem / (double) pageSize);
        this.content = lstData;
    }
}
