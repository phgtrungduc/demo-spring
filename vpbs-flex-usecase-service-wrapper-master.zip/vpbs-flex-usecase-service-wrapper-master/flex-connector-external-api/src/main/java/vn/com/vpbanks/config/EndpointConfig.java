package vn.com.vpbanks.config;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
@ConfigurationProperties(prefix = "endpoint")
@Getter
@Setter
@Configuration
@Slf4j
public class EndpointConfig {

    private DWH dwh;
    private long timeout;

    @Bean(name = "dwhApiClient")
    public WebClient dwhApiClient() {
        log.info("getInvestmentToolApiUrl: {}", dwh.baseUrl);
        return WebClient.builder().baseUrl(dwh.baseUrl)
            .filter(logRequest())
            .exchangeStrategies(ExchangeStrategies.builder().codecs(
                clientCodecConfigurer -> clientCodecConfigurer.defaultCodecs().maxInMemorySize(500000))
                .build())
            .build();
    }

    // This method returns filter function which will log request data
    private static ExchangeFilterFunction logRequest() {
        return ExchangeFilterFunction.ofRequestProcessor(clientRequest -> {
            log.info("Request: {} {}", clientRequest.method(), clientRequest.url());
            return Mono.just(clientRequest);
        });
    }

    @Data
    public static class DWH {
        String baseUrl;
        String spdv;
    }
}
