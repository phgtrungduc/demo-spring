package vn.com.vpbanks.dto.request;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class CancelLnSeRateReq {
    @NotBlank
    private String requestId;
    private String custodyCd;
    private String accountId;

    @NotBlank
    private String lnSeRateId;
    private String ipAddress;

    @NotBlank(message = "{FCERR50002}")
    private String via;

    @NotBlank
    private String productType;
}
