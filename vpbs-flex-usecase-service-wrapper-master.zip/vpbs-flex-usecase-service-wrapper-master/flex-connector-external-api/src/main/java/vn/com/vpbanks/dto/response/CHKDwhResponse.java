package vn.com.vpbanks.dto.response;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class CHKDwhResponse {
    private String status;
    private String message;
    private String code;
    private CHKDwhData data;
}
