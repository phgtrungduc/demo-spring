package vn.com.vpbanks.exception;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.bind.support.WebExchangeBindException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import vn.com.vpbanks.constants.ErrorConstants;
import vn.com.vpbanks.dto.common.ResponseFactory;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static vn.com.vpbanks.constants.ErrorConstants.INVALID_METHOD_ARGUMENT;

@RestControllerAdvice
@RequiredArgsConstructor
@Slf4j
public class GlobalExceptionHandler {

    private final ResponseFactory responseFactory;

    @ExceptionHandler(BizException.class)
    public ResponseEntity<Object> handleApiException(BizException apiException) {
        return responseFactory.failed(apiException.getCode(), apiException.getMsgArgs());
    }

    @ExceptionHandler(FlexException.class)
    public ResponseEntity<Object> handleFlexException(FlexException apiException) {
        return responseFactory.failedFlexResponse(apiException.getCode(), apiException.getMessage());
    }

    @ExceptionHandler
    public ResponseEntity<Object> handleAllException(Exception exception) {
        StringWriter writer = new StringWriter();
        PrintWriter printWriter = new PrintWriter(writer);
        exception.printStackTrace(printWriter);
        printWriter.flush();
        String stackTrace = writer.toString();
        log.error(stackTrace);
        return responseFactory.failed(ErrorConstants.INTERNAL_SERVER_ERROR_CODE);
    }

    @ExceptionHandler({MethodArgumentNotValidException.class, BindException.class})
    public ResponseEntity<Object> handleMethodArgumentNotValidException(BindException exception) {

        this.printStackTrace(exception);
        List<String> fieldErrors = new ArrayList<>();

        Map<String, String> errors = new HashMap<>();
        exception.getBindingResult().getAllErrors().stream().forEach(err -> {
            String fieldName = ((FieldError) err).getField();
            fieldErrors.add(fieldName);
            String errMsg = err.getDefaultMessage();
            errors.put(fieldName, errMsg);
        });

        return responseFactory.failed(INVALID_METHOD_ARGUMENT, new Object[]{fieldErrors.get(0)});
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Object> handleHttpMessageNotReadableException(HttpMessageNotReadableException exception) {
        this.printStackTrace(exception);
        return responseFactory.failed(ErrorConstants.INPUT_INVALID_CODE);
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<Object> handleHttpRequestMethodNotSupportedException(HttpRequestMethodNotSupportedException exception) {
        return responseFactory.failed(ErrorConstants.BAD_REQUEST, exception.getMessage());
    }

    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<Object> handleHttpMediaTypeNotSupportedException(HttpMediaTypeNotSupportedException exception) {
        return responseFactory.failed(ErrorConstants.BAD_REQUEST, exception.getMessage());
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<Object> handleMethodArgumentTypeMismatchException(MethodArgumentTypeMismatchException exception) {
        return responseFactory.failed(ErrorConstants.BAD_REQUEST, exception.getMessage());
    }

    @ExceptionHandler(WebExchangeBindException.class)
    public ResponseEntity<Object> handleWebExchangeBindException(WebExchangeBindException exception) {
        return responseFactory.failed(ErrorConstants.BAD_REQUEST, exception.getMessage());
    }


    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<Object> handleMissingServletRequestParameterException(MissingServletRequestParameterException exception) {

        return responseFactory.failed(ErrorConstants.BAD_REQUEST, exception.getMessage());
    }

    private void printStackTrace(Exception exception) {
        StringWriter writer = new StringWriter();
        PrintWriter printWriter = new PrintWriter(writer);
        exception.printStackTrace(printWriter);
        printWriter.flush();
        String stackTrace = writer.toString();
        log.error(stackTrace);
    }

}
