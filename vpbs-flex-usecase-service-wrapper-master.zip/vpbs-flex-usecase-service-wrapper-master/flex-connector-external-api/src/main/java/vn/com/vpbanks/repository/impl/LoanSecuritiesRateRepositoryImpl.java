package vn.com.vpbanks.repository.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.procedure.ProcedureOutputs;
import org.springframework.stereotype.Component;
import vn.com.vpbanks.config.properties.StoredProduceProperties;
import vn.com.vpbanks.repository.LoanSecuritiesRateRepository;
import vn.com.vpbanks.repository.vo.LnSeRateDVO;
import vn.com.vpbanks.repository.vo.LndebtlvschmDVO;
import vn.com.vpbanks.repository.vo.SymbolLnSeRateDVO;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static vn.com.vpbanks.constants.BaseConfigConstants.SEARCH_KEY_ALL;

@Component
@Slf4j
@RequiredArgsConstructor
public class LoanSecuritiesRateRepositoryImpl implements LoanSecuritiesRateRepository {

    private final EntityManager entityManager;
    private static final String SUCCESS_CODE = "0";

    private final StoredProduceProperties storedProduceProperties;

    @Override
    public List<LnSeRateDVO> getLnSeRate(String lnSeRateId, Integer offset, Integer limit, String productType) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(storedProduceProperties.getSP_GET_LNSERATE());
        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_lnserateid", String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_offset", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_limit", Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter("p_prmprotype", String.class, ParameterMode.IN);

        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.OUT);

        query.setParameter("p_lnserateid", lnSeRateId);
        query.setParameter("p_offset", offset);
        query.setParameter("p_limit", limit);
        query.setParameter("p_prmprotype", productType == null ? "DM" : productType);

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errMessage = (String) query.getOutputParameterValue("p_err_param");

        try {
            if (SUCCESS_CODE.equals(errCode)) {
                List<Object[]> objects = query.getResultList();
                if (SEARCH_KEY_ALL.equals(lnSeRateId)) {
                    return objects.stream()
                            .map(item ->
                                    LnSeRateDVO.builder()
                                            .id((String) item[0])
                                            .lnSeRateName((String) item[1])
                                            .rate1((BigDecimal) item[2])
                                            .rate2((BigDecimal) item[3])
                                            .rate3((BigDecimal) item[4])
                                            .lnLimitMax((BigDecimal) item[5])
                                            .lnAfLimit((BigDecimal) item[6])
                                            .status((String) item[7])
                                            .expiredDate((Timestamp) item[8])
                                            .afType((String) item[9])
                                            .calType((String) item[10])
                                            .valDay((BigDecimal) item[11])
                                            .productType((String) item[12])
                                            .note((String) item[13])
                                            .rowNum((BigDecimal) item[14])
                                            .totalRecord((BigDecimal) item[15])
                                            .build()
                            ).collect(Collectors.toList());

                } else {
                    return objects.stream()
                            .map(item ->
                                    LnSeRateDVO.builder()
                                            .id((String) item[0])
                                            .lnSeRateName((String) item[1])
                                            .rate1((BigDecimal) item[2])
                                            .rate2((BigDecimal) item[3])
                                            .rate3((BigDecimal) item[4])
                                            .lnLimitMax((BigDecimal) item[5])
                                            .lnAfLimit((BigDecimal) item[6])
                                            .status((String) item[7])
                                            .expiredDate((Timestamp) item[8])
                                            .afType((String) item[9])
                                            .calType((String) item[10])
                                            .valDay((BigDecimal) item[11])
                                            .productType((String) item[12])
                                            .note((String) item[13])
                                            .build()
                            ).collect(Collectors.toList());
                }
            }

            log.error("getLnSeRate call with error : {} , message {} ", errCode, errMessage);
            return null;
        } catch (NoResultException noResultException) {
            log.error("getLnSeRate NoResultException : {} ", noResultException.getMessage());
            return null;
        } finally {
            query.unwrap(ProcedureOutputs.class).release();
        }
    }

    public List<SymbolLnSeRateDVO> getSymbolOfLnSeRate(String lnSeRateId) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(storedProduceProperties.getSP_GET_SYMBOL_LNSERATE());
        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_lnserateid", String.class, ParameterMode.IN);

        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.OUT);

        query.setParameter("p_lnserateid", lnSeRateId);

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errMessage = (String) query.getOutputParameterValue("p_err_param");

        try {
            if (SUCCESS_CODE.equals(errCode)) {
                List<Object[]> objects = query.getResultList();
                return objects.stream()
                        .map(item -> SymbolLnSeRateDVO.builder()
                                .id((String) item[0])
                                .codeId((String) item[1])
                                .symbol((String) item[2])
                                .build())
                        .collect(Collectors.toList());
            } else {
                log.error("[getSymbolOfLnSeRate] call with error : {} , message {} ", errCode, errMessage);
            }

        } catch (NoResultException exception) {
            log.info("[getSymbolOfLnSeRate] NoResultException {}", exception.getMessage());
        } finally {
            query.unwrap(ProcedureOutputs.class).release();
        }
        return Collections.emptyList();
    }

    @Override
    public List<LndebtlvschmDVO> getLndebtlvschm(String lnId) {
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery(storedProduceProperties.getSP_GET_Lndebtlvschm());
        query.registerStoredProcedureParameter("pv_refCursor", void.class, ParameterMode.REF_CURSOR);
        query.registerStoredProcedureParameter("p_lnid", String.class, ParameterMode.IN);

        query.registerStoredProcedureParameter("p_err_code", String.class, ParameterMode.OUT);
        query.registerStoredProcedureParameter("p_err_param", String.class, ParameterMode.OUT);

        query.setParameter("p_lnid", lnId);

        String errCode = (String) query.getOutputParameterValue("p_err_code");
        String errMessage = (String) query.getOutputParameterValue("p_err_param");

        try {
            if (SUCCESS_CODE.equals(errCode)) {
                List<Object[]> objects = query.getResultList();
                return objects.stream()
                        .map(item -> LndebtlvschmDVO.builder()
                                .id((String) item[0])
                                .fromAmt((BigDecimal) item[1])
                                .toAmt((BigDecimal) item[2])
                                .rate((BigDecimal) item[3])
                                .build())
                        .collect(Collectors.toList());
            } else {
                log.error("[getLndebtlvschm] call with error : {} , message {} ", errCode, errMessage);
            }

        } catch (NoResultException exception) {
            log.info("[getLndebtlvschm] NoResultException {}", exception.getMessage());
        } finally {
            query.unwrap(ProcedureOutputs.class).release();
        }
        return null;
    }
}
