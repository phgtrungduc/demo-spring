package vn.com.vpbanks.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BizException extends RuntimeException {
    private String code;

    private String message;

    private Object data;

    private Object[] msgArgs;

    public BizException(String code, String message, Object data, Object[] messageArgs) {
        this.code = code;
        this.message = message;
        this.data = data;
        this.msgArgs = messageArgs;
    }

    public BizException(String code, Object[] messageArgs) {
        this.code = code;
        this.msgArgs = messageArgs;
    }

    public BizException(String code, String message) {
        this.code = code;
        this.message = message;
    }


    public BizException(String code) {
        this.code = code;
    }

    public BizException(String message, Throwable cause) {
        super(message, cause);
    }

    public BizException(Throwable cause) {
        super(cause);
    }

    protected BizException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
