package vn.com.vpbanks.repository.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Date;

@Data
@Entity
public class CurrentDateFlexVO {
    @Id
    @Column(name = "current_date")
    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "Asia/Bangkok")
    private Date currentDate;
}