package vn.com.vpbanks.dto.common;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import vn.com.vpbanks.constants.BaseConfigConstants;
import vn.com.vpbanks.constants.ErrorConstants;
import vn.com.vpbanks.exception.BizException;
import vn.com.vpbanks.utils.FlexMessageUtils;
import vn.com.vpbanks.utils.MessageUtils;

import java.time.LocalDateTime;

@Component
@RequiredArgsConstructor
public class ResponseFactory {

    private final MessageUtils messageUtils;

    public ResponseEntity<Object> success(Object data) {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setStatus(BaseConfigConstants.RESPONSE_STATUS_SUCCESS);
        baseResponse.setCode(ErrorConstants.SUCCESS);
        baseResponse.setMessage(messageUtils.getMessage(ErrorConstants.SUCCESS));
        baseResponse.setData(data);
        baseResponse.setTimestamp(LocalDateTime.now());
        return ResponseEntity.ok(baseResponse);
    }

    public ResponseEntity<Object> failed(String errCode, Object[] msgArgs) {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setStatus(BaseConfigConstants.RESPONSE_STATUS_FAIL);
        baseResponse.setCode(errCode);
        String messageError = messageUtils.getMessage(errCode, msgArgs);
        baseResponse.setMessage(messageError);
        baseResponse.setTimestamp(LocalDateTime.now());
        return ResponseEntity.ok(baseResponse);
    }

    public ResponseEntity<Object> failed(String errCode) {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setStatus(BaseConfigConstants.RESPONSE_STATUS_FAIL);
        baseResponse.setCode(errCode);
        baseResponse.setMessage(messageUtils.getMessage(errCode));
        baseResponse.setTimestamp(LocalDateTime.now());
        return ResponseEntity.ok(baseResponse);
    }

    public ResponseEntity<Object> failedFlexResponse(String errCode, String flexErrorMessage) {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setStatus(BaseConfigConstants.RESPONSE_STATUS_FAIL);
        baseResponse.setCode(errCode);
        baseResponse.setTimestamp(LocalDateTime.now());
        try {
            String errorMessage = FlexMessageUtils.getContentMessage(messageUtils.getMessage(errCode));
            baseResponse.setMessage(errorMessage);
            return ResponseEntity.ok(baseResponse);
        } catch (Exception ex) {
            baseResponse.setMessage(FlexMessageUtils.getContentMessage(flexErrorMessage));
            return ResponseEntity.ok(baseResponse);
        }
    }

    public ResponseEntity<Object> failed(String errCode, String errorMessage) {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setStatus(BaseConfigConstants.RESPONSE_STATUS_FAIL);
        baseResponse.setCode(errCode);
        baseResponse.setMessage(errorMessage);
        baseResponse.setTimestamp(LocalDateTime.now());
        return ResponseEntity.ok(baseResponse);
    }

    public ResponseEntity<Object> failed(String code, String message, Object data) {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setStatus(BaseConfigConstants.RESPONSE_STATUS_FAIL);
        baseResponse.setCode(code);
        baseResponse.setMessage(messageUtils.getMessage(code));
        baseResponse.setData(data);
        baseResponse.setTimestamp(LocalDateTime.now());
        return ResponseEntity.ok(baseResponse);
    }

    public ResponseEntity<Object> failed(BizException bizException) {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setStatus(BaseConfigConstants.RESPONSE_STATUS_FAIL);
        baseResponse.setCode(bizException.getCode());
        String messageError = messageUtils.getMessage(bizException.getCode());
        baseResponse.setMessage(messageError);
        baseResponse.setTimestamp(LocalDateTime.now());
        return ResponseEntity.ok(baseResponse);
    }
}
