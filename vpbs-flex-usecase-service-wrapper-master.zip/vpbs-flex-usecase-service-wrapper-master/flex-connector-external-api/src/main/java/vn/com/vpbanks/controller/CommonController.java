
package vn.com.vpbanks.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import vn.com.vpbanks.constants.UrlConstants;
import vn.com.vpbanks.repository.vo.WorkingDayDVO;
import vn.com.vpbanks.service.AccountService;

import javax.validation.Valid;
import java.util.List;

@Slf4j
@RestController
@RequestMapping(UrlConstants.V1_BASIC_EXTERNAL_URL + "/flex")
@RequiredArgsConstructor
@Validated
public class CommonController {

    private final AccountService cccountService;

    @GetMapping("getCurrentDate")
    public ResponseEntity<?> getCurrentDateFlex() {
        return cccountService.getCurrentDateFlex();
    }

    @GetMapping(value = "/getWorkingDay")
    public ResponseEntity get(@RequestParam @Valid String fromDate,
                            @RequestParam @Valid String toDate,
                            @RequestParam(required = false, defaultValue = "ALL") String holiday) {
        return cccountService.getListWorkingDay(fromDate, toDate, holiday);
    }
}