package vn.com.vpbanks.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class RequestIDUtils {

    public static String generateID(String prefix) {
        StringBuilder stringBuilder = new StringBuilder(prefix);
        String uuid = UUID.randomUUID().toString().toUpperCase().replaceAll("-", "");
        return stringBuilder.append(uuid).append(LocalDate.now().format(DateTimeFormatter.ofPattern("YYMMdd"))).toString();
    }
}
