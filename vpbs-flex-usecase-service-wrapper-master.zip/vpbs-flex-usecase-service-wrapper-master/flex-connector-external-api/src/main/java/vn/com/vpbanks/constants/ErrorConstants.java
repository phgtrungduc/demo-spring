package vn.com.vpbanks.constants;

public class ErrorConstants {
    public static final String SUCCESS = "FCINF20000";
    public static final String BAD_REQUEST = "FCERR40000";
    public static final String INPUT_INVALID_CODE = "FCERR40001";
    public static final String INVALID_METHOD_ARGUMENT = "FCERR40002";
    public static String INTERNAL_SERVER_ERROR_CODE = "FCERR50000";
    public static String INVALID_CUSTODYCD_ERR_CD = "FCERR50001";
}
